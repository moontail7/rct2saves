# RestedXP Guides

## [v4.6.54](https://github.com/RestedXP/RXPGuides/tree/v4.6.54) (2024-11-24)
[Full Changelog](https://github.com/RestedXP/RXPGuides/compare/v4.6.53...v4.6.54) [Previous Releases](https://github.com/RestedXP/RXPGuides/releases)

- Fixed issue where some objectives were not properly shown  

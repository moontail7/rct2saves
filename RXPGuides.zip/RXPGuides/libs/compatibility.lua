if not _G.securecallfunction then
    _G.securecallfunction = _G.securecall
end

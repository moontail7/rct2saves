
Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["scrollback"] = {
		["ChatFrame5"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 4,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["serverTime"] = 1709346780,
					["r"] = 1,
					["b"] = 0,
					["timestamp"] = 523198.152,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [1]
				{
					["message"] = "0 days, 0 hours, 0 minutes, 0 seconds",
					["timestamp"] = 523198.152,
				}, -- [2]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 523198.152,
				}, -- [3]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 523180.64,
					["g"] = 1,
					["b"] = 0,
				}, -- [4]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame7"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame6"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame8"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame10"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame9"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 263,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cFFFF1C1C Loaded: LFG Bulletin Board 3.17 by Vyscî-Whitemane",
					["timestamp"] = 523180.64,
				}, -- [1]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Dominos Detected, please make sure Dominos Elements are disabled in MoveAny!",
					["timestamp"] = 523180.64,
				}, -- [2]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Click the MoveAny Minimap Button to open the settings.",
					["timestamp"] = 523180.64,
				}, -- [3]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Or tap /move or /moveany in chat to open the settings.",
					["timestamp"] = 523180.64,
				}, -- [4]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 To hide these messages deactivate tips in the MoveAny menu.",
					["timestamp"] = 523180.64,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:32:53]|h|r Error parsing guide 12-17 The Barrens: Invalid function call (.isQuestTurnIn)\n.isQuestTurnIn 858",
					["timestamp"] = 523180.64,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:32:58]|h|r |cFF00FFB0WeaponSwingTimer: |rThank you for installing WeaponSwingTimer Version 7.2.4 by WatchYourSixx! Use |cFFFFC300/wst|r for more options.",
					["timestamp"] = 523180.64,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:00]|h|r |cffffff99<aux> loaded - /aux",
					["timestamp"] = 523198.152,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:01]|h|r RestedXP Guides: Targeting macro updated with (Warlord Kolkanis)",
					["timestamp"] = 523198.152,
					["serverTime"] = 1709346780,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:01]|h|r |c00FFAA00ThreatClassic2 v2.50 - Type /tc2 for options.|r",
					["timestamp"] = 523198.152,
					["serverTime"] = 1709346780,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:01]|h|r |cffe6cc80 [Whoa Thick Frames |cFF0070FFClassic|r |cffe6cc80v1.5d ] |cffffffffis now loaded. Use |cffffff00'/whoaf' |cffffffffto view options.",
					["timestamp"] = 523198.152,
					["serverTime"] = 1709346780,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:02]|h|r |cFFAAEEFFQuestie DB has updated!|r|cFFFF6F22 Data is being processed, this may take a few moments and cause some lag...",
					["timestamp"] = 523200.022,
					["serverTime"] = 1709346781,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:02]|h|r |cFF4DDBFF [1/9] Loading database...",
					["timestamp"] = 523200.022,
					["serverTime"] = 1709346781,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:03]|h|r |cFF4DDBFF [2/9] Applying database corrections...",
					["timestamp"] = 523200.382,
					["serverTime"] = 1709346782,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:03]|h|r |cFF4DDBFF [3/9] Initializing townfolks...",
					["timestamp"] = 523200.433,
					["serverTime"] = 1709346782,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:04]|h|r |cFFffff00[Questie]|r |cFF6ce314The 'Darkmoon Faire' world event is active!",
					["timestamp"] = 523201.437,
					["serverTime"] = 1709346783,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:04]|h|r |cFF4DDBFF [4/9] Initializing locale...",
					["timestamp"] = 523201.954,
					["serverTime"] = 1709346783,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:04]|h|r |cFF4DDBFF [5/9] Optimizing waypoints...",
					["timestamp"] = 523201.987,
					["serverTime"] = 1709346783,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:04]|h|r RestedXP Guides: TotemTimers has known incompatibilities with the Waypoint Arrow. Disable it if you're experiencing navigation issues.",
					["timestamp"] = 523202.154,
					["serverTime"] = 1709346783,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:04]|h|r |cFF4DDBFF [6/9] Updating NPCs...",
					["timestamp"] = 523202.354,
					["serverTime"] = 1709346783,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:08]|h|r |cFF4DDBFF [7/9] Updating objects...",
					["timestamp"] = 523206.004,
					["serverTime"] = 1709346787,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:10]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|h|HNWBCustomLink:timers|hYou are on a layered realm.|h|h",
					["timestamp"] = 523208.155,
					["serverTime"] = 1709346789,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:10]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|h|HNWBCustomLink:timers|hClick here to view current timers.|h|h",
					["timestamp"] = 523208.155,
					["serverTime"] = 1709346789,
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:10]|h|r |cFF4DDBFF [8/9] Updating quests...",
					["timestamp"] = 523208.337,
					["serverTime"] = 1709346789,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:13]|h|r |cFF4DDBFF [9/9] Updating items...",
					["timestamp"] = 523211.054,
					["serverTime"] = 1709346792,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:15]|h|r |cFFAAEEFFQuestie DB update complete!",
					["timestamp"] = 523213.137,
					["serverTime"] = 1709346794,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:35:04]|h|r You receive loot: |cffffffff|Hitem:5466::::::::8:::::::::|h[Scorpid Stinger]|h|r.",
					["serverTime"] = 1709346903,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523321.821,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:35:49]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Stunchance:29:CHANNEL:1|h|cffffffffStunchance|r|h|cffd8d8d8]|r: anyone here come click the portal for healing rune?",
					["serverTime"] = 1709346948,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523367.054,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:38:56]|h|r Your skill in Daggers has increased to 38.",
					["serverTime"] = 1709347135,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523553.653,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:39:36]|h|r You receive loot: |cffffffff|Hitem:769::::::::8:::::::::|h[Chunk of Boar Meat]|h|r.",
					["serverTime"] = 1709347175,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523594.104,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:40:13]|h|r Your skill in Thrown has increased to 8.",
					["serverTime"] = 1709347212,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523631.269,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:40:31]|h|r You loot 6 Copper",
					["serverTime"] = 1709347230,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523648.586,
					["g"] = 1,
					["b"] = 0,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:41:15]|h|r Kolkar Drudge attempts to run away in fear!",
					["serverTime"] = 1709347274,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523692.502,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:41:17]|h|r You feel normal.",
					["serverTime"] = 1709347276,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523694.835,
					["g"] = 1,
					["b"] = 0,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:41:19]|h|r You loot 1 Copper",
					["serverTime"] = 1709347278,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523696.786,
					["g"] = 1,
					["b"] = 0,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:41:33]|h|r Kolkar Outrunner attempts to run away in fear!",
					["serverTime"] = 1709347292,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523710.553,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:41:37]|h|r You receive loot: |cffffffff|Hitem:2589::::::::8:::::::::|h[Linen Cloth]|h|r.",
					["serverTime"] = 1709347296,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523714.602,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:41:38]|h|r You loot 4 Copper",
					["serverTime"] = 1709347297,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523715.635,
					["g"] = 1,
					["b"] = 0,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:41:46]|h|r Your skill in Thrown has increased to 9.",
					["serverTime"] = 1709347305,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523723.52,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:41:53]|h|r Your skill in Daggers has increased to 39.",
					["serverTime"] = 1709347312,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523730.452,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:42:06]|h|r Kolkar Drudge attempts to run away in fear!",
					["serverTime"] = 1709347325,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523744.32,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:42:10]|h|r You receive loot: |cffffffff|Hitem:2589::::::::8:::::::::|h[Linen Cloth]|h|r.",
					["serverTime"] = 1709347329,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523747.803,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:42:10]|h|r You receive loot: |cffffffff|Hitem:117::::::::8:::::::::|h[Tough Jerky]|h|r.",
					["serverTime"] = 1709347329,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523747.902,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:42:11]|h|r You loot 7 Copper",
					["serverTime"] = 1709347330,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523748.919,
					["g"] = 1,
					["b"] = 0,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:42:18]|h|r Your skill in Thrown has increased to 10.",
					["serverTime"] = 1709347337,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523755.785,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:42:36]|h|r Your skill in Defense has increased to 38.",
					["serverTime"] = 1709347355,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523773.752,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:42:50]|h|r Kolkar Outrunner attempts to run away in fear!",
					["serverTime"] = 1709347369,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523787.635,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:42:54]|h|r You receive loot: |cffffffff|Hitem:159::::::::8:::::::::|h[Refreshing Spring Water]|h|r.",
					["serverTime"] = 1709347373,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523792.068,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [48]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:42:55]|h|r You loot 7 Copper",
					["serverTime"] = 1709347374,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523793.119,
					["g"] = 1,
					["b"] = 0,
				}, -- [49]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:42:59]|h|r Your skill in Thrown has increased to 11.",
					["serverTime"] = 1709347378,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523796.635,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [50]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:43:20]|h|r Kolkar Outrunner attempts to run away in fear!",
					["serverTime"] = 1709347399,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523817.651,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [51]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:44:04]|h|r Kolkar Drudge attempts to run away in fear!",
					["serverTime"] = 1709347443,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523861.402,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [52]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:44:09]|h|r You loot 5 Copper",
					["serverTime"] = 1709347448,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523866.518,
					["g"] = 1,
					["b"] = 0,
				}, -- [53]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:44:12]|h|r You receive loot: |cffffffff|Hitem:2589::::::::8:::::::::|h[Linen Cloth]|h|rx2.",
					["serverTime"] = 1709347451,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523869.67,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [54]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:44:12]|h|r You receive loot: |cffffffff|Hitem:117::::::::8:::::::::|h[Tough Jerky]|h|r.",
					["serverTime"] = 1709347451,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523869.67,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [55]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:44:13]|h|r You loot 4 Copper",
					["serverTime"] = 1709347452,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523870.685,
					["g"] = 1,
					["b"] = 0,
				}, -- [56]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:44:24]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Mysticsharts:149:CHANNEL:1|h|cff3fc6eaMysticsharts|r|h|cffd8d8d8]|r: anyone help with frozen makrura?",
					["serverTime"] = 1709347463,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						3, -- [2]
						14, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523882.035,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [57]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:44:43]|h|r Your skill in Thrown has increased to 12.",
					["serverTime"] = 1709347482,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523900.968,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [58]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:44:55]|h|r Kolkar Drudge attempts to run away in fear!",
					["serverTime"] = 1709347494,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523913.251,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [59]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:45:00]|h|r You loot 11 Copper",
					["serverTime"] = 1709347499,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523917.868,
					["g"] = 1,
					["b"] = 0,
				}, -- [60]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:45:02]|h|r Your skill in Thrown has increased to 13.",
					["serverTime"] = 1709347501,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523920.301,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [61]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:45:19]|h|r You loot 12 Copper",
					["serverTime"] = 1709347518,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523936.967,
					["g"] = 1,
					["b"] = 0,
				}, -- [62]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:45:39]|h|r You receive loot: |cffffffff|Hitem:2589::::::::8:::::::::|h[Linen Cloth]|h|r.",
					["serverTime"] = 1709347538,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523957.251,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [63]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:45:40]|h|r You loot 11 Copper",
					["serverTime"] = 1709347539,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523958.286,
					["g"] = 1,
					["b"] = 0,
				}, -- [64]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:45:59]|h|r Your skill in Thrown has increased to 14.",
					["serverTime"] = 1709347558,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 523976.484,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [65]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:46:32]|h|r You loot 8 Copper",
					["serverTime"] = 1709347591,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524009.717,
					["g"] = 1,
					["b"] = 0,
				}, -- [66]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:46:43]|h|r Your skill in Thrown has increased to 15.",
					["serverTime"] = 1709347602,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524020.701,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [67]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:46:56]|h|r You loot 12 Copper",
					["serverTime"] = 1709347615,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524033.701,
					["g"] = 1,
					["b"] = 0,
				}, -- [68]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:47:08]|h|r RestedXP Guides: Targeting macro updated with (Trayexir)",
					["timestamp"] = 524045.934,
					["serverTime"] = 1709347627,
				}, -- [69]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:47:08]|h|r RestedXP Guides: Targeting macro updated with (Koiter)",
					["timestamp"] = 524045.934,
					["serverTime"] = 1709347627,
				}, -- [70]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:47:08]|h|r RestedXP Guides: Targeting macro updated with (Anara)",
					["timestamp"] = 524045.934,
					["serverTime"] = 1709347627,
				}, -- [71]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:47:08]|h|r RestedXP Guides: Targeting macro updated with (Alithea)",
					["timestamp"] = 524045.934,
					["serverTime"] = 1709347627,
				}, -- [72]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:47:08]|h|r RestedXP Guides: Targeting macro updated with (Spirit Healer)",
					["timestamp"] = 524045.934,
					["serverTime"] = 1709347627,
				}, -- [73]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:47:08]|h|r RestedXP Guides: Targeting macro updated with (Master Vornal)",
					["timestamp"] = 524046.251,
					["serverTime"] = 1709347627,
				}, -- [74]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:47:09]|h|r RestedXP Guides: Targeting macro updated with (Hai'zan)",
					["timestamp"] = 524046.401,
					["serverTime"] = 1709347628,
				}, -- [75]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:47:09]|h|r RestedXP Guides: Targeting macro updated with (Lar Prowltusk)",
					["timestamp"] = 524046.567,
					["serverTime"] = 1709347628,
				}, -- [76]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:48:13]|h|r Kolkar Drudge attempts to run away in fear!",
					["serverTime"] = 1709347693,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524111.251,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [77]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:50:04]|h|r Your Orgrimmar reputation has increased by 100.",
					["serverTime"] = 1709347803,
					["r"] = 0.501960813999176,
					["extraData"] = {
						36, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524222.216,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [78]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:50:04]|h|r Your Darkspear Trolls reputation has increased by 100.",
					["serverTime"] = 1709347803,
					["r"] = 0.501960813999176,
					["extraData"] = {
						36, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524222.216,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [79]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:50:04]|h|r Thwarting Kolkar Aggression completed.",
					["serverTime"] = 1709347803,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524222.249,
					["g"] = 1,
					["b"] = 0,
				}, -- [80]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:50:04]|h|r Experience gained: 1050.",
					["serverTime"] = 1709347803,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524222.249,
					["g"] = 1,
					["b"] = 0,
				}, -- [81]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:50:04]|h|r You receive item: |cffffffff|Hitem:4933::::::::8:::::::::|h[Seasoned Fighter's Cloak]|h|r.",
					["serverTime"] = 1709347803,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524222.266,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [82]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:52:12]|h|r RestedXP Guides: Targeting macro updated with (Lieutenant Benedict)",
					["timestamp"] = 524349.4990000001,
					["serverTime"] = 1709347931,
				}, -- [83]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:52:12]|h|r RestedXP Guides: Targeting macro updated with (Kul Tiras Marine)",
					["timestamp"] = 524349.4990000001,
					["serverTime"] = 1709347931,
				}, -- [84]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:52:12]|h|r RestedXP Guides: Targeting macro updated with (Kul Tiras Sailor)",
					["timestamp"] = 524349.4990000001,
					["serverTime"] = 1709347931,
				}, -- [85]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:52:12]|h|r RestedXP Guides: Targeting macro updated with (Watch Commander Zalaphil)",
					["timestamp"] = 524349.4990000001,
					["serverTime"] = 1709347931,
				}, -- [86]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:52:13]|h|r Discovered Tiragarde Keep: 55 experience gained",
					["serverTime"] = 1709347932,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524350.733,
					["g"] = 1,
					["b"] = 0,
				}, -- [87]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:52:19]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709347938,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524357.317,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [88]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:52:28]|h|r You receive loot: |cffffffff|Hitem:2070::::::::8:::::::::|h[Darnassian Bleu]|h|r.",
					["serverTime"] = 1709347947,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524365.566,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [89]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:52:29]|h|r You loot 4 Copper",
					["serverTime"] = 1709347948,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524366.599,
					["g"] = 1,
					["b"] = 0,
				}, -- [90]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:52:55]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709347974,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524393.3,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [91]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:53:06]|h|r You loot 3 Copper",
					["serverTime"] = 1709347985,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524404.115,
					["g"] = 1,
					["b"] = 0,
				}, -- [92]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:53:19]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709347998,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524417.265,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [93]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:53:27]|h|r Kul Tiras Sailor attempts to run away in fear!",
					["serverTime"] = 1709348007,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524425.0650000001,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [94]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:53:31]|h|r You loot 2 Copper",
					["serverTime"] = 1709348011,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524428.633,
					["g"] = 1,
					["b"] = 0,
				}, -- [95]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:53:41]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709348021,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524439.2,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [96]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:53:48]|h|r Kul Tiras Sailor attempts to run away in fear!",
					["serverTime"] = 1709348028,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524445.616,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [97]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:53:52]|h|r You loot 5 Copper",
					["serverTime"] = 1709348032,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524450.166,
					["g"] = 1,
					["b"] = 0,
				}, -- [98]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:54:02]|h|r Your skill in Defense has increased to 39.",
					["serverTime"] = 1709348042,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524460.166,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [99]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:54:02]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709348042,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524460.349,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [100]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:54:12]|h|r Kul Tiras Sailor attempts to run away in fear!",
					["serverTime"] = 1709348052,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524469.949,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [101]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:54:15]|h|r You loot 6 Copper",
					["serverTime"] = 1709348055,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524473.215,
					["g"] = 1,
					["b"] = 0,
				}, -- [102]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:54:20]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709348060,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524477.848,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [103]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:54:33]|h|r You loot 7 Copper",
					["serverTime"] = 1709348073,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524491.231,
					["g"] = 1,
					["b"] = 0,
				}, -- [104]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:54:43]|h|r Your skill in Thrown has increased to 16.",
					["serverTime"] = 1709348083,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524500.598,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [105]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:54:44]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709348084,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524501.533,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [106]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:54:44]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709348084,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524501.533,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [107]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:11]|h|r Kul Tiras Sailor attempts to run away in fear!",
					["serverTime"] = 1709348110,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524528.698,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [108]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:16]|h|r You loot 1 Copper",
					["serverTime"] = 1709348115,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524533.715,
					["g"] = 1,
					["b"] = 0,
				}, -- [109]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:17]|h|r You receive loot: |cff9d9d9d|Hitem:1367::::::::8:::::::::|h[Ragged Leather Boots]|h|r.",
					["serverTime"] = 1709348116,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524535.082,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [110]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:18]|h|r You loot 6 Copper",
					["serverTime"] = 1709348117,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524536.182,
					["g"] = 1,
					["b"] = 0,
				}, -- [111]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:29]|h|r You receive loot: |cffffffff|Hitem:2449::::::::8:::::::::|h[Earthroot]|h|r.",
					["serverTime"] = 1709348128,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524547.349,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [112]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:29]|h|r You receive loot: |cffffffff|Hitem:117::::::::8:::::::::|h[Tough Jerky]|h|rx2.",
					["serverTime"] = 1709348128,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524547.349,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [113]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:29]|h|r You receive loot: |cffffffff|Hitem:159::::::::8:::::::::|h[Refreshing Spring Water]|h|r.",
					["serverTime"] = 1709348128,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524547.349,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [114]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:29]|h|r You receive loot: |cffffffff|Hitem:118::::::::8:::::::::|h[Minor Healing Potion]|h|rx4.",
					["serverTime"] = 1709348128,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524547.349,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [115]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:30]|h|r You loot 39 Copper",
					["serverTime"] = 1709348129,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524548.381,
					["g"] = 1,
					["b"] = 0,
				}, -- [116]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:31]|h|r You receive loot: |cff1eff00|Hitem:210771::::::::8:::::::::|h[Waylaid Supplies: Copper Bars]|h|r.",
					["serverTime"] = 1709348130,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524548.965,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [117]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:55:54]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709348153,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524571.681,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [118]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:56:04]|h|r Kul Tiras Sailor attempts to run away in fear!",
					["serverTime"] = 1709348163,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524581.7980000001,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [119]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:56:05]|h|r You receive loot: |cffffffff|Hitem:2070::::::::8:::::::::|h[Darnassian Bleu]|h|r.",
					["serverTime"] = 1709348164,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524582.632,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [120]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:56:05]|h|r You receive loot: |cffffffff|Hitem:2589::::::::8:::::::::|h[Linen Cloth]|h|r.",
					["serverTime"] = 1709348164,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524582.632,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [121]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:56:06]|h|r You loot 4 Copper",
					["serverTime"] = 1709348165,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524583.732,
					["g"] = 1,
					["b"] = 0,
				}, -- [122]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:56:17]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709348176,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524595.149,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [123]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:56:25]|h|r You loot 5 Copper",
					["serverTime"] = 1709348185,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524602.914,
					["g"] = 1,
					["b"] = 0,
				}, -- [124]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:56:45]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709348205,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524622.848,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [125]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:56:54]|h|r Kul Tiras Sailor attempts to run away in fear!",
					["serverTime"] = 1709348214,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524632.381,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [126]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:56:58]|h|r You loot 2 Copper",
					["serverTime"] = 1709348218,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524636.115,
					["g"] = 1,
					["b"] = 0,
				}, -- [127]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:05]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709348225,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524642.698,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [128]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:05]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709348225,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524643.314,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [129]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:08]|h|r Kul Tiras Sailor attempts to run away in fear!",
					["serverTime"] = 1709348228,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524645.731,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [130]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:11]|h|r You receive loot: |cffffffff|Hitem:2589::::::::8:::::::::|h[Linen Cloth]|h|r.",
					["serverTime"] = 1709348231,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524648.782,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [131]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:12]|h|r You loot 5 Copper",
					["serverTime"] = 1709348232,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524649.7980000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [132]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:21]|h|r Kul Tiras Sailor attempts to run away in fear!",
					["serverTime"] = 1709348241,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524658.698,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [133]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:30]|h|r |cffd8d8d8[|r|Hplayer:Rattangkor:370|h|cffa5a5a5Rattangkor|r|h|cffd8d8d8]|r has invited you to join a group.",
					["serverTime"] = 1709348250,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524667.415,
					["g"] = 1,
					["b"] = 0,
				}, -- [134]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:30]|h|r Kul Tiras Marine attempts to run away in fear!",
					["serverTime"] = 1709348250,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524668.382,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [135]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:34]|h|r Dungeon difficulty set to Normal",
					["serverTime"] = 1709348254,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524671.515,
					["g"] = 1,
					["b"] = 0,
				}, -- [136]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:35]|h|r You loot 2 Copper",
					["serverTime"] = 1709348255,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524673.066,
					["g"] = 1,
					["b"] = 0,
				}, -- [137]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:41]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709348261,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524678.748,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [138]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:51]|h|r Kul Tiras Marine attempts to run away in fear!",
					["serverTime"] = 1709348271,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524689.0160000001,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [139]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:54]|h|r Kul Tiras Sailor attempts to run away in fear!",
					["serverTime"] = 1709348273,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524692.247,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [140]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:56]|h|r Interface action failed because of an AddOn",
					["serverTime"] = 1709348275,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 524693.883,
					["g"] = 1,
					["b"] = 0,
				}, -- [141]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:56]|h|r |cffc69b6dRattangkor|r receives loot: |cffffffff|Hitem:2589::::::::8:::::::::|h[Linen Cloth]|h|r.",
					["serverTime"] = 1709348275,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524694.33,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [142]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:57]|h|r |cffc69b6dRattangkor|r receives loot: |cff9d9d9d|Hitem:2644::::::::8:::::::::|h[Loose Chain Cloak]|h|r.",
					["serverTime"] = 1709348276,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524694.497,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [143]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:57]|h|r Your share of the loot is 1 Copper.",
					["serverTime"] = 1709348276,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524695.182,
					["g"] = 1,
					["b"] = 0,
				}, -- [144]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:57]|h|r You receive loot: |cffffffff|Hitem:2070::::::::8:::::::::|h[Darnassian Bleu]|h|r.",
					["serverTime"] = 1709348276,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524695.23,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [145]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:57:58]|h|r Your share of the loot is 5 Copper.",
					["serverTime"] = 1709348277,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524696.247,
					["g"] = 1,
					["b"] = 0,
				}, -- [146]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:10]|h|r Kul Tiras Marine attempts to run away in fear!",
					["serverTime"] = 1709348289,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524708.032,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [147]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:28]|h|r Your share of the loot is 4 Copper.",
					["serverTime"] = 1709348307,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524726.164,
					["g"] = 1,
					["b"] = 0,
				}, -- [148]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:49]|h|r Kul Tiras Marine attempts to run away in fear!",
					["serverTime"] = 1709348328,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524747.314,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [149]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:50]|h|r Congratulations, you have reached level 9!",
					["serverTime"] = 1709348329,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 524747.697,
					["g"] = 1,
					["b"] = 0,
				}, -- [150]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:50]|h|r You have gained 17 hit points.",
					["serverTime"] = 1709348329,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 524747.697,
					["g"] = 1,
					["b"] = 0,
				}, -- [151]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:50]|h|r Your Strength increases by 1.",
					["serverTime"] = 1709348329,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 524747.697,
					["g"] = 1,
					["b"] = 0,
				}, -- [152]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:50]|h|r Your Agility increases by 1.",
					["serverTime"] = 1709348329,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 524747.697,
					["g"] = 1,
					["b"] = 0,
				}, -- [153]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:50]|h|r Your Stamina increases by 1.",
					["serverTime"] = 1709348329,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 524747.697,
					["g"] = 1,
					["b"] = 0,
				}, -- [154]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:50]|h|r Your Spirit increases by 1.",
					["serverTime"] = 1709348329,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 524747.697,
					["g"] = 1,
					["b"] = 0,
				}, -- [155]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:50]|h|r Your skill in Assassination has increased to 45.",
					["serverTime"] = 1709348329,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524747.697,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [156]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:50]|h|r Your skill in Combat has increased to 45.",
					["serverTime"] = 1709348329,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524747.697,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [157]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:50]|h|r Your skill in Subtlety has increased to 45.",
					["serverTime"] = 1709348329,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524747.697,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [158]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:52]|h|r |cffc69b6dRattangkor|r receives loot: |cff9d9d9d|Hitem:2138::::::::9:::::::::|h[Sharpened Letter Opener]|h|r.",
					["serverTime"] = 1709348331,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524749.897,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [159]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:53]|h|r Your share of the loot is 1 Copper.",
					["serverTime"] = 1709348332,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524750.73,
					["g"] = 1,
					["b"] = 0,
				}, -- [160]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:55]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Rattangkor-Shadowstrike(AU):405:PARTY|h|cffd8d83f9|r:|cffc69b6dRattangkor|r|h|cffd8d8d8]|r: grtz",
					["serverTime"] = 1709348334,
					["r"] = 0.4627451300621033,
					["extraData"] = {
						50, -- [1]
						18, -- [2]
						19, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524753.098,
					["g"] = 0.7843137979507446,
					["b"] = 1,
				}, -- [161]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:58:56]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Shazzam:406:CHANNEL:1|h|cff0070ddShazzam|r|h|cffd8d8d8]|r: LFM need a hand getting rune from frozen guy",
					["serverTime"] = 1709348335,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						3, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524753.732,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [162]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:01]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Poisongrace-Shadowstrike(AU):408:PARTY|h|cffd8d83f9|r:|cfffff468Poisongrace|r|h|cffd8d8d8]|r: :)",
					["serverTime"] = 1709348340,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						18, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524758.797,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [163]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:08]|h|r Your skill in Daggers has increased to 40.",
					["serverTime"] = 1709348347,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524766.198,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [164]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:16]|h|r Your share of the loot is 2 Copper.",
					["serverTime"] = 1709348355,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524774.1140000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [165]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:30]|h|r Your skill in Daggers has increased to 41.",
					["serverTime"] = 1709348370,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524788.0970000001,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [166]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:32]|h|r Lieutenant Benedict attempts to run away in fear!",
					["serverTime"] = 1709348372,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524790.231,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [167]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:33]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Poisongrace-Shadowstrike(AU):420:PARTY|h|cffd8d83f9|r:|cfffff468Poisongrace|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Lieutenant Benedict for |Hquestie:784:Player-5818-00A98B51|h|cFFFFFF00[|r|cFFFFFF00[7] Vanquish the Betrayers|r|cFFFFFF00]|r|h!",
					["serverTime"] = 1709348373,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						18, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524791.247,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [168]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:38]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Shazzam-Shadowstrike(AU):423:CHANNEL:1|h|cff0070ddShazzam|r|h|cffd8d8d8]|r: east of Razor hill",
					["serverTime"] = 1709348378,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						3, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524795.748,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [169]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:44]|h|r |cffc69b6dRattangkor|r receives loot: |cffffffff|Hitem:2589::::::::9:::::::::|h[Linen Cloth]|h|rx2.",
					["serverTime"] = 1709348384,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524801.664,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [170]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:44]|h|r |cffc69b6dRattangkor|r receives loot: |cffffffff|Hitem:4882::::::::9:::::::::|h[Benedict's Key]|h|r.",
					["serverTime"] = 1709348384,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524801.831,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [171]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:44]|h|r You receive loot: |cffffffff|Hitem:4882::::::::9:::::::::|h[Benedict's Key]|h|r.",
					["serverTime"] = 1709348384,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524802.063,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [172]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:59:44]|h|r Your share of the loot is 8 Copper.",
					["serverTime"] = 1709348384,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524802.181,
					["g"] = 1,
					["b"] = 0,
				}, -- [173]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:00:04]|h|r Kul Tiras Marine attempts to run away in fear!",
					["serverTime"] = 1709348404,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524822.198,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [174]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:00:14]|h|r Your skill in Daggers has increased to 42.",
					["serverTime"] = 1709348414,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524831.714,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [175]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:00:18]|h|r Your skill in Defense has increased to 40.",
					["serverTime"] = 1709348418,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524835.447,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [176]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:00:20]|h|r Lieutenant Benedict attempts to run away in fear!",
					["serverTime"] = 1709348420,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524838.381,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [177]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:00:23]|h|r You receive loot: |cffffffff|Hitem:2589::::::::9:::::::::|h[Linen Cloth]|h|rx2.",
					["serverTime"] = 1709348423,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524840.914,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [178]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:00:24]|h|r |cffc69b6dRattangkor|r receives loot: |cffffffff|Hitem:2589::::::::9:::::::::|h[Linen Cloth]|h|rx2.",
					["serverTime"] = 1709348424,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524841.747,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [179]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:00:24]|h|r |cffc69b6dRattangkor|r receives loot: |cffffffff|Hitem:2070::::::::9:::::::::|h[Darnassian Bleu]|h|r.",
					["serverTime"] = 1709348424,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524841.898,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [180]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:00:24]|h|r Your share of the loot is 4 Copper.",
					["serverTime"] = 1709348424,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524841.98,
					["g"] = 1,
					["b"] = 0,
				}, -- [181]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:00:33]|h|r Kul Tiras Marine attempts to run away in fear!",
					["serverTime"] = 1709348433,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524851.363,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [182]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:00:34]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Poisongrace-Shadowstrike(AU):451:PARTY|h|cffd8d83f9|r:|cfffff468Poisongrace|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 8/8 Kul Tiras Marine for |Hquestie:784:Player-5818-00A98B51|h|cFFFFFF00[|r|cFFFFFF00[7] Vanquish the Betrayers |cFF00ff00(Complete)|r|r|cFFFFFF00]|r|h!",
					["serverTime"] = 1709348434,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						18, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524852.046,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [183]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:00:36]|h|r Your share of the loot is 2 Copper.",
					["serverTime"] = 1709348436,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524853.88,
					["g"] = 1,
					["b"] = 0,
				}, -- [184]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:00:52]|h|r You receive loot: |cffffffff|Hitem:5571::::::::9:::::::::|h[Small Black Pouch]|h|r.",
					["serverTime"] = 1709348451,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524870.1140000001,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [185]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:00:53]|h|r Your share of the loot is 4 Copper.",
					["serverTime"] = 1709348452,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524871.135,
					["g"] = 1,
					["b"] = 0,
				}, -- [186]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:01:17]|h|r You receive loot: |cffffffff|Hitem:4881::::::::9:::::::::|h[Aged Envelope]|h|r.",
					["serverTime"] = 1709348476,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524894.4400000001,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [187]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:01:17]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Poisongrace-Shadowstrike(AU):462:PARTY|h|cffd8d83f9|r:|cfffff468Poisongrace|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: Picked up |cffffffff|Hitem:4881::::::::9:::::::::|h[Aged Envelope]|h|r which starts |Hquestie:830:Player-5818-00A98B51|h|cFFFFFF00[|r|cFFFFFF00[7] The Admiral's Orders|r|cFFFFFF00]|r|h!",
					["serverTime"] = 1709348476,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						18, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524894.679,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [188]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:01:24]|h|r |cffc69b6dRattangkor|r receives loot: |cffffffff|Hitem:4881::::::::9:::::::::|h[Aged Envelope]|h|r.",
					["serverTime"] = 1709348483,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524901.6630000001,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [189]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:01:28]|h|r Your skill in Daggers has increased to 43.",
					["serverTime"] = 1709348487,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524905.964,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [190]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:01:36]|h|r Kul Tiras Marine attempts to run away in fear!",
					["serverTime"] = 1709348495,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524914.147,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [191]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:01:38]|h|r |cffc69b6dRattangkor|r receives loot: |cff9d9d9d|Hitem:1412::::::::9:::::::::|h[Crude Bastard Sword]|h|r.",
					["serverTime"] = 1709348497,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524915.763,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [192]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:01:39]|h|r Your share of the loot is 1 Copper.",
					["serverTime"] = 1709348498,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524916.53,
					["g"] = 1,
					["b"] = 0,
				}, -- [193]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:09]|h|r Kul Tiras Marine attempts to run away in fear!",
					["serverTime"] = 1709348528,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524946.963,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [194]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:11]|h|r Your share of the loot is 4 Copper.",
					["serverTime"] = 1709348530,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524949.216,
					["g"] = 1,
					["b"] = 0,
				}, -- [195]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:15]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709348534,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524952.746,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [196]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:20]|h|r Kul Tiras Sailor attempts to run away in fear!",
					["serverTime"] = 1709348539,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524957.914,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [197]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:24]|h|r Your share of the loot is 2 Copper.",
					["serverTime"] = 1709348544,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524961.6460000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [198]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:30]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709348550,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524967.997,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [199]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:37]|h|r You receive loot: |cff9d9d9d|Hitem:3363::::::::9:::::::::|h[Frayed Belt]|h|r.",
					["serverTime"] = 1709348557,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524974.948,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [200]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:38]|h|r Your share of the loot is 1 Copper.",
					["serverTime"] = 1709348558,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524975.979,
					["g"] = 1,
					["b"] = 0,
				}, -- [201]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:47]|h|r You receive item: |cffffffff|Hitem:4883::::::::9:::::::::|h[Admiral Proudmoore's Orders]|h|r.",
					["serverTime"] = 1709348567,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524985.18,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [202]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:47]|h|r Quest accepted: The Admiral's Orders",
					["serverTime"] = 1709348567,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524985.329,
					["g"] = 1,
					["b"] = 0,
				}, -- [203]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:48]|h|r RestedXP Guides: Targeting macro updated with (Cook Torka)",
					["timestamp"] = 524986.3470000001,
					["serverTime"] = 1709348568,
				}, -- [204]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:48]|h|r RestedXP Guides: Targeting macro updated with (Gar'Thok)",
					["timestamp"] = 524986.3470000001,
					["serverTime"] = 1709348568,
				}, -- [205]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:48]|h|r RestedXP Guides: Targeting macro updated with (Orgnil Soulscar)",
					["timestamp"] = 524986.3470000001,
					["serverTime"] = 1709348568,
				}, -- [206]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:54]|h|r Kul Tiras Sailor attempts to run away in fear!",
					["serverTime"] = 1709348574,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524991.496,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [207]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:02:57]|h|r |cffc69b6dRattangkor|r receives loot: |cffffffff|Hitem:2070::::::::9:::::::::|h[Darnassian Bleu]|h|r.",
					["serverTime"] = 1709348577,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 524994.713,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [208]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:03:22]|h|r |cffc69b6dRattangkor|r receives loot: |cff9d9d9d|Hitem:3370::::::::9:::::::::|h[Patchwork Belt]|h|r.",
					["serverTime"] = 1709348602,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525020.363,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [209]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:03:23]|h|r You receive loot: |cffffffff|Hitem:2589::::::::9:::::::::|h[Linen Cloth]|h|rx2.",
					["serverTime"] = 1709348603,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525020.563,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [210]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:03:23]|h|r Your share of the loot is 3 Copper.",
					["serverTime"] = 1709348603,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525021.164,
					["g"] = 1,
					["b"] = 0,
				}, -- [211]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:03:25]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Shazzam-Shadowstrike(AU):502:CHANNEL:1|h|cff0070ddShazzam|r|h|cffd8d8d8]|r: LF1M come killFrozen Makrura for rune!",
					["serverTime"] = 1709348605,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						3, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525022.962,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [212]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:03:26]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709348606,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525023.431,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [213]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:03:38]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Poisongrace-Shadowstrike(AU):507:PARTY|h|cffd8d83f9|r:|cfffff468Poisongrace|r|h|cffd8d8d8]|r: thx for the help. have fun",
					["serverTime"] = 1709348618,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						18, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525036.379,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [214]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:03:40]|h|r Kul Tiras Sailor attempts to run away in fear!",
					["serverTime"] = 1709348620,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525037.679,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [215]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:03:45]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Rattangkor-Shadowstrike(AU):509:PARTY|h|cffd8d83f9|r:|cffc69b6dRattangkor|r|h|cffd8d8d8]|r: np tnx",
					["serverTime"] = 1709348625,
					["r"] = 0.4627451300621033,
					["extraData"] = {
						50, -- [1]
						18, -- [2]
						19, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525042.946,
					["g"] = 0.7843137979507446,
					["b"] = 1,
				}, -- [216]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:03:52]|h|r You leave the group.",
					["serverTime"] = 1709348632,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525049.528,
					["g"] = 1,
					["b"] = 0,
				}, -- [217]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:03:53]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Firoches:513:CHANNEL:1|h|cfffff468Firoches|r|h|cffd8d8d8]|r: |cffffff00|Hinvplr:Firoches|h[invite]|h|r Me please",
					["serverTime"] = 1709348632,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						3, -- [2]
						23, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525050.647,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [218]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:04:23]|h|r Kul Tiras Sailor charges!",
					["serverTime"] = 1709348662,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525081.312,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [219]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:04:30]|h|r Kul Tiras Sailor attempts to run away in fear!",
					["serverTime"] = 1709348669,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525087.463,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [220]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:04:34]|h|r You receive loot: |cff9d9d9d|Hitem:2653::::::::9:::::::::|h[Flimsy Chain Gloves]|h|r.",
					["serverTime"] = 1709348673,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525091.629,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [221]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:04:34]|h|r You receive loot: |cffffffff|Hitem:2589::::::::9:::::::::|h[Linen Cloth]|h|rx2.",
					["serverTime"] = 1709348673,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525091.629,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [222]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:04:34]|h|r You receive loot: |cffffffff|Hitem:2070::::::::9:::::::::|h[Darnassian Bleu]|h|r.",
					["serverTime"] = 1709348673,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525091.629,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [223]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:04:35]|h|r You loot 7 Copper",
					["serverTime"] = 1709348674,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525092.73,
					["g"] = 1,
					["b"] = 0,
				}, -- [224]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:04:53]|h|r Your skill in Defense has increased to 41.",
					["serverTime"] = 1709348692,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525111.145,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [225]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:05:46]|h|r Your Orgrimmar reputation has increased by 100.",
					["serverTime"] = 1709348745,
					["r"] = 0.501960813999176,
					["extraData"] = {
						36, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525163.996,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [226]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:05:46]|h|r Your Darkspear Trolls reputation has increased by 100.",
					["serverTime"] = 1709348745,
					["r"] = 0.501960813999176,
					["extraData"] = {
						36, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525163.996,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [227]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:05:46]|h|r Vanquish the Betrayers completed.",
					["serverTime"] = 1709348745,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525163.996,
					["g"] = 1,
					["b"] = 0,
				}, -- [228]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:05:46]|h|r Experience gained: 937.",
					["serverTime"] = 1709348745,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525163.996,
					["g"] = 1,
					["b"] = 0,
				}, -- [229]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:05:46]|h|r Received 1 Silver, 75 Copper.",
					["serverTime"] = 1709348745,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525163.996,
					["g"] = 1,
					["b"] = 0,
				}, -- [230]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:05:46]|h|r Quest accepted: From The Wreckage....",
					["serverTime"] = 1709348745,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525164.312,
					["g"] = 1,
					["b"] = 0,
				}, -- [231]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:05:47]|h|r Your Orgrimmar reputation has increased by 100.",
					["serverTime"] = 1709348746,
					["r"] = 0.501960813999176,
					["extraData"] = {
						36, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525165.046,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [232]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:05:47]|h|r Your Darkspear Trolls reputation has increased by 100.",
					["serverTime"] = 1709348746,
					["r"] = 0.501960813999176,
					["extraData"] = {
						36, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525165.046,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [233]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:05:47]|h|r The Admiral's Orders completed.",
					["serverTime"] = 1709348746,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525165.046,
					["g"] = 1,
					["b"] = 0,
				}, -- [234]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:05:47]|h|r Experience gained: 937.",
					["serverTime"] = 1709348746,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525165.046,
					["g"] = 1,
					["b"] = 0,
				}, -- [235]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:05:47]|h|r You receive item: |cffffffff|Hitem:4883::::::::9:::::::::|h[Admiral Proudmoore's Orders]|h|r.",
					["serverTime"] = 1709348746,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525165.312,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [236]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:05:48]|h|r Quest accepted: The Admiral's Orders",
					["serverTime"] = 1709348747,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525165.562,
					["g"] = 1,
					["b"] = 0,
				}, -- [237]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:06:21]|h|r You receive item: |cffffffff|Hitem:4496::::::::9:::::::::|h[Small Brown Pouch]|h|r.",
					["serverTime"] = 1709348780,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525199.211,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [238]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:06:23]|h|r You receive item: |cffffffff|Hitem:4496::::::::9:::::::::|h[Small Brown Pouch]|h|r.",
					["serverTime"] = 1709348782,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525200.478,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [239]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:06:24]|h|r You receive item: |cffffffff|Hitem:4496::::::::9:::::::::|h[Small Brown Pouch]|h|r.",
					["serverTime"] = 1709348783,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525201.428,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [240]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:06:43]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Iphoneten:567:CHANNEL:1|h|cffc69b6dIphoneten|r|h|cffd8d8d8]|r: anyone seen the wandering swordsman?",
					["serverTime"] = 1709348802,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						3, -- [2]
						25, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525220.845,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [241]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:07:02]|h|r Quest accepted: Break a Few Eggs",
					["serverTime"] = 1709348821,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525240.045,
					["g"] = 1,
					["b"] = 0,
				}, -- [242]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:07:02]|h|r RestedXP Guides: Targeting macro updated with (Furl Scornbrow)",
					["timestamp"] = 525240.145,
					["serverTime"] = 1709348821,
				}, -- [243]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:03]|h|r Your Orgrimmar reputation has increased by 100.",
					["serverTime"] = 1709348942,
					["r"] = 0.501960813999176,
					["extraData"] = {
						36, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525360.444,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [244]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:03]|h|r Your Darkspear Trolls reputation has increased by 100.",
					["serverTime"] = 1709348942,
					["r"] = 0.501960813999176,
					["extraData"] = {
						36, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525360.444,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [245]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:03]|h|r Carry Your Weight completed.",
					["serverTime"] = 1709348942,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525360.4670000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [246]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:03]|h|r Experience gained: 937.",
					["serverTime"] = 1709348942,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525360.4670000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [247]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:03]|h|r You receive item: |cffffffff|Hitem:11845::::::::9:::::::::|h[Handmade Leather Bag]|h|r.",
					["serverTime"] = 1709348942,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525360.478,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [248]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:03]|h|r RestedXP Guides: Targeting macro updated with (Krunn)",
					["timestamp"] = 525360.594,
					["serverTime"] = 1709348942,
				}, -- [249]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:03]|h|r RestedXP Guides: Targeting macro updated with (Wuark)",
					["timestamp"] = 525360.745,
					["serverTime"] = 1709348942,
				}, -- [250]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:31]|h|r RestedXP Guides: Targeting macro updated with (Dwukk)",
					["timestamp"] = 525389.112,
					["serverTime"] = 1709348970,
				}, -- [251]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:32]|h|r RestedXP Guides: Targeting macro updated with (Uhgar)",
					["timestamp"] = 525390.312,
					["serverTime"] = 1709348971,
				}, -- [252]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:33]|h|r RestedXP Guides: Targeting macro updated with (Innkeeper Grosk)",
					["timestamp"] = 525390.6460000001,
					["serverTime"] = 1709348972,
				}, -- [253]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:09:34]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Firoches-Shadowstrike(AU):600:CHANNEL:3|h|cfffff468Firoches|r|h|cffd8d8d8]|r: Nurse Joy  Looking for more active members to join Looking at rading Gnomegen   in near Future. PSt if keen",
					["serverTime"] = 1709348973,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						27, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525392.162,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [254]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:10:03]|h|r Razor Hill is now your home.",
					["serverTime"] = 1709349002,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525420.878,
					["g"] = 1,
					["b"] = 0,
				}, -- [255]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:10:03]|h|r RestedXP Guides: Targeting macro updated with (Kaplak)",
					["timestamp"] = 525421.011,
					["serverTime"] = 1709349002,
				}, -- [256]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:10:03]|h|r RestedXP Guides: Targeting macro updated with (Rawrk)",
					["timestamp"] = 525421.177,
					["serverTime"] = 1709349002,
				}, -- [257]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:10:51]|h|r You have learned how to create a new item: Linen Bandage.",
					["serverTime"] = 1709349050,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525468.594,
					["g"] = 1,
					["b"] = 0,
				}, -- [258]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:10:51]|h|r You have learned a new ability: First Aid (Apprentice).",
					["serverTime"] = 1709349050,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525468.594,
					["g"] = 1,
					["b"] = 0,
				}, -- [259]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:10:51]|h|r RestedXP Guides: Targeting macro updated with (Jark)",
					["timestamp"] = 525468.743,
					["serverTime"] = 1709349050,
				}, -- [260]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:10:51]|h|r You have gained the First Aid skill.",
					["serverTime"] = 1709349050,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525468.81,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [261]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:13:13]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Okcya-Shadowstrike(AU):652:CHANNEL:1|h|cff0070ddOkcya|r|h|cffd8d8d8]|r: LF1M Fire dmg required for frozen makrua rune",
					["serverTime"] = 1709349192,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						3, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525610.9940000001,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [262]
				{
					["message"] = "|cff979797|Hpratcopy|h[13:13:40]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Firoches-Shadowstrike(AU):658:CHANNEL:1|h|cfffff468Firoches|r|h|cffd8d8d8]|r: any shamie looking for the totem",
					["serverTime"] = 1709349219,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						3, -- [2]
						23, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 525637.41,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [263]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}

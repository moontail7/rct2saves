
RXPCData = {
	["completedWaypoints"] = {
		[56] = {
		},
	},
	["currentStep"] = 56,
	["questObjectivesCache"] = {
		[0] = 21,
		[818] = {
			{
				["type"] = "item",
				["numRequired"] = 4,
				["text"] = "Intact Makrura Eye: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Crawler Mucus: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[834] = {
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Sack of Supplies: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[788] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Mottled Boar slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[789] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Scorpid Worker Tail: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[790] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Sarkoth's Mangled Claw: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[837] = {
			{
				["type"] = "monster",
				["numRequired"] = 4,
				["text"] = "Razormane Quilboar slain: 1/4",
				["finished"] = false,
				["numFulfilled"] = 1,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 4,
				["text"] = "Razormane Scout slain: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 4,
				["text"] = "Razormane Dustrunner slain: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
			{
				["type"] = "monster",
				["numRequired"] = 4,
				["text"] = "Razormane Battleguard slain: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [4]
		},
		[791] = {
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Canvas Scraps: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[77583] = {
			{
				["type"] = "spell",
				["numRequired"] = 1,
				["text"] = "Learn Spell: Engrave Gloves - Shadowstrike",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[4402] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Cactus Apple: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[808] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Minshina's Skull: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6394] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Thazz'ril's Pick: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[794] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Burning Blade Medallion: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[826] = {
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Hexed Troll slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Voodoo Troll slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Zalazane's Head: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[5441] = {
			{
				["type"] = "monster",
				["numRequired"] = 5,
				["text"] = "Peons Awoken: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[786] = {
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Attack Plan: Valley of Trials destroyed: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Attack Plan: Sen'jin Village destroyed: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Attack Plan: Orgrimmar destroyed: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[784] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Kul Tiras Sailor slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Kul Tiras Marine slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Lieutenant Benedict slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[825] = {
			{
				["type"] = "item",
				["numRequired"] = 3,
				["text"] = "Gnomish Tools: 0/3",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[792] = {
			{
				["type"] = "monster",
				["numRequired"] = 12,
				["text"] = "Vile Familiar slain: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[815] = {
			{
				["type"] = "item",
				["numRequired"] = 3,
				["text"] = "Taillasher Egg: 0/3",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[817] = {
			{
				["type"] = "item",
				["numRequired"] = 4,
				["text"] = "Durotar Tiger Fur: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[806] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Fizzle's Claw: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
	},
	["currentGuideGroup"] = "RestedXP Speedrun Guide (H)",
	["flightPaths"] = {
	},
	["questNameCache"] = {
		[4641] = "Your Place In The World",
		[834] = "Winds in the Desert",
		[788] = "Cutting Teeth",
		[804] = "Sarkoth",
		[789] = "Sting of the Scorpid",
		[805] = "Report to Sen'jin Village",
		[790] = "Sarkoth",
		[837] = "Encroachment",
		[791] = "Carry Your Weight",
		[77583] = "Atop the Cliffs",
		[4402] = "Galgar's Cactus Apple Surprise",
		[808] = "Minshina's Skull",
		[6394] = "Thazz'ril's Pick",
		[794] = "Burning Blade Medallion",
		[826] = "Zalazane",
		[815] = "Break a Few Eggs",
		[3088] = "Encrypted Parchment",
		[5441] = "Lazy Peons",
		[2161] = "A Peon's Burden",
		[786] = "Thwarting Kolkar Aggression",
		[792] = "Vile Familiars",
		[818] = "A Solvent Spirit",
		[830] = "The Admiral's Orders",
		[784] = "Vanquish the Betrayers",
		[831] = "The Admiral's Orders",
		[806] = "Dark Storms",
		[825] = "From The Wreckage....",
		[817] = "Practical Prey",
		[823] = "Report to Orgnil",
	},
	["currentGuideName"] = "06-10 Durotar",
	["stepSkip"] = {
		[30] = true,
		[31] = true,
		[16] = true,
		[9] = true,
		[2] = true,
		[5] = true,
		[38] = true,
		[20] = true,
		[40] = true,
		[41] = true,
		[11] = true,
		[23] = true,
		[12] = true,
		[24] = true,
		[48] = true,
		[49] = true,
		[14] = true,
		[55] = true,
		[29] = true,
		[10] = true,
	},
	["currentStepId"] = 3095400033,
}
RXPCTrackingData = {
	["profileKeys"] = {
		["Poisongrace - Shadowstrike (AU)"] = "Poisongrace - Shadowstrike (AU)",
	},
	["profiles"] = {
		["Poisongrace - Shadowstrike (AU)"] = {
			["levels"] = {
				nil, -- [1]
				nil, -- [2]
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 274,
							["count"] = 3,
						},
					},
					["timestamp"] = {
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 17,
							["minute"] = 39,
						},
						["finished"] = 2105,
						["started"] = 3,
					},
					["quests"] = {
					},
				}, -- [3]
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 2110,
							["count"] = 25,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 17,
							["minute"] = 39,
						},
						["finished"] = 3005,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 17,
							["minute"] = 54,
						},
						["started"] = 2106,
					},
					["quests"] = {
					},
				}, -- [4]
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 357,
							["count"] = 5,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 17,
							["minute"] = 54,
						},
						["finished"] = 4177,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 18,
							["minute"] = 13,
						},
						["started"] = 3006,
					},
					["quests"] = {
						["Durotar"] = {
							[789] = 375,
							[4402] = 570,
							[792] = 675,
							[77583] = 127,
							[5441] = 675,
						},
					},
				}, -- [5]
				{
					["groupExperience"] = 0,
					["deaths"] = 2,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 1396,
							["count"] = 17,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 18,
							["minute"] = 13,
						},
						["finished"] = 6856,
						["dateFinished"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 19,
							["minute"] = 27,
						},
						["started"] = 4178,
					},
					["quests"] = {
						["Durotar"] = {
							[6394] = 675,
							[805] = 345,
							[794] = 1012,
						},
					},
				}, -- [6]
				{
					["groupExperience"] = 0,
					["deaths"] = 1,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 2616,
							["count"] = 26,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 19,
							["minute"] = 27,
						},
						["started"] = 6857,
					},
					["quests"] = {
					},
				}, -- [7]
				{
					["groupExperience"] = 171,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 3332,
							["count"] = 33,
						},
					},
					["timestamp"] = {
						["dateFinished"] = {
							["monthDay"] = 2,
							["day"] = 0,
							["month"] = 3,
							["minute"] = 57,
							["year"] = 2024,
							["hour"] = 13,
							["weekday"] = 7,
						},
						["finished"] = 10923,
					},
					["quests"] = {
						["Durotar"] = {
							[786] = 1050,
						},
					},
				}, -- [8]
				{
					["groupExperience"] = 569,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 614,
							["count"] = 16,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 2,
							["day"] = 0,
							["month"] = 3,
							["minute"] = 57,
							["year"] = 2024,
							["hour"] = 13,
							["weekday"] = 7,
						},
						["started"] = 10924,
					},
					["quests"] = {
						["Durotar"] = {
							[830] = 937,
							[784] = 937,
							[791] = 937,
						},
					},
				}, -- [9]
			},
			["trackedGuid"] = "Player-5818-00A98B51",
		},
	},
}
RXPCComms = {
	["profileKeys"] = {
		["Poisongrace - Shadowstrike (AU)"] = "Poisongrace - Shadowstrike (AU)",
	},
	["profiles"] = {
		["Poisongrace - Shadowstrike (AU)"] = {
			["announcements"] = {
				["01-06 Durotar"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["06-10 Durotar"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
			},
			["players"] = {
				["Rattangkor"] = {
					["timePlayed"] = 358.23199999996,
					["class"] = "WARRIOR",
					["xp"] = 45,
				},
			},
		},
	},
}
RXPCSettings = nil

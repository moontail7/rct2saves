
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["combatId"] = 123,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001968,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 9.001968,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 9.001968,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Environment (Fire)"] = true,
								["Clattering Scorpid"] = true,
							},
							["targets"] = {
								["Clattering Scorpid"] = 9,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348709,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[1776] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["Clattering Scorpid"] = 9,
										},
										["n_total"] = 9,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 9,
										["c_max"] = 0,
										["id"] = 1776,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0.5516925905484109,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 19.001968,
							["start_time"] = 1709348708,
							["delay"] = 1709348693,
							["last_event"] = 1709348693,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002291,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 6.002291,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 6.002291,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3125-000062904E",
							["aID"] = "3125",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 6,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348709,
							["nome"] = "Clattering Scorpid",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6,
										["targets"] = {
											["Poisongrace"] = 6,
										},
										["n_total"] = 6,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 6,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 9.002291,
							["start_time"] = 1709348708,
							["delay"] = 1709348693,
							["last_event"] = 1709348693,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 123,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 123,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 123,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1776] = {
										["activedamt"] = 0,
										["id"] = 1776,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["pets"] = {
							},
							["cc_done_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1776] = {
										["id"] = 1776,
										["targets"] = {
											["Clattering Scorpid"] = 1,
										},
										["counter"] = 1,
									},
								},
							},
							["aID"] = "5818-00A98B51",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 4,
							["cc_done"] = 1.001746,
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["grupo"] = true,
							["cc_done_targets"] = {
								["Clattering Scorpid"] = 1,
							},
							["classe"] = "ROGUE",
							["debuff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["buff_uptime"] = 16,
							["buff_uptime_targets"] = {
							},
							["serial"] = "Player-5818-00A98B51",
							["last_event"] = 1709348709,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 123,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["tempo_start"] = 1709348693,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					68, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["Poisongrace"] = {
						{
							true, -- [1]
							6, -- [2]
							13, -- [3]
							1709349064.623, -- [4]
							211, -- [5]
							"Environment (Fire)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = false,
				["amountCasts"] = {
				},
				["instance_type"] = "none",
				["data_fim"] = "13:05:10",
				["hasTimer"] = 16.1019999999553,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Clattering Scorpid",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 525127.462,
				["CombatEndedAt"] = 525127.462,
				["aura_timeline"] = {
				},
				["data_inicio"] = "13:04:53",
				["end_time"] = 525127.462,
				["combat_id"] = 123,
				["overall_added"] = true,
				["frags"] = {
				},
				["combat_counter"] = 126,
				["totals_grupo"] = {
					9, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 9.001968,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 525111.145,
				["TimeData"] = {
				},
				["contra"] = "Clattering Scorpid",
			}, -- [1]
			{
				{
					["combatId"] = 122,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005592,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 117.005592,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 117.005592,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 117,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348672,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Kul Tiras Sailor"] = 50,
										},
										["n_total"] = 50,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 50,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[399985] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kul Tiras Sailor"] = 17,
										},
										["n_total"] = 17,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 17,
										["c_max"] = 0,
										["id"] = 399985,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kul Tiras Sailor"] = 50,
										},
										["n_total"] = 17,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 50,
										["c_max"] = 33,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 33,
										["successful_casted"] = 0,
										["c_total"] = 33,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kul Tiras Sailor"] = 0,
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 12.42757217217035,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 10.005592,
							["start_time"] = 1709348663,
							["delay"] = 0,
							["last_event"] = 1709348672,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005502,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 10.005502,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 10.005502,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-00006296B0",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 10,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348672,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6,
										["targets"] = {
											["Poisongrace"] = 10,
										},
										["n_total"] = 10,
										["n_min"] = 4,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 10,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 117.005502,
							["start_time"] = 1709348665,
							["delay"] = 0,
							["last_event"] = 1709348668,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 122,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 122,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 122,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["serial"] = "Player-5818-00A98B51",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 9,
							["grupo"] = true,
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348672,
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 122,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 525111.145,
				["tempo_start"] = 1709348663,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					127, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 2,
						["Eviscerate"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "13:04:33",
				["hasTimer"] = 9.065999999991618,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 525090.595,
				["CombatEndedAt"] = 525090.595,
				["aura_timeline"] = {
				},
				["data_inicio"] = "13:04:23",
				["end_time"] = 525090.595,
				["combat_id"] = 122,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 1,
				},
				["combat_counter"] = 125,
				["totals_grupo"] = {
					117, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 117.005592,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 525081.18,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [2]
			{
				{
					["combatId"] = 121,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.004676,
							["pets"] = {
							},
							["classe"] = "WARRIOR",
							["total_without_pet"] = 168.004676,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 168.004676,
							["spec"] = 71,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9F3B5",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 168,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A9F3B5",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348663,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 1,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kul Tiras Sailor"] = 92,
										},
										["n_total"] = 64,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 92,
										["c_max"] = 28,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 28,
										["successful_casted"] = 0,
										["c_total"] = 28,
										["n_amt"] = 5,
										["b_dmg"] = 9,
										["r_amt"] = 0,
									}, -- [1]
									[2764] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kul Tiras Sailor"] = 15,
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 15,
										["c_max"] = 15,
										["id"] = 2764,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 15,
										["successful_casted"] = 0,
										["c_total"] = 15,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[772] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Kul Tiras Sailor"] = 15,
										},
										["n_total"] = 15,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 15,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 772,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[78] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 23,
										["targets"] = {
											["Kul Tiras Sailor"] = 46,
										},
										["n_total"] = 46,
										["n_min"] = 23,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 46,
										["c_max"] = 0,
										["id"] = 78,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 6.706773493001506,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 46.004676,
							["start_time"] = 1709348635,
							["delay"] = 1709348646,
							["last_event"] = 1709348646,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006969,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 46.006969,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 46.006969,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-0000629660",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
							},
							["targets"] = {
								["Rattangkor"] = 46,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348663,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 2,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Rattangkor"] = 46,
											["Poisongrace"] = 0,
										},
										["n_total"] = 46,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 10,
										["MISS"] = 1,
										["total"] = 46,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 8,
										["b_dmg"] = 11,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 168.006969,
							["start_time"] = 1709348635,
							["delay"] = 1709348646,
							["last_event"] = 1709348663,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 121,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 121,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["flag_original"] = 1304,
							["resource"] = 0.003416,
							["pets"] = {
							},
							["aID"] = "5818-00A9F3B5",
							["passiveover"] = 0.003416,
							["total"] = 9.003416,
							["spec"] = 71,
							["received"] = 9.003416,
							["targets"] = {
								["Rattangkor"] = 9,
							},
							["powertype"] = 1,
							["alternatepower"] = 0.003416,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[100] = {
										["total"] = 9,
										["id"] = 100,
										["totalover"] = 0,
										["targets"] = {
											["Rattangkor"] = 9,
										},
										["counter"] = 1,
									},
								},
							},
							["grupo"] = true,
							["classe"] = "WARRIOR",
							["last_event"] = 1709348642,
							["totalover"] = 0.003416,
							["serial"] = "Player-5818-00A9F3B5",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 121,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[772] = {
										["activedamt"] = -1,
										["id"] = 772,
										["targets"] = {
										},
										["actived_at"] = 1709348614,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 0,
							["pets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["classe"] = "WARRIOR",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["actived_at"] = 1709348607,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["debuff_uptime"] = 0,
							["serial"] = "Player-5818-00A9F3B5",
							["aID"] = "5818-00A9F3B5",
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["last_event"] = 1709348614,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 25,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 25,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348632,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 121,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Rattangkor"] = "Player-5818-00A9F3B5",
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
					"Rattangkor", -- [2]
				},
				["CombatStartedAt"] = 525081.18,
				["tempo_start"] = 1709348607,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					214, -- [1]
					0, -- [2]
					{
						9, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["Rattangkor"] = {
						{
							true, -- [1]
							1, -- [2]
							6, -- [3]
							1709348646.041, -- [4]
							0, -- [5]
							"Kul Tiras Sailor", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Rattangkor"] = {
						["Throw"] = 1,
						["Heroic Strike"] = 2,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "13:03:52",
				["hasTimer"] = 24.0350000000326,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["aura_timeline"] = {
				},
				["data_inicio"] = "13:03:27",
				["end_time"] = 525049.645,
				["combat_id"] = 121,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 1,
				},
				["combat_counter"] = 124,
				["totals_grupo"] = {
					168, -- [1]
					0, -- [2]
					{
						9, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Rattangkor"] = 140.004676,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 525024.595,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [3]
			{
				{
					["combatId"] = 120,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 66834,
							["totalabsorbed"] = 0.002073,
							["pets"] = {
							},
							["classe"] = "WARRIOR",
							["total_without_pet"] = 172.002073,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 172.002073,
							["spec"] = 71,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9F3B5",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 172,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A9F3B5",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348600,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kul Tiras Sailor"] = 99,
										},
										["n_total"] = 69,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 99,
										["c_max"] = 30,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 30,
										["successful_casted"] = 0,
										["c_total"] = 30,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[6343] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 18,
										["targets"] = {
											["Kul Tiras Sailor"] = 35,
										},
										["n_total"] = 35,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 35,
										["c_max"] = 0,
										["id"] = 6343,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[772] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Kul Tiras Sailor"] = 15,
										},
										["n_total"] = 15,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 15,
										["c_max"] = 0,
										["id"] = 772,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[78] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 23,
										["targets"] = {
											["Kul Tiras Sailor"] = 23,
										},
										["n_total"] = 23,
										["n_min"] = 23,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 23,
										["c_max"] = 0,
										["id"] = 78,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 10.67275210967936,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 91.002073,
							["start_time"] = 1709348584,
							["delay"] = 0,
							["last_event"] = 1709348606,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004413,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 101.004413,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 101.004413,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 101,
							},
							["colocacao"] = 2,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348600,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Sailor"] = 47,
										},
										["n_total"] = 47,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 47,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1776] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kul Tiras Sailor"] = 8,
										},
										["n_total"] = 8,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 8,
										["c_max"] = 0,
										["id"] = 1776,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kul Tiras Sailor"] = 29,
										},
										["n_total"] = 29,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 29,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kul Tiras Sailor"] = 17,
										},
										["n_total"] = 17,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 17,
										["c_max"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 6.267337614777903,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.004413,
							["start_time"] = 1709348592,
							["delay"] = 0,
							["last_event"] = 1709348600,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006462,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 91.006462,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 91.006462,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-0000629694",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Rattangkor"] = 91,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348600,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 26,
										["targets"] = {
											["Rattangkor"] = 91,
										},
										["n_total"] = 91,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 91,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 11,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[6268] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 6268,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 273.006462,
							["start_time"] = 1709348586,
							["delay"] = 0,
							["last_event"] = 1709348599,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 120,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 120,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["resource"] = 0.004595,
							["targets"] = {
								["Rattangkor"] = 9,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "WARRIOR",
							["passiveover"] = 0.004595,
							["alternatepower"] = 0.004595,
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["grupo"] = true,
							["received"] = 9.004595,
							["aID"] = "5818-00A9F3B5",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[100] = {
										["total"] = 9,
										["id"] = 100,
										["totalover"] = 0,
										["targets"] = {
											["Rattangkor"] = 9,
										},
										["counter"] = 1,
									},
								},
							},
							["last_event"] = 1709348605,
							["totalover"] = 0.004595,
							["total"] = 9.004595,
							["serial"] = "Player-5818-00A9F3B5",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 120,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 2632,
							["pets"] = {
							},
							["serial"] = "Creature-0-5154-1-106-3128-0000E295EA",
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["monster"] = true,
							["aID"] = "3128",
							["nome"] = "Kul Tiras Sailor",
							["last_event"] = 0,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 66834,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[6343] = {
										["activedamt"] = 0,
										["id"] = 6343,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[772] = {
										["activedamt"] = 0,
										["id"] = 772,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[7922] = {
										["activedamt"] = -1,
										["id"] = 7922,
										["targets"] = {
										},
										["actived_at"] = 1709348584,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["pets"] = {
							},
							["classe"] = "WARRIOR",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 15,
							["debuff_uptime_targets"] = {
							},
							["spec"] = 71,
							["cc_break"] = 1.001941,
							["cc_break_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[0] = {
										["cc_break_oque"] = {
											[1776] = 1,
										},
										["id"] = 0,
										["cc_break"] = 1,
										["targets"] = {
											["Kul Tiras Sailor"] = 1,
										},
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 16,
							["serial"] = "Player-5818-00A9F3B5",
							["tipo"] = 4,
							["nome"] = "Rattangkor",
							["aID"] = "5818-00A9F3B5",
							["cc_break_oque"] = {
								[1776] = 1,
							},
							["last_event"] = 1709348600,
							["cc_break_targets"] = {
								["Kul Tiras Sailor"] = 1,
							},
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
						}, -- [2]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1776] = {
										["activedamt"] = 0,
										["id"] = 1776,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 16,
							["cc_done_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1776] = {
										["id"] = 1776,
										["targets"] = {
											["Kul Tiras Sailor"] = 1,
										},
										["counter"] = 1,
									},
								},
							},
							["aID"] = "5818-00A98B51",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 2,
							["cc_done"] = 1.008966,
							["buff_uptime_targets"] = {
							},
							["spec"] = 260,
							["grupo"] = true,
							["cc_done_targets"] = {
								["Kul Tiras Sailor"] = 1,
							},
							["nome"] = "Poisongrace",
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["pets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-5818-00A98B51",
							["last_event"] = 1709348600,
						}, -- [3]
					},
				}, -- [4]
				{
					["combatId"] = 120,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Rattangkor"] = "Player-5818-00A9F3B5",
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
					"Rattangkor", -- [2]
				},
				["CombatStartedAt"] = 525010.479,
				["tempo_start"] = 1709348584,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					364, -- [1]
					0, -- [2]
					{
						9, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 1,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Kul Tiras Sailor"] = {
						["Rushing Charge"] = 1,
					},
					["Rattangkor"] = {
						["Rend"] = 1,
						["Thunder Clap"] = 1,
						["Heroic Strike"] = 1,
					},
					["Poisongrace"] = {
						["Gouge"] = 1,
						["Sinister Strike"] = 2,
						["Eviscerate"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "13:03:21",
				["hasTimer"] = 16.11600000003818,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 8.434000000008382,
				["CombatEndedAt"] = 525018.9130000001,
				["aura_timeline"] = {
				},
				["data_inicio"] = "13:03:05",
				["end_time"] = 525019.212,
				["combat_id"] = 120,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 2,
				},
				["combat_counter"] = 123,
				["totals_grupo"] = {
					273, -- [1]
					0, -- [2]
					{
						9, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 1,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Rattangkor"] = 172.002073,
							["Poisongrace"] = 101.004413,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 525003.096,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [4]
			{
				{
					["combatId"] = 119,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006671,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 81.006671,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 81.006671,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 81,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348577,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Kul Tiras Sailor"] = 20,
										},
										["n_total"] = 20,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 20,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kul Tiras Sailor"] = 30,
										},
										["n_total"] = 30,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 30,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 31,
										["targets"] = {
											["Kul Tiras Sailor"] = 31,
										},
										["n_total"] = 31,
										["n_min"] = 31,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 31,
										["c_max"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 6.723103245083099,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 15.006671,
							["start_time"] = 1709348569,
							["delay"] = 0,
							["last_event"] = 1709348572,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.008953,
							["pets"] = {
							},
							["classe"] = "WARRIOR",
							["total_without_pet"] = 64.00895299999999,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 64.00895299999999,
							["spec"] = 71,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9F3B5",
							["damage_from"] = {
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 64,
							},
							["colocacao"] = 2,
							["aID"] = "5818-00A9F3B5",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348577,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kul Tiras Sailor"] = 56,
										},
										["n_total"] = 56,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 56,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[2764] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kul Tiras Sailor"] = 8,
										},
										["n_total"] = 8,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 8,
										["c_max"] = 0,
										["id"] = 2764,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[772] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kul Tiras Sailor"] = 0,
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 772,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 5.312387169060083,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.008953,
							["start_time"] = 1709348565,
							["delay"] = 0,
							["last_event"] = 1709348575,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001598,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 15.001598,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 15.001598,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-0000E296BE",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 15,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348577,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Rattangkor"] = 0,
											["Poisongrace"] = 15,
										},
										["n_total"] = 15,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 15,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 145.001598,
							["start_time"] = 1709348570,
							["delay"] = 0,
							["last_event"] = 1709348572,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 119,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 119,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["flag_original"] = 66834,
							["resource"] = 0.007708,
							["pets"] = {
							},
							["aID"] = "5818-00A9F3B5",
							["passiveover"] = 0.007708,
							["total"] = 9.007708,
							["spec"] = 71,
							["received"] = 9.007708,
							["targets"] = {
								["Rattangkor"] = 9,
							},
							["powertype"] = 1,
							["alternatepower"] = 0.007708,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[100] = {
										["total"] = 9,
										["id"] = 100,
										["totalover"] = 0,
										["targets"] = {
											["Rattangkor"] = 9,
										},
										["counter"] = 1,
									},
								},
							},
							["grupo"] = true,
							["classe"] = "WARRIOR",
							["last_event"] = 1709348583,
							["totalover"] = 0.007708,
							["serial"] = "Player-5818-00A9F3B5",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 119,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[772] = {
										["activedamt"] = 0,
										["id"] = 772,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 12,
							["pets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["classe"] = "WARRIOR",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["debuff_uptime"] = 3,
							["serial"] = "Player-5818-00A9F3B5",
							["aID"] = "5818-00A9F3B5",
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["last_event"] = 1709348577,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 12,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348577,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 119,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Rattangkor"] = "Player-5818-00A9F3B5",
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
					"Rattangkor", -- [2]
				},
				["CombatStartedAt"] = 524987.431,
				["tempo_start"] = 1709348565,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					160, -- [1]
					0, -- [2]
					{
						9, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Rattangkor"] = {
						["Rend"] = 2,
					},
					["Poisongrace"] = {
						["Sinister Strike"] = 2,
						["Eviscerate"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "13:02:57",
				["hasTimer"] = 12.04899999999907,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 7.131999999983236,
				["CombatEndedAt"] = 524994.563,
				["aura_timeline"] = {
				},
				["data_inicio"] = "13:02:45",
				["end_time"] = 524995.296,
				["combat_id"] = 119,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 1,
				},
				["combat_counter"] = 122,
				["totals_grupo"] = {
					145, -- [1]
					0, -- [2]
					{
						9, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Rattangkor"] = 64.00895299999999,
							["Poisongrace"] = 81.006671,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524983.247,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [5]
			{
				{
					["combatId"] = 118,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007718,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 68.007718,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 68.007718,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 68,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348556,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Kul Tiras Sailor"] = 19,
										},
										["n_total"] = 19,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 19,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[399985] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kul Tiras Sailor"] = 17,
										},
										["n_total"] = 17,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 17,
										["c_max"] = 0,
										["id"] = 399985,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kul Tiras Sailor"] = 32,
										},
										["n_total"] = 32,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 32,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 9.623279751060403,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.007718,
							["start_time"] = 1709348552,
							["delay"] = 0,
							["last_event"] = 1709348554,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.007958,
							["pets"] = {
							},
							["classe"] = "WARRIOR",
							["total_without_pet"] = 47.007958,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 47.007958,
							["spec"] = 71,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9F3B5",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 47,
							},
							["colocacao"] = 2,
							["aID"] = "5818-00A9F3B5",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348556,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14,
										["targets"] = {
											["Kul Tiras Sailor"] = 42,
										},
										["n_total"] = 42,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 42,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[772] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Kul Tiras Sailor"] = 5,
										},
										["n_total"] = 5,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 5,
										["c_max"] = 0,
										["id"] = 772,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 6.6517557663102,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 4.007958,
							["start_time"] = 1709348549,
							["delay"] = 0,
							["last_event"] = 1709348553,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007317,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 4.007317,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 4.007317,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-000062961E",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Rattangkor"] = 4,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348556,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 4,
										["targets"] = {
											["Rattangkor"] = 4,
										},
										["n_total"] = 4,
										["n_min"] = 4,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 4,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 115.007317,
							["start_time"] = 1709348553,
							["delay"] = 0,
							["last_event"] = 1709348553,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 118,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 118,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 118,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[772] = {
										["activedamt"] = 0,
										["id"] = 772,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[7922] = {
										["activedamt"] = -1,
										["id"] = 7922,
										["targets"] = {
										},
										["actived_at"] = 1709348550,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["classe"] = "WARRIOR",
							["buff_uptime"] = 7,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["debuff_uptime"] = 5,
							["serial"] = "Player-5818-00A9F3B5",
							["aID"] = "5818-00A9F3B5",
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["last_event"] = 1709348556,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 10,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[1784] = {
										["activedamt"] = 1,
										["id"] = 1784,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348556,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 118,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Rattangkor"] = "Player-5818-00A9F3B5",
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
					"Rattangkor", -- [2]
				},
				["CombatStartedAt"] = 524970.546,
				["tempo_start"] = 1709348549,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					119, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Rattangkor"] = {
						["Rend"] = 1,
					},
					["Poisongrace"] = {
						["Sinister Strike"] = 2,
						["Shadowstrike"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "13:02:37",
				["hasTimer"] = 7.0669999999227,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 3.467000000062399,
				["CombatEndedAt"] = 524974.013,
				["aura_timeline"] = {
				},
				["data_inicio"] = "13:02:30",
				["end_time"] = 524974.948,
				["combat_id"] = 118,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 1,
				},
				["combat_counter"] = 121,
				["totals_grupo"] = {
					115, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Rattangkor"] = 47.007958,
							["Poisongrace"] = 68.007718,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524967.881,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [6]
			{
				{
					["combatId"] = 117,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006366,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 87.006366,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 87.006366,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 87,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348541,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Sailor"] = 53,
										},
										["n_total"] = 30,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 53,
										["c_max"] = 23,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 23,
										["successful_casted"] = 0,
										["c_total"] = 23,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kul Tiras Sailor"] = 34,
										},
										["n_total"] = 34,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 34,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 12.35885880675278,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 10.006366,
							["start_time"] = 1709348536,
							["delay"] = 0,
							["last_event"] = 1709348540,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.006946,
							["pets"] = {
							},
							["classe"] = "WARRIOR",
							["total_without_pet"] = 47.006946,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 47.006946,
							["spec"] = 71,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9F3B5",
							["damage_from"] = {
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 47,
							},
							["colocacao"] = 2,
							["aID"] = "5818-00A9F3B5",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348541,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kul Tiras Sailor"] = 42,
										},
										["n_total"] = 42,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 42,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[772] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Kul Tiras Sailor"] = 5,
										},
										["n_total"] = 5,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 5,
										["c_max"] = 0,
										["id"] = 772,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 6.677123011328304,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.006946,
							["start_time"] = 1709348534,
							["delay"] = 0,
							["last_event"] = 1709348539,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004172,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 10.004172,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 10.004172,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-0000E296B0",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 10,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348541,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6,
										["targets"] = {
											["Poisongrace"] = 10,
										},
										["n_total"] = 10,
										["n_min"] = 4,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 10,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 134.004172,
							["start_time"] = 1709348536,
							["delay"] = 0,
							["last_event"] = 1709348538,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 117,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 117,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["resource"] = 0.001955,
							["targets"] = {
								["Rattangkor"] = 9,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "WARRIOR",
							["passiveover"] = 0.001955,
							["alternatepower"] = 0.001955,
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["grupo"] = true,
							["received"] = 9.001955,
							["aID"] = "5818-00A9F3B5",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[100] = {
										["total"] = 9,
										["id"] = 100,
										["totalover"] = 0,
										["targets"] = {
											["Rattangkor"] = 9,
										},
										["counter"] = 1,
									},
								},
							},
							["last_event"] = 1709348549,
							["totalover"] = 0.001955,
							["total"] = 9.001955,
							["serial"] = "Player-5818-00A9F3B5",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 117,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[772] = {
										["activedamt"] = 0,
										["id"] = 772,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[7922] = {
										["activedamt"] = -1,
										["id"] = 7922,
										["targets"] = {
										},
										["actived_at"] = 1709348535,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 7,
							["pets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["classe"] = "WARRIOR",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["debuff_uptime"] = 5,
							["serial"] = "Player-5818-00A9F3B5",
							["aID"] = "5818-00A9F3B5",
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["last_event"] = 1709348541,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 7,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348541,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 117,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Rattangkor"] = "Player-5818-00A9F3B5",
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
					"Rattangkor", -- [2]
				},
				["CombatStartedAt"] = 524954.33,
				["tempo_start"] = 1709348534,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					144, -- [1]
					0, -- [2]
					{
						9, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Rattangkor"] = {
						["Rend"] = 1,
					},
					["Poisongrace"] = {
						["Sinister Strike"] = 2,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "13:02:22",
				["hasTimer"] = 6.033999999985099,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 5.066000000108033,
				["CombatEndedAt"] = 524959.3960000001,
				["aura_timeline"] = {
				},
				["data_inicio"] = "13:02:15",
				["end_time"] = 524959.687,
				["combat_id"] = 117,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 1,
				},
				["combat_counter"] = 120,
				["totals_grupo"] = {
					134, -- [1]
					0, -- [2]
					{
						9, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Rattangkor"] = 47.006946,
							["Poisongrace"] = 87.006366,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524952.647,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [7]
			{
				{
					["combatId"] = 116,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004275,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 109.004275,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 109.004275,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Marine"] = true,
							},
							["targets"] = {
								["Kul Tiras Marine"] = 109,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348530,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Marine"] = 43,
										},
										["n_total"] = 43,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 43,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1757] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kul Tiras Marine"] = 66,
										},
										["n_total"] = 34,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 66,
										["c_max"] = 32,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 32,
										["successful_casted"] = 0,
										["c_total"] = 32,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 18.06501077233497,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 13.004275,
							["start_time"] = 1709348524,
							["delay"] = 0,
							["last_event"] = 1709348529,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.002077,
							["pets"] = {
							},
							["classe"] = "WARRIOR",
							["total_without_pet"] = 24.002077,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 24.002077,
							["spec"] = 71,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9F3B5",
							["damage_from"] = {
								["Kul Tiras Marine"] = true,
							},
							["targets"] = {
								["Kul Tiras Marine"] = 24,
							},
							["colocacao"] = 2,
							["aID"] = "5818-00A9F3B5",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348530,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Kul Tiras Marine"] = 24,
										},
										["n_total"] = 24,
										["n_min"] = 12,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 24,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 3.97780527014572,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 7.002077,
							["start_time"] = 1709348525,
							["delay"] = 0,
							["last_event"] = 1709348527,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007135,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 20.007135,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 20.007135,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3129-0000E2961E",
							["aID"] = "3129",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Rattangkor"] = 7,
								["Poisongrace"] = 13,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348530,
							["nome"] = "Kul Tiras Marine",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Rattangkor"] = 7,
											["Poisongrace"] = 13,
										},
										["n_total"] = 20,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 20,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 133.007135,
							["start_time"] = 1709348524,
							["delay"] = 0,
							["last_event"] = 1709348528,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 116,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 116,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["resource"] = 0.006706,
							["targets"] = {
								["Rattangkor"] = 9,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "WARRIOR",
							["passiveover"] = 0.006706,
							["alternatepower"] = 0.006706,
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["grupo"] = true,
							["received"] = 9.006706,
							["aID"] = "5818-00A9F3B5",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[100] = {
										["total"] = 9,
										["id"] = 100,
										["totalover"] = 0,
										["targets"] = {
											["Rattangkor"] = 9,
										},
										["counter"] = 1,
									},
								},
							},
							["last_event"] = 1709348534,
							["totalover"] = 0.006706,
							["total"] = 9.006706,
							["serial"] = "Player-5818-00A9F3B5",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 116,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 6,
							["classe"] = "WARRIOR",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A9F3B5",
							["aID"] = "5818-00A9F3B5",
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["last_event"] = 1709348530,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 6,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348530,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 116,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Rattangkor"] = "Player-5818-00A9F3B5",
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
					"Rattangkor", -- [2]
				},
				["CombatStartedAt"] = 524942.698,
				["tempo_start"] = 1709348524,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					153, -- [1]
					0, -- [2]
					{
						9, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 3,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "13:02:11",
				["hasTimer"] = 5.033999999985099,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Marine",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 5.782000000006519,
				["CombatEndedAt"] = 524948.48,
				["aura_timeline"] = {
				},
				["data_inicio"] = "13:02:05",
				["end_time"] = 524948.53,
				["combat_id"] = 116,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Marine"] = 1,
				},
				["combat_counter"] = 119,
				["totals_grupo"] = {
					133, -- [1]
					0, -- [2]
					{
						9, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Rattangkor"] = 24.002077,
							["Poisongrace"] = 109.004275,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524942.496,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Marine",
			}, -- [8]
			{
				{
					["combatId"] = 115,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001612,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 102.001612,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 102.001612,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Marine"] = true,
							},
							["targets"] = {
								["Kul Tiras Marine"] = 102,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348498,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Kul Tiras Marine"] = 38,
										},
										["n_total"] = 38,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 38,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1776] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kul Tiras Marine"] = 8,
										},
										["n_total"] = 8,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 8,
										["c_max"] = 0,
										["id"] = 1776,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Kul Tiras Marine"] = 30,
										},
										["n_total"] = 30,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 30,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 26,
										["targets"] = {
											["Kul Tiras Marine"] = 26,
										},
										["n_total"] = 26,
										["n_min"] = 26,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 26,
										["c_max"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 10.13227495786066,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 27.001612,
							["start_time"] = 1709348488,
							["delay"] = 0,
							["last_event"] = 1709348496,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.0072,
							["pets"] = {
							},
							["classe"] = "WARRIOR",
							["total_without_pet"] = 38.0072,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 38.0072,
							["spec"] = 71,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9F3B5",
							["damage_from"] = {
								["Kul Tiras Marine"] = true,
							},
							["targets"] = {
								["Kul Tiras Marine"] = 38,
							},
							["colocacao"] = 2,
							["aID"] = "5818-00A9F3B5",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348498,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 13,
										["targets"] = {
											["Kul Tiras Marine"] = 38,
										},
										["n_total"] = 38,
										["n_min"] = 12,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 38,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[78] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kul Tiras Marine"] = 0,
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 78,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 3.775424654841744,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 10.0072,
							["start_time"] = 1709348489,
							["delay"] = 0,
							["last_event"] = 1709348496,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.003614,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 37.003614,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 37.003614,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3129-000062967D",
							["aID"] = "3129",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Rattangkor"] = 10,
								["Poisongrace"] = 27,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348498,
							["nome"] = "Kul Tiras Marine",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Rattangkor"] = 10,
											["Poisongrace"] = 27,
										},
										["n_total"] = 37,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 37,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 140.003614,
							["start_time"] = 1709348489,
							["delay"] = 0,
							["last_event"] = 1709348495,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 115,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 115,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 115,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1776] = {
										["activedamt"] = 0,
										["id"] = 1776,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["pets"] = {
							},
							["aID"] = "5818-00A98B51",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 10,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 1,
							["debuff_uptime_targets"] = {
							},
							["spec"] = 260,
							["cc_break"] = 1.004446,
							["cc_done_targets"] = {
								["Kul Tiras Marine"] = 1,
							},
							["cc_break_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["DEBUFF"] = {
										["cc_break_oque"] = {
											[1776] = 1,
										},
										["id"] = "DEBUFF",
										["cc_break"] = 1,
										["targets"] = {
											["Kul Tiras Marine"] = 1,
										},
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 10,
							["cc_done_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1776] = {
										["id"] = 1776,
										["targets"] = {
											["Kul Tiras Marine"] = 1,
										},
										["counter"] = 1,
									},
								},
							},
							["grupo"] = true,
							["classe"] = "ROGUE",
							["cc_done"] = 1.006592,
							["nome"] = "Poisongrace",
							["buff_uptime_targets"] = {
							},
							["cc_break_oque"] = {
								[1776] = 1,
							},
							["tipo"] = 4,
							["cc_break_targets"] = {
								["Kul Tiras Marine"] = 1,
							},
							["serial"] = "Player-5818-00A98B51",
							["last_event"] = 1709348498,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 10,
							["classe"] = "WARRIOR",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 10,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A9F3B5",
							["aID"] = "5818-00A9F3B5",
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["last_event"] = 1709348498,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 115,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Rattangkor"] = "Player-5818-00A9F3B5",
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
					"Rattangkor", -- [2]
				},
				["tempo_start"] = 1709348488,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					177, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 1,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Rattangkor"] = {
						["Heroic Strike"] = 1,
					},
					["Poisongrace"] = {
						["Sinister Strike"] = 3,
						["Eviscerate"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "13:01:38",
				["hasTimer"] = 10.0669999999227,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Marine",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 524915.632,
				["CombatEndedAt"] = 524915.632,
				["aura_timeline"] = {
				},
				["data_inicio"] = "13:01:28",
				["end_time"] = 524916.031,
				["combat_id"] = 115,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Marine"] = 1,
				},
				["combat_counter"] = 118,
				["totals_grupo"] = {
					140, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 1,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Rattangkor"] = 38.0072,
							["Poisongrace"] = 102.001612,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524905.964,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Marine",
			}, -- [9]
			{
				{
					["combatId"] = 114,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.005685,
							["pets"] = {
							},
							["classe"] = "WARRIOR",
							["total_without_pet"] = 86.005685,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 86.005685,
							["spec"] = 71,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9F3B5",
							["damage_from"] = {
								["Kul Tiras Marine"] = true,
							},
							["targets"] = {
								["Kul Tiras Marine"] = 86,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A9F3B5",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348488,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kul Tiras Marine"] = 53,
										},
										["n_total"] = 53,
										["n_min"] = 12,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 53,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[772] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Kul Tiras Marine"] = 10,
										},
										["n_total"] = 10,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 10,
										["c_max"] = 0,
										["id"] = 772,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[78] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 23,
										["targets"] = {
											["Kul Tiras Marine"] = 23,
										},
										["n_total"] = 23,
										["n_min"] = 23,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 23,
										["c_max"] = 0,
										["id"] = 78,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 10.72657582933031,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 26.005685,
							["start_time"] = 1709348444,
							["delay"] = 0,
							["last_event"] = 1709348487,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008714,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 61.008714,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 61.008714,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Marine"] = true,
							},
							["targets"] = {
								["Kul Tiras Marine"] = 61,
							},
							["colocacao"] = 2,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348452,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Kul Tiras Marine"] = 29,
										},
										["n_total"] = 29,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 29,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kul Tiras Marine"] = 32,
										},
										["n_total"] = 32,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 32,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 7.60896906955541,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 6.008714,
							["start_time"] = 1709348446,
							["delay"] = 0,
							["last_event"] = 1709348450,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004396,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 32.004396,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 32.004396,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3129-0000629078",
							["aID"] = "3129",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Rattangkor"] = 26,
								["Poisongrace"] = 6,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348488,
							["nome"] = "Kul Tiras Marine",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["Rattangkor"] = 26,
											["Poisongrace"] = 6,
										},
										["n_total"] = 32,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 32,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 147.004396,
							["start_time"] = 1709348444,
							["delay"] = 0,
							["last_event"] = 1709348487,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 114,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 114,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 114,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[772] = {
										["activedamt"] = 0,
										["id"] = 772,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 8,
							["pets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["classe"] = "WARRIOR",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["debuff_uptime"] = 6,
							["serial"] = "Player-5818-00A9F3B5",
							["aID"] = "5818-00A9F3B5",
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["last_event"] = 1709348452,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 8,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348452,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 114,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Rattangkor"] = "Player-5818-00A9F3B5",
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
					"Rattangkor", -- [2]
				},
				["CombatStartedAt"] = 524901.014,
				["tempo_start"] = 1709348444,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					179, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["Rattangkor"] = {
						{
							true, -- [1]
							1, -- [2]
							9, -- [3]
							1709348487.676, -- [4]
							222, -- [5]
							"Kul Tiras Marine", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Rattangkor"] = {
						["Heroic Strike"] = 1,
						["Rend"] = 1,
					},
					["Poisongrace"] = {
						["Sinister Strike"] = 3,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "13:00:52",
				["hasTimer"] = 7.016999999992549,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Marine",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 5.766999999992549,
				["CombatEndedAt"] = 524869.497,
				["aura_timeline"] = {
				},
				["data_inicio"] = "13:00:44",
				["end_time"] = 524869.648,
				["combat_id"] = 114,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Marine"] = 1,
				},
				["combat_counter"] = 117,
				["totals_grupo"] = {
					147, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Rattangkor"] = 73.005685,
							["Poisongrace"] = 61.008714,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524861.63,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Marine",
			}, -- [10]
			{
				{
					["combatId"] = 113,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003703,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 112.003703,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 112.003703,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Marine"] = true,
							},
							["targets"] = {
								["Kul Tiras Marine"] = 112,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348436,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Marine"] = 56,
										},
										["n_total"] = 56,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 56,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kul Tiras Marine"] = 29,
										},
										["n_total"] = 29,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 29,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 27,
										["targets"] = {
											["Kul Tiras Marine"] = 27,
										},
										["n_total"] = 27,
										["n_min"] = 27,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 27,
										["c_max"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 9.2565043801831,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 27.003703,
							["start_time"] = 1709348424,
							["delay"] = 0,
							["last_event"] = 1709348434,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.007872,
							["pets"] = {
							},
							["classe"] = "WARRIOR",
							["total_without_pet"] = 41.007872,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 41.007872,
							["spec"] = 71,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9F3B5",
							["damage_from"] = {
							},
							["targets"] = {
								["Kul Tiras Marine"] = 41,
							},
							["colocacao"] = 2,
							["aID"] = "5818-00A9F3B5",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348436,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14,
										["targets"] = {
											["Kul Tiras Marine"] = 41,
										},
										["n_total"] = 41,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 41,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 3.389080330585033,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.007872,
							["start_time"] = 1709348426,
							["delay"] = 0,
							["last_event"] = 1709348432,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.003289,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 27.003289,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 27.003289,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3129-000162961E",
							["aID"] = "3129",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 27,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348436,
							["nome"] = "Kul Tiras Marine",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Poisongrace"] = 27,
										},
										["n_total"] = 27,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 27,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 153.003289,
							["start_time"] = 1709348423,
							["delay"] = 0,
							["last_event"] = 1709348432,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 113,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 113,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["resource"] = 0.003206,
							["targets"] = {
								["Rattangkor"] = 9,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "WARRIOR",
							["passiveover"] = 0.003206,
							["alternatepower"] = 0.003206,
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["grupo"] = true,
							["received"] = 9.003206,
							["aID"] = "5818-00A9F3B5",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[100] = {
										["total"] = 9,
										["id"] = 100,
										["totalover"] = 0,
										["targets"] = {
											["Rattangkor"] = 9,
										},
										["counter"] = 1,
									},
								},
							},
							["last_event"] = 1709348443,
							["totalover"] = 0.003206,
							["total"] = 9.003206,
							["serial"] = "Player-5818-00A9F3B5",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 113,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[772] = {
										["activedamt"] = 0,
										["id"] = 772,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 13,
							["pets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["classe"] = "WARRIOR",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 13,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["debuff_uptime"] = 3,
							["serial"] = "Player-5818-00A9F3B5",
							["aID"] = "5818-00A9F3B5",
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["last_event"] = 1709348436,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 13,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 13,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348436,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 113,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Rattangkor"] = "Player-5818-00A9F3B5",
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
					"Rattangkor", -- [2]
				},
				["tempo_start"] = 1709348423,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					180, -- [1]
					0, -- [2]
					{
						9, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Rattangkor"] = {
						["Rend"] = 1,
					},
					["Poisongrace"] = {
						["Sinister Strike"] = 2,
						["Eviscerate"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "13:00:36",
				["hasTimer"] = 11.08400000003167,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Marine",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 524852.863,
				["CombatEndedAt"] = 524852.863,
				["aura_timeline"] = {
				},
				["data_inicio"] = "13:00:24",
				["end_time"] = 524853.647,
				["combat_id"] = 113,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Marine"] = 1,
				},
				["combat_counter"] = 116,
				["totals_grupo"] = {
					153, -- [1]
					0, -- [2]
					{
						9, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Rattangkor"] = 41.007872,
							["Poisongrace"] = 112.003703,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524841.547,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Marine",
			}, -- [11]
			{
				{
					["combatId"] = 112,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00669,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 201.00669,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 201.00669,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Marine"] = true,
								["Lieutenant Benedict"] = true,
							},
							["targets"] = {
								["Kul Tiras Marine"] = 88,
								["Lieutenant Benedict"] = 113,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348421,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["g_amt"] = 1,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Marine"] = 45,
											["Lieutenant Benedict"] = 67,
										},
										["n_total"] = 70,
										["n_min"] = 7,
										["g_dmg"] = 7,
										["counter"] = 12,
										["total"] = 112,
										["c_max"] = 19,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 16,
										["successful_casted"] = 0,
										["c_total"] = 35,
										["n_amt"] = 8,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[399985] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14,
										["targets"] = {
											["Kul Tiras Marine"] = 14,
										},
										["n_total"] = 14,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 14,
										["c_max"] = 0,
										["id"] = 399985,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kul Tiras Marine"] = 29,
											["Lieutenant Benedict"] = 39,
										},
										["n_total"] = 68,
										["a_amt"] = 0,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 8,
										["DODGE"] = 1,
										["total"] = 68,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1776] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Lieutenant Benedict"] = 7,
										},
										["n_total"] = 7,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 7,
										["c_max"] = 0,
										["id"] = 1776,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 6.887328764790712,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 42.00669,
							["start_time"] = 1709348397,
							["delay"] = 0,
							["last_event"] = 1709348420,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.003626,
							["pets"] = {
							},
							["classe"] = "WARRIOR",
							["total_without_pet"] = 144.003626,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 144.003626,
							["spec"] = 71,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9F3B5",
							["damage_from"] = {
								["Kul Tiras Marine"] = true,
								["Lieutenant Benedict"] = true,
							},
							["targets"] = {
								["Kul Tiras Marine"] = 75,
								["Lieutenant Benedict"] = 69,
							},
							["colocacao"] = 2,
							["aID"] = "5818-00A9F3B5",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348421,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14,
										["targets"] = {
											["Kul Tiras Marine"] = 67,
											["Lieutenant Benedict"] = 34,
										},
										["n_total"] = 101,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 101,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 8,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[2764] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kul Tiras Marine"] = 8,
										},
										["n_total"] = 8,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 8,
										["c_max"] = 0,
										["id"] = 2764,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[772] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Kul Tiras Marine"] = 0,
											["Lieutenant Benedict"] = 15,
										},
										["n_total"] = 15,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 15,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 772,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[78] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20,
										["targets"] = {
											["Lieutenant Benedict"] = 20,
										},
										["n_total"] = 20,
										["n_min"] = 20,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 20,
										["c_max"] = 0,
										["id"] = 78,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 4.934165701569254,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 30.003626,
							["start_time"] = 1709348392,
							["delay"] = 0,
							["last_event"] = 1709348421,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005382,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 38.005382,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 38.005382,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3192-0000629621",
							["aID"] = "3192",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Rattangkor"] = 7,
								["Poisongrace"] = 31,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348421,
							["nome"] = "Lieutenant Benedict",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Rattangkor"] = 7,
											["Poisongrace"] = 31,
										},
										["n_total"] = 38,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 6,
										["DODGE"] = 1,
										["total"] = 38,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[7164] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 7164,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 182.005382,
							["start_time"] = 1709348409,
							["delay"] = 0,
							["last_event"] = 1709348418,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.00307,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 34.00307,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 34.00307,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3129-000062961E",
							["aID"] = "3129",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Rattangkor"] = 23,
								["Poisongrace"] = 11,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348421,
							["nome"] = "Kul Tiras Marine",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Rattangkor"] = 23,
											["Poisongrace"] = 11,
										},
										["n_total"] = 34,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 34,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 163.00307,
							["start_time"] = 1709348412,
							["delay"] = 1709348404,
							["last_event"] = 1709348404,
						}, -- [4]
					},
				}, -- [1]
				{
					["combatId"] = 112,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 112,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 112,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[772] = {
										["activedamt"] = 0,
										["id"] = 772,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["pets"] = {
							},
							["aID"] = "5818-00A9F3B5",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 29,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 9,
							["buff_uptime_targets"] = {
							},
							["spec"] = 71,
							["cc_break"] = 1.008109,
							["cc_break_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[0] = {
										["cc_break_oque"] = {
											[1776] = 1,
										},
										["id"] = 0,
										["cc_break"] = 1,
										["targets"] = {
											["Lieutenant Benedict"] = 1,
										},
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 29,
							["debuff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["nome"] = "Rattangkor",
							["classe"] = "WARRIOR",
							["cc_break_oque"] = {
								[1776] = 1,
							},
							["last_event"] = 1709348421,
							["cc_break_targets"] = {
								["Lieutenant Benedict"] = 1,
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A9F3B5",
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1776] = {
										["activedamt"] = 0,
										["id"] = 1776,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 33,
							["cc_done_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1776] = {
										["id"] = 1776,
										["targets"] = {
											["Lieutenant Benedict"] = 1,
										},
										["counter"] = 1,
									},
								},
							},
							["aID"] = "5818-00A98B51",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 29,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[1784] = {
										["activedamt"] = 1,
										["id"] = 1784,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 1,
							["cc_done"] = 1.002265,
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["grupo"] = true,
							["cc_done_targets"] = {
								["Lieutenant Benedict"] = 1,
							},
							["buff_uptime_targets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["pets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-5818-00A98B51",
							["last_event"] = 1709348421,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["pets"] = {
							},
							["serial"] = "Creature-0-5154-1-106-3192-0000629621",
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["monster"] = true,
							["aID"] = "3192",
							["nome"] = "Lieutenant Benedict",
							["last_event"] = 0,
							["tipo"] = 4,
						}, -- [3]
					},
				}, -- [4]
				{
					["combatId"] = 112,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Rattangkor"] = "Player-5818-00A9F3B5",
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
					"Rattangkor", -- [2]
				},
				["CombatStartedAt"] = 524840.281,
				["tempo_start"] = 1709348392,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					417, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 1,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Gouge"] = 1,
						["Stealth"] = 1,
						["Sinister Strike"] = 8,
						["Shadowstrike"] = 1,
					},
					["Rattangkor"] = {
						["Heroic Strike"] = 1,
						["Rend"] = 2,
					},
					["Lieutenant Benedict"] = {
						["Defensive Stance"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "13:00:22",
				["hasTimer"] = 29.18499999993946,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Marine",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 24.18400000000838,
				["CombatEndedAt"] = 524839.898,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:59:53",
				["end_time"] = 524840.232,
				["combat_id"] = 112,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Marine"] = 1,
					["Lieutenant Benedict"] = 1,
				},
				["combat_counter"] = 115,
				["totals_grupo"] = {
					345, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 1,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Rattangkor"] = 144.003626,
							["Poisongrace"] = 201.00669,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524811.047,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Marine",
			}, -- [12]
			{
				{
					["combatId"] = 111,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.008469,
							["pets"] = {
							},
							["classe"] = "WARRIOR",
							["total_without_pet"] = 177.008469,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 177.008469,
							["spec"] = 71,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9F3B5",
							["damage_from"] = {
								["Kul Tiras Marine"] = true,
								["Lieutenant Benedict"] = true,
							},
							["targets"] = {
								["Kul Tiras Marine"] = 94,
								["Lieutenant Benedict"] = 83,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A9F3B5",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348382,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 2,
										["g_amt"] = 1,
										["n_max"] = 14,
										["targets"] = {
											["Kul Tiras Marine"] = 40,
											["Lieutenant Benedict"] = 69,
										},
										["n_total"] = 98,
										["n_min"] = 5,
										["g_dmg"] = 11,
										["counter"] = 10,
										["total"] = 109,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 9,
										["b_dmg"] = 11,
										["r_amt"] = 0,
									}, -- [1]
									[6343] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Kul Tiras Marine"] = 16,
											["Lieutenant Benedict"] = 14,
										},
										["n_total"] = 30,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 30,
										["c_max"] = 0,
										["id"] = 6343,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[772] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Kul Tiras Marine"] = 15,
										},
										["n_total"] = 15,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 15,
										["c_max"] = 0,
										["id"] = 772,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[78] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 23,
										["targets"] = {
											["Kul Tiras Marine"] = 23,
										},
										["n_total"] = 23,
										["n_min"] = 23,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 23,
										["c_max"] = 0,
										["id"] = 78,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 8.35615677667596,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 103.008469,
							["start_time"] = 1709348361,
							["delay"] = 0,
							["last_event"] = 1709348380,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002307,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 164.002307,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 164.002307,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
							},
							["targets"] = {
								["Kul Tiras Marine"] = 70,
								["Lieutenant Benedict"] = 94,
							},
							["colocacao"] = 2,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348382,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 1,
										["g_amt"] = 1,
										["n_max"] = 8,
										["targets"] = {
											["Kul Tiras Marine"] = 16,
											["Lieutenant Benedict"] = 49,
										},
										["n_total"] = 43,
										["n_min"] = 4,
										["g_dmg"] = 8,
										["counter"] = 9,
										["total"] = 65,
										["c_max"] = 14,
										["a_amt"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 14,
										["successful_casted"] = 0,
										["c_total"] = 14,
										["n_amt"] = 6,
										["b_dmg"] = 4,
										["r_amt"] = 0,
									}, -- [1]
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 1,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Kul Tiras Marine"] = 16,
											["Lieutenant Benedict"] = 45,
										},
										["n_total"] = 61,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 61,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 8,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kul Tiras Marine"] = 38,
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 38,
										["c_max"] = 38,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 38,
										["successful_casted"] = 0,
										["c_total"] = 38,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 7.742166218208131,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.002307,
							["start_time"] = 1709348365,
							["delay"] = 0,
							["last_event"] = 1709348381,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006629,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 67.006629,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 67.006629,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3129-000062905E",
							["aID"] = "3129",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Rattangkor"] = 67,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348382,
							["nome"] = "Kul Tiras Marine",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["Rattangkor"] = 67,
										},
										["n_total"] = 67,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 10,
										["DODGE"] = 1,
										["total"] = 67,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 8,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 164.006629,
							["start_time"] = 1709348362,
							["delay"] = 0,
							["last_event"] = 1709348380,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006285,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 36.006285,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 36.006285,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3192-0000628EF6",
							["aID"] = "3192",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Rattangkor"] = 36,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348382,
							["nome"] = "Lieutenant Benedict",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Rattangkor"] = 36,
										},
										["n_total"] = 36,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 36,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[7164] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 7164,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[3248] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 3248,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 177.006285,
							["start_time"] = 1709348373,
							["delay"] = 1709348370,
							["last_event"] = 1709348370,
						}, -- [4]
					},
				}, -- [1]
				{
					["combatId"] = 111,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 111,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 111,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[6343] = {
										["activedamt"] = 0,
										["id"] = 6343,
										["targets"] = {
										},
										["uptime"] = 10,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[7922] = {
										["activedamt"] = -1,
										["id"] = 7922,
										["targets"] = {
										},
										["actived_at"] = 1709348361,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[772] = {
										["activedamt"] = 0,
										["id"] = 772,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["classe"] = "WARRIOR",
							["buff_uptime"] = 31,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 21,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[26635] = {
										["activedamt"] = 1,
										["id"] = 26635,
										["targets"] = {
										},
										["uptime"] = 10,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["debuff_uptime"] = 19,
							["serial"] = "Player-5818-00A9F3B5",
							["aID"] = "5818-00A9F3B5",
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["last_event"] = 1709348382,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 21,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 21,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348382,
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["serial"] = "Creature-0-5154-1-106-3192-0000628EF6",
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["monster"] = true,
							["aID"] = "3192",
							["nome"] = "Lieutenant Benedict",
							["last_event"] = 0,
							["tipo"] = 4,
						}, -- [3]
					},
				}, -- [4]
				{
					["combatId"] = 111,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Rattangkor"] = "Player-5818-00A9F3B5",
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
					"Rattangkor", -- [2]
				},
				["CombatStartedAt"] = 524783.498,
				["tempo_start"] = 1709348361,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					444, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 5,
						["Eviscerate"] = 1,
					},
					["Rattangkor"] = {
						["Heroic Strike"] = 1,
						["Thunder Clap"] = 1,
						["Rend"] = 1,
						["Berserking"] = 1,
					},
					["Lieutenant Benedict"] = {
						["Improved Blocking"] = 1,
						["Defensive Stance"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:59:43",
				["hasTimer"] = 21.18299999996088,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Lieutenant Benedict",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 16.31599999999162,
				["CombatEndedAt"] = 524799.814,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:59:22",
				["end_time"] = 524800.647,
				["combat_id"] = 111,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Marine"] = 1,
					["Lieutenant Benedict"] = 1,
				},
				["combat_counter"] = 114,
				["totals_grupo"] = {
					341, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Rattangkor"] = 177.008469,
							["Poisongrace"] = 164.002307,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524779.464,
				["TimeData"] = {
				},
				["contra"] = "Lieutenant Benedict",
			}, -- [13]
			{
				{
					["combatId"] = 110,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007656,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 136.007656,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 136.007656,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Marine"] = true,
							},
							["targets"] = {
								["Kul Tiras Marine"] = 136,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348355,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["Kul Tiras Marine"] = 34,
										},
										["n_total"] = 17,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 34,
										["c_max"] = 17,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 17,
										["successful_casted"] = 0,
										["c_total"] = 17,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1776] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kul Tiras Marine"] = 0,
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = 1776,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kul Tiras Marine"] = 48,
										},
										["n_total"] = 15,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 48,
										["c_max"] = 33,
										["MISS"] = 1,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 33,
										["successful_casted"] = 0,
										["c_total"] = 33,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kul Tiras Marine"] = 54,
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 54,
										["c_max"] = 54,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 54,
										["successful_casted"] = 0,
										["c_total"] = 54,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 11.26823993376779,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 9.007656,
							["start_time"] = 1709348349,
							["delay"] = 0,
							["last_event"] = 1709348353,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.008049,
							["pets"] = {
							},
							["classe"] = "WARRIOR",
							["total_without_pet"] = 46.008049,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 46.008049,
							["spec"] = 71,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9F3B5",
							["damage_from"] = {
								["Kul Tiras Marine"] = true,
							},
							["targets"] = {
								["Kul Tiras Marine"] = 46,
							},
							["colocacao"] = 2,
							["aID"] = "5818-00A9F3B5",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348355,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 13,
										["targets"] = {
											["Kul Tiras Marine"] = 38,
										},
										["n_total"] = 38,
										["n_min"] = 12,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 38,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[2764] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kul Tiras Marine"] = 8,
										},
										["n_total"] = 8,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 8,
										["c_max"] = 0,
										["id"] = 2764,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 3.811768765550559,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 13.008049,
							["start_time"] = 1709348343,
							["delay"] = 0,
							["last_event"] = 1709348351,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005309,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 22.005309,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 22.005309,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3129-0000628FDC",
							["aID"] = "3129",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Rattangkor"] = 13,
								["Poisongrace"] = 9,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348355,
							["nome"] = "Kul Tiras Marine",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 1,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["Rattangkor"] = 13,
											["Poisongrace"] = 9,
										},
										["n_total"] = 22,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 22,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 6,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 182.005309,
							["start_time"] = 1709348346,
							["delay"] = 0,
							["last_event"] = 1709348352,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 110,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 110,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["resource"] = 0.007024,
							["targets"] = {
								["Rattangkor"] = 9,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "WARRIOR",
							["passiveover"] = 0.007024,
							["alternatepower"] = 0.007024,
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["grupo"] = true,
							["received"] = 9.007024,
							["aID"] = "5818-00A9F3B5",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									[100] = {
										["total"] = 9,
										["id"] = 100,
										["totalover"] = 0,
										["targets"] = {
											["Rattangkor"] = 9,
										},
										["counter"] = 1,
									},
								},
							},
							["last_event"] = 1709348360,
							["totalover"] = 0.007024,
							["total"] = 9.007024,
							["serial"] = "Player-5818-00A9F3B5",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 110,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[772] = {
										["activedamt"] = 0,
										["id"] = 772,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 12,
							["pets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["classe"] = "WARRIOR",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["debuff_uptime"] = 2,
							["serial"] = "Player-5818-00A9F3B5",
							["aID"] = "5818-00A9F3B5",
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["last_event"] = 1709348355,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 12,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348355,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 110,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Rattangkor"] = "Player-5818-00A9F3B5",
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
					"Rattangkor", -- [2]
				},
				["CombatStartedAt"] = 524766.198,
				["tempo_start"] = 1709348343,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					204, -- [1]
					0, -- [2]
					{
						9, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Rattangkor"] = {
						["Rend"] = 1,
					},
					["Poisongrace"] = {
						["Gouge"] = 1,
						["Sinister Strike"] = 3,
						["Eviscerate"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:59:16",
				["hasTimer"] = 12.06999999994878,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Marine",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 6.898000000044704,
				["CombatEndedAt"] = 524773.096,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:59:04",
				["end_time"] = 524773.583,
				["combat_id"] = 110,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Marine"] = 1,
				},
				["combat_counter"] = 113,
				["totals_grupo"] = {
					182, -- [1]
					0, -- [2]
					{
						9, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Rattangkor"] = 46.008049,
							["Poisongrace"] = 136.007656,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524761.513,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Marine",
			}, -- [14]
			{
				{
					["combatId"] = 109,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002249,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 116.002249,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 116.002249,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
							},
							["targets"] = {
								["Kul Tiras Marine"] = 116,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348330,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 1,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["Kul Tiras Marine"] = 45,
										},
										["n_total"] = 27,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 45,
										["c_max"] = 18,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 18,
										["successful_casted"] = 0,
										["c_total"] = 18,
										["n_amt"] = 4,
										["b_dmg"] = 3,
										["r_amt"] = 0,
									}, -- [1]
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kul Tiras Marine"] = 44,
										},
										["n_total"] = 44,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 44,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 27,
										["targets"] = {
											["Kul Tiras Marine"] = 27,
										},
										["n_total"] = 27,
										["n_min"] = 27,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 27,
										["c_max"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 12.76995255389648,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.002249,
							["start_time"] = 1709348323,
							["delay"] = 0,
							["last_event"] = 1709348329,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.00233,
							["pets"] = {
							},
							["classe"] = "WARRIOR",
							["total_without_pet"] = 45.00233,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 45.00233,
							["spec"] = 71,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9F3B5",
							["damage_from"] = {
							},
							["targets"] = {
								["Kul Tiras Marine"] = 45,
							},
							["colocacao"] = 2,
							["aID"] = "5818-00A9F3B5",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348330,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14,
										["targets"] = {
											["Kul Tiras Marine"] = 40,
										},
										["n_total"] = 14,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 4,
										["DODGE"] = 1,
										["total"] = 40,
										["c_max"] = 26,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 26,
										["successful_casted"] = 0,
										["c_total"] = 26,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[772] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Kul Tiras Marine"] = 5,
										},
										["n_total"] = 5,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 5,
										["c_max"] = 0,
										["id"] = 772,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 4.954021356213467,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.00233,
							["start_time"] = 1709348321,
							["delay"] = 0,
							["last_event"] = 1709348328,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006564,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 0.006564,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 0.006564,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3129-0000629005",
							["aID"] = "3129",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348330,
							["nome"] = "Kul Tiras Marine",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Rattangkor"] = 0,
											["Poisongrace"] = 0,
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 4,
										["DODGE"] = 2,
										["total"] = 0,
										["c_max"] = 0,
										["MISS"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 161.006564,
							["start_time"] = 1709348330,
							["delay"] = 0,
							["last_event"] = 1709348329,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 109,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 109,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 109,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[772] = {
										["activedamt"] = 0,
										["id"] = 772,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 9,
							["pets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["classe"] = "WARRIOR",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["debuff_uptime"] = 5,
							["serial"] = "Player-5818-00A9F3B5",
							["aID"] = "5818-00A9F3B5",
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["last_event"] = 1709348330,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 9,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348330,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 109,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Rattangkor"] = "Player-5818-00A9F3B5",
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
					"Rattangkor", -- [2]
				},
				["CombatStartedAt"] = 524741.098,
				["tempo_start"] = 1709348321,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					161, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Rattangkor"] = {
						["Rend"] = 1,
					},
					["Poisongrace"] = {
						["Sinister Strike"] = 4,
						["Eviscerate"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:58:51",
				["hasTimer"] = 9.084000000031665,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Marine",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 7.699000000022352,
				["CombatEndedAt"] = 524748.797,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:58:42",
				["end_time"] = 524748.8640000001,
				["combat_id"] = 109,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Marine"] = 1,
				},
				["combat_counter"] = 112,
				["totals_grupo"] = {
					161, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Rattangkor"] = 45.00233,
							["Poisongrace"] = 116.002249,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524739.78,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Marine",
			}, -- [15]
			{
				{
					["combatId"] = 108,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.00802,
							["pets"] = {
							},
							["classe"] = "WARRIOR",
							["total_without_pet"] = 274.00802,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 274.00802,
							["spec"] = 71,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9F3B5",
							["damage_from"] = {
								["Kul Tiras Marine"] = true,
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Marine"] = 230,
								["Kul Tiras Sailor"] = 44,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A9F3B5",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348294,
							["nome"] = "Rattangkor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 1,
										["g_amt"] = 0,
										["n_max"] = 14,
										["targets"] = {
											["Kul Tiras Marine"] = 141,
											["Kul Tiras Sailor"] = 27,
										},
										["n_total"] = 168,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 168,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 13,
										["b_dmg"] = 9,
										["r_amt"] = 0,
									}, -- [1]
									[6343] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kul Tiras Marine"] = 17,
											["Kul Tiras Sailor"] = 17,
										},
										["n_total"] = 34,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 34,
										["c_max"] = 0,
										["id"] = 6343,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[772] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Kul Tiras Marine"] = 25,
										},
										["n_total"] = 25,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 25,
										["c_max"] = 0,
										["id"] = 772,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[78] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kul Tiras Marine"] = 47,
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 47,
										["c_max"] = 47,
										["id"] = 78,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 47,
										["successful_casted"] = 0,
										["c_total"] = 47,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 8.249278058763158,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 60.00802,
							["start_time"] = 1709348261,
							["delay"] = 0,
							["last_event"] = 1709348292,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007613,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 155.007613,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 155.007613,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Marine"] = true,
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Marine"] = 66,
								["Kul Tiras Sailor"] = 89,
							},
							["colocacao"] = 2,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348294,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 1,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Marine"] = 20,
											["Kul Tiras Sailor"] = 60,
										},
										["n_total"] = 64,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 80,
										["c_max"] = 16,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 16,
										["successful_casted"] = 0,
										["c_total"] = 16,
										["n_amt"] = 7,
										["b_dmg"] = 7,
										["r_amt"] = 0,
									}, -- [1]
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Kul Tiras Marine"] = 46,
											["Kul Tiras Sailor"] = 29,
										},
										["n_total"] = 75,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 75,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 4.666655015653012,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 110.007613,
							["start_time"] = 1709348275,
							["delay"] = 1709348279,
							["last_event"] = 1709348279,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.003347,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 107.003347,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 107.003347,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3129-0000628F5F",
							["aID"] = "3129",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Rattangkor"] = 41,
								["Poisongrace"] = 66,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348294,
							["nome"] = "Kul Tiras Marine",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Rattangkor"] = 41,
											["Poisongrace"] = 66,
										},
										["n_total"] = 107,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 14,
										["MISS"] = 1,
										["total"] = 107,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 12,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 296.003347,
							["start_time"] = 1709348261,
							["delay"] = 0,
							["last_event"] = 1709348321,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004702,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 63.004702,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 63.004702,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-0000628F5A",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Rattangkor"] = 19,
								["Poisongrace"] = 44,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348294,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 30,
										["targets"] = {
											["Rattangkor"] = 19,
											["Poisongrace"] = 44,
										},
										["n_total"] = 63,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 63,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[6268] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 6268,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 133.004702,
							["start_time"] = 1709348283,
							["delay"] = 1709348273,
							["last_event"] = 1709348273,
						}, -- [4]
					},
				}, -- [1]
				{
					["combatId"] = 108,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 108,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 108,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 2632,
							["pets"] = {
							},
							["serial"] = "Creature-0-5154-1-106-3128-0000628F5A",
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["monster"] = true,
							["aID"] = "3128",
							["nome"] = "Kul Tiras Sailor",
							["last_event"] = 0,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[772] = {
										["activedamt"] = 0,
										["id"] = 772,
										["targets"] = {
										},
										["uptime"] = 18,
										["appliedamt"] = 3,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[6343] = {
										["activedamt"] = 0,
										["id"] = 6343,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 33,
							["aID"] = "5818-00A9F3B5",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 33,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 22,
							["nome"] = "Rattangkor",
							["spec"] = 71,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["tipo"] = 4,
							["classe"] = "WARRIOR",
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-5818-00A9F3B5",
							["last_event"] = 1709348294,
						}, -- [2]
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["serial"] = "Player-5818-00A98B51",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 33,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[23234] = {
										["activedamt"] = 1,
										["id"] = 23234,
										["targets"] = {
										},
										["actived_at"] = 1709348261,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 33,
							["grupo"] = true,
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348294,
							["tipo"] = 4,
						}, -- [3]
					},
				}, -- [4]
				{
					["combatId"] = 108,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Rattangkor"] = "Player-5818-00A9F3B5",
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
					"Rattangkor", -- [2]
				},
				["tempo_start"] = 1709348261,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					599, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 4,
					},
					["Kul Tiras Sailor"] = {
						["Rushing Charge"] = 1,
					},
					["Rattangkor"] = {
						["Rend"] = 3,
						["Thunder Clap"] = 1,
						["Heroic Strike"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:58:14",
				["hasTimer"] = 32.2160000000149,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Marine",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 524710.731,
				["CombatEndedAt"] = 524710.731,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:57:41",
				["end_time"] = 524711.947,
				["combat_id"] = 108,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Marine"] = 2,
					["Kul Tiras Sailor"] = 1,
				},
				["combat_counter"] = 111,
				["totals_grupo"] = {
					429, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Rattangkor"] = 274.00802,
							["Poisongrace"] = 155.007613,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524678.731,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Marine",
			}, -- [16]
			{
				{
					["combatId"] = 107,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00525,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 287.00525,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 287.00525,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Marine"] = true,
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Marine"] = 182,
								["Kul Tiras Sailor"] = 105,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 105,
								[64] = 164,
							},
							["end_time"] = 1709348261,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 1,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Marine"] = 75,
											["Kul Tiras Sailor"] = 40,
										},
										["n_total"] = 86,
										["n_min"] = 8,
										["g_dmg"] = 10,
										["counter"] = 12,
										["total"] = 115,
										["c_max"] = 19,
										["a_amt"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 19,
										["successful_casted"] = 0,
										["c_total"] = 19,
										["n_amt"] = 9,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[399985] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 18,
										["targets"] = {
											["Kul Tiras Marine"] = 18,
											["Kul Tiras Sailor"] = 15,
										},
										["n_total"] = 33,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 33,
										["c_max"] = 0,
										["id"] = 399985,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kul Tiras Marine"] = 89,
											["Kul Tiras Sailor"] = 50,
										},
										["n_total"] = 72,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 139,
										["c_max"] = 35,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 32,
										["successful_casted"] = 0,
										["c_total"] = 67,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 10.50647032986097,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 77.00525,
							["start_time"] = 1709348225,
							["delay"] = 0,
							["last_event"] = 1709348261,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001073,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 53.001073,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 53.001073,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3129-0000628FCC",
							["aID"] = "3129",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 53,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348261,
							["nome"] = "Kul Tiras Marine",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Poisongrace"] = 53,
										},
										["n_total"] = 53,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 8,
										["MISS"] = 1,
										["total"] = 53,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 182.001073,
							["start_time"] = 1709348238,
							["delay"] = 0,
							["last_event"] = 1709348260,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001227,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 42.001227,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 42.001227,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-0000628F5F",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Rattangkor"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Rattangkor"] = 18,
								["Poisongrace"] = 24,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348252,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 24,
										["targets"] = {
											["Rattangkor"] = 18,
											["Poisongrace"] = 24,
										},
										["n_total"] = 42,
										["n_min"] = 4,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 42,
										["c_max"] = 0,
										["DODGE"] = 3,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[6268] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 6268,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 233.001227,
							["start_time"] = 1709348237,
							["delay"] = 1709348241,
							["last_event"] = 1709348241,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 107,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 107,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 107,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 27,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 27,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[23234] = {
										["activedamt"] = 0,
										["id"] = 23234,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348252,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["pets"] = {
							},
							["serial"] = "Creature-0-5154-1-106-3128-0000628F93",
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["monster"] = true,
							["aID"] = "3128",
							["nome"] = "Kul Tiras Sailor",
							["last_event"] = 0,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 107,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 524677.732,
				["tempo_start"] = 1709348225,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					510, -- [1]
					0, -- [2]
					{
						18, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["Poisongrace"] = {
						{
							true, -- [1]
							1, -- [2]
							10, -- [3]
							1709348260.111, -- [4]
							143, -- [5]
							"Kul Tiras Marine", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Kul Tiras Sailor"] = {
						["Rushing Charge"] = 1,
					},
					["Poisongrace"] = {
						["Sinister Strike"] = 7,
						["Blood Fury"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:57:32",
				["hasTimer"] = 27.16599999996834,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 27.3169999999227,
				["CombatEndedAt"] = 524669.899,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:57:05",
				["end_time"] = 524669.899,
				["combat_id"] = 107,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Marine"] = 1,
					["Kul Tiras Sailor"] = 2,
				},
				["combat_counter"] = 110,
				["totals_grupo"] = {
					287, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 269.00525,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524642.582,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [17]
			{
				{
					["combatId"] = 106,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006457,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 145.006457,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 145.006457,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 145,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 145,
							},
							["end_time"] = 1709348217,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Kul Tiras Sailor"] = 85,
										},
										["n_total"] = 47,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 85,
										["c_max"] = 19,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 19,
										["successful_casted"] = 0,
										["c_total"] = 38,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[399985] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14,
										["targets"] = {
											["Kul Tiras Sailor"] = 14,
										},
										["n_total"] = 14,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 14,
										["c_max"] = 0,
										["id"] = 399985,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Kul Tiras Sailor"] = 46,
										},
										["n_total"] = 46,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 46,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 11.32862945308379,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 52.006457,
							["start_time"] = 1709348204,
							["delay"] = 0,
							["last_event"] = 1709348215,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.004982,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 52.004982,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 52.004982,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-0000628F98",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 52,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348225,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 24,
										["targets"] = {
											["Poisongrace"] = 52,
										},
										["n_total"] = 52,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 52,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 145.004982,
							["start_time"] = 1709348206,
							["delay"] = 0,
							["last_event"] = 1709348225,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 106,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 106,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 106,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 13,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 13,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348217,
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 106,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 524622.732,
				["tempo_start"] = 1709348204,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					197, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["Poisongrace"] = {
						{
							true, -- [1]
							1, -- [2]
							24, -- [3]
							1709348224.961, -- [4]
							194, -- [5]
							"Kul Tiras Sailor", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 4,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:56:58",
				["hasTimer"] = 12.06700000003912,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 12.80000000004657,
				["CombatEndedAt"] = 524635.532,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:56:45",
				["end_time"] = 524635.532,
				["combat_id"] = 106,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 1,
				},
				["combat_counter"] = 109,
				["totals_grupo"] = {
					145, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 145.006457,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524622.732,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [18]
			{
				{
					["combatId"] = 105,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00464,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 112.00464,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 112.00464,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 112,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 17,
							},
							["end_time"] = 1709348183,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Sailor"] = 21,
										},
										["n_total"] = 21,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 21,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[399985] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kul Tiras Sailor"] = 17,
										},
										["n_total"] = 17,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 17,
										["c_max"] = 0,
										["id"] = 399985,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Kul Tiras Sailor"] = 32,
										},
										["n_total"] = 32,
										["n_min"] = 16,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 32,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 42,
										["targets"] = {
											["Kul Tiras Sailor"] = 42,
										},
										["n_total"] = 42,
										["n_min"] = 42,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 42,
										["c_max"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 17.27933353913792,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 11.00464,
							["start_time"] = 1709348176,
							["delay"] = 0,
							["last_event"] = 1709348181,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.003272,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 11.003272,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 11.003272,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-0000629124",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 11,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348183,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6,
										["targets"] = {
											["Poisongrace"] = 11,
										},
										["n_total"] = 11,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 11,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 112.003272,
							["start_time"] = 1709348178,
							["delay"] = 0,
							["last_event"] = 1709348204,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 105,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 105,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 105,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 7,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348183,
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 105,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["tempo_start"] = 1709348176,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					123, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 2,
						["Eviscerate"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:56:24",
				["hasTimer"] = 6.030999999959022,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 524601.498,
				["CombatEndedAt"] = 524601.498,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:56:17",
				["end_time"] = 524601.498,
				["combat_id"] = 105,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 1,
				},
				["combat_counter"] = 108,
				["totals_grupo"] = {
					112, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 112.00464,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524595.0160000001,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [19]
			{
				{
					["combatId"] = 104,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004297,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 155.004297,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 155.004297,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 155,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 155,
							},
							["end_time"] = 1709348165,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Sailor"] = 69,
										},
										["n_total"] = 69,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 69,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 7,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[399985] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14,
										["targets"] = {
											["Kul Tiras Sailor"] = 14,
										},
										["n_total"] = 14,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 14,
										["c_max"] = 0,
										["id"] = 399985,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kul Tiras Sailor"] = 72,
										},
										["n_total"] = 43,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 72,
										["c_max"] = 29,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 29,
										["successful_casted"] = 0,
										["c_total"] = 29,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 13.1549093610134,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 21.004297,
							["start_time"] = 1709348153,
							["delay"] = 0,
							["last_event"] = 1709348163,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.008906,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 21.008906,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 21.008906,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-00006292D0",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 21,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348165,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Poisongrace"] = 21,
										},
										["n_total"] = 21,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 6,
										["MISS"] = 1,
										["total"] = 21,
										["c_max"] = 0,
										["DODGE"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 155.008906,
							["start_time"] = 1709348157,
							["delay"] = 0,
							["last_event"] = 1709348176,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 104,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 104,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 104,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 12,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348165,
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 104,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 524595.0160000001,
				["tempo_start"] = 1709348153,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					176, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 4,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:56:05",
				["hasTimer"] = 11.05099999997765,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 524583.331,
				["CombatEndedAt"] = 524583.331,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:55:54",
				["end_time"] = 524583.331,
				["combat_id"] = 104,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 1,
				},
				["combat_counter"] = 107,
				["totals_grupo"] = {
					155, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 155.004297,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524571.5480000001,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [20]
			{
				{
					["combatId"] = 103,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007326,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 258.007326,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 258.007326,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 258,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 258,
							},
							["end_time"] = 1709348114,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Kul Tiras Sailor"] = 128,
										},
										["n_total"] = 110,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 128,
										["c_max"] = 18,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 18,
										["successful_casted"] = 0,
										["c_total"] = 18,
										["n_amt"] = 11,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[2764] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Sailor"] = 11,
										},
										["n_total"] = 11,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 11,
										["c_max"] = 0,
										["id"] = 2764,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20,
										["targets"] = {
											["Kul Tiras Sailor"] = 50,
										},
										["n_total"] = 20,
										["n_min"] = 20,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 50,
										["c_max"] = 30,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 30,
										["successful_casted"] = 0,
										["c_total"] = 30,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kul Tiras Sailor"] = 60,
										},
										["n_total"] = 60,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 60,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1776] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["Kul Tiras Sailor"] = 9,
										},
										["n_total"] = 9,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 9,
										["c_max"] = 0,
										["id"] = 1776,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 8.487083092098764,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 67.007326,
							["start_time"] = 1709348083,
							["delay"] = 0,
							["last_event"] = 1709348113,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.004354,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 67.004354,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 67.004354,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-00006290DB",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 67,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348114,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 30,
										["targets"] = {
											["Poisongrace"] = 67,
										},
										["n_total"] = 67,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 16,
										["MISS"] = 1,
										["total"] = 67,
										["c_max"] = 0,
										["DODGE"] = 8,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 7,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[6268] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 6268,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 258.004354,
							["start_time"] = 1709348085,
							["delay"] = 0,
							["last_event"] = 1709348153,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 103,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 103,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 103,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 2632,
							["pets"] = {
							},
							["serial"] = "Creature-0-5154-1-106-3128-0000629168",
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["monster"] = true,
							["aID"] = "3128",
							["nome"] = "Kul Tiras Sailor",
							["last_event"] = 0,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1776] = {
										["activedamt"] = 0,
										["id"] = 1776,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 45,
							["cc_done_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1776] = {
										["id"] = 1776,
										["targets"] = {
											["Kul Tiras Sailor"] = 1,
										},
										["counter"] = 1,
									},
								},
							},
							["aID"] = "5818-00A98B51",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 31,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[5277] = {
										["activedamt"] = 1,
										["id"] = 5277,
										["targets"] = {
										},
										["uptime"] = 14,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 4,
							["cc_done"] = 1.00728,
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["grupo"] = true,
							["cc_done_targets"] = {
								["Kul Tiras Sailor"] = 1,
							},
							["buff_uptime_targets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["pets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-5818-00A98B51",
							["last_event"] = 1709348114,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 103,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 524571.5480000001,
				["tempo_start"] = 1709348083,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					325, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Gouge"] = 1,
						["Evasion"] = 1,
						["Sinister Strike"] = 4,
						["Eviscerate"] = 2,
					},
					["Kul Tiras Sailor"] = {
						["Rushing Charge"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:55:14",
				["hasTimer"] = 30.15000000002328,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 524531.832,
				["CombatEndedAt"] = 524531.832,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:54:44",
				["end_time"] = 524531.832,
				["combat_id"] = 103,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 2,
				},
				["combat_counter"] = 106,
				["totals_grupo"] = {
					258, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 258.007326,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524501.432,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [21]
			{
				{
					["combatId"] = 102,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008883,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 153.008883,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 153.008883,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 153,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 153,
							},
							["end_time"] = 1709348071,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Sailor"] = 45,
										},
										["n_total"] = 45,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 45,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[399985] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kul Tiras Sailor"] = 15,
										},
										["n_total"] = 15,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 15,
										["c_max"] = 0,
										["id"] = 399985,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kul Tiras Sailor"] = 46,
										},
										["n_total"] = 46,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 46,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 47,
										["targets"] = {
											["Kul Tiras Sailor"] = 47,
										},
										["n_total"] = 47,
										["n_min"] = 47,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 47,
										["c_max"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 13.74372433302592,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 36.008883,
							["start_time"] = 1709348060,
							["delay"] = 0,
							["last_event"] = 1709348070,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007365,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 36.007365,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 36.007365,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-000062917D",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 36,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348071,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Poisongrace"] = 36,
										},
										["n_total"] = 36,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 36,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 153.007365,
							["start_time"] = 1709348062,
							["delay"] = 0,
							["last_event"] = 1709348070,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 102,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 102,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 102,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 11,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 11,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348071,
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 102,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 524500.598,
				["tempo_start"] = 1709348060,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					189, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 3,
						["Eviscerate"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:54:31",
				["hasTimer"] = 11.03300000005402,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 524488.865,
				["CombatEndedAt"] = 524488.865,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:54:20",
				["end_time"] = 524488.865,
				["combat_id"] = 102,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 1,
				},
				["combat_counter"] = 105,
				["totals_grupo"] = {
					153, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 153.008883,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524477.732,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [22]
			{
				{
					["combatId"] = 101,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004842,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 175.004842,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 175.004842,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 175,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 175,
							},
							["end_time"] = 1709348053,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Sailor"] = 55,
										},
										["n_total"] = 55,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 55,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[399985] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14,
										["targets"] = {
											["Kul Tiras Sailor"] = 14,
										},
										["n_total"] = 14,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 14,
										["c_max"] = 0,
										["id"] = 399985,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14,
										["targets"] = {
											["Kul Tiras Sailor"] = 56,
										},
										["n_total"] = 28,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 56,
										["c_max"] = 28,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 28,
										["successful_casted"] = 0,
										["c_total"] = 28,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 50,
										["targets"] = {
											["Kul Tiras Sailor"] = 50,
										},
										["n_total"] = 50,
										["n_min"] = 50,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 50,
										["c_max"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 15.55736883268982,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 60.004842,
							["start_time"] = 1709348041,
							["delay"] = 0,
							["last_event"] = 1709348053,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.00464,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 105.00464,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 105.00464,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-00006290FA",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Bishoptamaki"] = true,
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Bishoptamaki"] = 45,
								["Poisongrace"] = 60,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348060,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 31,
										["targets"] = {
											["Bishoptamaki"] = 45,
											["Poisongrace"] = 60,
										},
										["n_total"] = 105,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 105,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 8,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[6268] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 6268,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 285.00464,
							["start_time"] = 1709348041,
							["delay"] = 0,
							["last_event"] = 1709348060,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 101,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 101,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 101,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 12,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348053,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["pets"] = {
							},
							["serial"] = "Creature-0-5154-1-106-3128-0000E29124",
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["monster"] = true,
							["aID"] = "3128",
							["nome"] = "Kul Tiras Sailor",
							["last_event"] = 0,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 101,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 524477.732,
				["tempo_start"] = 1709348041,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					390, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 3,
						["Eviscerate"] = 1,
					},
					["Kul Tiras Sailor"] = {
						["Rushing Charge"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:54:14",
				["hasTimer"] = 11.06599999999162,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 524471.415,
				["CombatEndedAt"] = 524471.415,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:54:02",
				["end_time"] = 524471.415,
				["combat_id"] = 101,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 1,
				},
				["combat_counter"] = 104,
				["totals_grupo"] = {
					175, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 175.004842,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524460.166,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [23]
			{
				{
					["combatId"] = 100,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003879,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 142.003879,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 142.003879,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 142,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 142,
							},
							["end_time"] = 1709348030,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Sailor"] = 59,
										},
										["n_total"] = 59,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 59,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[399985] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kul Tiras Sailor"] = 17,
										},
										["n_total"] = 17,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 17,
										["c_max"] = 0,
										["id"] = 399985,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kul Tiras Sailor"] = 66,
										},
										["n_total"] = 33,
										["n_min"] = 16,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 66,
										["c_max"] = 33,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 33,
										["successful_casted"] = 0,
										["c_total"] = 33,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 14.5869418592916,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 20.003879,
							["start_time"] = 1709348020,
							["delay"] = 0,
							["last_event"] = 1709348029,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.008,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 20.008,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 20.008,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-000062946B",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 20,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348030,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Poisongrace"] = 20,
										},
										["n_total"] = 20,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 20,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 142.008,
							["start_time"] = 1709348022,
							["delay"] = 0,
							["last_event"] = 1709348026,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 100,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 100,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 100,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 10,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 10,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348030,
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 100,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 524460.166,
				["tempo_start"] = 1709348020,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					162, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 3,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:53:51",
				["hasTimer"] = 9.033999999985099,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 9.73499999998603,
				["CombatEndedAt"] = 524448.817,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:53:41",
				["end_time"] = 524448.817,
				["combat_id"] = 100,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 1,
				},
				["combat_counter"] = 103,
				["totals_grupo"] = {
					142, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 142.003879,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524439.082,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [24]
			{
				{
					["combatId"] = 99,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00893,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 168.00893,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 168.00893,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 168,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 168,
							},
							["end_time"] = 1709348008,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Sailor"] = 57,
										},
										["n_total"] = 57,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 57,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[399985] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kul Tiras Sailor"] = 17,
										},
										["n_total"] = 17,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 17,
										["c_max"] = 0,
										["id"] = 399985,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Kul Tiras Sailor"] = 47,
										},
										["n_total"] = 47,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 47,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 47,
										["targets"] = {
											["Kul Tiras Sailor"] = 47,
										},
										["n_total"] = 47,
										["n_min"] = 47,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 47,
										["c_max"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 17.71685437096573,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 49.00893,
							["start_time"] = 1709347998,
							["delay"] = 0,
							["last_event"] = 1709348007,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.008134,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 49.008134,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 49.008134,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-0000628D5B",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 49,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709348008,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 28,
										["targets"] = {
											["Poisongrace"] = 49,
										},
										["n_total"] = 49,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 49,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 168.008134,
							["start_time"] = 1709347998,
							["delay"] = 0,
							["last_event"] = 1709348020,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 99,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 99,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 99,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["serial"] = "Player-5818-00A98B51",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 10,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 10,
							["grupo"] = true,
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709348008,
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 99,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["tempo_start"] = 1709347998,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					217, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 3,
						["Eviscerate"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:53:29",
				["hasTimer"] = 9.03200000000652,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 524426.582,
				["CombatEndedAt"] = 524426.582,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:53:19",
				["end_time"] = 524426.582,
				["combat_id"] = 99,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 1,
				},
				["combat_counter"] = 102,
				["totals_grupo"] = {
					168, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 168.00893,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524417.099,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [25]
			{
				{
					["combatId"] = 98,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003382,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 143.003382,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 143.003382,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 143,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 143,
							},
							["end_time"] = 1709347984,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Sailor"] = 63,
										},
										["n_total"] = 46,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 63,
										["c_max"] = 17,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 17,
										["successful_casted"] = 0,
										["c_total"] = 17,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[399985] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14,
										["targets"] = {
											["Kul Tiras Sailor"] = 14,
										},
										["n_total"] = 14,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 14,
										["c_max"] = 0,
										["id"] = 399985,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Kul Tiras Sailor"] = 31,
										},
										["n_total"] = 31,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 31,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 35,
										["targets"] = {
											["Kul Tiras Sailor"] = 35,
										},
										["n_total"] = 35,
										["n_min"] = 35,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 35,
										["c_max"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 15.02609877063276,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 15.003382,
							["start_time"] = 1709347975,
							["delay"] = 0,
							["last_event"] = 1709347983,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007293,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 15.007293,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 15.007293,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-0000628EA3",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 15,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347984,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Poisongrace"] = 15,
										},
										["n_total"] = 15,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 15,
										["c_max"] = 0,
										["DODGE"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 143.007293,
							["start_time"] = 1709347977,
							["delay"] = 0,
							["last_event"] = 1709347983,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 98,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 98,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 98,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 9,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709347984,
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 98,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 524417.099,
				["tempo_start"] = 1709347975,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					158, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 2,
						["Eviscerate"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:53:05",
				["hasTimer"] = 9.032999999937601,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 9.51699999999255,
				["CombatEndedAt"] = 524402.699,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:52:55",
				["end_time"] = 524402.699,
				["combat_id"] = 98,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 1,
				},
				["combat_counter"] = 101,
				["totals_grupo"] = {
					143, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 143.003382,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524393.182,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [26]
			{
				{
					["combatId"] = 97,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008817,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 142.008817,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 142.008817,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
							},
							["targets"] = {
								["Kul Tiras Sailor"] = 142,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 142,
							},
							["end_time"] = 1709347947,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kul Tiras Sailor"] = 60,
										},
										["n_total"] = 39,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 60,
										["c_max"] = 21,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 21,
										["successful_casted"] = 0,
										["c_total"] = 21,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[399985] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Kul Tiras Sailor"] = 16,
										},
										["n_total"] = 16,
										["n_min"] = 16,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 16,
										["c_max"] = 0,
										["id"] = 399985,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14,
										["targets"] = {
											["Kul Tiras Sailor"] = 27,
										},
										["n_total"] = 27,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 27,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 39,
										["targets"] = {
											["Kul Tiras Sailor"] = 39,
										},
										["n_total"] = 39,
										["n_min"] = 39,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 39,
										["c_max"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 18.0925999489329,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 51.008817,
							["start_time"] = 1709347939,
							["delay"] = 0,
							["last_event"] = 1709347946,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005267,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 51.005267,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 51.005267,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3128-0000628DB3",
							["aID"] = "3128",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 51,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347975,
							["nome"] = "Kul Tiras Sailor",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 29,
										["targets"] = {
											["Poisongrace"] = 51,
										},
										["n_total"] = 51,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 51,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 142.005267,
							["start_time"] = 1709347941,
							["delay"] = 0,
							["last_event"] = 1709347975,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 97,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 97,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 97,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 8,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709347947,
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 97,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 524357.167,
				["tempo_start"] = 1709347939,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					193, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["Poisongrace"] = {
						{
							true, -- [1]
							1, -- [2]
							29, -- [3]
							1709347975.561, -- [4]
							194, -- [5]
							"Kul Tiras Sailor", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 3,
						["Eviscerate"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:52:27",
				["hasTimer"] = 7.050000000046566,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kul Tiras Sailor",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 7.849000000045635,
				["CombatEndedAt"] = 524365.0160000001,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:52:19",
				["end_time"] = 524365.0160000001,
				["combat_id"] = 97,
				["overall_added"] = true,
				["frags"] = {
					["Kul Tiras Sailor"] = 1,
				},
				["combat_counter"] = 100,
				["totals_grupo"] = {
					142, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 142.008817,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524357.167,
				["TimeData"] = {
				},
				["contra"] = "Kul Tiras Sailor",
			}, -- [27]
			{
				{
					["combatId"] = 96,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006289,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 136.006289,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 136.006289,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kul Tiras Sailor"] = true,
								["Clattering Scorpid"] = true,
							},
							["targets"] = {
								["Clattering Scorpid"] = 136,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347860,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Clattering Scorpid"] = 75,
										},
										["n_total"] = 53,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 75,
										["c_max"] = 22,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 22,
										["successful_casted"] = 0,
										["c_total"] = 22,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Clattering Scorpid"] = 61,
										},
										["n_total"] = 61,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 61,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 6.777947224163103,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 99.006289,
							["start_time"] = 1709347851,
							["delay"] = 0,
							["last_event"] = 1709347860,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005422,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 69.005422,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 69.005422,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3125-000062917D",
							["aID"] = "3125",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 69,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347939,
							["nome"] = "Clattering Scorpid",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Poisongrace"] = 64,
										},
										["n_total"] = 64,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 64,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 9,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[11918] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1,
										["targets"] = {
											["Poisongrace"] = 5,
										},
										["n_total"] = 5,
										["n_min"] = 1,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 5,
										["c_max"] = 0,
										["id"] = 11918,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 136.005422,
							["start_time"] = 1709347907,
							["delay"] = 1709347871,
							["last_event"] = 1709347871,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 96,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 96,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 96,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 20,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 20,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709347860,
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 96,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["tempo_start"] = 1709347840,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					235, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["Poisongrace"] = {
						{
							true, -- [1]
							11918, -- [2]
							1, -- [3]
							1709347862.778, -- [4]
							139, -- [5]
							"Clattering Scorpid", -- [6]
							nil, -- [7]
							8, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [1]
						{
							true, -- [1]
							11918, -- [2]
							1, -- [3]
							1709347865.78, -- [4]
							148, -- [5]
							"Clattering Scorpid", -- [6]
							nil, -- [7]
							8, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [2]
						{
							true, -- [1]
							11918, -- [2]
							1, -- [3]
							1709347868.795, -- [4]
							167, -- [5]
							"Clattering Scorpid", -- [6]
							nil, -- [7]
							8, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [3]
						{
							true, -- [1]
							11918, -- [2]
							1, -- [3]
							1709347871.779, -- [4]
							176, -- [5]
							"Clattering Scorpid", -- [6]
							nil, -- [7]
							8, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [4]
						{
							true, -- [1]
							1, -- [2]
							30, -- [3]
							1709347939.546, -- [4]
							194, -- [5]
							"Kul Tiras Sailor", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 6,
					},
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 4,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:51:00",
				["hasTimer"] = 19.08300000004238,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Clattering Scorpid",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 524278.333,
				["CombatEndedAt"] = 524278.333,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:50:40",
				["end_time"] = 524278.333,
				["combat_id"] = 96,
				["overall_added"] = true,
				["frags"] = {
					["Clattering Scorpid"] = 1,
				},
				["combat_counter"] = 99,
				["totals_grupo"] = {
					136, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 136.006289,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524258.267,
				["TimeData"] = {
				},
				["contra"] = "Clattering Scorpid",
			}, -- [28]
			{
				{
					["combatId"] = 95,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006128,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 9.006128,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 9.006128,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Clattering Scorpid"] = true,
							},
							["targets"] = {
								["Clattering Scorpid"] = 9,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347776,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[1776] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["Clattering Scorpid"] = 9,
										},
										["n_total"] = 9,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 9,
										["c_max"] = 0,
										["id"] = 1776,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0.3475122704117447,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 22.006128,
							["start_time"] = 1709347775,
							["delay"] = 1709347760,
							["last_event"] = 1709347760,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001497,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 22.001497,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 22.001497,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3125-0000628436",
							["aID"] = "3125",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 22,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347776,
							["nome"] = "Clattering Scorpid",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Poisongrace"] = 22,
										},
										["n_total"] = 22,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[11918] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Poisongrace"] = 0,
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["RESIST"] = 1,
										["id"] = 11918,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 9.001497,
							["start_time"] = 1709347771,
							["delay"] = 1709347754,
							["last_event"] = 1709347754,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 95,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 95,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 95,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1776] = {
										["activedamt"] = 0,
										["id"] = 1776,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 26,
							["cc_done_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1776] = {
										["id"] = 1776,
										["targets"] = {
											["Clattering Scorpid"] = 1,
										},
										["counter"] = 1,
									},
								},
							},
							["aID"] = "5818-00A98B51",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 26,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 4,
							["cc_done"] = 1.008499,
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["grupo"] = true,
							["cc_done_targets"] = {
								["Clattering Scorpid"] = 1,
							},
							["buff_uptime_targets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["pets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-5818-00A98B51",
							["last_event"] = 1709347776,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 95,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 524255.749,
				["tempo_start"] = 1709347750,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					31, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = false,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Gouge"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:49:36",
				["hasTimer"] = 25.11700000002747,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Clattering Scorpid",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 524194.166,
				["CombatEndedAt"] = 524194.166,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:49:10",
				["end_time"] = 524194.166,
				["combat_id"] = 95,
				["overall_added"] = true,
				["frags"] = {
				},
				["combat_counter"] = 98,
				["totals_grupo"] = {
					9, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 9.006128,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524168.25,
				["TimeData"] = {
				},
				["contra"] = "Clattering Scorpid",
			}, -- [29]
			{
				{
					["combatId"] = 94,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008971,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 8.008971,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 8.008971,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
							},
							["targets"] = {
								["Kolkar Drudge"] = 8,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347729,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[1776] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kolkar Drudge"] = 8,
											["Clattering Scorpid"] = 0,
										},
										["n_total"] = 8,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 8,
										["c_max"] = 0,
										["BLOCK"] = 1,
										["id"] = 1776,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0.5031392762908294,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.008971,
							["start_time"] = 1709347728,
							["delay"] = 1709347713,
							["last_event"] = 1709347749,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006177,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 0.006177,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 0.006177,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3119-0000E291B6",
							["aID"] = "3119",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347729,
							["nome"] = "Kolkar Drudge",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 8.006177,
							["start_time"] = 1709347729,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 94,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 94,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 94,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1776] = {
										["activedamt"] = 0,
										["id"] = 1776,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["pets"] = {
							},
							["cc_done_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[1776] = {
										["id"] = 1776,
										["targets"] = {
											["Kolkar Drudge"] = 1,
										},
										["counter"] = 1,
									},
								},
							},
							["aID"] = "5818-00A98B51",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 4,
							["cc_done"] = 1.007936,
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["grupo"] = true,
							["cc_done_targets"] = {
								["Kolkar Drudge"] = 1,
							},
							["classe"] = "ROGUE",
							["debuff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["buff_uptime"] = 16,
							["buff_uptime_targets"] = {
							},
							["serial"] = "Player-5818-00A98B51",
							["last_event"] = 1709347729,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 94,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 524166.634,
				["tempo_start"] = 1709347713,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					8, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = false,
				["amountCasts"] = {
				},
				["instance_type"] = "none",
				["data_fim"] = "12:48:49",
				["hasTimer"] = 15.08399999997346,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kolkar Drudge",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 15.91800000000512,
				["CombatEndedAt"] = 524146.801,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:48:33",
				["end_time"] = 524146.801,
				["combat_id"] = 94,
				["overall_added"] = true,
				["frags"] = {
				},
				["combat_counter"] = 97,
				["totals_grupo"] = {
					8, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 8.008971,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524130.883,
				["TimeData"] = {
				},
				["contra"] = "Kolkar Drudge",
			}, -- [30]
			{
				{
					["combatId"] = 93,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008328,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 150.008328,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 150.008328,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kolkar Drudge"] = true,
								["Kolkar Outrunner"] = true,
								["Environment (Fire)"] = true,
							},
							["targets"] = {
								["Kolkar Outrunner"] = 150,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347613,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kolkar Outrunner"] = 48,
										},
										["n_total"] = 30,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 48,
										["c_max"] = 18,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 18,
										["successful_casted"] = 0,
										["c_total"] = 18,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[2764] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kolkar Outrunner"] = 11,
										},
										["n_total"] = 11,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 11,
										["c_max"] = 0,
										["id"] = 2764,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kolkar Outrunner"] = 30,
										},
										["n_total"] = 30,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 30,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kolkar Outrunner"] = 61,
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 61,
										["c_max"] = 61,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 61,
										["successful_casted"] = 0,
										["c_total"] = 61,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 15.48872772328715,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 59.008328,
							["start_time"] = 1709347603,
							["delay"] = 0,
							["last_event"] = 1709347612,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007295,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 32.007295,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 32.007295,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3120-0000628AB0",
							["aID"] = "3120",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 32,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347613,
							["nome"] = "Kolkar Outrunner",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["Poisongrace"] = 25,
										},
										["n_total"] = 25,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 25,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[6660] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Poisongrace"] = 7,
										},
										["n_total"] = 7,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 7,
										["c_max"] = 0,
										["id"] = 6660,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 150.007295,
							["start_time"] = 1709347604,
							["delay"] = 0,
							["last_event"] = 1709347610,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 93,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 93,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 93,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 10,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 10,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709347613,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["serial"] = "Creature-0-5154-1-106-3120-0000628AB0",
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["monster"] = true,
							["aID"] = "3120",
							["nome"] = "Kolkar Outrunner",
							["last_event"] = 0,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 93,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 524109.518,
				["tempo_start"] = 1709347603,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					362, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["Poisongrace"] = {
						{
							true, -- [1]
							6, -- [2]
							20, -- [3]
							1709347618.58, -- [4]
							156, -- [5]
							"Environment (Fire)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
							true, -- [1]
							1, -- [2]
							7, -- [3]
							1709347713.262, -- [4]
							194, -- [5]
							"Kolkar Drudge", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 3,
					},
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 3,
						["Eviscerate"] = 1,
					},
					["Kolkar Outrunner"] = {
						["Shoot"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:46:53",
				["hasTimer"] = 9.048999999999069,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kolkar Outrunner",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 6.065000000002328,
				["CombatEndedAt"] = 524115.583,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:46:44",
				["end_time"] = 524031.353,
				["combat_id"] = 93,
				["overall_added"] = true,
				["frags"] = {
					["Kolkar Outrunner"] = 1,
				},
				["combat_counter"] = 96,
				["totals_grupo"] = {
					150, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 150.008328,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 524021.668,
				["TimeData"] = {
				},
				["contra"] = "Kolkar Outrunner",
			}, -- [31]
			{
				{
					["combatId"] = 92,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003325,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 159.003325,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 159.003325,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kolkar Outrunner"] = true,
							},
							["targets"] = {
								["Kolkar Outrunner"] = 159,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347590,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 1,
										["g_amt"] = 1,
										["n_max"] = 10,
										["targets"] = {
											["Kolkar Outrunner"] = 51,
										},
										["n_total"] = 23,
										["n_min"] = 5,
										["g_dmg"] = 10,
										["counter"] = 6,
										["total"] = 51,
										["c_max"] = 18,
										["a_amt"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 18,
										["successful_casted"] = 0,
										["c_total"] = 18,
										["n_amt"] = 3,
										["b_dmg"] = 5,
										["r_amt"] = 0,
									}, -- [1]
									[2764] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kolkar Outrunner"] = 24,
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 24,
										["c_max"] = 24,
										["id"] = 2764,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 24,
										["successful_casted"] = 0,
										["c_total"] = 24,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Kolkar Outrunner"] = 47,
										},
										["n_total"] = 47,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 47,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 1,
										["g_amt"] = 0,
										["n_max"] = 37,
										["targets"] = {
											["Kolkar Outrunner"] = 37,
										},
										["n_total"] = 37,
										["n_min"] = 37,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 37,
										["c_max"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 37,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 5.185003750086878,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 85.003325,
							["start_time"] = 1709347581,
							["delay"] = 1709347560,
							["last_event"] = 1709347589,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007865,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 85.00786500000001,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 85.00786500000001,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3120-0000628A9B",
							["aID"] = "3120",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 85,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347590,
							["nome"] = "Kolkar Outrunner",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Poisongrace"] = 46,
										},
										["n_total"] = 46,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 46,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[6660] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["Poisongrace"] = 39,
										},
										["n_total"] = 39,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 39,
										["c_max"] = 0,
										["id"] = 6660,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 5,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 159.007865,
							["start_time"] = 1709347561,
							["delay"] = 0,
							["last_event"] = 1709347589,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 92,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 92,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 92,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 30,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 30,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709347590,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["serial"] = "Creature-0-5154-1-106-3120-0000628A9B",
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["monster"] = true,
							["aID"] = "3120",
							["nome"] = "Kolkar Outrunner",
							["last_event"] = 0,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 92,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 524020.701,
				["tempo_start"] = 1709347560,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					244, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Kolkar Outrunner"] = {
						["Shoot"] = 5,
					},
					["Poisongrace"] = {
						["Sinister Strike"] = 4,
						["Eviscerate"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:46:31",
				["hasTimer"] = 30.1819999999716,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kolkar Outrunner",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 524008.701,
				["CombatEndedAt"] = 524008.701,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:46:00",
				["end_time"] = 524008.701,
				["combat_id"] = 92,
				["overall_added"] = true,
				["frags"] = {
					["Kolkar Outrunner"] = 1,
				},
				["combat_counter"] = 95,
				["totals_grupo"] = {
					159, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 159.003325,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 523978.035,
				["TimeData"] = {
				},
				["contra"] = "Kolkar Outrunner",
			}, -- [32]
			{
				{
					["combatId"] = 91,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003927,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 176.003927,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 176.003927,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kolkar Outrunner"] = true,
							},
							["targets"] = {
								["Kolkar Outrunner"] = 176,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347538,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 1,
										["g_amt"] = 1,
										["n_max"] = 10,
										["targets"] = {
											["Kolkar Outrunner"] = 81,
										},
										["n_total"] = 57,
										["n_min"] = 3,
										["g_dmg"] = 8,
										["counter"] = 9,
										["total"] = 81,
										["c_max"] = 16,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 16,
										["successful_casted"] = 0,
										["c_total"] = 16,
										["n_amt"] = 7,
										["b_dmg"] = 3,
										["r_amt"] = 0,
									}, -- [1]
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kolkar Outrunner"] = 41,
										},
										["n_total"] = 41,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 41,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 26,
										["targets"] = {
											["Kolkar Outrunner"] = 54,
										},
										["n_total"] = 26,
										["n_min"] = 26,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 54,
										["c_max"] = 28,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 28,
										["successful_casted"] = 0,
										["c_total"] = 28,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 10.40519816728421,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 62.003927,
							["start_time"] = 1709347525,
							["delay"] = 0,
							["last_event"] = 1709347537,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007914,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 62.007914,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 62.007914,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3120-0000628A81",
							["aID"] = "3120",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 62,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347538,
							["nome"] = "Kolkar Outrunner",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Poisongrace"] = 42,
										},
										["n_total"] = 42,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 42,
										["c_max"] = 0,
										["DODGE"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[6660] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Poisongrace"] = 20,
										},
										["n_total"] = 20,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 20,
										["c_max"] = 0,
										["id"] = 6660,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 176.007914,
							["start_time"] = 1709347521,
							["delay"] = 0,
							["last_event"] = 1709347535,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 91,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 91,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 91,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 17,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 17,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709347538,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["serial"] = "Creature-0-5154-1-106-3120-0000628A81",
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["monster"] = true,
							["aID"] = "3120",
							["nome"] = "Kolkar Outrunner",
							["last_event"] = 0,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 91,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 523976.484,
				["tempo_start"] = 1709347521,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					238, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Kolkar Outrunner"] = {
						["Shoot"] = 1,
					},
					["Poisongrace"] = {
						["Sinister Strike"] = 3,
						["Eviscerate"] = 2,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:45:38",
				["hasTimer"] = 16.09900000004564,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kolkar Outrunner",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 523955.65,
				["CombatEndedAt"] = 523955.65,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:45:21",
				["end_time"] = 523955.65,
				["combat_id"] = 91,
				["overall_added"] = true,
				["frags"] = {
					["Kolkar Outrunner"] = 1,
				},
				["combat_counter"] = 94,
				["totals_grupo"] = {
					176, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 176.003927,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 523938.735,
				["TimeData"] = {
				},
				["contra"] = "Kolkar Outrunner",
			}, -- [33]
			{
				{
					["combatId"] = 90,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002593,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 149.002593,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 149.002593,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kolkar Drudge"] = true,
							},
							["targets"] = {
								["Kolkar Drudge"] = 149,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347517,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kolkar Drudge"] = 58,
										},
										["n_total"] = 58,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 58,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[2764] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 13,
										["targets"] = {
											["Kolkar Drudge"] = 13,
										},
										["n_total"] = 13,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 13,
										["c_max"] = 0,
										["id"] = 2764,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 1,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kolkar Drudge"] = 41,
										},
										["n_total"] = 41,
										["n_min"] = 12,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 41,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 12,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 37,
										["targets"] = {
											["Kolkar Drudge"] = 37,
										},
										["n_total"] = 37,
										["n_min"] = 37,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 37,
										["c_max"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 11.64173708883591,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 28.002593,
							["start_time"] = 1709347504,
							["delay"] = 0,
							["last_event"] = 1709347516,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006313,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 28.006313,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 28.006313,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3119-0000628AD9",
							["aID"] = "3119",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 28,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347517,
							["nome"] = "Kolkar Drudge",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Poisongrace"] = 28,
										},
										["n_total"] = 28,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 28,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 149.006313,
							["start_time"] = 1709347509,
							["delay"] = 0,
							["last_event"] = 1709347515,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 90,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 90,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 90,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 13,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 13,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709347517,
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 90,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 523937.867,
				["tempo_start"] = 1709347504,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					177, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 3,
						["Eviscerate"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:45:17",
				["hasTimer"] = 12.08100000000559,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kolkar Drudge",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 523934.602,
				["CombatEndedAt"] = 523934.602,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:45:04",
				["end_time"] = 523934.602,
				["combat_id"] = 90,
				["overall_added"] = true,
				["frags"] = {
					["Kolkar Drudge"] = 1,
				},
				["combat_counter"] = 93,
				["totals_grupo"] = {
					149, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 149.002593,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 523921.803,
				["TimeData"] = {
				},
				["contra"] = "Kolkar Drudge",
			}, -- [34]
			{
				{
					["combatId"] = 89,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003593,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 182.003593,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 182.003593,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kolkar Drudge"] = true,
							},
							["targets"] = {
								["Kolkar Drudge"] = 182,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347498,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kolkar Drudge"] = 65,
										},
										["n_total"] = 65,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 65,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 7,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[2764] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kolkar Drudge"] = 11,
										},
										["n_total"] = 11,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 11,
										["c_max"] = 0,
										["id"] = 2764,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kolkar Drudge"] = 56,
										},
										["n_total"] = 56,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 56,
										["c_max"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 50,
										["targets"] = {
											["Kolkar Drudge"] = 50,
										},
										["n_total"] = 50,
										["n_min"] = 50,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 50,
										["c_max"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 12.57973410285333,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 27.003593,
							["start_time"] = 1709347483,
							["delay"] = 0,
							["last_event"] = 1709347498,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.008055,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 27.008055,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 27.008055,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3119-0000628AD4",
							["aID"] = "3119",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 27,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347498,
							["nome"] = "Kolkar Drudge",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Poisongrace"] = 27,
										},
										["n_total"] = 27,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 27,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 182.008055,
							["start_time"] = 1709347485,
							["delay"] = 0,
							["last_event"] = 1709347493,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 89,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 89,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 89,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 15,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709347498,
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 89,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 523920.301,
				["tempo_start"] = 1709347483,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					209, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 4,
						["Eviscerate"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:44:58",
				["hasTimer"] = 14.13400000002002,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kolkar Drudge",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 523916.385,
				["CombatEndedAt"] = 523916.385,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:44:44",
				["end_time"] = 523916.385,
				["combat_id"] = 89,
				["overall_added"] = true,
				["frags"] = {
					["Kolkar Drudge"] = 1,
				},
				["combat_counter"] = 92,
				["totals_grupo"] = {
					182, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 182.003593,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 523901.917,
				["TimeData"] = {
				},
				["contra"] = "Kolkar Drudge",
			}, -- [35]
			{
				{
					["combatId"] = 88,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008034,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 156.008034,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 156.008034,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kolkar Drudge"] = true,
							},
							["targets"] = {
								["Kolkar Drudge"] = 156,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347448,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 1,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Kolkar Drudge"] = 60,
										},
										["n_total"] = 60,
										["a_amt"] = 0,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 14,
										["MISS"] = 5,
										["total"] = 60,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 7,
										["b_dmg"] = 5,
										["r_amt"] = 0,
									}, -- [1]
									[399985] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Kolkar Drudge"] = 16,
										},
										["n_total"] = 16,
										["n_min"] = 16,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 16,
										["c_max"] = 0,
										["id"] = 399985,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 1,
										["b_amt"] = 1,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Kolkar Drudge"] = 80,
										},
										["n_total"] = 54,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 80,
										["c_max"] = 26,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 26,
										["successful_casted"] = 0,
										["c_total"] = 26,
										["n_amt"] = 4,
										["b_dmg"] = 10,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kolkar Drudge"] = 0,
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 6.882909820886701,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 74.00803400000001,
							["start_time"] = 1709347425,
							["delay"] = 0,
							["last_event"] = 1709347446,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.004831,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 74.004831,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 74.004831,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3119-0000628A23",
							["aID"] = "3119",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 74,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347448,
							["nome"] = "Kolkar Drudge",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Poisongrace"] = 74,
										},
										["n_total"] = 74,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 74,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 8,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[7272] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 7272,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 156.004831,
							["start_time"] = 1709347427,
							["delay"] = 0,
							["last_event"] = 1709347441,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 88,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 88,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 88,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["serial"] = "Player-5818-00A98B51",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 23,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 23,
							["grupo"] = true,
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709347448,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["serial"] = "Creature-0-5154-1-106-3119-0000628A23",
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["monster"] = true,
							["aID"] = "3119",
							["nome"] = "Kolkar Drudge",
							["last_event"] = 0,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 88,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 523900.968,
				["tempo_start"] = 1709347425,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					230, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 5,
						["Eviscerate"] = 1,
					},
					["Kolkar Drudge"] = {
						["Dust Cloud"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:44:08",
				["hasTimer"] = 22.14999999996508,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kolkar Drudge",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 22.66599999996834,
				["CombatEndedAt"] = 523866.185,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:43:46",
				["end_time"] = 523866.185,
				["combat_id"] = 88,
				["overall_added"] = true,
				["frags"] = {
					["Kolkar Drudge"] = 1,
				},
				["combat_counter"] = 91,
				["totals_grupo"] = {
					156, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 156.008034,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 523843.519,
				["TimeData"] = {
				},
				["contra"] = "Kolkar Drudge",
			}, -- [36]
			{
				{
					["combatId"] = 87,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003371,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 188.003371,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 188.003371,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kolkar Outrunner"] = true,
								["Kolkar Drudge"] = true,
							},
							["targets"] = {
								["Kolkar Outrunner"] = 188,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347402,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 2,
										["n_max"] = 10,
										["targets"] = {
											["Kolkar Outrunner"] = 72,
										},
										["n_total"] = 58,
										["n_min"] = 7,
										["g_dmg"] = 14,
										["counter"] = 9,
										["total"] = 72,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 7,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[2764] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kolkar Outrunner"] = 11,
										},
										["n_total"] = 11,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 11,
										["c_max"] = 0,
										["id"] = 2764,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kolkar Outrunner"] = 69,
										},
										["n_total"] = 43,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 69,
										["c_max"] = 26,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 26,
										["successful_casted"] = 0,
										["c_total"] = 26,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 36,
										["targets"] = {
											["Kolkar Outrunner"] = 36,
										},
										["n_total"] = 36,
										["n_min"] = 36,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 36,
										["c_max"] = 0,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 8.1858044585695,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 89.003371,
							["start_time"] = 1709347389,
							["delay"] = 1709347379,
							["last_event"] = 1709347401,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002263,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 79.002263,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 79.002263,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3120-0000628B42",
							["aID"] = "3120",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 79,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347402,
							["nome"] = "Kolkar Outrunner",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Poisongrace"] = 49,
										},
										["n_total"] = 49,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 49,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[6660] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Poisongrace"] = 30,
										},
										["n_total"] = 30,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 30,
										["c_max"] = 0,
										["id"] = 6660,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 188.002263,
							["start_time"] = 1709347381,
							["delay"] = 0,
							["last_event"] = 1709347397,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 87,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 87,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 87,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 23,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 22,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[5277] = {
										["activedamt"] = 1,
										["id"] = 5277,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709347402,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["serial"] = "Creature-0-5154-1-106-3120-0000628B42",
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["monster"] = true,
							["aID"] = "3120",
							["nome"] = "Kolkar Outrunner",
							["last_event"] = 0,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 87,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["tempo_start"] = 1709347379,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					277, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["Poisongrace"] = {
						{
							true, -- [1]
							1, -- [2]
							10, -- [3]
							1709347425.898, -- [4]
							175, -- [5]
							"Kolkar Drudge", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 4,
						["Eviscerate"] = 1,
					},
					["Kolkar Outrunner"] = {
						["Shoot"] = 3,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:43:23",
				["hasTimer"] = 22.08399999997346,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kolkar Outrunner",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 523820.785,
				["CombatEndedAt"] = 523820.785,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:43:00",
				["end_time"] = 523820.785,
				["combat_id"] = 87,
				["overall_added"] = true,
				["frags"] = {
					["Kolkar Outrunner"] = 1,
				},
				["combat_counter"] = 90,
				["totals_grupo"] = {
					188, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 188.003371,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 523797.818,
				["TimeData"] = {
				},
				["contra"] = "Kolkar Outrunner",
			}, -- [37]
			{
				{
					["combatId"] = 86,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003129,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 173.003129,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 173.003129,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kolkar Outrunner"] = true,
							},
							["targets"] = {
								["Kolkar Outrunner"] = 173,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347373,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 1,
										["n_max"] = 10,
										["targets"] = {
											["Kolkar Outrunner"] = 91,
										},
										["n_total"] = 81,
										["n_min"] = 7,
										["g_dmg"] = 10,
										["counter"] = 13,
										["DODGE"] = 1,
										["total"] = 91,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 10,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[2764] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Kolkar Outrunner"] = 10,
										},
										["n_total"] = 10,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 10,
										["c_max"] = 0,
										["id"] = 2764,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["Kolkar Outrunner"] = 72,
										},
										["n_total"] = 72,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 7,
										["a_amt"] = 0,
										["total"] = 72,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[6760] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kolkar Outrunner"] = 0,
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 6760,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 5.133776343508272,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 80.003129,
							["start_time"] = 1709347354,
							["delay"] = 1709347339,
							["last_event"] = 1709347372,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005606,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 80.005606,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 80.005606,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3120-00006289E5",
							["aID"] = "3120",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 80,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347373,
							["nome"] = "Kolkar Outrunner",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Poisongrace"] = 59,
										},
										["n_total"] = 59,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 59,
										["c_max"] = 0,
										["DODGE"] = 3,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[6660] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Poisongrace"] = 21,
										},
										["n_total"] = 21,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 21,
										["c_max"] = 0,
										["id"] = 6660,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 173.005606,
							["start_time"] = 1709347340,
							["delay"] = 0,
							["last_event"] = 1709347368,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 86,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 86,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 86,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 41,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 34,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[5277] = {
										["activedamt"] = 1,
										["id"] = 5277,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709347373,
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["serial"] = "Creature-0-5154-1-106-3120-00006289E5",
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["monster"] = true,
							["aID"] = "3120",
							["nome"] = "Kolkar Outrunner",
							["last_event"] = 0,
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 86,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 523796.635,
				["tempo_start"] = 1709347339,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					253, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Kolkar Outrunner"] = {
						["Shoot"] = 2,
					},
					["Poisongrace"] = {
						["Eviscerate"] = 1,
						["Evasion"] = 1,
						["Sinister Strike"] = 7,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:42:53",
				["hasTimer"] = 33.16600000002654,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kolkar Outrunner",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 523790.785,
				["CombatEndedAt"] = 523790.785,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:42:19",
				["end_time"] = 523790.785,
				["combat_id"] = 86,
				["overall_added"] = true,
				["frags"] = {
					["Kolkar Outrunner"] = 1,
				},
				["combat_counter"] = 89,
				["totals_grupo"] = {
					173, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 173.003129,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 523757.086,
				["TimeData"] = {
				},
				["contra"] = "Kolkar Outrunner",
			}, -- [38]
			{
				{
					["combatId"] = 85,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007569,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 158.007569,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 158.007569,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kolkar Drudge"] = true,
							},
							["targets"] = {
								["Kolkar Drudge"] = 158,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347328,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Kolkar Drudge"] = 86,
										},
										["n_total"] = 86,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 86,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 10,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[1757] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Kolkar Drudge"] = 72,
										},
										["n_total"] = 72,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 72,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 10.10730947352967,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 48.007569,
							["start_time"] = 1709347312,
							["delay"] = 0,
							["last_event"] = 1709347327,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.00691,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 48.00691,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 48.00691,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3119-00006289FF",
							["aID"] = "3119",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 48,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347328,
							["nome"] = "Kolkar Drudge",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Poisongrace"] = 48,
										},
										["n_total"] = 48,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 48,
										["c_max"] = 0,
										["DODGE"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 158.00691,
							["start_time"] = 1709347315,
							["delay"] = 0,
							["last_event"] = 1709347325,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 85,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 85,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 85,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 16,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709347328,
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 85,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 523755.785,
				["tempo_start"] = 1709347312,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					206, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 5,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:42:08",
				["hasTimer"] = 15.03400000004331,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kolkar Drudge",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 523745.835,
				["CombatEndedAt"] = 523745.835,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:41:52",
				["end_time"] = 523745.835,
				["combat_id"] = 85,
				["overall_added"] = true,
				["frags"] = {
					["Kolkar Drudge"] = 1,
				},
				["combat_counter"] = 88,
				["totals_grupo"] = {
					158, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 158.007569,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 523730.202,
				["TimeData"] = {
				},
				["contra"] = "Kolkar Drudge",
			}, -- [39]
			{
				{
					["combatId"] = 84,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00833,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["total_without_pet"] = 164.00833,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 164.00833,
							["spec"] = 260,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A98B51",
							["damage_from"] = {
								["Kolkar Outrunner"] = true,
							},
							["targets"] = {
								["Kolkar Outrunner"] = 164,
							},
							["colocacao"] = 1,
							["aID"] = "5818-00A98B51",
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347295,
							["nome"] = "Poisongrace",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kolkar Outrunner"] = 83,
											["Kolkar Drudge"] = 0,
										},
										["n_total"] = 48,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 83,
										["c_max"] = 20,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 15,
										["successful_casted"] = 0,
										["c_total"] = 35,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kolkar Drudge"] = 0,
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 2,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [2]
									[1757] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14,
										["targets"] = {
											["Kolkar Outrunner"] = 69,
										},
										["n_total"] = 14,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 69,
										["c_max"] = 28,
										["id"] = 1757,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 27,
										["successful_casted"] = 0,
										["c_total"] = 55,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[399985] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Kolkar Outrunner"] = 12,
										},
										["n_total"] = 12,
										["n_min"] = 12,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 12,
										["c_max"] = 0,
										["id"] = 399985,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 12.66571395472368,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 28.00833,
							["start_time"] = 1709347282,
							["delay"] = 0,
							["last_event"] = 1709347312,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.003555,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 28.003555,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 28.003555,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-106-3120-00006291AC",
							["aID"] = "3120",
							["fight_component"] = true,
							["damage_from"] = {
								["Poisongrace"] = true,
							},
							["targets"] = {
								["Poisongrace"] = 28,
							},
							["monster"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1709347295,
							["nome"] = "Kolkar Outrunner",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Poisongrace"] = 28,
										},
										["n_total"] = 28,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 28,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 164.003555,
							["start_time"] = 1709347287,
							["delay"] = 0,
							["last_event"] = 1709347291,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 84,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 84,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 84,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime"] = 13,
							["classe"] = "ROGUE",
							["buff_uptime_targets"] = {
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[436412] = {
										["activedamt"] = 1,
										["id"] = 436412,
										["targets"] = {
										},
										["uptime"] = 13,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-5818-00A98B51",
							["aID"] = "5818-00A98B51",
							["nome"] = "Poisongrace",
							["spec"] = 260,
							["last_event"] = 1709347295,
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 84,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Poisongrace"] = "Player-5818-00A98B51",
				},
				["raid_roster_indexed"] = {
					"Poisongrace", -- [1]
				},
				["CombatStartedAt"] = 523723.52,
				["tempo_start"] = 1709347282,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					192, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Poisongrace"] = {
						["Sinister Strike"] = 3,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "12:41:36",
				["hasTimer"] = 12.06599999999162,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kolkar Outrunner",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 523713.852,
				["CombatEndedAt"] = 523713.852,
				["aura_timeline"] = {
				},
				["data_inicio"] = "12:41:23",
				["end_time"] = 523713.852,
				["combat_id"] = 84,
				["overall_added"] = true,
				["frags"] = {
					["Kolkar Outrunner"] = 1,
				},
				["combat_counter"] = 87,
				["totals_grupo"] = {
					164, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Poisongrace"] = 164.00833,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 523700.903,
				["TimeData"] = {
				},
				["contra"] = "Kolkar Outrunner",
			}, -- [40]
		},
	},
	["ocd_tracker"] = {
		["enabled"] = false,
		["current_cooldowns"] = {
		},
		["lines_per_column"] = 12,
		["group_frames"] = true,
		["width"] = 120,
		["frames"] = {
			["defensive-raid"] = {
			},
			["main"] = {
			},
			["ofensive"] = {
			},
			["defensive-target"] = {
			},
			["utility"] = {
			},
			["defensive-personal"] = {
			},
		},
		["show_options"] = false,
		["ignored_cooldowns"] = {
		},
		["framme_locked"] = false,
		["cooldowns"] = {
		},
		["own_frame"] = {
			["defensive-raid"] = false,
			["ofensive"] = false,
			["defensive-target"] = false,
			["utility"] = false,
			["defensive-personal"] = false,
		},
		["height"] = 18,
		["show_conditions"] = {
			["only_inside_instance"] = true,
			["only_in_group"] = true,
		},
		["show_title"] = true,
		["filters"] = {
			["itemutil"] = false,
			["itempower"] = false,
			["defensive-target"] = false,
			["itemheal"] = false,
			["defensive-personal"] = false,
			["defensive-raid"] = false,
			["ofensive"] = true,
			["crowdcontrol"] = false,
			["utility"] = false,
		},
	},
	["last_version"] = "1.15.1 12330",
	["player_stats"] = {
	},
	["force_font_outline"] = "",
	["tabela_instancias"] = {
	},
	["coach"] = {
		["enabled"] = false,
		["welcome_panel_pos"] = {
		},
		["last_coach_name"] = false,
	},
	["local_instances_config"] = {
		{
			["modo"] = 2,
			["sub_attribute"] = 1,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["is_open"] = true,
			["isLocked"] = false,
			["snap"] = {
			},
			["segment"] = 0,
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -359.9997863769531,
					["x"] = 696.1112060546875,
					["w"] = 268.2222595214844,
					["h"] = 142.0000457763672,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
	},
	["cached_talents"] = {
	},
	["last_instance_id"] = 0,
	["data_harvest_for_charsts"] = {
		["players"] = {
			{
				["name"] = "Damage of Each Individual Player",
				["playerOnly"] = true,
				["playerKey"] = "total",
				["combatObjectContainer"] = 1,
			}, -- [1]
		},
		["totals"] = {
			{
				["combatObjectSubTableKey"] = 1,
				["name"] = "Damage of All Player Combined",
				["combatObjectSubTableName"] = "totals",
			}, -- [1]
		},
	},
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["announce_prepots"] = {
		["enabled"] = false,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["active_profile"] = "Poisongrace-Shadowstrike (AU)",
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["combat_log"] = {
		["inverse_deathlog_overalldata"] = false,
		["track_hunter_frenzy"] = false,
		["evoker_calc_damage"] = false,
		["inverse_deathlog_raid"] = false,
		["merge_critical_heals"] = false,
		["merge_gemstones_1007"] = false,
		["evoker_show_realtimedps"] = false,
		["inverse_deathlog_mplus"] = false,
	},
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["mythic_plus_log"] = {
	},
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["cached_roles"] = {
	},
	["ignore_nicktag"] = false,
	["combat_counter"] = 126,
	["on_death_menu"] = false,
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["enabled"] = true,
			["animate"] = false,
			["hide_pull_bar"] = false,
			["author"] = "Terciob",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["usefocus"] = false,
			["updatespeed"] = 1,
			["disable_gouge"] = false,
			["showamount"] = false,
			["useplayercolor"] = false,
			["absolute_mode"] = false,
			["playSound"] = false,
			["playSoundFile"] = "Details Threat Warning Volume 3",
			["useclasscolors"] = false,
		},
		["DETAILS_PLUGIN_COMPARETWO_WINDOW"] = {
			["enabled"] = true,
			["author"] = "Terciob",
		},
		["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
			["use_square_mode"] = false,
			["is_first_run"] = false,
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["scale"] = 1,
			["arrow_anchor_y"] = 0,
			["minimap"] = {
				["minimapPos"] = 304.022555701998,
				["radius"] = 160,
				["hide"] = true,
			},
			["row_height"] = 20,
			["arrow_anchor_x"] = 0,
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["row_texture"] = "Details Serenity",
			["square_grow_direction"] = "right",
			["point"] = "CENTER",
			["main_frame_strata"] = "LOW",
			["square_amount"] = 5,
			["enabled"] = false,
			["arrow_size"] = 10,
			["font_size"] = 10,
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.2, -- [4]
			},
			["row_color"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.1, -- [3]
				0.4, -- [4]
			},
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["per_second"] = {
				["enabled"] = false,
				["point"] = "CENTER",
				["scale"] = 1,
				["font_shadow"] = true,
				["y"] = -3.0517578125e-05,
				["x"] = 0.0001220703125,
				["size"] = 32,
				["update_speed"] = 0.05,
				["attribute_type"] = 1,
			},
			["use_spark"] = true,
			["x"] = 3.0517578125e-05,
			["font_face"] = "Friz Quadrata TT",
			["square_size"] = 32,
			["y"] = -1.52587890625e-05,
			["author"] = "Terciob",
			["main_frame_locked"] = false,
			["main_frame_size"] = {
				300.0000610351563, -- [1]
				499.9999389648438, -- [2]
			},
		},
	},
	["last_instance_time"] = 0,
	["combat_id"] = 123,
	["savedStyles"] = {
	},
	["last_day"] = "02",
	["character_data"] = {
		["logons"] = 5,
	},
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 0.6107460000000001,
					["pets"] = {
					},
					["aID"] = "5818-00A98B51",
					["total_without_pet"] = 14625.610746,
					["last_dps_realtime"] = 0,
					["total"] = 14625.610746,
					["spec"] = 260,
					["on_hold"] = false,
					["total_extra"] = 0,
					["serial"] = "Player-5818-00A98B51",
					["damage_from"] = {
						["Lieutenant Benedict"] = true,
						["Dire Mottled Boar"] = true,
						["Kul Tiras Sailor"] = true,
						["Razormane Quilboar"] = true,
						["Kul Tiras Marine"] = true,
						["Clattering Scorpid"] = true,
						["Kolkar Outrunner"] = true,
						["Scorpid Worker"] = true,
						["Makrura Clacker"] = true,
						["Mottled Boar"] = true,
						["Kolkar Drudge"] = true,
						["Sarkoth"] = true,
						["Felstalker"] = true,
						["Yarrog Baneshadow"] = true,
						["Pygmy Surf Crawler"] = true,
						["Vile Familiar"] = true,
					},
					["targets"] = {
						["Lieutenant Benedict"] = 207,
						["Dire Mottled Boar"] = 190,
						["Kul Tiras Sailor"] = 2241,
						["Razormane Quilboar"] = 322,
						["Kul Tiras Marine"] = 1024,
						["Clattering Scorpid"] = 544,
						["Kolkar Outrunner"] = 1157,
						["Scorpid Worker"] = 1312,
						["Makrura Clacker"] = 845,
						["Mottled Boar"] = 58,
						["Kolkar Drudge"] = 2296,
						["Sarkoth"] = 91,
						["Felstalker"] = 492,
						["Yarrog Baneshadow"] = 163,
						["Pygmy Surf Crawler"] = 2124,
						["Vile Familiar"] = 1559,
					},
					["classe"] = "ROGUE",
					["dps_started"] = false,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
						[64] = 164,
						[16] = 134,
						[128] = 3414,
					},
					["end_time"] = 1708669885,
					["nome"] = "Poisongrace",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 74,
								["b_amt"] = 19,
								["g_amt"] = 40,
								["n_max"] = 12,
								["targets"] = {
									["Lieutenant Benedict"] = 116,
									["Dire Mottled Boar"] = 81,
									["Kul Tiras Sailor"] = 931,
									["Razormane Quilboar"] = 156,
									["Kul Tiras Marine"] = 401,
									["Clattering Scorpid"] = 280,
									["Kolkar Outrunner"] = 482,
									["Scorpid Worker"] = 693,
									["Makrura Clacker"] = 371,
									["Mottled Boar"] = 16,
									["Kolkar Drudge"] = 969,
									["Sarkoth"] = 43,
									["Felstalker"] = 247,
									["Yarrog Baneshadow"] = 88,
									["Pygmy Surf Crawler"] = 967,
									["Vile Familiar"] = 825,
								},
								["n_total"] = 5279,
								["DODGE"] = 21,
								["n_min"] = 0,
								["g_dmg"] = 266,
								["counter"] = 856,
								["MISS"] = 17,
								["r_amt"] = 0,
								["c_max"] = 23,
								["b_dmg"] = 78,
								["id"] = 1,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["PARRY"] = 15,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 1121,
								["n_amt"] = 689,
								["total"] = 6666,
								["a_amt"] = 0,
							}, -- [1]
							[2098] = {
								["c_amt"] = 4,
								["b_amt"] = 2,
								["g_amt"] = 0,
								["n_max"] = 30,
								["targets"] = {
									["Razormane Quilboar"] = 17,
									["Clattering Scorpid"] = 20,
									["Kolkar Outrunner"] = 23,
									["Scorpid Worker"] = 245,
									["Makrura Clacker"] = 139,
									["Mottled Boar"] = 16,
									["Kolkar Drudge"] = 207,
									["Sarkoth"] = 21,
									["Felstalker"] = 39,
									["Yarrog Baneshadow"] = 19,
									["Pygmy Surf Crawler"] = 319,
									["Vile Familiar"] = 237,
								},
								["n_total"] = 1192,
								["DODGE"] = 2,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 75,
								["MISS"] = 2,
								["total"] = 1302,
								["c_max"] = 56,
								["r_amt"] = 0,
								["id"] = 2098,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 110,
								["n_amt"] = 65,
								["b_dmg"] = 34,
								["a_amt"] = 0,
							},
							[2764] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 13,
								["targets"] = {
									["Mottled Boar"] = 5,
									["Kolkar Drudge"] = 36,
									["Pygmy Surf Crawler"] = 18,
									["Kolkar Outrunner"] = 56,
									["Kul Tiras Sailor"] = 11,
								},
								["n_total"] = 102,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 126,
								["c_max"] = 24,
								["id"] = 2764,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 24,
								["n_amt"] = 10,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[1752] = {
								["c_amt"] = 8,
								["b_amt"] = 4,
								["g_amt"] = 0,
								["n_max"] = 13,
								["targets"] = {
									["Mottled Boar"] = 21,
									["Scorpid Worker"] = 374,
									["Sarkoth"] = 27,
									["Felstalker"] = 154,
									["Yarrog Baneshadow"] = 45,
									["Vile Familiar"] = 395,
								},
								["n_total"] = 863,
								["DODGE"] = 1,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 109,
								["a_amt"] = 0,
								["r_amt"] = 0,
								["c_max"] = 24,
								["b_dmg"] = 23,
								["id"] = 1752,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 153,
								["n_amt"] = 96,
								["total"] = 1016,
								["MISS"] = 2,
							},
							[53] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Vile Familiar"] = 54,
								},
								["n_total"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 54,
								["c_max"] = 54,
								["id"] = 53,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 54,
								["n_amt"] = 0,
								["n_max"] = 0,
								["r_amt"] = 0,
							},
							[6760] = {
								["c_amt"] = 5,
								["b_amt"] = 1,
								["g_amt"] = 0,
								["n_max"] = 50,
								["targets"] = {
									["Dire Mottled Boar"] = 53,
									["Kolkar Drudge"] = 125,
									["Kul Tiras Marine"] = 172,
									["Kul Tiras Sailor"] = 358,
									["Kolkar Outrunner"] = 188,
								},
								["n_total"] = 685,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 28,
								["a_amt"] = 0,
								["total"] = 896,
								["c_max"] = 61,
								["MISS"] = 2,
								["id"] = 6760,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 211,
								["n_amt"] = 20,
								["b_dmg"] = 37,
								["r_amt"] = 0,
							},
							[1757] = {
								["c_amt"] = 25,
								["b_amt"] = 4,
								["g_amt"] = 0,
								["b_dmg"] = 39,
								["targets"] = {
									["Dire Mottled Boar"] = 43,
									["Razormane Quilboar"] = 110,
									["Kul Tiras Marine"] = 429,
									["Clattering Scorpid"] = 218,
									["Kolkar Outrunner"] = 383,
									["Makrura Clacker"] = 279,
									["Kolkar Drudge"] = 794,
									["Lieutenant Benedict"] = 84,
									["Kul Tiras Sailor"] = 737,
									["Pygmy Surf Crawler"] = 644,
								},
								["n_total"] = 3025,
								["g_dmg"] = 0,
								["n_min"] = 0,
								["a_amt"] = 0,
								["counter"] = 271,
								["DODGE"] = 9,
								["total"] = 3721,
								["c_max"] = 35,
								["r_amt"] = 0,
								["id"] = 1757,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["PARRY"] = 9,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 696,
								["n_amt"] = 218,
								["n_max"] = 18,
								["MISS"] = 10,
							},
							[1776] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Makrura Clacker"] = 14,
									["Lieutenant Benedict"] = 7,
									["Kolkar Drudge"] = 8,
									["Razormane Quilboar"] = 17,
									["Kul Tiras Marine"] = 8,
									["Pygmy Surf Crawler"] = 25,
									["Kul Tiras Sailor"] = 17,
									["Clattering Scorpid"] = 26,
								},
								["n_total"] = 105,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 122,
								["c_max"] = 17,
								["a_amt"] = 0,
								["id"] = 1776,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 17,
								["n_amt"] = 13,
								["n_max"] = 9,
								["r_amt"] = 0,
							},
							[399985] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Dire Mottled Boar"] = 13,
									["Razormane Quilboar"] = 22,
									["Kul Tiras Marine"] = 14,
									["Pygmy Surf Crawler"] = 151,
									["Kolkar Outrunner"] = 25,
									["Makrura Clacker"] = 42,
									["Kolkar Drudge"] = 157,
									["Felstalker"] = 52,
									["Yarrog Baneshadow"] = 11,
									["Kul Tiras Sailor"] = 187,
									["Vile Familiar"] = 48,
								},
								["n_total"] = 676,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 54,
								["total"] = 722,
								["c_max"] = 25,
								["id"] = 399985,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 46,
								["n_amt"] = 52,
								["n_max"] = 17,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["last_dps"] = 0,
					["start_time"] = 1708668300,
					["delay"] = 0,
					["damage_taken"] = 3727.610745999999,
				}, -- [1]
				{
					["flag_original"] = 68136,
					["pets"] = {
					},
					["aID"] = "3098",
					["total_without_pet"] = 4.005710000000001,
					["last_dps_realtime"] = 0,
					["dps_started"] = false,
					["total"] = 4.005710000000001,
					["on_hold"] = false,
					["total_extra"] = 0,
					["serial"] = "Creature-0-5153-1-94-3098-0000583AAE",
					["damage_from"] = {
						["Poisongrace"] = true,
					},
					["targets"] = {
						["Poisongrace"] = 4,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["classe"] = "UNKNOW",
					["fight_component"] = true,
					["end_time"] = 1708669885,
					["totalabsorbed"] = 0.00571,
					["nome"] = "Mottled Boar",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2,
								["targets"] = {
									["Poisongrace"] = 4,
								},
								["n_total"] = 4,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 4,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 58.00570999999999,
					["start_time"] = 1708669877,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [2]
				{
					["flag_original"] = 68136,
					["pets"] = {
					},
					["aID"] = "3124",
					["total_without_pet"] = 229.096421,
					["last_dps_realtime"] = 0,
					["dps_started"] = false,
					["total"] = 229.096421,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5153-1-94-3124-0000583CB2",
					["damage_from"] = {
						["Poisongrace"] = true,
					},
					["targets"] = {
						["Poisongrace"] = 229,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["classe"] = "UNKNOW",
					["fight_component"] = true,
					["end_time"] = 1708670387,
					["totalabsorbed"] = 0.096421,
					["nome"] = "Scorpid Worker",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 213,
								},
								["n_total"] = 213,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 99,
								["MISS"] = 4,
								["r_amt"] = 0,
								["spellschool"] = 1,
								["DODGE"] = 17,
								["id"] = 1,
								["r_dmg"] = 0,
								["c_max"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 78,
								["n_max"] = 3,
								["total"] = 213,
							}, -- [1]
							[6751] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 16,
								},
								["n_total"] = 16,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 16,
								["c_max"] = 0,
								["id"] = 6751,
								["r_dmg"] = 0,
								["spellschool"] = 8,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 16,
								["n_max"] = 1,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["on_hold"] = false,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 1312.096421,
					["start_time"] = 1708670198,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [3]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["aID"] = "3101",
					["total_without_pet"] = 256.074015,
					["last_dps_realtime"] = 0,
					["dps_started"] = false,
					["total"] = 256.074015,
					["on_hold"] = false,
					["total_extra"] = 0,
					["serial"] = "Creature-0-5153-1-94-3101-0000583DE5",
					["classe"] = "UNKNOW",
					["damage_from"] = {
						["Getutrix"] = true,
						["Poisongrace"] = true,
					},
					["targets"] = {
						["Poisongrace"] = 256,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["totalabsorbed"] = 0.07401499999999998,
					["fight_component"] = true,
					["end_time"] = 1708670839,
					["monster"] = true,
					["nome"] = "Vile Familiar",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 215,
								},
								["n_total"] = 215,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 74,
								["MISS"] = 3,
								["r_amt"] = 0,
								["spellschool"] = 1,
								["DODGE"] = 6,
								["id"] = 1,
								["r_dmg"] = 0,
								["c_max"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 65,
								["n_max"] = 4,
								["total"] = 215,
							}, -- [1]
							[11921] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 41,
								},
								["n_total"] = 41,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 41,
								["c_max"] = 0,
								["id"] = 11921,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 11,
								["c_total"] = 0,
								["n_amt"] = 12,
								["n_max"] = 5,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 1583.074015,
					["start_time"] = 1708670640,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [4]
				{
					["flag_original"] = 2632,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 30.013748,
					["last_dps_realtime"] = 0,
					["monster"] = true,
					["total"] = 30.013748,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5153-1-94-3281-0000583FCF",
					["on_hold"] = false,
					["damage_from"] = {
						["Poisongrace"] = true,
					},
					["targets"] = {
						["Poisongrace"] = 30,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["totalabsorbed"] = 0.013748,
					["fight_component"] = true,
					["end_time"] = 1708671309,
					["aID"] = "3281",
					["nome"] = "Sarkoth",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 25,
								},
								["n_total"] = 25,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 9,
								["DODGE"] = 1,
								["r_amt"] = 0,
								["spellschool"] = 1,
								["MISS"] = 1,
								["id"] = 1,
								["r_dmg"] = 0,
								["c_max"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 7,
								["n_max"] = 4,
								["total"] = 25,
							}, -- [1]
							[11918] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 5,
								},
								["n_total"] = 5,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 5,
								["c_max"] = 0,
								["id"] = 11918,
								["r_dmg"] = 0,
								["spellschool"] = 8,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 5,
								["n_max"] = 1,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 91.01374799999999,
					["start_time"] = 1708671288,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [5]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 107.041744,
					["last_dps_realtime"] = 0,
					["monster"] = true,
					["total"] = 107.041744,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5153-1-94-3102-0000D845B6",
					["on_hold"] = false,
					["damage_from"] = {
						["Poisongrace"] = true,
					},
					["targets"] = {
						["Poisongrace"] = 107,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["totalabsorbed"] = 0.041744,
					["fight_component"] = true,
					["end_time"] = 1708672482,
					["aID"] = "3102",
					["nome"] = "Felstalker",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 107,
								},
								["n_total"] = 107,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 37,
								["MISS"] = 2,
								["r_amt"] = 0,
								["spellschool"] = 1,
								["DODGE"] = 2,
								["id"] = 1,
								["r_dmg"] = 0,
								["c_max"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 33,
								["n_max"] = 4,
								["total"] = 107,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 492.041744,
					["start_time"] = 1708672404,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [6]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 136.016171,
					["last_dps_realtime"] = 0,
					["monster"] = true,
					["total"] = 136.016171,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5153-1-94-3183-0000584686",
					["on_hold"] = false,
					["damage_from"] = {
						["Poisongrace"] = true,
					},
					["targets"] = {
						["Poisongrace"] = 136,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["totalabsorbed"] = 0.016171,
					["fight_component"] = true,
					["end_time"] = 1708672878,
					["aID"] = "3183",
					["nome"] = "Yarrog Baneshadow",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 50,
								},
								["n_total"] = 50,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 13,
								["MISS"] = 1,
								["r_amt"] = 0,
								["spellschool"] = 1,
								["DODGE"] = 2,
								["id"] = 1,
								["r_dmg"] = 0,
								["c_max"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 10,
								["n_max"] = 6,
								["total"] = 50,
							}, -- [1]
							[172] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 47,
								},
								["n_total"] = 47,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 47,
								["c_max"] = 0,
								["id"] = 172,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["c_total"] = 0,
								["n_amt"] = 8,
								["n_max"] = 6,
								["r_amt"] = 0,
							},
							[348] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 39,
								},
								["n_total"] = 39,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 39,
								["c_max"] = 0,
								["id"] = 348,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["c_total"] = 0,
								["n_amt"] = 11,
								["n_max"] = 7,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 163.016171,
					["start_time"] = 1708672828,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [7]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 250.022018,
					["last_dps_realtime"] = 0,
					["monster"] = true,
					["total"] = 250.022018,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5153-1-94-3111-0000584A1C",
					["on_hold"] = false,
					["damage_from"] = {
						["Poisongrace"] = true,
					},
					["targets"] = {
						["Poisongrace"] = 250,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["totalabsorbed"] = 0.022018,
					["fight_component"] = true,
					["end_time"] = 1708674118,
					["aID"] = "3111",
					["nome"] = "Razormane Quilboar",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 196,
								},
								["n_total"] = 196,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 31,
								["DODGE"] = 4,
								["r_amt"] = 0,
								["spellschool"] = 1,
								["MISS"] = 3,
								["id"] = 1,
								["r_dmg"] = 0,
								["c_max"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 24,
								["n_max"] = 10,
								["total"] = 196,
							}, -- [1]
							[5280] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 54,
								},
								["n_total"] = 54,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 20,
								["total"] = 54,
								["c_max"] = 0,
								["id"] = 5280,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 4,
								["c_total"] = 0,
								["n_amt"] = 20,
								["n_max"] = 3,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 322.022018,
					["start_time"] = 1708674063,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [8]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 207.038256,
					["last_dps_realtime"] = 0,
					["monster"] = true,
					["total"] = 207.038256,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5153-1-94-3125-0000584C3F",
					["on_hold"] = false,
					["damage_from"] = {
						["Poisongrace"] = true,
					},
					["targets"] = {
						["Poisongrace"] = 207,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["totalabsorbed"] = 0.038256,
					["fight_component"] = true,
					["end_time"] = 1708674312,
					["aID"] = "3125",
					["nome"] = "Clattering Scorpid",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 204,
								},
								["n_total"] = 204,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 39,
								["MISS"] = 1,
								["r_amt"] = 0,
								["spellschool"] = 1,
								["DODGE"] = 7,
								["id"] = 1,
								["r_dmg"] = 0,
								["c_max"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 31,
								["n_max"] = 8,
								["total"] = 204,
							}, -- [1]
							[11918] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1,
								["targets"] = {
									["Poisongrace"] = 3,
								},
								["n_total"] = 3,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 3,
								["c_max"] = 0,
								["RESIST"] = 1,
								["id"] = 11918,
								["r_dmg"] = 0,
								["spellschool"] = 8,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 544.038256,
					["start_time"] = 1708674228,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [9]
				{
					["flag_original"] = 68136,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 559.094732,
					["last_dps_realtime"] = 0,
					["dps_started"] = false,
					["total"] = 559.094732,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5153-1-76-3106-0000599983",
					["damage_from"] = {
						["Poisongrace"] = true,
					},
					["targets"] = {
						["Poisongrace"] = 559,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["aID"] = "3106",
					["fight_component"] = true,
					["end_time"] = 1708763226,
					["totalabsorbed"] = 0.094732,
					["nome"] = "Pygmy Surf Crawler",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 559,
								},
								["n_total"] = 559,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 93,
								["DODGE"] = 7,
								["r_amt"] = 0,
								["spellschool"] = 1,
								["MISS"] = 2,
								["id"] = 1,
								["r_dmg"] = 0,
								["c_max"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 84,
								["n_max"] = 8,
								["total"] = 559,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["on_hold"] = false,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 2124.094732,
					["start_time"] = 1708763011,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [10]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 353.039919,
					["last_dps_realtime"] = 0,
					["monster"] = true,
					["total"] = 353.039919,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5153-1-76-3103-0000599C29",
					["on_hold"] = false,
					["damage_from"] = {
						["Poisongrace"] = true,
					},
					["targets"] = {
						["Poisongrace"] = 353,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["totalabsorbed"] = 0.039919,
					["fight_component"] = true,
					["end_time"] = 1708763302,
					["aID"] = "3103",
					["nome"] = "Makrura Clacker",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 353,
								},
								["n_total"] = 353,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 50,
								["MISS"] = 2,
								["r_amt"] = 0,
								["spellschool"] = 1,
								["DODGE"] = 6,
								["id"] = 1,
								["r_dmg"] = 0,
								["c_max"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 42,
								["n_max"] = 11,
								["total"] = 353,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 845.039919,
					["start_time"] = 1708763187,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [11]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 528.105047,
					["last_dps_realtime"] = 0,
					["monster"] = true,
					["total"] = 528.105047,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5153-1-76-3119-000059A90D",
					["on_hold"] = false,
					["damage_from"] = {
						["Poisongrace"] = true,
						["Zenmesh"] = true,
						["野猪"] = true,
					},
					["targets"] = {
						["Poisongrace"] = 492,
						["Zenmesh"] = 9,
						["野猪"] = 27,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["totalabsorbed"] = 0.105047,
					["fight_component"] = true,
					["end_time"] = 1708763894,
					["aID"] = "3119",
					["nome"] = "Kolkar Drudge",
					["spells"] = {
						["_ActorTable"] = {
							{
								["DODGE"] = 16,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 492,
									["Zenmesh"] = 9,
									["野猪"] = 27,
								},
								["n_total"] = 528,
								["g_dmg"] = 0,
								["n_min"] = 0,
								["a_amt"] = 0,
								["counter"] = 85,
								["MISS"] = 4,
								["total"] = 528,
								["c_max"] = 0,
								["c_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 64,
								["r_amt"] = 0,
								["n_max"] = 11,
							}, -- [1]
							[7272] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
								},
								["n_total"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 7272,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["c_total"] = 0,
								["n_amt"] = 0,
								["n_max"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 2511.105047,
					["start_time"] = 1708763704,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [12]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 391.040478,
					["last_dps_realtime"] = 0,
					["monster"] = true,
					["total"] = 391.040478,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5153-1-76-3120-000059AADE",
					["on_hold"] = false,
					["damage_from"] = {
						["Poisongrace"] = true,
					},
					["targets"] = {
						["Poisongrace"] = 391,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["totalabsorbed"] = 0.04047800000000001,
					["fight_component"] = true,
					["end_time"] = 1708764109,
					["aID"] = "3120",
					["nome"] = "Kolkar Outrunner",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Poisongrace"] = 274,
								},
								["n_total"] = 274,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 37,
								["total"] = 274,
								["c_max"] = 0,
								["DODGE"] = 8,
								["id"] = 1,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 29,
								["n_max"] = 12,
								["r_amt"] = 0,
							}, -- [1]
							[6660] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 11,
								["targets"] = {
									["Poisongrace"] = 117,
								},
								["n_total"] = 117,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 13,
								["total"] = 117,
								["c_max"] = 0,
								["id"] = 6660,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 12,
								["c_total"] = 0,
								["n_amt"] = 13,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 1157.040478,
					["start_time"] = 1708763979,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [13]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.008858,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 48.008858,
					["last_dps_realtime"] = 0,
					["dps_started"] = false,
					["total"] = 48.008858,
					["on_hold"] = false,
					["total_extra"] = 0,
					["serial"] = "Creature-0-5154-1-106-3099-000061D2CD",
					["aID"] = "3099",
					["fight_component"] = true,
					["damage_from"] = {
						["Poisongrace"] = true,
					},
					["targets"] = {
						["Poisongrace"] = 48,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["end_time"] = 1709347175,
					["nome"] = "Dire Mottled Boar",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 11,
								["targets"] = {
									["Poisongrace"] = 48,
								},
								["n_total"] = 48,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["DODGE"] = 2,
								["total"] = 48,
								["c_max"] = 0,
								["MISS"] = 1,
								["id"] = 1,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
					},
					["friendlyfire"] = {
					},
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 190.008858,
					["start_time"] = 1709347156,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [14]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.106957,
					["pets"] = {
					},
					["serial"] = "Creature-0-5154-1-106-3128-0000628DB3",
					["classe"] = "UNKNOW",
					["aID"] = "3128",
					["total_without_pet"] = 604.106957,
					["last_dps_realtime"] = 0,
					["dps_started"] = false,
					["total"] = 604.106957,
					["on_hold"] = false,
					["total_extra"] = 0,
					["fight_component"] = true,
					["damage_from"] = {
						["Poisongrace"] = true,
						["Rattangkor"] = true,
						["Bishoptamaki"] = true,
					},
					["targets"] = {
						["Rattangkor"] = 172,
						["Poisongrace"] = 432,
					},
					["monster"] = true,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["end_time"] = 1709347947,
					["nome"] = "Kul Tiras Sailor",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 2,
								["g_amt"] = 0,
								["n_max"] = 30,
								["targets"] = {
									["Rattangkor"] = 172,
									["Poisongrace"] = 432,
								},
								["n_total"] = 604,
								["a_amt"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 93,
								["MISS"] = 3,
								["total"] = 604,
								["c_max"] = 0,
								["DODGE"] = 15,
								["id"] = 1,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 74,
								["b_dmg"] = 11,
								["r_amt"] = 0,
							}, -- [1]
							[6268] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_total"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 6268,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 5,
								["c_total"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 2929.106957,
					["start_time"] = 1709347764,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [15]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.048745,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 380.048745,
					["last_dps_realtime"] = 0,
					["dps_started"] = false,
					["total"] = 380.048745,
					["serial"] = "Creature-0-5154-1-106-3129-0000628FCC",
					["aID"] = "3129",
					["on_hold"] = false,
					["total_extra"] = 0,
					["fight_component"] = true,
					["damage_from"] = {
						["Rattangkor"] = true,
						["Poisongrace"] = true,
					},
					["targets"] = {
						["Rattangkor"] = 178,
						["Poisongrace"] = 202,
					},
					["monster"] = true,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["end_time"] = 1709348252,
					["nome"] = "Kul Tiras Marine",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 1,
								["g_amt"] = 0,
								["n_max"] = 11,
								["targets"] = {
									["Rattangkor"] = 178,
									["Poisongrace"] = 202,
								},
								["n_total"] = 380,
								["a_amt"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 59,
								["DODGE"] = 8,
								["total"] = 380,
								["c_max"] = 0,
								["MISS"] = 3,
								["id"] = 1,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 47,
								["b_dmg"] = 6,
								["r_amt"] = 0,
							}, -- [1]
						},
					},
					["friendlyfire"] = {
					},
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 1690.048745,
					["start_time"] = 1709348128,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [16]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.090958,
					["pets"] = {
					},
					["classe"] = "WARRIOR",
					["total_without_pet"] = 1332.090958,
					["last_dps_realtime"] = 0,
					["dps_started"] = false,
					["total"] = 1332.090958,
					["serial"] = "Player-5818-00A9F3B5",
					["spec"] = 71,
					["aID"] = "5818-00A9F3B5",
					["on_hold"] = false,
					["total_extra"] = 0,
					["damage_from"] = {
						["Kul Tiras Marine"] = true,
						["Kul Tiras Sailor"] = true,
						["Lieutenant Benedict"] = true,
					},
					["targets"] = {
						["Kul Tiras Marine"] = 666,
						["Kul Tiras Sailor"] = 514,
						["Lieutenant Benedict"] = 152,
					},
					["grupo"] = true,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["end_time"] = 1709348294,
					["nome"] = "Rattangkor",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 3,
								["b_amt"] = 4,
								["g_amt"] = 1,
								["n_max"] = 15,
								["targets"] = {
									["Kul Tiras Marine"] = 469,
									["Kul Tiras Sailor"] = 330,
									["Lieutenant Benedict"] = 103,
								},
								["n_total"] = 807,
								["n_min"] = 0,
								["g_dmg"] = 11,
								["counter"] = 69,
								["MISS"] = 1,
								["total"] = 902,
								["c_max"] = 30,
								["DODGE"] = 1,
								["id"] = 1,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 84,
								["n_amt"] = 63,
								["b_dmg"] = 29,
								["r_amt"] = 0,
							}, -- [1]
							[6343] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 18,
								["targets"] = {
									["Kul Tiras Marine"] = 33,
									["Kul Tiras Sailor"] = 52,
									["Lieutenant Benedict"] = 14,
								},
								["n_total"] = 99,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 99,
								["c_max"] = 0,
								["id"] = 6343,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[772] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 5,
								["targets"] = {
									["Kul Tiras Marine"] = 55,
									["Kul Tiras Sailor"] = 40,
									["Lieutenant Benedict"] = 15,
								},
								["n_total"] = 110,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 24,
								["total"] = 110,
								["c_max"] = 0,
								["DODGE"] = 2,
								["id"] = 772,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 22,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[78] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 23,
								["targets"] = {
									["Kul Tiras Marine"] = 93,
									["Kul Tiras Sailor"] = 69,
									["Lieutenant Benedict"] = 20,
								},
								["n_total"] = 135,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 182,
								["c_max"] = 47,
								["MISS"] = 1,
								["id"] = 78,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 47,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[2764] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8,
								["targets"] = {
									["Kul Tiras Marine"] = 16,
									["Kul Tiras Sailor"] = 23,
								},
								["n_total"] = 24,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 39,
								["c_max"] = 15,
								["id"] = 2764,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 15,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 375.090958,
					["start_time"] = 1709348100,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [17]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.015092,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 74.015092,
					["last_dps_realtime"] = 0,
					["dps_started"] = false,
					["total"] = 74.015092,
					["serial"] = "Creature-0-5154-1-106-3192-0000628EF6",
					["aID"] = "3192",
					["on_hold"] = false,
					["total_extra"] = 0,
					["fight_component"] = true,
					["damage_from"] = {
						["Rattangkor"] = true,
						["Poisongrace"] = true,
					},
					["targets"] = {
						["Rattangkor"] = 43,
						["Poisongrace"] = 31,
					},
					["monster"] = true,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["end_time"] = 1709348383,
					["nome"] = "Lieutenant Benedict",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 11,
								["targets"] = {
									["Rattangkor"] = 43,
									["Poisongrace"] = 31,
								},
								["n_total"] = 74,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["DODGE"] = 1,
								["total"] = 74,
								["c_max"] = 0,
								["a_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 8,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[7164] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_total"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 7164,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["c_total"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[3248] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_total"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 3248,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["c_total"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 359.015092,
					["start_time"] = 1709348359,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [18]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["targets_overheal"] = {
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.00615,
					["total_without_pet"] = 39.00615,
					["total"] = 39.00615,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-5818-00A98B51",
					["totalabsorb"] = 0.00615,
					["last_hps"] = 0,
					["targets"] = {
						["Poisongrace"] = 39,
					},
					["last_event"] = 0,
					["totalover_without_pet"] = 0.00615,
					["healing_taken"] = 39.00615,
					["fight_component"] = true,
					["end_time"] = 1708674152,
					["healing_from"] = {
						["Poisongrace"] = true,
					},
					["spec"] = 260,
					["nome"] = "Poisongrace",
					["spells"] = {
						["_ActorTable"] = {
							[439] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 39,
								["targets"] = {
									["Poisongrace"] = 39,
								},
								["n_total"] = 39,
								["n_min"] = 0,
								["counter"] = 1,
								["overheal"] = 0,
								["total"] = 39,
								["spellschool"] = 1,
								["id"] = 439,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_max"] = 0,
								["c_total"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 1,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["start_time"] = 1708674148,
					["aID"] = "5818-00A98B51",
					["custom"] = 0,
					["tipo"] = 2,
					["totaldenied"] = 0.00615,
					["delay"] = 0,
					["classe"] = "ROGUE",
				}, -- [1]
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[1776] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 14,
								["id"] = 1776,
								["uptime"] = 42,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["aID"] = "5818-00A98B51",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[19705] = {
								["actived_at"] = 1708763251,
								["refreshamt"] = 0,
								["activedamt"] = 9,
								["appliedamt"] = 9,
								["id"] = 19705,
								["uptime"] = 114,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[23234] = {
								["actived_at"] = 1709348261,
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 23234,
								["uptime"] = 0,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[5277] = {
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 5277,
								["uptime"] = 22,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[1784] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 1784,
								["uptime"] = 7,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[436412] = {
								["refreshamt"] = 0,
								["activedamt"] = 123,
								["appliedamt"] = 123,
								["id"] = 436412,
								["uptime"] = 1830,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 42,
					["buff_uptime_targets"] = {
					},
					["spec"] = 260,
					["cc_break"] = 5.025407,
					["cc_done_targets"] = {
						["Makrura Clacker"] = 2,
						["Lieutenant Benedict"] = 1,
						["Kolkar Drudge"] = 1,
						["Razormane Quilboar"] = 2,
						["Kul Tiras Marine"] = 1,
						["Pygmy Surf Crawler"] = 2,
						["Kul Tiras Sailor"] = 2,
						["Clattering Scorpid"] = 3,
					},
					["serial"] = "Player-5818-00A98B51",
					["tipo"] = 4,
					["cc_break_spells"] = {
						["_ActorTable"] = {
							[0] = {
								["cc_break_oque"] = {
									[1776] = 3,
								},
								["id"] = 0,
								["targets"] = {
									["Pygmy Surf Crawler"] = 2,
									["Clattering Scorpid"] = 1,
								},
								["cc_break"] = 3,
								["counter"] = 0,
							},
							["DEBUFF"] = {
								["cc_break_oque"] = {
									[1776] = 2,
								},
								["id"] = "DEBUFF",
								["targets"] = {
									["Kul Tiras Marine"] = 1,
									["Razormane Quilboar"] = 1,
								},
								["cc_break"] = 2,
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime"] = 1973,
					["cc_done_spells"] = {
						["_ActorTable"] = {
							[1776] = {
								["id"] = 1776,
								["targets"] = {
									["Makrura Clacker"] = 2,
									["Lieutenant Benedict"] = 1,
									["Kolkar Drudge"] = 1,
									["Razormane Quilboar"] = 2,
									["Kul Tiras Marine"] = 1,
									["Pygmy Surf Crawler"] = 2,
									["Kul Tiras Sailor"] = 2,
									["Clattering Scorpid"] = 3,
								},
								["counter"] = 14,
							},
						},
						["tipo"] = 9,
					},
					["fight_component"] = true,
					["cc_done"] = 14.071991,
					["nome"] = "Poisongrace",
					["grupo"] = true,
					["cc_break_oque"] = {
						[1776] = 5,
					},
					["last_event"] = 0,
					["cc_break_targets"] = {
						["Kul Tiras Marine"] = 1,
						["Clattering Scorpid"] = 1,
						["Pygmy Surf Crawler"] = 2,
						["Razormane Quilboar"] = 1,
					},
					["classe"] = "ROGUE",
					["debuff_uptime_targets"] = {
					},
				}, -- [1]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["aID"] = "3101",
					["fight_component"] = true,
					["nome"] = "Vile Familiar",
					["monster"] = true,
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["serial"] = "Creature-0-5153-1-94-3101-0000583DE5",
					["tipo"] = 4,
				}, -- [2]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["aID"] = "3183",
					["monster"] = true,
					["nome"] = "Yarrog Baneshadow",
					["spec"] = 267,
					["fight_component"] = true,
					["last_event"] = 0,
					["tipo"] = 4,
					["serial"] = "Creature-0-5153-1-94-3183-0000584686",
					["classe"] = "WARLOCK",
				}, -- [3]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["aID"] = "3111",
					["fight_component"] = true,
					["nome"] = "Razormane Quilboar",
					["monster"] = true,
					["tipo"] = 4,
					["last_event"] = 0,
					["serial"] = "Creature-0-5153-1-94-3111-0000584A1C",
					["classe"] = "UNKNOW",
				}, -- [4]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["monster"] = true,
					["nome"] = "Kolkar Drudge",
					["tipo"] = 4,
					["last_event"] = 0,
					["aID"] = "3119",
					["serial"] = "Creature-0-5153-1-76-3119-000059A9F3",
					["fight_component"] = true,
				}, -- [5]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["aID"] = "3120",
					["serial"] = "Creature-0-5154-1-106-3120-00006289E5",
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["tipo"] = 4,
					["nome"] = "Kolkar Outrunner",
					["monster"] = true,
					["last_event"] = 0,
				}, -- [6]
				{
					["flag_original"] = 2632,
					["pets"] = {
					},
					["serial"] = "Creature-0-5154-1-106-3128-0000E29124",
					["aID"] = "3128",
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["tipo"] = 4,
					["nome"] = "Kul Tiras Sailor",
					["monster"] = true,
					["last_event"] = 0,
				}, -- [7]
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							[6343] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 6,
								["id"] = 6343,
								["uptime"] = 20,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[772] = {
								["actived_at"] = 1709348614,
								["refreshamt"] = 0,
								["activedamt"] = -1,
								["appliedamt"] = 13,
								["id"] = 772,
								["uptime"] = 74,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[7922] = {
								["refreshamt"] = 0,
								["appliedamt"] = 0,
								["activedamt"] = -4,
								["uptime"] = 0,
								["id"] = 7922,
								["actived_at"] = 6837394030,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["pets"] = {
					},
					["classe"] = "WARRIOR",
					["buff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							[436412] = {
								["actived_at"] = 1709348607,
								["refreshamt"] = 0,
								["activedamt"] = 14,
								["appliedamt"] = 14,
								["id"] = 436412,
								["uptime"] = 183,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[26635] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 26635,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["debuff_uptime"] = 94,
					["buff_uptime_targets"] = {
					},
					["spec"] = 71,
					["cc_break"] = 2.01005,
					["cc_break_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							[0] = {
								["cc_break_oque"] = {
									[1776] = 2,
								},
								["id"] = 0,
								["cc_break"] = 2,
								["targets"] = {
									["Kul Tiras Sailor"] = 1,
									["Lieutenant Benedict"] = 1,
								},
								["counter"] = 0,
							},
						},
					},
					["buff_uptime"] = 193,
					["tipo"] = 4,
					["aID"] = "5818-00A9F3B5",
					["nome"] = "Rattangkor",
					["grupo"] = true,
					["debuff_uptime_targets"] = {
					},
					["cc_break_oque"] = {
						[1776] = 2,
					},
					["last_event"] = 0,
					["cc_break_targets"] = {
						["Kul Tiras Sailor"] = 1,
						["Lieutenant Benedict"] = 1,
					},
					["serial"] = "Player-5818-00A9F3B5",
				}, -- [8]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["aID"] = "3192",
					["tipo"] = 4,
					["serial"] = "Creature-0-5154-1-106-3192-0000628EF6",
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "Lieutenant Benedict",
					["monster"] = true,
					["last_event"] = 0,
				}, -- [9]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["raid_roster_indexed"] = {
		},
		["tempo_start"] = 1708669877,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["bossTimers"] = {
		},
		["combat_counter"] = 3,
		["totals"] = {
			20527.403852, -- [1]
			39.004793, -- [2]
			{
				18.007563, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 0,
				["dispell"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["cc_break"] = 7.035456999999999,
				["dead"] = 0,
			}, -- [4]
			["frags_total"] = 0,
			["voidzone_damage"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["overall_refreshed"] = true,
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["damage_section"] = {
			},
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage"] = {
			},
		},
		["amountCasts"] = {
			["Rattangkor"] = {
				["Thunder Clap"] = 3,
				["Berserking"] = 1,
				["Rend"] = 15,
				["Throw"] = 1,
				["Heroic Strike"] = 8,
			},
			["Razormane Quilboar"] = {
				["Razor Mane"] = 4,
			},
			["Kul Tiras Sailor"] = {
				["Rushing Charge"] = 5,
			},
			["Kolkar Outrunner"] = {
				["Shoot"] = 12,
			},
			["Kolkar Drudge"] = {
				["Dust Cloud"] = 3,
			},
			["Lieutenant Benedict"] = {
				["Defensive Stance"] = 2,
				["Improved Blocking"] = 1,
			},
			["Yarrog Baneshadow"] = {
				["Corruption"] = 3,
				["Immolate"] = 3,
			},
			["Poisongrace"] = {
				["Evasion"] = 2,
				["Backstab"] = 1,
				["Healing Potion"] = 1,
				["Sinister Strike"] = 371,
				["Eviscerate"] = 103,
				["Blood Fury"] = 6,
				["Shadowstrike"] = 2,
				["Stealth"] = 1,
				["Gouge"] = 13,
			},
			["Vile Familiar"] = {
				["Fireball"] = 11,
			},
		},
		["cleu_events"] = {
			["n"] = 1,
		},
		["totals_grupo"] = {
			15957.693307, -- [1]
			39.004793, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 0,
				["dispell"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["cc_break"] = 7.035456999999999,
				["dead"] = 0,
			}, -- [4]
		},
		["data_inicio"] = "16:31:17",
		["end_time"] = 525127.462,
		["frags"] = {
		},
		["spells_cast_timeline"] = {
		},
		["data_fim"] = "13:05:10",
		["overall_enemy_name"] = "-- x -- x --",
		["segments_added"] = {
			{
				["elapsed"] = 16.31700000003912,
				["type"] = 0,
				["name"] = "Clattering Scorpid",
				["clock"] = "13:04:53",
			}, -- [1]
			{
				["elapsed"] = 9.414999999920838,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "13:04:23",
			}, -- [2]
			{
				["elapsed"] = 25.05000000004657,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "13:03:27",
			}, -- [3]
			{
				["elapsed"] = 16.11600000003818,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "13:03:05",
			}, -- [4]
			{
				["elapsed"] = 12.04899999999907,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "13:02:45",
			}, -- [5]
			{
				["elapsed"] = 7.0669999999227,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "13:02:30",
			}, -- [6]
			{
				["elapsed"] = 7.040000000037253,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "13:02:15",
			}, -- [7]
			{
				["elapsed"] = 6.033999999985099,
				["type"] = 0,
				["name"] = "Kul Tiras Marine",
				["clock"] = "13:02:05",
			}, -- [8]
			{
				["elapsed"] = 10.0669999999227,
				["type"] = 0,
				["name"] = "Kul Tiras Marine",
				["clock"] = "13:01:28",
			}, -- [9]
			{
				["elapsed"] = 8.018000000040047,
				["type"] = 0,
				["name"] = "Kul Tiras Marine",
				["clock"] = "13:00:44",
			}, -- [10]
			{
				["elapsed"] = 12.09999999997672,
				["type"] = 0,
				["name"] = "Kul Tiras Marine",
				["clock"] = "13:00:24",
			}, -- [11]
			{
				["elapsed"] = 29.18499999993946,
				["type"] = 0,
				["name"] = "Kul Tiras Marine",
				["clock"] = "12:59:53",
			}, -- [12]
			{
				["elapsed"] = 21.18299999996088,
				["type"] = 0,
				["name"] = "Lieutenant Benedict",
				["clock"] = "12:59:22",
			}, -- [13]
			{
				["elapsed"] = 12.06999999994878,
				["type"] = 0,
				["name"] = "Kul Tiras Marine",
				["clock"] = "12:59:04",
			}, -- [14]
			{
				["elapsed"] = 9.084000000031665,
				["type"] = 0,
				["name"] = "Kul Tiras Marine",
				["clock"] = "12:58:42",
			}, -- [15]
			{
				["elapsed"] = 33.2160000000149,
				["type"] = 0,
				["name"] = "Kul Tiras Marine",
				["clock"] = "12:57:41",
			}, -- [16]
			{
				["elapsed"] = 27.3169999999227,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "12:57:05",
			}, -- [17]
			{
				["elapsed"] = 12.80000000004657,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "12:56:45",
			}, -- [18]
			{
				["elapsed"] = 6.481999999959953,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "12:56:17",
			}, -- [19]
			{
				["elapsed"] = 11.7829999999376,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "12:55:54",
			}, -- [20]
			{
				["elapsed"] = 30.40000000002328,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "12:54:44",
			}, -- [21]
			{
				["elapsed"] = 11.13300000003073,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "12:54:20",
			}, -- [22]
			{
				["elapsed"] = 11.24900000006892,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "12:54:02",
			}, -- [23]
			{
				["elapsed"] = 9.73499999998603,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "12:53:41",
			}, -- [24]
			{
				["elapsed"] = 9.48300000000745,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "12:53:19",
			}, -- [25]
			{
				["elapsed"] = 9.51699999999255,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "12:52:55",
			}, -- [26]
			{
				["elapsed"] = 7.849000000045635,
				["type"] = 0,
				["name"] = "Kul Tiras Sailor",
				["clock"] = "12:52:19",
			}, -- [27]
			{
				["elapsed"] = 20.06599999999162,
				["type"] = 0,
				["name"] = "Clattering Scorpid",
				["clock"] = "12:50:40",
			}, -- [28]
			{
				["elapsed"] = 25.91600000002654,
				["type"] = 0,
				["name"] = "Clattering Scorpid",
				["clock"] = "12:49:10",
			}, -- [29]
			{
				["elapsed"] = 15.91800000000512,
				["type"] = 0,
				["name"] = "Kolkar Drudge",
				["clock"] = "12:48:33",
			}, -- [30]
			{
				["elapsed"] = 9.684999999997672,
				["type"] = 0,
				["name"] = "Kolkar Outrunner",
				["clock"] = "12:46:44",
			}, -- [31]
			{
				["elapsed"] = 30.66599999996834,
				["type"] = 0,
				["name"] = "Kolkar Outrunner",
				["clock"] = "12:46:00",
			}, -- [32]
			{
				["elapsed"] = 16.91500000003725,
				["type"] = 0,
				["name"] = "Kolkar Outrunner",
				["clock"] = "12:45:21",
			}, -- [33]
			{
				["elapsed"] = 12.79899999999907,
				["type"] = 0,
				["name"] = "Kolkar Drudge",
				["clock"] = "12:45:04",
			}, -- [34]
			{
				["elapsed"] = 14.46799999999348,
				["type"] = 0,
				["name"] = "Kolkar Drudge",
				["clock"] = "12:44:44",
			}, -- [35]
			{
				["elapsed"] = 22.66599999996834,
				["type"] = 0,
				["name"] = "Kolkar Drudge",
				["clock"] = "12:43:46",
			}, -- [36]
			{
				["elapsed"] = 22.96700000000419,
				["type"] = 0,
				["name"] = "Kolkar Outrunner",
				["clock"] = "12:43:00",
			}, -- [37]
			{
				["elapsed"] = 33.69900000002235,
				["type"] = 0,
				["name"] = "Kolkar Outrunner",
				["clock"] = "12:42:19",
			}, -- [38]
			{
				["elapsed"] = 15.63300000003073,
				["type"] = 0,
				["name"] = "Kolkar Drudge",
				["clock"] = "12:41:52",
			}, -- [39]
			{
				["elapsed"] = 12.94900000002235,
				["type"] = 0,
				["name"] = "Kolkar Outrunner",
				["clock"] = "12:41:23",
			}, -- [40]
		},
		["cleu_timeline"] = {
		},
		["start_time"] = 523298.3399999999,
		["TimeData"] = {
		},
		["trinketProcs"] = {
		},
	},
	["last_realversion"] = 155,
	["nick_tag_cache"] = {
		["nextreset"] = 1709965612,
		["last_version"] = 16,
	},
	["data_harvested_for_charts"] = {
	},
	["announce_cooldowns"] = {
		["enabled"] = false,
		["ignored_cooldowns"] = {
		},
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
	},
}

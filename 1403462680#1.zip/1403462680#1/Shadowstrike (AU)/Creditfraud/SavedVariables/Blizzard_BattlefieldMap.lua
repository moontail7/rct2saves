
BattlefieldMapOptions = {
	["locked"] = false,
	["opacity"] = 0.5542929768562317,
	["position"] = {
		["y"] = 873.3333129882812,
		["x"] = 879.444091796875,
	},
	["showPlayers"] = true,
}

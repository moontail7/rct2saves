
TrinketMenuPerOptions = {
	["Visible"] = "ON",
	["MainScale"] = 1,
	["XPos"] = 400,
	["Alpha"] = 1,
	["MainOrient"] = "HORIZONTAL",
	["FirstUse"] = true,
	["ItemsUsed"] = {
		["216941"] = 0,
		["211449"] = 0,
		["18849"] = 0,
	},
	["Hidden"] = {
	},
	["MenuDock"] = "BOTTOMLEFT",
	["MainDock"] = "BOTTOMRIGHT",
	["YPos"] = 400,
	["MenuScale"] = 1,
	["MenuOrient"] = "VERTICAL",
}
TrinketMenuQueue = {
	["Enabled"] = {
	},
	["Stats"] = {
	},
	["Sort"] = {
		{
			0, -- [1]
			"211449", -- [2]
			"18849", -- [3]
			"216941", -- [4]
			"215371", -- [5]
		}, -- [1]
		[0] = {
			0, -- [1]
			"18849", -- [2]
			"211449", -- [3]
			"216941", -- [4]
			"215371", -- [5]
		},
	},
	["Profiles"] = {
	},
}

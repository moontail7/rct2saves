
ItemRackUser = {
	["ButtonSpacing"] = 4,
	["QueuesEnabled"] = {
	},
	["Locked"] = "OFF",
	["MainScale"] = 1,
	["SetMenuWrapValue"] = 3,
	["SetMenuWrap"] = "OFF",
	["Sets"] = {
		["~CombatQueue"] = {
			["equip"] = {
			},
		},
		["~Unequip"] = {
			["equip"] = {
			},
		},
	},
	["EnableQueues"] = "ON",
	["EnablePerSetQueues"] = "OFF",
	["Buttons"] = {
		[17] = {
			["Top"] = 159.7326965332031,
			["MainDock"] = "TOPLEFT",
			["MenuDock"] = "BOTTOMLEFT",
			["Left"] = 775.9367065429688,
			["MenuOrient"] = "VERTICAL",
		},
		[16] = {
			["DockTo"] = 17,
			["Side"] = "RIGHT",
		},
	},
	["ItemsUsed"] = {
	},
	["Events"] = {
		["Enabled"] = {
		},
		["Set"] = {
		},
	},
	["Alpha"] = 1,
	["Hidden"] = {
	},
	["EnableEvents"] = "ON",
	["MenuScale"] = 0.85,
	["Queues"] = {
	},
}

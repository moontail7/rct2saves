
RXPCData = {
	["completedWaypoints"] = {
		[2] = {
		},
	},
	["currentStep"] = 2,
	["questObjectivesCache"] = {
		[0] = 23,
		[570] = {
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Shadowmaw Claw: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Pristine Tigress Fang: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[1048] = {
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "High Inquisitor Whitemane slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Scarlet Commander Mograine slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Herod slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Houndmaster Loksey slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [4]
		},
		[213] = {
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Tumbled Crystal: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[186] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Stranglethorn Tiger slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[190] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Young Panther slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[194] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Stranglethorn Raptor slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[605] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Singing Crystal Shard: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[575] = {
			{
				["type"] = "item",
				["numRequired"] = 2,
				["text"] = "Large River Crocolisk Skin: 0/2",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[1182] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Fuel Regulator Blueprints: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[187] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Elder Stranglethorn Tiger slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[191] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Panther slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[195] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Lashtail Raptor slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[80133] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["generated"] = true,
				["text"] = "Objective Complete",
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[188] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Paw of Sin'Dall: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[192] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Shadowmaw Panther slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[569] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Mosh'Ogg Brute slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 5,
				["text"] = "Mosh'Ogg Witch Doctor slain: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[582] = {
			{
				["type"] = "item",
				["numRequired"] = 20,
				["text"] = "Shrunken Head: 0/20",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[629] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Tablet Shard: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[596] = {
			{
				["type"] = "item",
				["numRequired"] = 25,
				["text"] = "Bloody Bone Necklace: 0/25",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[568] = {
			{
				["type"] = "monster",
				["numRequired"] = 15,
				["text"] = "Lashtail Raptor slain: 0/15",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[185] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Young Stranglethorn Tiger slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[189] = {
			{
				["type"] = "item",
				["numRequired"] = 15,
				["text"] = "Bloodscalp Ear: 0/15",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[581] = {
			{
				["type"] = "item",
				["numRequired"] = 9,
				["text"] = "Bloodscalp Tusk: 0/9",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
	},
	["currentGuideGroup"] = "RestedXP Rune & Books Guide",
	["flightPaths"] = {
		[58] = "Zoram'gar Outpost, Ashenvale",
		[30] = "Freewind Post, Thousand Needles",
		[61] = "Splintertree Post, Ashenvale",
		[17] = "Hammerfall, Arathi",
		[18] = "Booty Bay, Stranglethorn",
		[10] = "The Sepulcher, Silverpine Forest",
		[20] = "Grom'gol, Stranglethorn",
		[80] = "Ratchet, The Barrens",
		[11] = "Undercity, Tirisfal",
		[22] = "Thunder Bluff, Mulgore",
		[23] = "Orgrimmar, Durotar",
		[25] = "Crossroads, The Barrens",
		[13] = "Tarren Mill, Hillsbrad",
		[42] = "Camp Mojache, Feralas",
		[21] = "Kargath, Badlands",
		[77] = "Camp Taurajo, The Barrens",
		[55] = "Brackenwall Village, Dustwallow Marsh",
		[56] = "Stonard, Swamp of Sorrows",
		[29] = "Sun Rock Retreat, Stonetalon Mountains",
		[38] = "Shadowprey Village, Desolace",
	},
	["questNameCache"] = {
		[570] = "Mok'thardin's Enchantment",
		[213] = "Hostile Takeover",
		[186] = "Tiger Mastery",
		[190] = "Panther Mastery",
		[194] = "Raptor Mastery",
		[605] = "Singing Blue Shards",
		[575] = "Supply and Demand",
		[1182] = "Goblin Sponsorship",
		[187] = "Tiger Mastery",
		[191] = "Panther Mastery",
		[195] = "Raptor Mastery",
		[188] = "Tiger Mastery",
		[192] = "Panther Mastery",
		[596] = "Bloody Bone Necklaces",
		[582] = "Headhunting",
		[629] = "The Vile Reef",
		[189] = "Bloodscalp Ears",
		[568] = "The Defense of Grom'gol",
		[185] = "Tiger Mastery",
		[569] = "The Defense of Grom'gol",
		[581] = "Hunt for Yenniku",
	},
	["currentGuideName"] = "Just a Flesh Wound - 25 (Reputation)",
	["stepSkip"] = {
	},
	["currentStepId"] = 1574836247,
}
RXPCTrackingData = {
	["profileKeys"] = {
		["Creditfraud - Shadowstrike (AU)"] = "Creditfraud - Shadowstrike (AU)",
	},
	["profiles"] = {
		["Creditfraud - Shadowstrike (AU)"] = {
			["levels"] = {
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 375,
							["count"] = 9,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 6,
							["year"] = 2023,
							["hour"] = 8,
							["minute"] = 25,
						},
						["finished"] = 838,
						["dateFinished"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 40,
							["year"] = 2023,
							["hour"] = 8,
							["weekday"] = 6,
						},
						["started"] = 0,
					},
					["quests"] = {
						["Durotar"] = {
							[4641] = 40,
						},
					},
				}, -- [1]
				{
					["groupExperience"] = 16,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 126,
							["count"] = 3,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 40,
							["year"] = 2023,
							["hour"] = 8,
							["weekday"] = 6,
						},
						["finished"] = 1699,
						["dateFinished"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 55,
							["year"] = 2023,
							["hour"] = 8,
							["weekday"] = 6,
						},
						["started"] = 839,
					},
					["quests"] = {
						["Durotar"] = {
							[788] = 170,
							[790] = 450,
							[804] = 110,
							[3088] = 40,
						},
					},
				}, -- [2]
				{
					["groupExperience"] = 614,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 1394,
							["count"] = 25,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 55,
							["year"] = 2023,
							["hour"] = 8,
							["weekday"] = 6,
						},
						["finished"] = 3281,
						["dateFinished"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 21,
							["year"] = 2023,
							["hour"] = 9,
							["weekday"] = 6,
						},
						["started"] = 1700,
					},
					["quests"] = {
					},
				}, -- [3]
				{
					["groupExperience"] = 1941,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 489,
							["count"] = 10,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 21,
							["year"] = 2023,
							["hour"] = 9,
							["weekday"] = 6,
						},
						["finished"] = 4126,
						["dateFinished"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 35,
							["year"] = 2023,
							["hour"] = 9,
							["weekday"] = 6,
						},
						["started"] = 3282,
					},
					["quests"] = {
						["Durotar"] = {
							[4402] = 380,
							[5441] = 450,
							[792] = 450,
							[789] = 250,
						},
					},
				}, -- [4]
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 1325,
							["count"] = 18,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 35,
							["year"] = 2023,
							["hour"] = 9,
							["weekday"] = 6,
						},
						["finished"] = 5588,
						["dateFinished"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 6,
							["year"] = 2023,
							["hour"] = 12,
							["minute"] = 27,
						},
						["started"] = 4127,
					},
					["quests"] = {
						["Durotar"] = {
							[6394] = 450,
							[805] = 230,
							[77583] = 85,
							[794] = 675,
						},
					},
				}, -- [5]
				{
					["groupExperience"] = 238,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 2327,
							["count"] = 36,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 6,
							["year"] = 2023,
							["hour"] = 12,
							["minute"] = 27,
						},
						["finished"] = 7861,
						["dateFinished"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 5,
							["year"] = 2023,
							["hour"] = 13,
							["weekday"] = 6,
						},
						["started"] = 5589,
					},
					["quests"] = {
						["Durotar"] = {
							[2161] = 110,
							[823] = 320,
							[786] = 700,
						},
					},
				}, -- [6]
				{
					["groupExperience"] = 316,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 2290,
							["count"] = 41,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 5,
							["year"] = 2023,
							["hour"] = 13,
							["weekday"] = 6,
						},
						["finished"] = 10067,
						["dateFinished"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 6,
							["year"] = 2023,
							["hour"] = 13,
							["minute"] = 50,
						},
						["started"] = 7862,
					},
					["quests"] = {
						["Durotar"] = {
							[830] = 625,
							[784] = 625,
							[791] = 625,
						},
						["Orgrimmar"] = {
							[78611] = 70,
						},
					},
				}, -- [7]
				{
					["groupExperience"] = 353,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 4154,
							["count"] = 62,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 6,
							["year"] = 2023,
							["hour"] = 13,
							["minute"] = 50,
						},
						["finished"] = 13188,
						["dateFinished"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 6,
							["year"] = 2023,
							["hour"] = 14,
							["minute"] = 42,
						},
						["started"] = 10068,
					},
					["quests"] = {
						["Durotar"] = {
							[808] = 775,
						},
					},
				}, -- [8]
				{
					["groupExperience"] = 392,
					["deaths"] = 1,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 3326,
							["count"] = 52,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 6,
							["year"] = 2023,
							["hour"] = 14,
							["minute"] = 42,
						},
						["finished"] = 16703,
						["dateFinished"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 33,
							["year"] = 2023,
							["hour"] = 16,
							["weekday"] = 6,
						},
						["started"] = 13189,
					},
					["quests"] = {
						["Durotar"] = {
							[818] = 625,
							[826] = 850,
							[834] = 775,
							[817] = 700,
						},
						["Orgrimmar"] = {
							[78611] = 70,
						},
					},
				}, -- [9]
				{
					["groupExperience"] = 625,
					["deaths"] = 2,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 3346,
							["count"] = 48,
						},
						["The Barrens"] = {
							["xp"] = 81,
							["count"] = 1,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 33,
							["year"] = 2023,
							["hour"] = 16,
							["weekday"] = 6,
						},
						["finished"] = 20317,
						["dateFinished"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 33,
							["year"] = 2023,
							["hour"] = 17,
							["weekday"] = 6,
						},
						["started"] = 16704,
					},
					["quests"] = {
						["Durotar"] = {
							[828] = 90,
							[837] = 625,
							[825] = 700,
							[806] = 900,
							[815] = 700,
							[827] = 900,
						},
						["Orgrimmar"] = {
							[831] = 625,
						},
					},
				}, -- [10]
				{
					["groupExperience"] = 602,
					["deaths"] = 1,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 2990,
							["count"] = 50,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 33,
							["year"] = 2023,
							["hour"] = 17,
							["weekday"] = 6,
						},
						["finished"] = 24870,
						["dateFinished"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 19,
							["year"] = 2023,
							["hour"] = 19,
							["weekday"] = 6,
						},
						["started"] = 20318,
					},
					["quests"] = {
						["Durotar"] = {
							[812] = 975,
							[835] = 875,
							[816] = 875,
						},
						["The Barrens"] = {
							[840] = 460,
						},
						["Orgrimmar"] = {
							[829] = 460,
							[5726] = 900,
							[832] = 675,
						},
					},
				}, -- [11]
				{
					["groupExperience"] = 1373,
					["deaths"] = 1,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 67,
							["count"] = 1,
						},
						["The Barrens"] = {
							["xp"] = 688,
							["count"] = 7,
						},
						["Silverpine Forest"] = {
							["xp"] = 2799,
							["count"] = 35,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 19,
							["year"] = 2023,
							["hour"] = 19,
							["weekday"] = 6,
						},
						["finished"] = 32193,
						["dateFinished"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 6,
							["year"] = 2023,
							["hour"] = 21,
							["minute"] = 21,
						},
						["started"] = 24871,
					},
					["quests"] = {
						["Orgrimmar"] = {
							[6385] = 210,
							[6384] = 420,
							[78611] = 70,
							[5727] = 460,
						},
						["The Barrens"] = {
							[842] = 900,
							[6365] = 210,
							[924] = 1250,
							[809] = 460,
						},
						["Silverpine Forest"] = {
							[428] = 230,
							[435] = 875,
							[429] = 440,
						},
					},
				}, -- [12]
				{
					["groupExperience"] = 2838,
					["deaths"] = 4,
					["mobs"] = {
						["Silverpine Forest"] = {
							["xp"] = 5906,
							["count"] = 75,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 6,
							["year"] = 2023,
							["hour"] = 21,
							["minute"] = 21,
						},
						["finished"] = 36879,
						["dateFinished"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 43,
							["year"] = 2023,
							["hour"] = 23,
							["weekday"] = 6,
						},
						["started"] = 32194,
					},
					["quests"] = {
						["Silverpine Forest"] = {
							[430] = 650,
							[438] = 875,
							[425] = 675,
							[3221] = 90,
							[437] = 975,
							[449] = 440,
							[422] = 875,
							[421] = 850,
						},
					},
				}, -- [13]
				{
					["groupExperience"] = 11703,
					["deaths"] = 4,
					["mobs"] = {
						["Ragefire Chasm"] = {
							["xp"] = 9818,
							["count"] = 125,
						},
						["Silverpine Forest"] = {
							["xp"] = 288,
							["count"] = 3,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 43,
							["year"] = 2023,
							["hour"] = 23,
							["weekday"] = 6,
						},
						["finished"] = 43528,
						["dateFinished"] = {
							["monthDay"] = 2,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 7,
							["year"] = 2023,
							["hour"] = 1,
							["minute"] = 34,
						},
						["started"] = 36880,
					},
					["quests"] = {
						["Ragefire Chasm"] = {
							[5722] = 875,
						},
						["Undercity"] = {
							[447] = 900,
							[1359] = 110,
						},
					},
				}, -- [14]
				{
					["groupExperience"] = 4308,
					["deaths"] = 1,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 283,
							["count"] = 10,
						},
						["Silverpine Forest"] = {
							["xp"] = 3620,
							["count"] = 37,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 2,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 7,
							["year"] = 2023,
							["hour"] = 1,
							["minute"] = 34,
						},
						["finished"] = 50170,
						["dateFinished"] = {
							["monthDay"] = 2,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 48,
							["year"] = 2023,
							["hour"] = 13,
							["weekday"] = 7,
						},
						["started"] = 43529,
					},
					["quests"] = {
						["Orgrimmar"] = {
							[5728] = 1150,
							[5729] = 110,
							[5730] = 1450,
							[5761] = 1150,
						},
						["Undercity"] = {
							[5725] = 1450,
						},
						["The Barrens"] = {
							[6386] = 1050,
							[1358] = 1050,
							[1492] = 440,
						},
						["Silverpine Forest"] = {
							[423] = 975,
							[439] = 290,
							[482] = 100,
							[477] = 975,
							[478] = 750,
							[481] = 100,
						},
					},
				}, -- [15]
				{
					["groupExperience"] = 467,
					["deaths"] = 2,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 10039,
							["count"] = 134,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 2,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 48,
							["year"] = 2023,
							["hour"] = 13,
							["weekday"] = 7,
						},
						["finished"] = 56573,
						["dateFinished"] = {
							["monthDay"] = 2,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 7,
							["year"] = 2023,
							["hour"] = 16,
							["minute"] = 2,
						},
						["started"] = 50171,
					},
					["quests"] = {
						["The Barrens"] = {
							[887] = 750,
							[5041] = 975,
							[892] = 100,
							[844] = 900,
							[895] = 1150,
							[890] = 100,
							[871] = 900,
							[845] = 900,
						},
					},
				}, -- [16]
				{
					["groupExperience"] = 83,
					["deaths"] = 1,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 7954,
							["count"] = 81,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 2,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 7,
							["year"] = 2023,
							["hour"] = 16,
							["minute"] = 2,
						},
						["finished"] = 68075,
						["dateFinished"] = {
							["monthDay"] = 2,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 33,
							["year"] = 2023,
							["hour"] = 20,
							["weekday"] = 7,
						},
						["started"] = 56574,
					},
					["quests"] = {
						["The Barrens"] = {
							[867] = 1050,
							[869] = 900,
							[901] = 750,
							[903] = 1050,
							[2382] = 120,
							[894] = 750,
							[881] = 1450,
							[900] = 490,
							[902] = 1150,
							[870] = 675,
						},
						["Orgrimmar"] = {
							[1963] = 675,
							[78611] = 15,
						},
					},
				}, -- [17]
				{
					["groupExperience"] = 0,
					["deaths"] = 2,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 6099,
							["count"] = 45,
						},
						["Stonetalon Mountains"] = {
							["xp"] = 1470,
							["count"] = 9,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 2,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 33,
							["year"] = 2023,
							["hour"] = 20,
							["weekday"] = 7,
						},
						["finished"] = 74483,
						["dateFinished"] = {
							["monthDay"] = 5,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 51,
							["year"] = 2023,
							["hour"] = 19,
							["weekday"] = 3,
						},
						["started"] = 68076,
					},
					["quests"] = {
						["Thunder Bluff"] = {
							[5723] = 1050,
							[853] = 800,
							[5724] = 1450,
							[79100] = 110,
						},
						["The Barrens"] = {
							[3281] = 1350,
							[3261] = 140,
							[877] = 1150,
							[905] = 1250,
							[4921] = 1150,
							[848] = 1050,
							[1061] = 320,
							[875] = 1150,
						},
					},
				}, -- [18]
				{
					["groupExperience"] = 2459,
					["deaths"] = 12,
					["mobs"] = {
						["Stonetalon Mountains"] = {
							["xp"] = 9150,
							["count"] = 88,
						},
						["The Barrens"] = {
							["xp"] = 7956,
							["count"] = 66,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 5,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 51,
							["year"] = 2023,
							["hour"] = 19,
							["weekday"] = 3,
						},
						["finished"] = 82898,
						["dateFinished"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 27,
							["year"] = 2023,
							["hour"] = 1,
							["weekday"] = 5,
						},
						["started"] = 74484,
					},
					["quests"] = {
						["The Barrens"] = {
							[6548] = 1350,
						},
						["Stonetalon Mountains"] = {
							[1483] = 420,
							[1093] = 1650,
						},
					},
				}, -- [19]
				{
					["groupExperience"] = 15598,
					["deaths"] = 0,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 3953,
							["count"] = 44,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 27,
							["year"] = 2023,
							["hour"] = 1,
							["weekday"] = 5,
						},
						["finished"] = 88780,
						["dateFinished"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 5,
							["year"] = 2023,
							["hour"] = 11,
							["minute"] = 48,
						},
						["started"] = 82899,
					},
					["quests"] = {
						["Mulgore"] = {
							[7926] = 650,
						},
						["The Barrens"] = {
							[878] = 1650,
							[865] = 1350,
							[882] = 1800,
							[899] = 1950,
							[888] = 1150,
							[1094] = 825,
							[2458] = 1150,
							[883] = 1300,
							[5052] = 1250,
							[1069] = 1950,
							[2381] = 1350,
							[880] = 1150,
						},
						["Orgrimmar"] = {
							[2460] = 160,
							[79100] = 110,
							[2478] = 1950,
						},
					},
				}, -- [20]
				{
					["groupExperience"] = 15756,
					["deaths"] = 2,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 2188,
							["count"] = 17,
						},
						["The Wailing Caverns"] = {
							["xp"] = 14058,
							["count"] = 228,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 5,
							["year"] = 2023,
							["hour"] = 11,
							["minute"] = 48,
						},
						["finished"] = 98002,
						["dateFinished"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 5,
							["year"] = 2023,
							["hour"] = 14,
							["minute"] = 22,
						},
						["started"] = 88781,
					},
					["quests"] = {
						["The Barrens"] = {
							[884] = 1450,
							[907] = 1700,
							[913] = 1950,
						},
						["Thunder Bluff"] = {
							[914] = 2200,
							[1489] = 290,
							[1490] = 120,
							[79100] = 85,
						},
					},
				}, -- [21]
				{
					["groupExperience"] = 9053,
					["deaths"] = 1,
					["mobs"] = {
						["The Wailing Caverns"] = {
							["xp"] = 9053,
							["count"] = 140,
						},
						["Stonetalon Mountains"] = {
							["xp"] = 105,
							["count"] = 1,
						},
						["Silverpine Forest"] = {
							["xp"] = 155,
							["count"] = 1,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 5,
							["year"] = 2023,
							["hour"] = 14,
							["minute"] = 22,
						},
						["finished"] = 109837,
						["dateFinished"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 5,
							["year"] = 2023,
							["hour"] = 17,
							["minute"] = 48,
						},
						["started"] = 98003,
					},
					["quests"] = {
						["Undercity"] = {
							[441] = 460,
						},
						["The Barrens"] = {
							[1062] = 1450,
							[874] = 550,
							[6981] = 2650,
						},
						["The Wailing Caverns"] = {
							[1487] = 2050,
							[1486] = 1600,
						},
						["Thunder Bluff"] = {
							[962] = 1700,
							[1063] = 675,
							[1064] = 340,
							[3369] = 2000,
						},
						["Tirisfal Glades"] = {
							[440] = 460,
						},
						["Stonetalon Mountains"] = {
							[6461] = 1450,
							[1095] = 1100,
						},
						["Silverpine Forest"] = {
							[264] = 320,
							[3301] = 625,
						},
					},
				}, -- [22]
				{
					["groupExperience"] = 13842,
					["deaths"] = 2,
					["mobs"] = {
						["Shadowfang Keep"] = {
							["xp"] = 5150,
							["count"] = 80,
						},
						["Silverpine Forest"] = {
							["xp"] = 116,
							["count"] = 1,
						},
						["Hillsbrad Foothills"] = {
							["xp"] = 6019,
							["count"] = 58,
						},
						["Stonetalon Mountains"] = {
							["xp"] = 1433,
							["count"] = 14,
						},
						["Ashenvale"] = {
							["xp"] = 465,
							["count"] = 4,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 5,
							["year"] = 2023,
							["hour"] = 17,
							["minute"] = 48,
						},
						["finished"] = 120568,
						["dateFinished"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 5,
							["year"] = 2023,
							["hour"] = 20,
							["minute"] = 47,
						},
						["started"] = 109838,
					},
					["quests"] = {
						["Hillsbrad Foothills"] = {
							[1065] = 1350,
							[494] = 775,
							[1066] = 1850,
							[2479] = 1050,
							[2480] = 160,
							[498] = 2200,
							[549] = 1750,
							[493] = 1150,
						},
						["Undercity"] = {
							[78611] = 5,
						},
						["Shadowfang Keep"] = {
							[1098] = 2000,
						},
						["Silverpine Forest"] = {
							[78261] = 1850,
						},
					},
				}, -- [23]
				{
					["groupExperience"] = 9818,
					["deaths"] = 0,
					["mobs"] = {
						["Shadowfang Keep"] = {
							["xp"] = 3972,
							["count"] = 37,
						},
						["The Deadmines"] = {
							["xp"] = 446,
							["count"] = 7,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 5,
							["year"] = 2023,
							["hour"] = 20,
							["minute"] = 47,
						},
						["finished"] = 134001,
						["dateFinished"] = {
							["monthDay"] = 8,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 6,
							["year"] = 2023,
							["hour"] = 1,
							["minute"] = 28,
						},
						["started"] = 120569,
					},
					["quests"] = {
						["Silverpine Forest"] = {
							[1014] = 3300,
						},
						["Undercity"] = {
							[1013] = 2100,
						},
					},
				}, -- [24]
				{
					["groupExperience"] = 11973,
					["deaths"] = 46,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 1328,
							["count"] = 6,
						},
						["Blackfathom Deeps"] = {
							["xp"] = 3291,
							["count"] = 137,
						},
						["Ashenvale"] = {
							["xp"] = 48,
							["count"] = 1,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 8,
							["day"] = 0,
							["month"] = 12,
							["weekday"] = 6,
							["year"] = 2023,
							["hour"] = 1,
							["minute"] = 28,
						},
						["finished"] = 226218,
						["dateFinished"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 23,
							["year"] = 2024,
							["hour"] = 11,
							["weekday"] = 6,
						},
						["started"] = 134002,
					},
					["quests"] = {
						["The Barrens"] = {
							[868] = 1750,
							[849] = 2100,
							[879] = 1500,
							[846] = 2100,
							[885] = 1500,
							[906] = 3050,
						},
					},
				}, -- [25]
				{
					["groupExperience"] = 28077,
					["deaths"] = 0,
					["mobs"] = {
						["Blackfathom Deeps"] = {
							["xp"] = 225,
							["count"] = 8,
						},
						["Razorfen Kraul"] = {
							["xp"] = 25902,
							["count"] = 217,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 23,
							["year"] = 2024,
							["hour"] = 11,
							["weekday"] = 6,
						},
						["finished"] = 231457,
						["dateFinished"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 12,
							["minute"] = 50,
						},
						["started"] = 226219,
					},
					["quests"] = {
						["The Barrens"] = {
							[893] = 1950,
						},
					},
				}, -- [26]
				{
					["groupExperience"] = 38970,
					["deaths"] = 0,
					["mobs"] = {
						["Razorfen Kraul"] = {
							["xp"] = 35920,
							["count"] = 281,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 12,
							["minute"] = 50,
						},
						["finished"] = 238354,
						["dateFinished"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 14,
							["minute"] = 55,
						},
						["started"] = 231458,
					},
					["quests"] = {
						["Razorfen Kraul"] = {
							[1144] = 3050,
						},
					},
				}, -- [27]
				{
					["groupExperience"] = 41254,
					["deaths"] = 0,
					["mobs"] = {
						["Razorfen Kraul"] = {
							["xp"] = 36216,
							["count"] = 258,
						},
						["Scarlet Monastery"] = {
							["xp"] = 5038,
							["count"] = 47,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 14,
							["minute"] = 55,
						},
						["finished"] = 247581,
						["dateFinished"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 18,
							["minute"] = 26,
						},
						["started"] = 238355,
					},
					["quests"] = {
					},
				}, -- [28]
				{
					["groupExperience"] = 44458,
					["deaths"] = 0,
					["mobs"] = {
						["Scarlet Monastery"] = {
							["xp"] = 44458,
							["count"] = 435,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 18,
							["minute"] = 26,
						},
						["finished"] = 254454,
						["dateFinished"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 20,
							["minute"] = 20,
						},
						["started"] = 247582,
					},
					["quests"] = {
					},
				}, -- [29]
				{
					["groupExperience"] = 47366,
					["deaths"] = 0,
					["mobs"] = {
						["Scarlet Monastery"] = {
							["xp"] = 44566,
							["count"] = 390,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 20,
							["minute"] = 20,
						},
						["finished"] = 265386,
						["dateFinished"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 32,
							["year"] = 2024,
							["hour"] = 23,
							["weekday"] = 6,
						},
						["started"] = 254455,
					},
					["quests"] = {
						["Undercity"] = {
							[6522] = 2800,
						},
					},
				}, -- [30]
				{
					["groupExperience"] = 44174,
					["deaths"] = 1,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 3798,
							["count"] = 33,
						},
						["Scarlet Monastery"] = {
							["xp"] = 44174,
							["count"] = 425,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 32,
							["year"] = 2024,
							["hour"] = 23,
							["weekday"] = 6,
						},
						["finished"] = 281134,
						["dateFinished"] = {
							["monthDay"] = 10,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 59,
							["year"] = 2024,
							["hour"] = 3,
							["weekday"] = 7,
						},
						["started"] = 265387,
					},
					["quests"] = {
						["The Barrens"] = {
							[857] = 2450,
						},
						["Ashenvale"] = {
							[235] = 15,
						},
					},
				}, -- [31]
				{
					["groupExperience"] = 53218,
					["deaths"] = 0,
					["mobs"] = {
						["Thousand Needles"] = {
							["xp"] = 272,
							["count"] = 3,
						},
						["Scarlet Monastery"] = {
							["xp"] = 53218,
							["count"] = 428,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 10,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 59,
							["year"] = 2024,
							["hour"] = 3,
							["weekday"] = 7,
						},
						["finished"] = 292871,
						["dateFinished"] = {
							["monthDay"] = 10,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 14,
							["minute"] = 13,
						},
						["started"] = 281135,
					},
					["quests"] = {
						["Thousand Needles"] = {
							[4542] = 310,
						},
					},
				}, -- [32]
				{
					["groupExperience"] = 58470,
					["deaths"] = 0,
					["mobs"] = {
						["Scarlet Monastery"] = {
							["xp"] = 58470,
							["count"] = 531,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 10,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 14,
							["minute"] = 13,
						},
						["finished"] = 301826,
						["dateFinished"] = {
							["monthDay"] = 10,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 19,
							["year"] = 2024,
							["hour"] = 17,
							["weekday"] = 7,
						},
						["started"] = 292872,
					},
					["quests"] = {
					},
				}, -- [33]
				{
					["groupExperience"] = 62782,
					["deaths"] = 1,
					["mobs"] = {
						["Scarlet Monastery"] = {
							["xp"] = 62782,
							["count"] = 524,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 10,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 19,
							["year"] = 2024,
							["hour"] = 17,
							["weekday"] = 7,
						},
						["finished"] = 311472,
						["dateFinished"] = {
							["monthDay"] = 10,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 20,
							["minute"] = 5,
						},
						["started"] = 301827,
					},
					["quests"] = {
					},
				}, -- [34]
				{
					["groupExperience"] = 67305,
					["deaths"] = 0,
					["mobs"] = {
						["Scarlet Monastery"] = {
							["xp"] = 67305,
							["count"] = 437,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 10,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 20,
							["minute"] = 5,
						},
						["finished"] = 321042,
						["dateFinished"] = {
							["monthDay"] = 10,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 22,
							["minute"] = 45,
						},
						["started"] = 311473,
					},
					["quests"] = {
					},
				}, -- [35]
				{
					["groupExperience"] = 64483,
					["deaths"] = 0,
					["mobs"] = {
						["Dustwallow Marsh"] = {
							["xp"] = 3905,
							["count"] = 16,
						},
						["Scarlet Monastery"] = {
							["xp"] = 64483,
							["count"] = 472,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 10,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 22,
							["minute"] = 45,
						},
						["finished"] = 334985,
						["dateFinished"] = {
							["monthDay"] = 11,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 40,
							["year"] = 2024,
							["hour"] = 2,
							["weekday"] = 1,
						},
						["started"] = 321043,
					},
					["quests"] = {
						["Dustwallow Marsh"] = {
							[1251] = 700,
							[1321] = 280,
							[1268] = 1350,
							[1269] = 700,
						},
					},
				}, -- [36]
				{
					["groupExperience"] = 76137,
					["deaths"] = 2,
					["mobs"] = {
						["Scarlet Monastery"] = {
							["xp"] = 76137,
							["count"] = 486,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 11,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 40,
							["year"] = 2024,
							["hour"] = 2,
							["weekday"] = 1,
						},
						["finished"] = 347486,
						["dateFinished"] = {
							["monthDay"] = 11,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 1,
							["year"] = 2024,
							["hour"] = 6,
							["minute"] = 15,
						},
						["started"] = 334986,
					},
					["quests"] = {
					},
				}, -- [37]
				{
					["groupExperience"] = 67944,
					["deaths"] = 1,
					["mobs"] = {
						["Dustwallow Marsh"] = {
							["xp"] = 8896,
							["count"] = 35,
						},
						["Scarlet Monastery"] = {
							["xp"] = 67944,
							["count"] = 397,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 11,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 1,
							["year"] = 2024,
							["hour"] = 6,
							["minute"] = 15,
						},
						["finished"] = 370409,
						["dateFinished"] = {
							["monthDay"] = 11,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 1,
							["year"] = 2024,
							["hour"] = 18,
							["minute"] = 49,
						},
						["started"] = 347487,
					},
					["quests"] = {
						["Dustwallow Marsh"] = {
							[1273] = 3550,
						},
					},
				}, -- [38]
				{
					["groupExperience"] = 85805,
					["deaths"] = 1,
					["mobs"] = {
						["Scarlet Monastery"] = {
							["xp"] = 85805,
							["count"] = 466,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 11,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 1,
							["year"] = 2024,
							["hour"] = 18,
							["minute"] = 49,
						},
						["finished"] = 381112,
						["dateFinished"] = {
							["monthDay"] = 11,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 0,
							["year"] = 2024,
							["hour"] = 22,
							["weekday"] = 1,
						},
						["started"] = 370410,
					},
					["quests"] = {
					},
				}, -- [39]
				{
					["groupExperience"] = 0,
					["deaths"] = 20,
					["mobs"] = {
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 11,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 0,
							["year"] = 2024,
							["hour"] = 22,
							["weekday"] = 1,
						},
						["started"] = 381113,
					},
					["quests"] = {
					},
				}, -- [40]
			},
			["trackedGuid"] = "Player-5818-009C395E",
		},
	},
}
RXPCComms = {
	["profileKeys"] = {
		["Creditfraud - Shadowstrike (AU)"] = "Creditfraud - Shadowstrike (AU)",
	},
	["profiles"] = {
		["Creditfraud - Shadowstrike (AU)"] = {
			["announcements"] = {
				["06-10 Durotar"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["11-14 Silverpine Forest"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["10-12 Durotar"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["12-17 The Barrens"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["01-06 Orc/Troll"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["24-26 Southern Barrens/Stonetalon"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["22-24 Hillsbrad"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
			},
			["players"] = {
				["Beryl"] = {
					["timePlayed"] = 112.2480000000214,
					["class"] = "PRIEST",
					["xp"] = 21,
				},
				["Sor"] = {
					["timePlayed"] = 2117.09600000002,
					["class"] = "WARRIOR",
					["xp"] = 3050,
				},
				["Vedd"] = {
					["timePlayed"] = 3305.712999999989,
					["class"] = "WARLOCK",
					["xp"] = 99,
				},
				["Anton"] = {
					["class"] = "WARRIOR",
					["lastSeen"] = 593099.52,
					["xpPercentage"] = 37,
					["isRxp"] = true,
					["timePlayed"] = 3686.015999999945,
					["level"] = 22,
				},
				["Getodacrappa"] = {
					["isRxp"] = true,
					["lastSeen"] = 581672.937,
					["xpPercentage"] = 57,
					["level"] = 33,
					["timePlayed"] = 0,
					["class"] = "PRIEST",
				},
				["Addyg"] = {
					["level"] = 17,
					["class"] = "ROGUE",
					["lastSeen"] = 171358.456,
					["timePlayed"] = 4.070000000006985,
					["isRxp"] = true,
					["xp"] = 44,
					["xpPercentage"] = 11,
				},
				["Mikeg"] = {
					["isRxp"] = true,
					["lastSeen"] = 377018.59,
					["xpPercentage"] = 16,
					["level"] = 24,
					["timePlayed"] = 0,
					["class"] = "MAGE",
				},
				["Ithgore"] = {
					["timePlayed"] = 600.2709999999934,
					["class"] = "WARRIOR",
					["xp"] = 36,
				},
				["Ayriisu"] = {
					["xpPercentage"] = 79,
					["isRxp"] = true,
					["lastSeen"] = 88243.172,
					["timePlayed"] = 128.8340000000026,
					["level"] = 10,
					["xp"] = 34,
					["class"] = "MAGE",
				},
				["Voodoo"] = {
					["timePlayed"] = 11521.73399999988,
					["class"] = "PRIEST",
					["xp"] = 187,
				},
				["Subaruwrxone"] = {
					["timePlayed"] = 1911.113999999943,
					["class"] = "PRIEST",
					["xp"] = 193,
				},
				["Nyxie"] = {
					["timePlayed"] = 582.4910000000091,
					["class"] = "MAGE",
					["xp"] = 50,
				},
				["Totes"] = {
					["timePlayed"] = 224.3410000000004,
					["class"] = "SHAMAN",
					["xp"] = 40,
				},
				["Nessh"] = {
					["timePlayed"] = 5013.544999999926,
					["class"] = "MAGE",
					["xp"] = 171,
				},
				["Bajez"] = {
					["timePlayed"] = 103.997000000003,
					["class"] = "SHAMAN",
					["xp"] = 33,
				},
				["Bigsneed"] = {
					["timePlayed"] = 207.1269999999786,
					["class"] = "WARLOCK",
					["xp"] = 33,
				},
				["Fishhunter"] = {
					["timePlayed"] = 57.62900000000082,
					["class"] = "HUNTER",
					["xp"] = 28,
				},
				["Questionmark"] = {
					["timePlayed"] = 2464.053000000014,
					["class"] = "SHAMAN",
					["xp"] = 217,
				},
				["Lase"] = {
					["isRxp"] = true,
					["lastSeen"] = 391624.051,
					["xpPercentage"] = 43,
					["level"] = 30,
					["timePlayed"] = 4077.156999999948,
					["class"] = "PRIEST",
				},
				["Altdorf"] = {
					["class"] = "DRUID",
					["lastSeen"] = 1547.147,
					["xpPercentage"] = 42,
					["isRxp"] = true,
					["timePlayed"] = 3954.035999999983,
					["level"] = 23,
				},
				["Wido"] = {
					["level"] = 8,
					["lastSeen"] = 76407.56,
					["xpPercentage"] = 28,
					["class"] = "HUNTER",
					["timePlayed"] = 100.3120000000054,
					["isRxp"] = true,
				},
				["Kaizen"] = {
					["level"] = 39,
					["lastSeen"] = 572525.151,
					["xpPercentage"] = 49,
					["class"] = "HUNTER",
					["timePlayed"] = 0,
					["isRxp"] = true,
				},
				["Unkiejay"] = {
					["timePlayed"] = 3620.028000000049,
					["class"] = "DRUID",
					["xp"] = 203,
				},
				["Morechilly"] = {
					["class"] = "WARRIOR",
					["lastSeen"] = 11243.944,
					["xpPercentage"] = 3,
					["isRxp"] = true,
					["timePlayed"] = 0,
					["level"] = 25,
				},
				["Asaucysloth"] = {
					["xpPercentage"] = 66,
					["isRxp"] = true,
					["lastSeen"] = 160847.39,
					["timePlayed"] = 201.0869999999995,
					["level"] = 14,
					["xp"] = 22,
					["class"] = "MAGE",
				},
				["Packardbell"] = {
					["timePlayed"] = 4.070000000006985,
					["class"] = "SHAMAN",
					["xp"] = 44,
				},
				["Cowtown"] = {
					["timePlayed"] = 112.8099999999977,
					["class"] = "DRUID",
					["xp"] = 1500,
				},
				["Tango"] = {
					["timePlayed"] = 5275.715999999899,
					["class"] = "MAGE",
					["xp"] = 174,
				},
				["Innerbloom"] = {
					["class"] = "DRUID",
					["lastSeen"] = 9437.252,
					["xpPercentage"] = 4,
					["isRxp"] = true,
					["timePlayed"] = 0,
					["level"] = 25,
				},
				["Adahy"] = {
					["timePlayed"] = 2640.737999999954,
					["class"] = "DRUID",
					["xp"] = 109,
				},
				["Anzacer"] = {
					["level"] = 37,
					["lastSeen"] = 656633.728,
					["xpPercentage"] = 20,
					["class"] = "ROGUE",
					["timePlayed"] = 0,
					["isRxp"] = true,
				},
				["Aidenbf"] = {
					["timePlayed"] = 0,
					["class"] = "HUNTER",
					["xp"] = 35,
				},
				["Numbskull"] = {
					["timePlayed"] = 112.8099999999977,
					["class"] = "SHAMAN",
					["xp"] = 1500,
				},
				["Richtar"] = {
					["timePlayed"] = 2117.09600000002,
					["class"] = "WARRIOR",
					["xp"] = 3050,
				},
				["Rofo"] = {
					["timePlayed"] = 9750.74199999997,
					["class"] = "PRIEST",
					["xp"] = 218,
				},
				["Justicex"] = {
					["level"] = 39,
					["lastSeen"] = 479355.168,
					["xpPercentage"] = 79,
					["class"] = "SHAMAN",
					["timePlayed"] = 2453.318000000028,
					["isRxp"] = true,
				},
				["Uba"] = {
					["isRxp"] = true,
					["lastSeen"] = 356815.825,
					["xpPercentage"] = 43,
					["level"] = 29,
					["timePlayed"] = 3345.755000000005,
					["class"] = "PRIEST",
				},
				["Lanarhoades"] = {
					["level"] = 13,
					["lastSeen"] = 162879.462,
					["xpPercentage"] = 14,
					["class"] = "ROGUE",
					["timePlayed"] = 248.7489999999816,
					["isRxp"] = true,
				},
				["Muffinmcgee"] = {
					["timePlayed"] = 5536.976999999975,
					["class"] = "SHAMAN",
					["xp"] = 900,
				},
				["Boomtoon"] = {
					["timePlayed"] = 13547.304,
					["class"] = "DRUID",
					["xp"] = 147,
				},
				["Shampaign"] = {
					["timePlayed"] = 171.6620000000039,
					["class"] = "SHAMAN",
					["xp"] = 8,
				},
				["Gocrom"] = {
					["isRxp"] = true,
					["lastSeen"] = 45018.022,
					["xpPercentage"] = 0,
					["level"] = 25,
					["timePlayed"] = 0,
					["class"] = "ROGUE",
				},
				["Cougs"] = {
					["class"] = "PRIEST",
					["lastSeen"] = 435398.527,
					["xpPercentage"] = 49,
					["isRxp"] = true,
					["timePlayed"] = 7496.959999999963,
					["level"] = 31,
				},
				["Saucy"] = {
					["isRxp"] = true,
					["lastSeen"] = 527963.131,
					["xpPercentage"] = 12,
					["level"] = 38,
					["timePlayed"] = 1150.207999999984,
					["class"] = "SHAMAN",
				},
				["Rektcher"] = {
					["timePlayed"] = 187.2880000000005,
					["class"] = "HUNTER",
					["xp"] = 32,
				},
				["Precursor"] = {
					["timePlayed"] = 250.0239999999758,
					["class"] = "PRIEST",
					["xp"] = 33,
				},
				["Deny"] = {
					["class"] = "ROGUE",
					["lastSeen"] = 59098.369,
					["xpPercentage"] = 88,
					["isRxp"] = true,
					["timePlayed"] = 171.6620000000039,
					["level"] = 4,
				},
				["Necrosis"] = {
					["timePlayed"] = 600.2709999999934,
					["class"] = "PRIEST",
					["xp"] = 36,
				},
				["Lavey"] = {
					["class"] = "SHAMAN",
					["lastSeen"] = 532226.574,
					["xpPercentage"] = 42,
					["isRxp"] = true,
					["timePlayed"] = 4824.787999999942,
					["level"] = 39,
				},
				["Ai"] = {
					["class"] = "WARLOCK",
					["lastSeen"] = 56425.846,
					["xpPercentage"] = 46,
					["isRxp"] = true,
					["timePlayed"] = 0,
					["level"] = 2,
				},
				["Underhill"] = {
					["class"] = "WARRIOR",
					["lastSeen"] = 57317.113,
					["xpPercentage"] = 51,
					["isRxp"] = true,
					["timePlayed"] = 0,
					["level"] = 4,
				},
				["Frameone"] = {
					["class"] = "ROGUE",
					["lastSeen"] = 11243.944,
					["xpPercentage"] = 2,
					["isRxp"] = true,
					["timePlayed"] = 0,
					["level"] = 25,
				},
				["Rocketbunny"] = {
					["timePlayed"] = 656.9500000000116,
					["class"] = "PRIEST",
					["xp"] = 132,
				},
				["Mooves"] = {
					["timePlayed"] = 2239.118000000133,
					["class"] = "DRUID",
					["xp"] = 86,
				},
				["Itsjesse"] = {
					["level"] = 23,
					["lastSeen"] = 548693.567,
					["xpPercentage"] = 26,
					["class"] = "ROGUE",
					["timePlayed"] = 191.9319999999134,
					["isRxp"] = true,
				},
				["Moobugg"] = {
					["isRxp"] = true,
					["lastSeen"] = 296587.547,
					["xpPercentage"] = 0,
					["level"] = 25,
					["timePlayed"] = 0,
					["class"] = "HUNTER",
				},
				["Egothan"] = {
					["timePlayed"] = 38.90600000001723,
					["class"] = "SHAMAN",
					["xp"] = 34,
				},
				["Dadbloke"] = {
					["timePlayed"] = 2587.472999999998,
					["class"] = "MAGE",
					["xp"] = 217,
				},
				["Benedictus"] = {
					["isRxp"] = true,
					["lastSeen"] = 386421.786,
					["xpPercentage"] = 34,
					["level"] = 32,
					["timePlayed"] = 0,
					["class"] = "PRIEST",
				},
				["Supa"] = {
					["isRxp"] = true,
					["lastSeen"] = 92967.122,
					["xpPercentage"] = 24,
					["level"] = 11,
					["timePlayed"] = 134.0449999999983,
					["class"] = "HUNTER",
				},
				["Môrt"] = {
					["timePlayed"] = 1858.600999999966,
					["class"] = "HUNTER",
					["xp"] = 113,
				},
				["Novac"] = {
					["timePlayed"] = 250.0239999999758,
					["class"] = "WARRIOR",
					["xp"] = 33,
				},
				["Undeadinbed"] = {
					["level"] = 21,
					["lastSeen"] = 126017.136,
					["xpPercentage"] = 69,
					["class"] = "MAGE",
					["timePlayed"] = 0,
					["isRxp"] = true,
				},
				["Jabbo"] = {
					["timePlayed"] = 0,
					["class"] = "PRIEST",
					["xp"] = 16,
				},
				["Tinted"] = {
					["timePlayed"] = 60.81700000001001,
					["isRxp"] = true,
					["lastSeen"] = 109500.876,
					["xpPercentage"] = 2,
					["class"] = "PRIEST",
					["xp"] = 46,
					["level"] = 16,
				},
				["Chats"] = {
					["timePlayed"] = 0,
					["class"] = "PRIEST",
					["xp"] = 16,
				},
				["Mootok"] = {
					["isRxp"] = true,
					["lastSeen"] = 296587.547,
					["xpPercentage"] = 4,
					["level"] = 25,
					["timePlayed"] = 0,
					["class"] = "SHAMAN",
				},
				["Qumquick"] = {
					["timePlayed"] = 250.0239999999758,
					["class"] = "ROGUE",
					["xp"] = 33,
				},
				["Hsham"] = {
					["timePlayed"] = 2117.09600000002,
					["class"] = "SHAMAN",
					["xp"] = 3050,
				},
				["Mogrel"] = {
					["timePlayed"] = 1017.969999999972,
					["class"] = "ROGUE",
					["xp"] = 207,
				},
				["Moozou"] = {
					["timePlayed"] = 3499.312999999966,
					["class"] = "DRUID",
					["xp"] = 146,
				},
				["Biggriz"] = {
					["timePlayed"] = 2239.118000000133,
					["class"] = "SHAMAN",
					["xp"] = 86,
				},
				["Jarnysauce"] = {
					["timePlayed"] = 7496.959999999963,
					["class"] = "WARRIOR",
					["xp"] = 264,
				},
				["Binarz"] = {
					["class"] = "DRUID",
					["lastSeen"] = 593100.024,
					["xpPercentage"] = 0,
					["isRxp"] = true,
					["timePlayed"] = 3686.015999999945,
					["level"] = 25,
				},
				["Kaarsung"] = {
					["timePlayed"] = 77.33300000001327,
					["class"] = "SHAMAN",
					["xp"] = 31,
				},
				["Yumiyana"] = {
					["timePlayed"] = 0,
					["class"] = "SHAMAN",
					["xp"] = 41,
				},
				["Porkjerky"] = {
					["timePlayed"] = 9838.332999999868,
					["class"] = "PRIEST",
					["xp"] = 169,
				},
				["Zaz"] = {
					["isRxp"] = true,
					["lastSeen"] = 435398.743,
					["xpPercentage"] = 41,
					["level"] = 35,
					["timePlayed"] = 0,
					["class"] = "PRIEST",
				},
				["Bbanner"] = {
					["timePlayed"] = 3066.460000000021,
					["class"] = "SHAMAN",
					["xp"] = 1950,
				},
				["Pajamasray"] = {
					["level"] = 25,
					["lastSeen"] = 104137.29,
					["xpPercentage"] = 0,
					["class"] = "SHAMAN",
					["timePlayed"] = 0,
					["isRxp"] = true,
				},
				["Elmeera"] = {
					["level"] = 25,
					["lastSeen"] = 104216.534,
					["xpPercentage"] = 0,
					["class"] = "PRIEST",
					["timePlayed"] = 0,
					["isRxp"] = true,
				},
				["Sixsixone"] = {
					["timePlayed"] = 248.7489999999816,
					["class"] = "SHAMAN",
					["xp"] = 29,
				},
				["Kaff"] = {
					["timePlayed"] = 60.81700000001001,
					["class"] = "SHAMAN",
					["xp"] = 46,
				},
				["Oldace"] = {
					["timePlayed"] = 57.62900000000082,
					["class"] = "HUNTER",
					["xp"] = 21,
				},
				["Milkers"] = {
					["isRxp"] = true,
					["lastSeen"] = 296587.547,
					["xpPercentage"] = 0,
					["level"] = 25,
					["timePlayed"] = 0,
					["class"] = "DRUID",
				},
				["Dotsnotthots"] = {
					["isRxp"] = true,
					["lastSeen"] = 4642.552,
					["xpPercentage"] = 0,
					["level"] = 25,
					["timePlayed"] = 0,
					["class"] = "WARLOCK",
				},
				["Buckbee"] = {
					["class"] = "PRIEST",
					["lastSeen"] = 83500.16100000001,
					["xpPercentage"] = 15,
					["isRxp"] = true,
					["timePlayed"] = 201.0690000000031,
					["level"] = 11,
				},
				["Clerifythat"] = {
					["isRxp"] = true,
					["lastSeen"] = 462016.399,
					["xpPercentage"] = 22,
					["level"] = 36,
					["timePlayed"] = 17317.16500000004,
					["class"] = "PRIEST",
				},
				["Hroken"] = {
					["level"] = 25,
					["lastSeen"] = 616232.685,
					["xpPercentage"] = 0,
					["class"] = "WARRIOR",
					["timePlayed"] = 1544.116000000038,
					["isRxp"] = true,
				},
				["Lvlonetech"] = {
					["timePlayed"] = 201.0869999999995,
					["class"] = "WARRIOR",
					["xp"] = 22,
				},
				["Gtm"] = {
					["class"] = "HUNTER",
					["lastSeen"] = 397905.452,
					["xpPercentage"] = 33,
					["isRxp"] = true,
					["timePlayed"] = 85234.61699999982,
					["level"] = 31,
				},
				["Raheem"] = {
					["timePlayed"] = 2488.488000000012,
					["class"] = "WARLOCK",
					["xp"] = 164,
				},
				["Windmaster"] = {
					["class"] = "SHAMAN",
					["lastSeen"] = 588268.977,
					["xpPercentage"] = 6,
					["isRxp"] = true,
					["timePlayed"] = 2239.118000000133,
					["level"] = 20,
				},
				["Tuglife"] = {
					["level"] = 24,
					["lastSeen"] = 126017.355,
					["xpPercentage"] = 8,
					["class"] = "SHAMAN",
					["timePlayed"] = 85234.61699999982,
					["isRxp"] = true,
				},
				["Papicodone"] = {
					["timePlayed"] = 174.3570000000182,
					["class"] = "SHAMAN",
					["xp"] = 11,
				},
				["Finablo"] = {
					["class"] = "DRUID",
					["lastSeen"] = 719627.458,
					["xpPercentage"] = 0,
					["isRxp"] = true,
					["timePlayed"] = 0,
					["level"] = 40,
				},
				["Roguvulkz"] = {
					["class"] = "ROGUE",
					["lastSeen"] = 719627.458,
					["xpPercentage"] = 0,
					["isRxp"] = true,
					["timePlayed"] = 0,
					["level"] = 40,
				},
				["Yawn"] = {
					["class"] = "SHAMAN",
					["lastSeen"] = 551491.295,
					["xpPercentage"] = 32,
					["isRxp"] = true,
					["timePlayed"] = 1717.064000000013,
					["level"] = 39,
				},
				["Booked"] = {
					["timePlayed"] = 849.4179999999978,
					["class"] = "ROGUE",
					["xp"] = 25,
				},
				["Nollie"] = {
					["timePlayed"] = 0,
					["class"] = "ROGUE",
					["xp"] = 16,
				},
				["Solaro"] = {
					["isRxp"] = true,
					["lastSeen"] = 527963.131,
					["xpPercentage"] = 62,
					["level"] = 39,
					["timePlayed"] = 1150.207999999984,
					["class"] = "WARRIOR",
				},
				["Mìku"] = {
					["timePlayed"] = 1131.831000000006,
					["class"] = "PRIEST",
					["xp"] = 149,
				},
				["Podgey"] = {
					["timePlayed"] = 2758.417000000016,
					["class"] = "PRIEST",
					["xp"] = 141,
				},
				["Vynarel"] = {
					["class"] = "MAGE",
					["level"] = 7,
					["lastSeen"] = 77557.836,
					["xpPercentage"] = 91,
					["isRxp"] = true,
					["xp"] = 45,
					["timePlayed"] = 0,
				},
				["Voodoomedic"] = {
					["timePlayed"] = 3686.015999999945,
					["class"] = "PRIEST",
					["xp"] = 2200,
				},
				["Freak"] = {
					["class"] = "PRIEST",
					["lastSeen"] = 588268.751,
					["xpPercentage"] = 13,
					["isRxp"] = true,
					["timePlayed"] = 2239.118000000133,
					["level"] = 22,
				},
				["Pinkspider"] = {
					["timePlayed"] = 58.55000000004657,
					["class"] = "WARLOCK",
					["xp"] = 78,
				},
				["Fully"] = {
					["isRxp"] = true,
					["lastSeen"] = 356815.376,
					["xpPercentage"] = 45,
					["level"] = 27,
					["timePlayed"] = 3345.755000000005,
					["class"] = "WARRIOR",
				},
				["Elyas"] = {
					["timePlayed"] = 2099.792000000016,
					["class"] = "DRUID",
					["xp"] = 50,
				},
				["Dregzz"] = {
					["timePlayed"] = 950.4700000000303,
					["class"] = "WARLOCK",
					["xp"] = 202,
				},
				["Crums"] = {
					["timePlayed"] = 2758.417000000016,
					["class"] = "WARRIOR",
					["xp"] = 141,
				},
				["Eightball"] = {
					["timePlayed"] = 112.8099999999977,
					["class"] = "SHAMAN",
					["xp"] = 1500,
				},
				["Zluryy"] = {
					["timePlayed"] = 128.8340000000026,
					["class"] = "MAGE",
					["xp"] = 34,
				},
				["Johnwayne"] = {
					["timePlayed"] = 248.7489999999816,
					["class"] = "HUNTER",
					["xp"] = 29,
				},
				["Bownana"] = {
					["timePlayed"] = 125.8290000000125,
					["class"] = "HUNTER",
					["xp"] = 31,
				},
				["Hiemdel"] = {
					["timePlayed"] = 3686.015999999945,
					["class"] = "HUNTER",
					["xp"] = 2200,
				},
				["Snackie"] = {
					["isRxp"] = true,
					["lastSeen"] = 553719.822,
					["xpPercentage"] = 85,
					["level"] = 38,
					["timePlayed"] = 194.0499999999302,
					["class"] = "DRUID",
				},
				["Quaari"] = {
					["timePlayed"] = 183.4410000000498,
					["class"] = "HUNTER",
					["xp"] = 18,
				},
				["Bigbeefyboi"] = {
					["class"] = "DRUID",
					["lastSeen"] = 11243.696,
					["xpPercentage"] = 0,
					["isRxp"] = true,
					["timePlayed"] = 0,
					["level"] = 25,
				},
				["Folazee"] = {
					["timePlayed"] = 3499.312999999966,
					["class"] = "HUNTER",
					["xp"] = 146,
				},
				["Zaralito"] = {
					["class"] = "HUNTER",
					["lastSeen"] = 59098.369,
					["xpPercentage"] = 6,
					["isRxp"] = true,
					["timePlayed"] = 171.6620000000039,
					["level"] = 5,
				},
				["Floggo"] = {
					["class"] = "DRUID",
					["lastSeen"] = 448927.689,
					["xpPercentage"] = 70,
					["isRxp"] = true,
					["timePlayed"] = 2456.769000000029,
					["level"] = 31,
				},
				["Hungryjack"] = {
					["timePlayed"] = 201.0869999999995,
					["class"] = "ROGUE",
					["xp"] = 22,
				},
				["Jshay"] = {
					["class"] = "HUNTER",
					["lastSeen"] = 182613.101,
					["xpPercentage"] = 54,
					["isRxp"] = true,
					["timePlayed"] = 5536.976999999975,
					["level"] = 15,
				},
				["Onemangang"] = {
					["class"] = "SHAMAN",
					["lastSeen"] = 59098.369,
					["xpPercentage"] = 95,
					["isRxp"] = true,
					["timePlayed"] = 171.6620000000039,
					["level"] = 4,
				},
				["Capt"] = {
					["timePlayed"] = 805.2960000000312,
					["class"] = "WARRIOR",
					["xp"] = 68,
				},
				["Fuzzlepuff"] = {
					["timePlayed"] = 191.9319999999134,
					["class"] = "ROGUE",
					["xp"] = 1300,
				},
				["Arak"] = {
					["timePlayed"] = 859.079000000027,
					["class"] = "PRIEST",
					["xp"] = 128,
				},
				["Sixincher"] = {
					["level"] = 25,
					["lastSeen"] = 33526.896,
					["xpPercentage"] = 0,
					["class"] = "PRIEST",
					["timePlayed"] = 0,
					["isRxp"] = true,
				},
				["Brag"] = {
					["timePlayed"] = 189.2960000000021,
					["class"] = "MAGE",
					["xp"] = 39,
				},
				["Pressd"] = {
					["timePlayed"] = 38.90600000001723,
					["class"] = "WARRIOR",
					["xp"] = 34,
				},
				["Ozylock"] = {
					["timePlayed"] = 128.8340000000026,
					["class"] = "WARLOCK",
					["xp"] = 34,
				},
				["Haseul"] = {
					["class"] = "MAGE",
					["lastSeen"] = 112007.91,
					["xpPercentage"] = 69,
					["isRxp"] = true,
					["timePlayed"] = 6307.968000000014,
					["level"] = 14,
				},
				["Johncena"] = {
					["timePlayed"] = 248.7489999999816,
					["class"] = "ROGUE",
					["xp"] = 29,
				},
				["Stress"] = {
					["isRxp"] = true,
					["lastSeen"] = 1547.147,
					["xpPercentage"] = 3,
					["level"] = 25,
					["timePlayed"] = 0,
					["class"] = "WARRIOR",
				},
				["Skornn"] = {
					["timePlayed"] = 0,
					["class"] = "HUNTER",
					["xp"] = 41,
				},
				["Thendeths"] = {
					["class"] = "PRIEST",
					["lastSeen"] = 107866.878,
					["xpPercentage"] = 13,
					["isRxp"] = true,
					["timePlayed"] = 466.2880000000005,
					["level"] = 13,
				},
				["Hirsty"] = {
					["class"] = "HUNTER",
					["lastSeen"] = 57317.113,
					["xpPercentage"] = 63,
					["isRxp"] = true,
					["timePlayed"] = 0,
					["level"] = 4,
				},
				["Thantashift"] = {
					["class"] = "DRUID",
					["lastSeen"] = 369620.9,
					["xpPercentage"] = 39,
					["isRxp"] = true,
					["timePlayed"] = 0,
					["level"] = 30,
				},
				["Kittymeatz"] = {
					["timePlayed"] = 183.6750000000029,
					["class"] = "PRIEST",
					["xp"] = 31,
				},
				["Locknloadz"] = {
					["timePlayed"] = 192.4590000000026,
					["class"] = "WARRIOR",
					["xp"] = 50,
				},
				["Heiniu"] = {
					["timePlayed"] = 752.2359999999753,
					["class"] = "DRUID",
					["xp"] = 218,
				},
				["Crackk"] = {
					["timePlayed"] = 3066.460000000021,
					["class"] = "WARRIOR",
					["xp"] = 1950,
				},
				["Ashley"] = {
					["class"] = "WARLOCK",
					["lastSeen"] = 107867.125,
					["xpPercentage"] = 99,
					["isRxp"] = true,
					["timePlayed"] = 790.1719999999914,
					["level"] = 12,
				},
				["Porkhunt"] = {
					["class"] = "HUNTER",
					["lastSeen"] = 87693.52500000001,
					["xpPercentage"] = 54,
					["isRxp"] = true,
					["timePlayed"] = 259.0869999999995,
					["level"] = 11,
				},
				["Nawfdaddy"] = {
					["isRxp"] = true,
					["lastSeen"] = 44683.415,
					["xpPercentage"] = 0,
					["level"] = 25,
					["timePlayed"] = 0,
					["class"] = "HUNTER",
				},
				["Hunk"] = {
					["timePlayed"] = 600.2709999999934,
					["class"] = "PRIEST",
					["xp"] = 31,
				},
				["Skyshimo"] = {
					["class"] = "MAGE",
					["lastSeen"] = 11243.944,
					["xpPercentage"] = 0,
					["isRxp"] = true,
					["timePlayed"] = 0,
					["level"] = 25,
				},
				["Noobicus"] = {
					["timePlayed"] = 70.97900000005029,
					["class"] = "WARLOCK",
					["xp"] = 18,
				},
				["Sylet"] = {
					["level"] = 12,
					["lastSeen"] = 100447.029,
					["xpPercentage"] = 49,
					["class"] = "MAGE",
					["timePlayed"] = 600.2709999999934,
					["isRxp"] = true,
				},
				["Majenta"] = {
					["timePlayed"] = 11.38300000000163,
					["class"] = "MAGE",
					["xp"] = 31,
				},
				["Manaissues"] = {
					["timePlayed"] = 2488.488000000012,
					["class"] = "PRIEST",
					["xp"] = 164,
				},
				["Tiki"] = {
					["timePlayed"] = 6375.913000000001,
					["class"] = "DRUID",
					["xp"] = 193,
				},
				["Lucaa"] = {
					["timePlayed"] = 3576.285000000033,
					["class"] = "DRUID",
					["xp"] = 162,
				},
			},
		},
	},
}
RXPCSettings = nil

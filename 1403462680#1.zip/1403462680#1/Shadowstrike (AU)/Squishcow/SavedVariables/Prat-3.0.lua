
Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["scrollback"] = {
		["ChatFrame5"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 4,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["serverTime"] = 1709994796,
					["r"] = 1,
					["b"] = 0,
					["timestamp"] = 70687.35,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [1]
				{
					["message"] = "0 days, 0 hours, 0 minutes, 0 seconds",
					["timestamp"] = 70687.35,
				}, -- [2]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 70687.35,
				}, -- [3]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 70681.337,
					["g"] = 1,
					["b"] = 0,
				}, -- [4]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 48,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[18:42:37]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["serverTime"] = 1709994796,
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["timestamp"] = 70687.35,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [1]
				{
					["message"] = "0 days, 0 hours, 0 minutes, 0 seconds",
					["timestamp"] = 70687.35,
				}, -- [2]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 70687.35,
				}, -- [3]
				{
					["message"] = "|cFFFF1C1C Loaded: LFG Bulletin Board 3.17 by Vyscî-Whitemane",
					["timestamp"] = 70681.337,
				}, -- [4]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Dominos Detected, please make sure Dominos Elements are disabled in MoveAny!",
					["timestamp"] = 70681.337,
				}, -- [5]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Click the MoveAny Minimap Button to open the settings.",
					["timestamp"] = 70681.337,
				}, -- [6]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Or tap /move or /moveany in chat to open the settings.",
					["timestamp"] = 70681.337,
				}, -- [7]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 To hide these messages deactivate tips in the MoveAny menu.",
					["timestamp"] = 70681.337,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:03]|h|r Error parsing guide 12-17 The Barrens: Invalid function call (.isQuestTurnIn)\n.isQuestTurnIn 858",
					["timestamp"] = 70681.337,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:04]|h|r |cFF00FFB0WeaponSwingTimer: |rThank you for installing WeaponSwingTimer Version 7.2.4 by WatchYourSixx! Use |cFFFFC300/wst|r for more options.",
					["timestamp"] = 70681.337,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:06]|h|r |cffffff99<aux> loaded - /aux",
					["timestamp"] = 70687.35,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:06]|h|r RestedXP Guides: Targeting macro updated with (Supervisor Fizsprocket)",
					["timestamp"] = 70687.35,
					["serverTime"] = 1709994796,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:06]|h|r RestedXP Guides: Targeting macro updated with (Venture Co. Supervisor)",
					["timestamp"] = 70687.35,
					["serverTime"] = 1709994796,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:06]|h|r RestedXP Guides: Targeting macro updated with (Venture Co. Worker)",
					["timestamp"] = 70687.35,
					["serverTime"] = 1709994796,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:07]|h|r |c00FFAA00ThreatClassic2 v2.50 - Type /tc2 for options.|r",
					["timestamp"] = 70687.35,
					["serverTime"] = 1709994797,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:07]|h|r |cffe6cc80 [Whoa Thick Frames |cFF0070FFClassic|r |cffe6cc80v1.5d ] |cffffffffis now loaded. Use |cffffff00'/whoaf' |cffffffffto view options.",
					["timestamp"] = 70687.35,
					["serverTime"] = 1709994797,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:09]|h|r RestedXP Guides: Targeting macro updated with (Morin Cloudstalker)",
					["timestamp"] = 70689.985,
					["serverTime"] = 1709994799,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:09]|h|r RestedXP Guides: Targeting macro updated with (Gennia Runetotem)",
					["timestamp"] = 70690.152,
					["serverTime"] = 1709994799,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:10]|h|r RestedXP Guides: TotemTimers has known incompatibilities with the Waypoint Arrow. Disable it if you're experiencing navigation issues.",
					["timestamp"] = 70691.352,
					["serverTime"] = 1709994800,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:13]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LookingForGroup]|h",
					["serverTime"] = 1709994803,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70693.918,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:14]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Chookkin-Shadowstrike(AU):444:CHANNEL:1|h|cff0070ddChookkin|r|h|cffd8d8d8]|r: ill come",
					["serverTime"] = 1709994804,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70695.75200000001,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:16]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|h|HNWBCustomLink:timers|hYou are on a layered realm.|h|h",
					["timestamp"] = 70697.352,
					["serverTime"] = 1709994806,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:16]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|h|HNWBCustomLink:timers|hClick here to view current timers.|h|h",
					["timestamp"] = 70697.352,
					["serverTime"] = 1709994806,
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:18]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Eugethehuge-Shadowstrike(AU):445:CHANNEL:4|h|cffc69b6dEugethehuge|r|h|cffd8d8d8]|r: LFM GNOMER 6/6xp - checking logs",
					["serverTime"] = 1709994808,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70699.21800000001,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:27]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Tysom-Shadowstrike(AU):446:CHANNEL:4|h|cffc69b6dTysom|r|h|cffd8d8d8]|r: LF1M RFK",
					["serverTime"] = 1709994817,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70707.886,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:33:30]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Pandahi-Shadowstrike(AU):447:CHANNEL:4|h|cffc69b6dPandahi|r|h|cffd8d8d8]|r: LF1M Arms need dps",
					["serverTime"] = 1709994820,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70710.852,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:34:01]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Moogician-Shadowstrike(AU):448:CHANNEL:4|h|cffff7c0aMoogician|r|h|cffd8d8d8]|r: LF TANK BFD QUICK RUN COME GET XP OR LOOTS!!",
					["serverTime"] = 1709994851,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70742.669,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:34:04]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Pandahi-Shadowstrike(AU):449:CHANNEL:4|h|cffc69b6dPandahi|r|h|cffd8d8d8]|r: LF1M Arms need dps",
					["serverTime"] = 1709994854,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70745.352,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:34:05]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Soupguzzler-Shadowstrike(AU):450:CHANNEL:4|h|cffc69b6dSoupguzzler|r|h|cffd8d8d8]|r: LFG SFK WARRIOR TANK",
					["serverTime"] = 1709994855,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70745.903,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:34:10]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Melonmuncher-Shadowstrike(AU):451:CHANNEL:4|h|cfffff468Melonmuncher|r|h|cffd8d8d8]|r: LF3M Wailing Caverns",
					["serverTime"] = 1709994860,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70751.72,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:34:13]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Melonmuncher-Shadowstrike(AU):452:CHANNEL:1|h|cfffff468Melonmuncher|r|h|cffd8d8d8]|r: LF3M Wailing Caverns",
					["serverTime"] = 1709994863,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						4, -- [2]
						19, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70754.352,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:34:22]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Bbox-Shadowstrike(AU):453:CHANNEL:4|h|cffff7c0aBbox|r|h|cffd8d8d8]|r: LF1m dps or tank sm cath",
					["serverTime"] = 1709994872,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						21, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70762.836,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:34:26]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Sapr-Shadowstrike(AU):454:CHANNEL:4|h|cfffff468Sapr|r|h|cffd8d8d8]|r: LF1M TANK BFD",
					["serverTime"] = 1709994876,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						23, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70767.185,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:34:29]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Mooseman-Shadowstrike(AU):455:CHANNEL:4|h|cffff7c0aMooseman|r|h|cffd8d8d8]|r: cat lfg sm gy spam",
					["serverTime"] = 1709994879,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						25, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70770.202,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:34:41]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Linthia-Shadowstrike(AU):456:CHANNEL:4|h|cff3fc6eaLinthia|r|h|cffd8d8d8]|r: LFM SFK",
					["serverTime"] = 1709994891,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						27, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70781.919,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:34:44]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Moogician-Shadowstrike(AU):457:CHANNEL:4|h|cffff7c0aMoogician|r|h|cffd8d8d8]|r: LF TANK BFD QUICK RUN COME GET XP OR LOOTS!!",
					["serverTime"] = 1709994894,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70784.986,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:34:53]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Soupguzzler-Shadowstrike(AU):458:CHANNEL:4|h|cffc69b6dSoupguzzler|r|h|cffd8d8d8]|r: LFG SFK WARRIOR TANK",
					["serverTime"] = 1709994903,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70793.969,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:34:53]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Pandahi-Shadowstrike(AU):459:CHANNEL:4|h|cffc69b6dPandahi|r|h|cffd8d8d8]|r: LF1M Arms need dps",
					["serverTime"] = 1709994903,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70794.303,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:34:54]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Melonmuncher-Shadowstrike(AU):460:CHANNEL:4|h|cfffff468Melonmuncher|r|h|cffd8d8d8]|r: LF2M Wailing Caverns",
					["serverTime"] = 1709994904,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70794.887,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:34:55]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Melonmuncher-Shadowstrike(AU):461:CHANNEL:1|h|cfffff468Melonmuncher|r|h|cffd8d8d8]|r: LF2M Wailing Caverns",
					["serverTime"] = 1709994905,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						4, -- [2]
						19, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70796.686,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:35:01]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Sapr-Shadowstrike(AU):462:CHANNEL:4|h|cfffff468Sapr|r|h|cffd8d8d8]|r: LF1M TANK BFD",
					["serverTime"] = 1709994911,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						23, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70802.719,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:35:22]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Melonmuncher-Shadowstrike(AU):463:CHANNEL:1|h|cfffff468Melonmuncher|r|h|cffd8d8d8]|r: LF1M Wailing Caverns",
					["serverTime"] = 1709994932,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						4, -- [2]
						19, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70823.401,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:35:23]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Pandahi-Shadowstrike(AU):464:CHANNEL:4|h|cffc69b6dPandahi|r|h|cffd8d8d8]|r: LF1M Arms need dps",
					["serverTime"] = 1709994933,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70824.401,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:35:24]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Melonmuncher-Shadowstrike(AU):465:CHANNEL:4|h|cfffff468Melonmuncher|r|h|cffd8d8d8]|r: LF1M Wailing Caverns",
					["serverTime"] = 1709994934,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70825.402,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:35:25]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Gnargnar:466:CHANNEL:4|h|cff8787edGnargnar|r|h|cffd8d8d8]|r: LF1M RFD dps, can summ",
					["serverTime"] = 1709994935,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						29, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70825.985,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:35:28]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Offyourhead-Shadowstrike(AU):467:CHANNEL:4|h|cffc69b6dOffyourhead|r|h|cffd8d8d8]|r: DPS/OT LFG GNOMER",
					["serverTime"] = 1709994938,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						1, -- [2]
						31, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70829.135,
					["g"] = 0.3764706254005432,
					["b"] = 0.3529411852359772,
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:35:38]|h|r |Hchannel:channel:1|h[1] |h Left Channel: |Hchannel:CHANNEL:1|h[1. General - The Barrens]|h",
					["serverTime"] = 1709994948,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						4, -- [2]
						33, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70839.202,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:35:38]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - The Barrens]|h",
					["serverTime"] = 1709994948,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						35, -- [2]
						36, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 70839.202,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [48]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}


_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["tipo"] = 2,
					["combatId"] = 10,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["pets"] = {
							},
							["classe"] = "DRUID",
							["total_without_pet"] = 169.001531,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 169.001531,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9759E",
							["damage_from"] = {
								["Environment (Falling)"] = true,
							},
							["targets"] = {
								["Flatland Cougar"] = 169,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1708679042,
							["totalabsorbed"] = 0.001531,
							["aID"] = "5818-00A9759E",
							["nome"] = "Squishcow",
							["spells"] = {
								["_ActorTable"] = {
									[5177] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Flatland Cougar"] = 110,
										},
										["n_total"] = 110,
										["n_min"] = 35,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 110,
										["c_max"] = 0,
										["id"] = 5177,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["n_max"] = 38,
										["r_amt"] = 0,
									},
									[414684] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Flatland Cougar"] = 36,
										},
										["n_total"] = 36,
										["n_min"] = 36,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 36,
										["c_max"] = 0,
										["id"] = 414684,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["n_max"] = 36,
										["r_amt"] = 0,
									},
									[8924] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Flatland Cougar"] = 23,
										},
										["n_total"] = 23,
										["n_min"] = 23,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 23,
										["c_max"] = 0,
										["id"] = 8924,
										["r_dmg"] = 0,
										["spellschool"] = 64,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["n_max"] = 23,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708679040,
							["damage_taken"] = 19.001531,
							["start_time"] = 1708679035,
							["delay"] = 0,
							["last_dps"] = 26.06439404666376,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 0.007527,
							["last_dps_realtime"] = 0,
							["monster"] = true,
							["total"] = 0.007527,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-75-3035-00005651C9",
							["on_hold"] = false,
							["damage_from"] = {
								["Squishcow"] = true,
							},
							["targets"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["totalabsorbed"] = 0.007527,
							["fight_component"] = true,
							["end_time"] = 1708679042,
							["aID"] = "3035",
							["nome"] = "Flatland Cougar",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 169.007527,
							["start_time"] = 1708679042,
							["delay"] = 0,
							["last_dps"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 10,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 10,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 10,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[414684] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 1,
										["id"] = 414684,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[8924] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 0,
										["id"] = 8924,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["buff_uptime"] = 14,
							["classe"] = "DRUID",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[5232] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 5232,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[436412] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 436412,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 1,
							["buff_uptime_targets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["nome"] = "Squishcow",
							["last_event"] = 1708679042,
							["aID"] = "5818-00A9759E",
							["serial"] = "Player-5818-00A9759E",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 10,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Squishcow"] = "Player-5818-00A9759E",
				},
				["raid_roster_indexed"] = {
					"Squishcow", -- [1]
				},
				["tempo_start"] = 1708679035,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["combat_counter"] = 15,
				["playing_solo"] = true,
				["totals"] = {
					188, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					169, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Squishcow"] = {
						["Sunfire"] = 1,
						["Wrath"] = 1,
						["Moonfire"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "19:04:02",
				["hasTimer"] = 6.011000000056811,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Flatland Cougar",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 570266.295,
				["CombatEndedAt"] = 570266.295,
				["aura_timeline"] = {
				},
				["data_inicio"] = "19:03:56",
				["end_time"] = 570266.295,
				["combat_id"] = 10,
				["overall_added"] = true,
				["frags"] = {
					["Flatland Cougar"] = 1,
				},
				["TimeData"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["Squishcow"] = 169.001531,
						}, -- [1]
					},
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["player_last_events"] = {
					["Squishcow"] = {
						{
							true, -- [1]
							3, -- [2]
							19, -- [3]
							1708679053.042, -- [4]
							331, -- [5]
							"Environment (Falling)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["start_time"] = 570259.811,
				["contra"] = "Flatland Cougar",
				["spells_cast_timeline"] = {
				},
			}, -- [1]
			{
				{
					["tipo"] = 2,
					["combatId"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["pets"] = {
							},
							["classe"] = "DRUID",
							["total_without_pet"] = 159.001223,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 159.001223,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9759E",
							["damage_from"] = {
								["Flatland Cougar"] = true,
							},
							["targets"] = {
								["Flatland Cougar"] = 159,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1708679027,
							["totalabsorbed"] = 0.001223,
							["aID"] = "5818-00A9759E",
							["nome"] = "Squishcow",
							["spells"] = {
								["_ActorTable"] = {
									[8924] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Flatland Cougar"] = 49,
										},
										["n_total"] = 49,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 49,
										["c_max"] = 0,
										["id"] = 8924,
										["r_dmg"] = 0,
										["spellschool"] = 64,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["n_max"] = 19,
										["r_amt"] = 0,
									},
									[5177] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Flatland Cougar"] = 110,
										},
										["n_total"] = 110,
										["n_min"] = 36,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 110,
										["c_max"] = 0,
										["id"] = 5177,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["n_max"] = 37,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708679027,
							["damage_taken"] = 37.001223,
							["start_time"] = 1708679018,
							["delay"] = 0,
							["last_dps"] = 17.38478274665146,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 37.00726,
							["last_dps_realtime"] = 0,
							["monster"] = true,
							["total"] = 37.00726,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-75-3035-0000583544",
							["on_hold"] = false,
							["damage_from"] = {
								["Squishcow"] = true,
							},
							["targets"] = {
								["Squishcow"] = 37,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["totalabsorbed"] = 0.00726,
							["fight_component"] = true,
							["end_time"] = 1708679027,
							["aID"] = "3035",
							["nome"] = "Flatland Cougar",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Squishcow"] = 37,
										},
										["n_total"] = 37,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 37,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["n_max"] = 8,
										["r_amt"] = 0,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708679026,
							["damage_taken"] = 159.00726,
							["start_time"] = 1708679018,
							["delay"] = 0,
							["last_dps"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 9,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 9,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[8924] = {
										["activedamt"] = -1,
										["id"] = 8924,
										["targets"] = {
										},
										["actived_at"] = 1708679027,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["buff_uptime"] = 18,
							["classe"] = "DRUID",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[5232] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 9,
										["id"] = 5232,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[436412] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 9,
										["id"] = 436412,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 0,
							["buff_uptime_targets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["nome"] = "Squishcow",
							["last_event"] = 1708679027,
							["aID"] = "5818-00A9759E",
							["serial"] = "Player-5818-00A9759E",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 9,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Squishcow"] = "Player-5818-00A9759E",
				},
				["raid_roster_indexed"] = {
					"Squishcow", -- [1]
				},
				["CombatStartedAt"] = 570258.185,
				["tempo_start"] = 1708679018,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["combat_counter"] = 14,
				["playing_solo"] = true,
				["totals"] = {
					196, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					159, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Squishcow"] = {
						["Wrath"] = 3,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "19:03:48",
				["hasTimer"] = 9.008000000030734,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Flatland Cougar",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 570251.306,
				["CombatEndedAt"] = 570251.306,
				["aura_timeline"] = {
				},
				["data_inicio"] = "19:03:38",
				["end_time"] = 570251.306,
				["combat_id"] = 9,
				["overall_added"] = true,
				["frags"] = {
					["Flatland Cougar"] = 1,
				},
				["TimeData"] = {
				},
				["player_last_events"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["Squishcow"] = 159.001223,
						}, -- [1]
					},
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["start_time"] = 570242.16,
				["contra"] = "Flatland Cougar",
				["spells_cast_timeline"] = {
				},
			}, -- [2]
			{
				{
					["tipo"] = 2,
					["combatId"] = 8,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["pets"] = {
							},
							["classe"] = "DRUID",
							["total_without_pet"] = 192.007295,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 192.007295,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9759E",
							["damage_from"] = {
								["Environment (Falling)"] = true,
								["Environment (Fire)"] = true,
								["Elder Plainstrider"] = true,
							},
							["targets"] = {
								["Elder Plainstrider"] = 192,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1708678003,
							["totalabsorbed"] = 0.007295,
							["aID"] = "5818-00A9759E",
							["nome"] = "Squishcow",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Elder Plainstrider"] = 180,
										},
										["n_total"] = 109,
										["n_min"] = 34,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 180,
										["c_max"] = 71,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 71,
										["successful_casted"] = 0,
										["c_total"] = 71,
										["n_amt"] = 3,
										["n_max"] = 39,
										["r_amt"] = 0,
									}, -- [1]
									[467] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Elder Plainstrider"] = 12,
										},
										["n_total"] = 12,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 12,
										["c_max"] = 0,
										["id"] = 467,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["n_max"] = 3,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708678002,
							["damage_taken"] = 93.007295,
							["start_time"] = 1708677996,
							["delay"] = 1708677983,
							["last_dps"] = 7.42774835590611,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 31.006093,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 31.006093,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-75-2957-00035611E9",
							["damage_from"] = {
								["Squishcow"] = true,
							},
							["targets"] = {
								["Squishcow"] = 31,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["aID"] = "2957",
							["fight_component"] = true,
							["end_time"] = 1708678003,
							["totalabsorbed"] = 0.006093,
							["nome"] = "Elder Plainstrider",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Squishcow"] = 31,
										},
										["n_total"] = 31,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 31,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["n_max"] = 9,
										["r_amt"] = 0,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["on_hold"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708678002,
							["damage_taken"] = 192.006093,
							["start_time"] = 1708677996,
							["delay"] = 1708677983,
							["last_dps"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 8,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 8,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 8,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["aID"] = "5818-00A9759E",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[5487] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 26,
										["id"] = 5487,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[5232] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 26,
										["id"] = 5232,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[414824] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 18,
										["id"] = 414824,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[414827] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 9,
										["id"] = 414827,
										["refreshamt"] = 7,
										["actived"] = false,
										["counter"] = 0,
									},
									[467] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 26,
										["id"] = 467,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[436412] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 26,
										["id"] = 436412,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "Squishcow",
							["grupo"] = true,
							["buff_uptime"] = 131,
							["tipo"] = 4,
							["classe"] = "DRUID",
							["serial"] = "Player-5818-00A9759E",
							["last_event"] = 1708678003,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 8,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Squishcow"] = "Player-5818-00A9759E",
				},
				["raid_roster_indexed"] = {
					"Squishcow", -- [1]
				},
				["CombatStartedAt"] = 570241.586,
				["tempo_start"] = 1708677977,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					630, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 30,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					192, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
				},
				["instance_type"] = "none",
				["data_fim"] = "18:46:43",
				["hasTimer"] = 25.03200000000652,
				["pvp"] = true,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Elder Plainstrider",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 25.84999999997672,
				["CombatEndedAt"] = 569227.091,
				["aura_timeline"] = {
				},
				["data_inicio"] = "18:46:17",
				["end_time"] = 569227.091,
				["combat_id"] = 8,
				["frags"] = {
					["Elder Plainstrider"] = 1,
				},
				["overall_added"] = true,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["Squishcow"] = 192.007295,
						}, -- [1]
					},
				},
				["player_last_events"] = {
					["Squishcow"] = {
						{
							true, -- [1]
							3, -- [2]
							18, -- [3]
							1708678275.691, -- [4]
							331, -- [5]
							"Environment (Falling)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
							true, -- [1]
							6, -- [2]
							23, -- [3]
							1708678537.383, -- [4]
							331, -- [5]
							"Environment (Fire)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [2]
						{
							true, -- [1]
							3, -- [2]
							21, -- [3]
							1708678802.689, -- [4]
							331, -- [5]
							"Environment (Falling)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 4,
					},
				},
				["combat_counter"] = 13,
				["start_time"] = 569201.241,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [3]
			{
				{
					["tipo"] = 2,
					["combatId"] = 7,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["pets"] = {
							},
							["classe"] = "DRUID",
							["total_without_pet"] = 224.008616,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 224.008616,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9759E",
							["damage_from"] = {
								["Prairie Wolf Alpha"] = true,
							},
							["targets"] = {
								["Prairie Wolf Alpha"] = 224,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1708677964,
							["totalabsorbed"] = 0.008616,
							["aID"] = "5818-00A9759E",
							["nome"] = "Squishcow",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Prairie Wolf Alpha"] = 203,
										},
										["n_total"] = 203,
										["n_min"] = 32,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 203,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 6,
										["n_max"] = 36,
										["r_amt"] = 0,
									}, -- [1]
									[467] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Prairie Wolf Alpha"] = 21,
										},
										["n_total"] = 21,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 21,
										["c_max"] = 0,
										["id"] = 467,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 7,
										["n_max"] = 3,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708677964,
							["damage_taken"] = 45.008616,
							["start_time"] = 1708677950,
							["delay"] = 0,
							["last_dps"] = 15.63650816696813,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 45.007849,
							["last_dps_realtime"] = 0,
							["monster"] = true,
							["total"] = 45.007849,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-75-2960-000057D9CF",
							["on_hold"] = false,
							["damage_from"] = {
								["Squishcow"] = true,
							},
							["targets"] = {
								["Squishcow"] = 45,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["totalabsorbed"] = 0.007849,
							["fight_component"] = true,
							["end_time"] = 1708677964,
							["aID"] = "2960",
							["nome"] = "Prairie Wolf Alpha",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Squishcow"] = 45,
										},
										["n_total"] = 45,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 45,
										["c_max"] = 0,
										["DODGE"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 7,
										["n_max"] = 7,
										["r_amt"] = 0,
									}, -- [1]
									[5781] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 5781,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["c_total"] = 0,
										["n_amt"] = 0,
										["n_max"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708677963,
							["damage_taken"] = 224.007849,
							["start_time"] = 1708677953,
							["delay"] = 0,
							["last_dps"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 7,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 7,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["aID"] = "5818-00A9759E",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[5487] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 14,
										["id"] = 5487,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[5232] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 14,
										["id"] = 5232,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[414827] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 14,
										["id"] = 414827,
										["refreshamt"] = 15,
										["actived"] = false,
										["counter"] = 0,
									},
									[467] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 14,
										["id"] = 467,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[436412] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 14,
										["id"] = 436412,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "Squishcow",
							["grupo"] = true,
							["buff_uptime"] = 70,
							["tipo"] = 4,
							["classe"] = "DRUID",
							["serial"] = "Player-5818-00A9759E",
							["last_event"] = 1708677964,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Prairie Wolf Alpha",
							["fight_component"] = true,
							["last_event"] = 0,
							["tipo"] = 4,
							["serial"] = "Creature-0-5154-1-75-2960-000057D9CF",
							["aID"] = "2960",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 7,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Squishcow"] = "Player-5818-00A9759E",
				},
				["raid_roster_indexed"] = {
					"Squishcow", -- [1]
				},
				["CombatStartedAt"] = 569173.832,
				["tempo_start"] = 1708677950,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["combat_counter"] = 12,
				["playing_solo"] = true,
				["totals"] = {
					269, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					224, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Prairie Wolf Alpha"] = {
						["Threatening Growl"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "18:46:04",
				["hasTimer"] = 14.01399999996647,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Prairie Wolf Alpha",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 14.32600000000093,
				["CombatEndedAt"] = 569188.158,
				["aura_timeline"] = {
				},
				["data_inicio"] = "18:45:50",
				["end_time"] = 569188.158,
				["combat_id"] = 7,
				["overall_added"] = true,
				["frags"] = {
					["Prairie Wolf Alpha"] = 1,
				},
				["TimeData"] = {
				},
				["player_last_events"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["Squishcow"] = 224.008616,
						}, -- [1]
					},
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["start_time"] = 569173.832,
				["contra"] = "Prairie Wolf Alpha",
				["spells_cast_timeline"] = {
				},
			}, -- [4]
			{
				{
					["tipo"] = 2,
					["combatId"] = 6,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["pets"] = {
							},
							["classe"] = "DRUID",
							["total_without_pet"] = 228.007698,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 228.007698,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9759E",
							["damage_from"] = {
								["Flatland Prowler"] = true,
							},
							["targets"] = {
								["Flatland Prowler"] = 228,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1708677935,
							["totalabsorbed"] = 0.007698,
							["aID"] = "5818-00A9759E",
							["nome"] = "Squishcow",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 1,
										["g_amt"] = 0,
										["b_dmg"] = 34,
										["targets"] = {
											["Flatland Prowler"] = 207,
										},
										["n_total"] = 136,
										["n_min"] = 32,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 207,
										["c_max"] = 71,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 71,
										["successful_casted"] = 0,
										["c_total"] = 71,
										["n_amt"] = 4,
										["n_max"] = 37,
										["r_amt"] = 0,
									}, -- [1]
									[467] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Flatland Prowler"] = 21,
										},
										["n_total"] = 21,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 21,
										["c_max"] = 0,
										["id"] = 467,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 7,
										["n_max"] = 3,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708677935,
							["damage_taken"] = 58.007698,
							["start_time"] = 1708677922,
							["delay"] = 0,
							["last_dps"] = 17.62174031994515,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 58.006648,
							["last_dps_realtime"] = 0,
							["monster"] = true,
							["total"] = 58.006648,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-75-3566-0000D6FD5E",
							["on_hold"] = false,
							["damage_from"] = {
								["Squishcow"] = true,
							},
							["targets"] = {
								["Squishcow"] = 58,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["totalabsorbed"] = 0.006648,
							["fight_component"] = true,
							["end_time"] = 1708677935,
							["aID"] = "3566",
							["nome"] = "Flatland Prowler",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Squishcow"] = 58,
										},
										["n_total"] = 58,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 58,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 6,
										["n_max"] = 10,
										["r_amt"] = 0,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708677935,
							["damage_taken"] = 228.006648,
							["start_time"] = 1708677924,
							["delay"] = 0,
							["last_dps"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 6,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 6,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 6,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["aID"] = "5818-00A9759E",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[5487] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 12,
										["id"] = 5487,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[5232] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 12,
										["id"] = 5232,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[414827] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 9,
										["id"] = 414827,
										["refreshamt"] = 9,
										["actived"] = false,
										["counter"] = 0,
									},
									[467] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 12,
										["id"] = 467,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[436412] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 12,
										["id"] = 436412,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "Squishcow",
							["grupo"] = true,
							["buff_uptime"] = 57,
							["tipo"] = 4,
							["classe"] = "DRUID",
							["serial"] = "Player-5818-00A9759E",
							["last_event"] = 1708677935,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 6,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Squishcow"] = "Player-5818-00A9759E",
				},
				["raid_roster_indexed"] = {
					"Squishcow", -- [1]
				},
				["tempo_start"] = 1708677922,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["combat_counter"] = 11,
				["playing_solo"] = true,
				["totals"] = {
					286, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					228, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
				},
				["instance_type"] = "none",
				["data_fim"] = "18:45:36",
				["hasTimer"] = 12.0109999999404,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Flatland Prowler",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 569159.459,
				["CombatEndedAt"] = 569159.459,
				["aura_timeline"] = {
				},
				["data_inicio"] = "18:45:23",
				["end_time"] = 569159.459,
				["combat_id"] = 6,
				["overall_added"] = true,
				["frags"] = {
					["Flatland Prowler"] = 1,
				},
				["TimeData"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["Squishcow"] = 228.007698,
						}, -- [1]
					},
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["player_last_events"] = {
				},
				["start_time"] = 569146.52,
				["contra"] = "Flatland Prowler",
				["spells_cast_timeline"] = {
				},
			}, -- [5]
			{
				{
					["tipo"] = 2,
					["combatId"] = 5,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["pets"] = {
							},
							["classe"] = "DRUID",
							["total_without_pet"] = 228.003125,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 228.003125,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9759E",
							["damage_from"] = {
								["Flatland Prowler"] = true,
							},
							["targets"] = {
								["Flatland Prowler"] = 228,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1708677918,
							["totalabsorbed"] = 0.003125,
							["aID"] = "5818-00A9759E",
							["nome"] = "Squishcow",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Flatland Prowler"] = 207,
										},
										["n_total"] = 207,
										["n_min"] = 31,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 207,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 6,
										["n_max"] = 39,
										["r_amt"] = 0,
									}, -- [1]
									[467] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Flatland Prowler"] = 21,
										},
										["n_total"] = 21,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 21,
										["c_max"] = 0,
										["id"] = 467,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 7,
										["n_max"] = 3,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708677917,
							["damage_taken"] = 64.003125,
							["start_time"] = 1708677902,
							["delay"] = 0,
							["last_dps"] = 14.06732015055668,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 64.00233399999999,
							["last_dps_realtime"] = 0,
							["monster"] = true,
							["total"] = 64.00233399999999,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-75-3566-0000570CC3",
							["on_hold"] = false,
							["damage_from"] = {
								["Squishcow"] = true,
							},
							["targets"] = {
								["Squishcow"] = 64,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["totalabsorbed"] = 0.002334,
							["fight_component"] = true,
							["end_time"] = 1708677922,
							["aID"] = "3566",
							["nome"] = "Flatland Prowler",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Squishcow"] = 64,
										},
										["n_total"] = 64,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 64,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 7,
										["n_max"] = 10,
										["r_amt"] = 0,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708677922,
							["damage_taken"] = 228.002334,
							["start_time"] = 1708677904,
							["delay"] = 0,
							["last_dps"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 5,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 5,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 5,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["aID"] = "5818-00A9759E",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[467] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 16,
										["id"] = 467,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[436412] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 16,
										["id"] = 436412,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[5232] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 16,
										["id"] = 5232,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[5487] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 16,
										["id"] = 5487,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "Squishcow",
							["grupo"] = true,
							["buff_uptime"] = 64,
							["tipo"] = 4,
							["classe"] = "DRUID",
							["serial"] = "Player-5818-00A9759E",
							["last_event"] = 1708677918,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 5,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Squishcow"] = "Player-5818-00A9759E",
				},
				["raid_roster_indexed"] = {
					"Squishcow", -- [1]
				},
				["CombatStartedAt"] = 569146.52,
				["tempo_start"] = 1708677902,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["combat_counter"] = 10,
				["playing_solo"] = true,
				["totals"] = {
					292, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					228, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
				},
				["instance_type"] = "none",
				["data_fim"] = "18:45:19",
				["hasTimer"] = 16.02800000004936,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Flatland Prowler",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 569142.468,
				["CombatEndedAt"] = 569142.468,
				["aura_timeline"] = {
				},
				["data_inicio"] = "18:45:02",
				["end_time"] = 569142.468,
				["combat_id"] = 5,
				["overall_added"] = true,
				["frags"] = {
					["Flatland Prowler"] = 1,
				},
				["TimeData"] = {
				},
				["player_last_events"] = {
					["Squishcow"] = {
						{
							true, -- [1]
							1, -- [2]
							10, -- [3]
							1708677922.584, -- [4]
							379, -- [5]
							"Flatland Prowler", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["Squishcow"] = 228.003125,
						}, -- [1]
					},
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["start_time"] = 569126.26,
				["contra"] = "Flatland Prowler",
				["spells_cast_timeline"] = {
				},
			}, -- [6]
			{
				{
					["tipo"] = 2,
					["combatId"] = 4,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["pets"] = {
							},
							["classe"] = "DRUID",
							["total_without_pet"] = 241.008459,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 241.008459,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9759E",
							["damage_from"] = {
								["Flatland Prowler"] = true,
								["Prairie Wolf Alpha"] = true,
							},
							["targets"] = {
								["Prairie Wolf Alpha"] = 241,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1708677883,
							["totalabsorbed"] = 0.008459,
							["aID"] = "5818-00A9759E",
							["nome"] = "Squishcow",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Prairie Wolf Alpha"] = 105,
										},
										["n_total"] = 105,
										["n_min"] = 34,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 105,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["n_max"] = 37,
										["r_amt"] = 0,
									}, -- [1]
									[467] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Prairie Wolf Alpha"] = 21,
										},
										["n_total"] = 21,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 21,
										["c_max"] = 0,
										["id"] = 467,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 7,
										["n_max"] = 3,
										["r_amt"] = 0,
									},
									[5177] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Prairie Wolf Alpha"] = 38,
										},
										["n_total"] = 38,
										["n_min"] = 38,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 38,
										["c_max"] = 0,
										["id"] = 5177,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 1,
										["n_max"] = 38,
										["r_amt"] = 0,
									},
									[414684] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Prairie Wolf Alpha"] = 77,
										},
										["n_total"] = 77,
										["n_min"] = 18,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 77,
										["c_max"] = 0,
										["id"] = 414684,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["n_max"] = 40,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708677882,
							["damage_taken"] = 56.008459,
							["start_time"] = 1708677870,
							["delay"] = 0,
							["last_dps"] = 18.52628634028038,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 46.008983,
							["last_dps_realtime"] = 0,
							["monster"] = true,
							["total"] = 46.008983,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-75-2960-000057DAC9",
							["on_hold"] = false,
							["damage_from"] = {
								["Squishcow"] = true,
							},
							["targets"] = {
								["Squishcow"] = 46,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["totalabsorbed"] = 0.008983,
							["fight_component"] = true,
							["end_time"] = 1708677883,
							["aID"] = "2960",
							["nome"] = "Prairie Wolf Alpha",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Squishcow"] = 46,
										},
										["n_total"] = 46,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 46,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 6,
										["n_max"] = 8,
										["r_amt"] = 0,
									}, -- [1]
									[5781] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 5781,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["c_total"] = 0,
										["n_amt"] = 0,
										["n_max"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708677881,
							["damage_taken"] = 241.008983,
							["start_time"] = 1708677871,
							["delay"] = 0,
							["last_dps"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 4,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 4,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 4,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[414684] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 7,
										["id"] = 414684,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["buff_uptime"] = 48,
							["classe"] = "DRUID",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[467] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 13,
										["id"] = 467,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[436412] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 13,
										["id"] = 436412,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[5232] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 13,
										["id"] = 5232,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[5487] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 9,
										["id"] = 5487,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 7,
							["buff_uptime_targets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["nome"] = "Squishcow",
							["last_event"] = 1708677883,
							["aID"] = "5818-00A9759E",
							["serial"] = "Player-5818-00A9759E",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Prairie Wolf Alpha",
							["fight_component"] = true,
							["last_event"] = 0,
							["tipo"] = 4,
							["serial"] = "Creature-0-5154-1-75-2960-000057DAC9",
							["aID"] = "2960",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 4,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Squishcow"] = "Player-5818-00A9759E",
				},
				["raid_roster_indexed"] = {
					"Squishcow", -- [1]
				},
				["CombatStartedAt"] = 569126.26,
				["tempo_start"] = 1708677870,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["combat_counter"] = 9,
				["playing_solo"] = true,
				["totals"] = {
					297, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					241, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Squishcow"] = {
						["Sunfire"] = 1,
						["Wrath"] = 1,
						["Bear Form"] = 1,
					},
					["Prairie Wolf Alpha"] = {
						["Threatening Growl"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "18:44:43",
				["hasTimer"] = 12.00699999998324,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Prairie Wolf Alpha",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 13.00899999996182,
				["CombatEndedAt"] = 569106.828,
				["aura_timeline"] = {
				},
				["data_inicio"] = "18:44:30",
				["end_time"] = 569106.828,
				["combat_id"] = 4,
				["overall_added"] = true,
				["frags"] = {
					["Prairie Wolf Alpha"] = 1,
				},
				["TimeData"] = {
				},
				["player_last_events"] = {
					["Squishcow"] = {
						{
							true, -- [1]
							1, -- [2]
							10, -- [3]
							1708677902.324, -- [4]
							427, -- [5]
							"Flatland Prowler", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["Squishcow"] = 241.008459,
						}, -- [1]
					},
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["start_time"] = 569093.819,
				["contra"] = "Prairie Wolf Alpha",
				["spells_cast_timeline"] = {
				},
			}, -- [7]
			{
				{
					["tipo"] = 2,
					["combatId"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["pets"] = {
							},
							["classe"] = "DRUID",
							["total_without_pet"] = 524.001718,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 524.001718,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9759E",
							["damage_from"] = {
								["Arra'chea"] = true,
								["Prairie Wolf Alpha"] = true,
							},
							["targets"] = {
								["Arra'chea"] = 524,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 524,
							},
							["end_time"] = 1708677828,
							["totalabsorbed"] = 0.001718,
							["aID"] = "5818-00A9759E",
							["nome"] = "Squishcow",
							["spells"] = {
								["_ActorTable"] = {
									[467] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Arra'chea"] = 24,
										},
										["n_total"] = 24,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 24,
										["c_max"] = 0,
										["id"] = 467,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 8,
										["n_max"] = 3,
										["r_amt"] = 0,
									},
									[8924] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Arra'chea"] = 147,
										},
										["n_total"] = 147,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 147,
										["c_max"] = 0,
										["id"] = 8924,
										["r_dmg"] = 0,
										["spellschool"] = 64,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 11,
										["n_max"] = 20,
										["r_amt"] = 0,
									},
									[414684] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Arra'chea"] = 172,
										},
										["n_total"] = 172,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 172,
										["c_max"] = 0,
										["id"] = 414684,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 8,
										["n_max"] = 34,
										["r_amt"] = 0,
									},
									[5177] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Arra'chea"] = 181,
										},
										["n_total"] = 181,
										["n_min"] = 34,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 181,
										["c_max"] = 0,
										["id"] = 5177,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["n_max"] = 38,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708677826,
							["damage_taken"] = 280.001718,
							["start_time"] = 1708677791,
							["delay"] = 0,
							["last_dps"] = 14.16871854635628,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 274.00276,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 274.00276,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-75-3058-0000585A64",
							["damage_from"] = {
								["Squishcow"] = true,
							},
							["targets"] = {
								["Squishcow"] = 274,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["aID"] = "3058",
							["fight_component"] = true,
							["end_time"] = 1708677828,
							["totalabsorbed"] = 0.00276,
							["nome"] = "Arra'chea",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["b_dmg"] = 0,
										["targets"] = {
											["Squishcow"] = 274,
										},
										["n_total"] = 274,
										["n_min"] = 16,
										["g_dmg"] = 0,
										["counter"] = 15,
										["total"] = 274,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 15,
										["n_max"] = 21,
										["r_amt"] = 0,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["on_hold"] = false,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708677826,
							["damage_taken"] = 524.00276,
							["start_time"] = 1708677794,
							["delay"] = 0,
							["last_dps"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["Squishcow"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DRUID",
							["totalover"] = 14.006686,
							["total_without_pet"] = 28.006686,
							["total"] = 28.006686,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-5818-00A9759E",
							["totalabsorb"] = 0.006686,
							["last_hps"] = 0,
							["targets"] = {
								["Squishcow"] = 28,
							},
							["totalover_without_pet"] = 0.006686,
							["heal_enemy_amt"] = 0,
							["healing_taken"] = 28.006686,
							["fight_component"] = true,
							["end_time"] = 1708677828,
							["targets_overheal"] = {
								["Squishcow"] = 14,
							},
							["nome"] = "Squishcow",
							["spells"] = {
								["_ActorTable"] = {
									[1058] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Squishcow"] = 14,
										},
										["n_max"] = 14,
										["targets"] = {
											["Squishcow"] = 28,
										},
										["n_total"] = 28,
										["n_min"] = 0,
										["counter"] = 3,
										["overheal"] = 14,
										["total"] = 28,
										["spellschool"] = 8,
										["id"] = 1058,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_max"] = 0,
										["c_total"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 3,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["aID"] = "5818-00A9759E",
							["start_time"] = 1708677821,
							["custom"] = 0,
							["tipo"] = 2,
							["totaldenied"] = 0.006686,
							["delay"] = 0,
							["last_event"] = 1708677827,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 3,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[20549] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 2,
										["id"] = 20549,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[8924] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 23,
										["id"] = 8924,
										["refreshamt"] = 2,
										["actived"] = false,
										["counter"] = 0,
									},
									[414684] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 20,
										["id"] = 414684,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 101,
							["classe"] = "DRUID",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[467] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 17,
										["id"] = 467,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[436412] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 37,
										["id"] = 436412,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[5232] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 37,
										["id"] = 5232,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[1058] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = 1058,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 45,
							["nome"] = "Squishcow",
							["aID"] = "5818-00A9759E",
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["pets"] = {
							},
							["serial"] = "Player-5818-00A9759E",
							["last_event"] = 1708677828,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["pets"] = {
							},
							["aID"] = "3058",
							["fight_component"] = true,
							["nome"] = "Arra'chea",
							["classe"] = "UNKNOW",
							["tipo"] = 4,
							["serial"] = "Creature-0-5154-1-75-3058-0000585A64",
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 3,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Squishcow"] = "Player-5818-00A9759E",
				},
				["raid_roster_indexed"] = {
					"Squishcow", -- [1]
				},
				["tempo_start"] = 1708677791,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					804, -- [1]
					28, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					524, -- [1]
					28, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Arra'chea"] = {
						["Head Butt"] = 1,
					},
					["Squishcow"] = {
						["Wrath"] = 4,
						["Rejuvenation"] = 1,
						["War Stomp"] = 1,
						["Sunfire"] = 2,
						["Moonfire"] = 4,
						["Thorns"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "18:43:48",
				["hasTimer"] = 36.04600000008941,
				["pvp"] = true,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Arra'chea",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 569051.762,
				["CombatEndedAt"] = 569051.762,
				["aura_timeline"] = {
				},
				["data_inicio"] = "18:43:11",
				["end_time"] = 569051.762,
				["combat_id"] = 3,
				["frags"] = {
					["Arra'chea"] = 1,
				},
				["overall_added"] = true,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Squishcow"] = 28.006686,
						}, -- [1]
					},
					["damage"] = {
						{
							["Squishcow"] = 524.001718,
						}, -- [1]
					},
				},
				["combat_counter"] = 8,
				["player_last_events"] = {
					["Squishcow"] = {
						{
							true, -- [1]
							1, -- [2]
							6, -- [3]
							1708677869.883, -- [4]
							427, -- [5]
							"Prairie Wolf Alpha", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["start_time"] = 569014.779,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [8]
			{
				{
					["tipo"] = 2,
					["combatId"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["pets"] = {
							},
							["classe"] = "DRUID",
							["total_without_pet"] = 230.00523,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 230.00523,
							["colocacao"] = 1,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9759E",
							["damage_from"] = {
								["Prairie Wolf Alpha"] = true,
							},
							["targets"] = {
								["Prairie Wolf Alpha"] = 230,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["end_time"] = 1708677401,
							["totalabsorbed"] = 0.00523,
							["aID"] = "5818-00A9759E",
							["nome"] = "Squishcow",
							["spells"] = {
								["_ActorTable"] = {
									[5177] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 38,
										["targets"] = {
											["Prairie Wolf Alpha"] = 110,
										},
										["n_total"] = 110,
										["n_min"] = 36,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 110,
										["c_max"] = 0,
										["id"] = 5177,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[414684] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 36,
										["targets"] = {
											["Prairie Wolf Alpha"] = 71,
										},
										["n_total"] = 71,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 71,
										["c_max"] = 0,
										["id"] = 414684,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[8924] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 19,
										["targets"] = {
											["Prairie Wolf Alpha"] = 49,
										},
										["n_total"] = 49,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 49,
										["c_max"] = 0,
										["id"] = 8924,
										["r_dmg"] = 0,
										["spellschool"] = 64,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708677400,
							["damage_taken"] = 81.00523,
							["start_time"] = 1708677390,
							["delay"] = 0,
							["last_dps"] = 12.96096190687731,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 127.008532,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 127.008532,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-75-2960-0000583E3E",
							["friendlyfire"] = {
							},
							["damage_from"] = {
								["Jotunhoof"] = true,
								["Squishcow"] = true,
							},
							["targets"] = {
								["Jotunhoof"] = 46,
								["Squishcow"] = 81,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["totalabsorbed"] = 0.008532,
							["fight_component"] = true,
							["end_time"] = 1708677791,
							["aID"] = "2960",
							["nome"] = "Prairie Wolf Alpha",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Jotunhoof"] = 46,
											["Squishcow"] = 81,
										},
										["n_total"] = 102,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 17,
										["total"] = 127,
										["c_max"] = 13,
										["MISS"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 12,
										["successful_casted"] = 0,
										["c_total"] = 25,
										["n_amt"] = 13,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[5781] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_total"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 5781,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["c_total"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["monster"] = true,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708677412,
							["damage_taken"] = 398.008532,
							["start_time"] = 1708677762,
							["delay"] = 1708677412,
							["last_dps"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 2,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 2,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[8924] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 10,
										["id"] = 8924,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[414684] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 8,
										["id"] = 414684,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 40,
							["pets"] = {
							},
							["classe"] = "DRUID",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[436412] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 17,
										["id"] = 436412,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[5232] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 17,
										["id"] = 5232,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[414800] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = 414800,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 18,
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["aID"] = "5818-00A9759E",
							["tipo"] = 4,
							["last_event"] = 1708677401,
							["serial"] = "Player-5818-00A9759E",
							["nome"] = "Squishcow",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["nome"] = "Prairie Wolf Alpha",
							["monster"] = true,
							["tipo"] = 4,
							["aID"] = "2960",
							["serial"] = "Creature-0-5154-1-75-2960-0000583E3E",
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Squishcow"] = "Player-5818-00A9759E",
				},
				["raid_roster_indexed"] = {
					"Squishcow", -- [1]
				},
				["CombatStartedAt"] = 569013.319,
				["tempo_start"] = 1708677384,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["combat_counter"] = 7,
				["playing_solo"] = true,
				["totals"] = {
					745, -- [1]
					0, -- [2]
					{
						9, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Squishcow"] = {
						["Sunfire"] = 1,
						["Moonfire"] = 1,
						["Wrath"] = 3,
					},
					["Prairie Wolf Alpha"] = {
						["Threatening Growl"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "18:36:42",
				["hasTimer"] = 17.03000000002794,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Prairie Wolf Alpha",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 568625.613,
				["CombatEndedAt"] = 568625.613,
				["aura_timeline"] = {
				},
				["data_inicio"] = "18:36:24",
				["end_time"] = 568625.613,
				["combat_id"] = 2,
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["Squishcow"] = 230.00523,
						}, -- [1]
					},
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals_grupo"] = {
					230, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 568607.867,
				["contra"] = "Prairie Wolf Alpha",
				["frags"] = {
					["Prairie Wolf Alpha"] = 1,
				},
			}, -- [9]
			{
				{
					["tipo"] = 2,
					["combatId"] = 1,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["pets"] = {
							},
							["classe"] = "DRUID",
							["total_without_pet"] = 238.005248,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 238.005248,
							["colocacao"] = 1,
							["on_hold"] = false,
							["total_extra"] = 0,
							["serial"] = "Player-5818-00A9759E",
							["damage_from"] = {
								["The Rake"] = true,
							},
							["targets"] = {
								["The Rake"] = 238,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[16] = 238,
							},
							["end_time"] = 1708677283,
							["totalabsorbed"] = 0.005248,
							["aID"] = "5818-00A9759E",
							["nome"] = "Squishcow",
							["spells"] = {
								["_ActorTable"] = {
									[8924] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 21,
										["targets"] = {
											["The Rake"] = 61,
										},
										["n_total"] = 61,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 61,
										["c_max"] = 0,
										["id"] = 8924,
										["r_dmg"] = 0,
										["spellschool"] = 64,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[414684] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 36,
										["targets"] = {
											["The Rake"] = 105,
										},
										["n_total"] = 105,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 105,
										["c_max"] = 0,
										["id"] = 414684,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[5177] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 37,
										["targets"] = {
											["The Rake"] = 72,
										},
										["n_total"] = 72,
										["n_min"] = 35,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 72,
										["c_max"] = 0,
										["id"] = 5177,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708677283,
							["damage_taken"] = 95.005248,
							["start_time"] = 1708677269,
							["delay"] = 0,
							["last_dps"] = 16.58804349038409,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total_without_pet"] = 95.006998,
							["last_dps_realtime"] = 0,
							["dps_started"] = false,
							["total"] = 95.006998,
							["friendlyfire"] = {
							},
							["total_extra"] = 0,
							["serial"] = "Creature-0-5154-1-75-5807-0000584A26",
							["on_hold"] = false,
							["damage_from"] = {
								["Squishcow"] = true,
							},
							["targets"] = {
								["Squishcow"] = 95,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["totalabsorbed"] = 0.006998,
							["fight_component"] = true,
							["end_time"] = 1708677283,
							["aID"] = "5807",
							["nome"] = "The Rake",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["Squishcow"] = 76,
										},
										["n_total"] = 76,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 76,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["c_total"] = 0,
										["n_amt"] = 10,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[12166] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["g_amt"] = 0,
										["n_max"] = 19,
										["targets"] = {
											["Squishcow"] = 19,
										},
										["n_total"] = 19,
										["n_min"] = 19,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 19,
										["c_max"] = 0,
										["id"] = 12166,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["c_total"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["monster"] = true,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1708677282,
							["damage_taken"] = 238.006998,
							["start_time"] = 1708677271,
							["delay"] = 0,
							["last_dps"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 1,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 1,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 1,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[414684] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 12,
										["id"] = 414684,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[8924] = {
										["activedamt"] = -1,
										["id"] = 8924,
										["targets"] = {
										},
										["actived_at"] = 1708677281,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 28,
							["pets"] = {
							},
							["classe"] = "DRUID",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[436412] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 14,
										["id"] = 436412,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[5232] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 14,
										["id"] = 5232,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 12,
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["aID"] = "5818-00A9759E",
							["tipo"] = 4,
							["last_event"] = 1708677283,
							["serial"] = "Player-5818-00A9759E",
							["nome"] = "Squishcow",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["nome"] = "The Rake",
							["monster"] = true,
							["tipo"] = 4,
							["aID"] = "5807",
							["serial"] = "Creature-0-5154-1-75-5807-0000584A26",
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 1,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Squishcow"] = "Player-5818-00A9759E",
				},
				["raid_roster_indexed"] = {
					"Squishcow", -- [1]
				},
				["CombatStartedAt"] = 568606.2390000001,
				["tempo_start"] = 1708677269,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["bossTimers"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					333, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["amountCasts"] = {
					["Squishcow"] = {
						["Wrath"] = 2,
						["Sunfire"] = 1,
					},
					["The Rake"] = {
						["Muscle Tear"] = 1,
					},
				},
				["instance_type"] = "none",
				["data_fim"] = "18:34:44",
				["hasTimer"] = 14.02800000004936,
				["bIsClosed"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "The Rake",
				["trinketProcs"] = {
				},
				["TotalElapsedCombatTime"] = 14.34799999999814,
				["CombatEndedAt"] = 568507.502,
				["aura_timeline"] = {
				},
				["data_inicio"] = "18:34:29",
				["end_time"] = 568507.502,
				["combat_id"] = 1,
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["totals_grupo"] = {
					238, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["Squishcow"] = 238.005248,
						}, -- [1]
					},
				},
				["combat_counter"] = 6,
				["start_time"] = 568493.154,
				["contra"] = "The Rake",
				["frags"] = {
					["The Rake"] = 1,
				},
			}, -- [10]
		},
	},
	["ocd_tracker"] = {
		["show_title"] = true,
		["current_cooldowns"] = {
		},
		["lines_per_column"] = 12,
		["group_frames"] = true,
		["show_options"] = false,
		["frames"] = {
			["defensive-raid"] = {
			},
			["main"] = {
			},
			["ofensive"] = {
			},
			["defensive-target"] = {
			},
			["utility"] = {
			},
			["defensive-personal"] = {
			},
		},
		["width"] = 120,
		["ignored_cooldowns"] = {
		},
		["cooldowns"] = {
		},
		["height"] = 18,
		["own_frame"] = {
			["defensive-raid"] = false,
			["ofensive"] = false,
			["defensive-target"] = false,
			["utility"] = false,
			["defensive-personal"] = false,
		},
		["framme_locked"] = false,
		["show_conditions"] = {
			["only_inside_instance"] = true,
			["only_in_group"] = true,
		},
		["enabled"] = false,
		["filters"] = {
			["itemutil"] = false,
			["itempower"] = false,
			["defensive-target"] = false,
			["itemheal"] = false,
			["defensive-personal"] = false,
			["defensive-raid"] = false,
			["ofensive"] = true,
			["crowdcontrol"] = false,
			["utility"] = false,
		},
	},
	["last_version"] = "1.15.1 12330",
	["player_stats"] = {
	},
	["force_font_outline"] = "",
	["tabela_instancias"] = {
	},
	["coach"] = {
		["enabled"] = false,
		["welcome_panel_pos"] = {
		},
		["last_coach_name"] = false,
	},
	["local_instances_config"] = {
		{
			["modo"] = 2,
			["sub_attribute"] = 1,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["is_open"] = true,
			["isLocked"] = false,
			["snap"] = {
			},
			["segment"] = 0,
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -304.8888092041016,
					["x"] = 695.112060546875,
					["w"] = 310,
					["h"] = 158.0000152587891,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
	},
	["cached_talents"] = {
	},
	["last_instance_id"] = 0,
	["data_harvest_for_charsts"] = {
		["players"] = {
			{
				["playerKey"] = "total",
				["combatObjectContainer"] = 1,
				["name"] = "Damage of Each Individual Player",
				["playerOnly"] = true,
			}, -- [1]
		},
		["totals"] = {
			{
				["combatObjectSubTableKey"] = 1,
				["name"] = "Damage of All Player Combined",
				["combatObjectSubTableName"] = "totals",
			}, -- [1]
		},
	},
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["announce_prepots"] = {
		["enabled"] = false,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["active_profile"] = "Squishcow-Shadowstrike (AU)",
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["combat_log"] = {
		["inverse_deathlog_overalldata"] = false,
		["evoker_calc_damage"] = false,
		["track_hunter_frenzy"] = false,
		["merge_critical_heals"] = false,
		["inverse_deathlog_raid"] = false,
		["merge_gemstones_1007"] = false,
		["evoker_show_realtimedps"] = false,
		["inverse_deathlog_mplus"] = false,
	},
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["mythic_plus_log"] = {
	},
	["ignore_nicktag"] = false,
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["combat_counter"] = 15,
	["data_harvested_for_charts"] = {
	},
	["nick_tag_cache"] = {
		["nextreset"] = 1711290781,
		["last_version"] = 16,
	},
	["last_realversion"] = 155,
	["last_instance_time"] = 0,
	["combat_id"] = 10,
	["savedStyles"] = {
	},
	["last_day"] = "10",
	["character_data"] = {
		["logons"] = 4,
	},
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["pets"] = {
					},
					["classe"] = "DRUID",
					["total_without_pet"] = 2433.051408,
					["last_dps_realtime"] = 0,
					["dps_started"] = false,
					["total"] = 2433.051408,
					["on_hold"] = false,
					["total_extra"] = 0,
					["serial"] = "Player-5818-00A9759E",
					["damage_from"] = {
						["Arra'chea"] = true,
						["The Rake"] = true,
						["Flatland Cougar"] = true,
						["Prairie Wolf Alpha"] = true,
						["Flatland Prowler"] = true,
						["Elder Plainstrider"] = true,
					},
					["targets"] = {
						["Arra'chea"] = 524,
						["The Rake"] = 238,
						["Flatland Cougar"] = 328,
						["Prairie Wolf Alpha"] = 695,
						["Flatland Prowler"] = 456,
						["Elder Plainstrider"] = 192,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
						[16] = 238,
						[128] = 524,
					},
					["end_time"] = 1708677284,
					["totalabsorbed"] = 0.051408,
					["aID"] = "5818-00A9759E",
					["nome"] = "Squishcow",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 1,
								["g_amt"] = 0,
								["b_dmg"] = 34,
								["targets"] = {
									["Prairie Wolf Alpha"] = 308,
									["Flatland Prowler"] = 414,
									["Elder Plainstrider"] = 180,
								},
								["n_total"] = 760,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 24,
								["total"] = 902,
								["c_max"] = 71,
								["id"] = 1,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 142,
								["n_amt"] = 22,
								["n_max"] = 39,
								["r_amt"] = 0,
							}, -- [1]
							[467] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Arra'chea"] = 24,
									["Prairie Wolf Alpha"] = 42,
									["Flatland Prowler"] = 42,
									["Elder Plainstrider"] = 12,
								},
								["n_total"] = 120,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 40,
								["total"] = 120,
								["c_max"] = 0,
								["id"] = 467,
								["r_dmg"] = 0,
								["spellschool"] = 8,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 40,
								["n_max"] = 3,
								["r_amt"] = 0,
							},
							[5177] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 38,
								["targets"] = {
									["Arra'chea"] = 181,
									["The Rake"] = 72,
									["Flatland Cougar"] = 220,
									["Prairie Wolf Alpha"] = 148,
								},
								["n_total"] = 621,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 17,
								["total"] = 621,
								["c_max"] = 0,
								["id"] = 5177,
								["r_dmg"] = 0,
								["spellschool"] = 8,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 17,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[414684] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 40,
								["targets"] = {
									["Arra'chea"] = 172,
									["The Rake"] = 105,
									["Flatland Cougar"] = 36,
									["Prairie Wolf Alpha"] = 148,
								},
								["n_total"] = 461,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 20,
								["total"] = 461,
								["c_max"] = 0,
								["id"] = 414684,
								["r_dmg"] = 0,
								["spellschool"] = 8,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 20,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[8924] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 23,
								["targets"] = {
									["Arra'chea"] = 147,
									["The Rake"] = 61,
									["Flatland Cougar"] = 72,
									["Prairie Wolf Alpha"] = 49,
								},
								["n_total"] = 329,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 25,
								["total"] = 329,
								["c_max"] = 0,
								["id"] = 8924,
								["r_dmg"] = 0,
								["spellschool"] = 64,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 25,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["friendlyfire"] = {
					},
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 721.0514079999999,
					["start_time"] = 1708677140,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [1]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 95.01216099999999,
					["last_dps_realtime"] = 0,
					["dps_started"] = false,
					["total"] = 95.01216099999999,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5154-1-75-5807-0000584A26",
					["on_hold"] = false,
					["damage_from"] = {
						["Squishcow"] = true,
					},
					["targets"] = {
						["Squishcow"] = 95,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["totalabsorbed"] = 0.012161,
					["fight_component"] = true,
					["end_time"] = 1708677284,
					["aID"] = "5807",
					["nome"] = "The Rake",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 9,
								["targets"] = {
									["Squishcow"] = 76,
								},
								["n_total"] = 76,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 76,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 10,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[12166] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 19,
								["targets"] = {
									["Squishcow"] = 19,
								},
								["n_total"] = 19,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 19,
								["c_max"] = 0,
								["id"] = 12166,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["c_total"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 238.012161,
					["start_time"] = 1708677269,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [2]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 172.033591,
					["last_dps_realtime"] = 0,
					["dps_started"] = false,
					["total"] = 172.033591,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5154-1-75-2960-0000583E3E",
					["on_hold"] = false,
					["damage_from"] = {
						["Squishcow"] = true,
					},
					["targets"] = {
						["Squishcow"] = 172,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["totalabsorbed"] = 0.033591,
					["fight_component"] = true,
					["end_time"] = 1708677402,
					["aID"] = "2960",
					["nome"] = "Prairie Wolf Alpha",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 10,
								["targets"] = {
									["Squishcow"] = 172,
								},
								["n_total"] = 172,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 27,
								["DODGE"] = 3,
								["r_amt"] = 0,
								["spellschool"] = 1,
								["MISS"] = 1,
								["id"] = 1,
								["r_dmg"] = 0,
								["c_max"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 23,
								["b_dmg"] = 0,
								["total"] = 172,
							}, -- [1]
							[5781] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_total"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 5781,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["c_total"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 695.033591,
					["start_time"] = 1708677359,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [3]
				{
					["flag_original"] = 68136,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 274.006051,
					["last_dps_realtime"] = 0,
					["dps_started"] = false,
					["total"] = 274.006051,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5154-1-75-3058-0000585A64",
					["damage_from"] = {
						["Squishcow"] = true,
					},
					["targets"] = {
						["Squishcow"] = 274,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["aID"] = "3058",
					["fight_component"] = true,
					["end_time"] = 1708677828,
					["totalabsorbed"] = 0.006051,
					["nome"] = "Arra'chea",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Squishcow"] = 274,
								},
								["n_total"] = 274,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 15,
								["total"] = 274,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 15,
								["n_max"] = 21,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["on_hold"] = false,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 524.006051,
					["start_time"] = 1708677791,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [4]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 112.011672,
					["last_dps_realtime"] = 0,
					["monster"] = true,
					["total"] = 112.011672,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5154-1-75-3566-0000570CC3",
					["on_hold"] = false,
					["damage_from"] = {
						["Squishcow"] = true,
					},
					["targets"] = {
						["Squishcow"] = 112,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["totalabsorbed"] = 0.011672,
					["fight_component"] = true,
					["end_time"] = 1708677919,
					["aID"] = "3566",
					["nome"] = "Flatland Prowler",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Squishcow"] = 112,
								},
								["n_total"] = 112,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 13,
								["total"] = 112,
								["c_max"] = 0,
								["DODGE"] = 1,
								["id"] = 1,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 12,
								["n_max"] = 10,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 456.011672,
					["start_time"] = 1708677891,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [5]
				{
					["flag_original"] = 68136,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 31.010536,
					["last_dps_realtime"] = 0,
					["dps_started"] = false,
					["total"] = 31.010536,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5154-1-75-2957-00035611E9",
					["damage_from"] = {
						["Squishcow"] = true,
					},
					["targets"] = {
						["Squishcow"] = 31,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["aID"] = "2957",
					["fight_component"] = true,
					["end_time"] = 1708678003,
					["totalabsorbed"] = 0.010536,
					["nome"] = "Elder Plainstrider",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Squishcow"] = 31,
								},
								["n_total"] = 31,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 31,
								["c_max"] = 0,
								["MISS"] = 1,
								["id"] = 1,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 4,
								["n_max"] = 9,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["on_hold"] = false,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 192.010536,
					["start_time"] = 1708677993,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [6]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["total_without_pet"] = 37.01899400000001,
					["last_dps_realtime"] = 0,
					["monster"] = true,
					["total"] = 37.01899400000001,
					["friendlyfire"] = {
					},
					["total_extra"] = 0,
					["serial"] = "Creature-0-5154-1-75-3035-0000583544",
					["on_hold"] = false,
					["damage_from"] = {
						["Squishcow"] = true,
					},
					["targets"] = {
						["Squishcow"] = 37,
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["totalabsorbed"] = 0.018994,
					["fight_component"] = true,
					["end_time"] = 1708679028,
					["aID"] = "3035",
					["nome"] = "Flatland Cougar",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["g_amt"] = 0,
								["b_dmg"] = 0,
								["targets"] = {
									["Squishcow"] = 37,
								},
								["n_total"] = 37,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 37,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["spellschool"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["c_total"] = 0,
								["n_amt"] = 5,
								["n_max"] = 8,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 328.018994,
					["start_time"] = 1708679016,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [7]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["healing_from"] = {
						["Squishcow"] = true,
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "DRUID",
					["totalover"] = 14.012942,
					["total_without_pet"] = 28.012942,
					["total"] = 28.012942,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-5818-00A9759E",
					["totalabsorb"] = 0.012942,
					["last_hps"] = 0,
					["targets"] = {
						["Squishcow"] = 28,
					},
					["totalover_without_pet"] = 0.012942,
					["heal_enemy_amt"] = 0,
					["healing_taken"] = 28.012942,
					["fight_component"] = true,
					["end_time"] = 1708677828,
					["targets_overheal"] = {
						["Squishcow"] = 14,
					},
					["nome"] = "Squishcow",
					["spells"] = {
						["_ActorTable"] = {
							[1058] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Squishcow"] = 14,
								},
								["n_max"] = 14,
								["targets"] = {
									["Squishcow"] = 28,
								},
								["n_total"] = 28,
								["n_min"] = 0,
								["counter"] = 3,
								["overheal"] = 14,
								["total"] = 28,
								["spellschool"] = 8,
								["id"] = 1058,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_max"] = 0,
								["c_total"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 3,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["aID"] = "5818-00A9759E",
					["start_time"] = 1708677818,
					["custom"] = 0,
					["tipo"] = 2,
					["totaldenied"] = 0.012942,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [1]
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[20549] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 1,
								["id"] = 20549,
								["uptime"] = 2,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[8924] = {
								["refreshamt"] = 2,
								["appliedamt"] = 4,
								["activedamt"] = -2,
								["uptime"] = 33,
								["id"] = 8924,
								["actived_at"] = 3417356308,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[414684] = {
								["refreshamt"] = 1,
								["activedamt"] = 0,
								["appliedamt"] = 5,
								["id"] = 414684,
								["uptime"] = 48,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "DRUID",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[1058] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 1058,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[414827] = {
								["refreshamt"] = 31,
								["activedamt"] = 4,
								["appliedamt"] = 4,
								["id"] = 414827,
								["uptime"] = 32,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[467] = {
								["refreshamt"] = 0,
								["activedamt"] = 6,
								["appliedamt"] = 6,
								["id"] = 467,
								["uptime"] = 98,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[414824] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 414824,
								["uptime"] = 18,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[5232] = {
								["refreshamt"] = 0,
								["activedamt"] = 10,
								["appliedamt"] = 10,
								["id"] = 5232,
								["uptime"] = 165,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[5487] = {
								["refreshamt"] = 0,
								["activedamt"] = 6,
								["appliedamt"] = 6,
								["id"] = 5487,
								["uptime"] = 77,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[414800] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 414800,
								["uptime"] = 6,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[436412] = {
								["refreshamt"] = 0,
								["activedamt"] = 10,
								["appliedamt"] = 10,
								["id"] = 436412,
								["uptime"] = 165,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["fight_component"] = true,
					["debuff_uptime"] = 83,
					["buff_uptime"] = 571,
					["debuff_uptime_targets"] = {
					},
					["nome"] = "Squishcow",
					["grupo"] = true,
					["buff_uptime_targets"] = {
					},
					["last_event"] = 0,
					["aID"] = "5818-00A9759E",
					["serial"] = "Player-5818-00A9759E",
					["tipo"] = 4,
				}, -- [1]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["fight_component"] = true,
					["nome"] = "The Rake",
					["monster"] = true,
					["last_event"] = 0,
					["aID"] = "5807",
					["serial"] = "Creature-0-5154-1-75-5807-0000584A26",
					["tipo"] = 4,
				}, -- [2]
				{
					["flag_original"] = 68168,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["fight_component"] = true,
					["nome"] = "Prairie Wolf Alpha",
					["monster"] = true,
					["last_event"] = 0,
					["aID"] = "2960",
					["serial"] = "Creature-0-5154-1-75-2960-0000583E3E",
					["tipo"] = 4,
				}, -- [3]
				{
					["flag_original"] = 68136,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["fight_component"] = true,
					["nome"] = "Arra'chea",
					["tipo"] = 4,
					["last_event"] = 0,
					["serial"] = "Creature-0-5154-1-75-3058-0000585A64",
					["aID"] = "3058",
				}, -- [4]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["raid_roster_indexed"] = {
		},
		["tempo_start"] = 1708677269,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["bossTimers"] = {
		},
		["combat_counter"] = 5,
		["totals"] = {
			3154.115127, -- [1]
			28.006686, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 0,
				["dispell"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
			["frags_total"] = 0,
			["voidzone_damage"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["overall_refreshed"] = true,
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["damage_section"] = {
			},
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage"] = {
			},
		},
		["end_time"] = 570266.295,
		["amountCasts"] = {
			["Arra'chea"] = {
				["Head Butt"] = 1,
			},
			["The Rake"] = {
				["Muscle Tear"] = 1,
			},
			["Prairie Wolf Alpha"] = {
				["Threatening Growl"] = 3,
			},
			["Squishcow"] = {
				["Sunfire"] = 6,
				["Wrath"] = 14,
				["War Stomp"] = 1,
				["Bear Form"] = 1,
				["Rejuvenation"] = 1,
				["Moonfire"] = 6,
				["Thorns"] = 1,
			},
		},
		["cleu_events"] = {
			["n"] = 1,
		},
		["totals_grupo"] = {
			2433.050143, -- [1]
			28.006686, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 0,
				["dispell"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
		},
		["data_inicio"] = "18:34:29",
		["spells_cast_timeline"] = {
		},
		["segments_added"] = {
			{
				["elapsed"] = 6.484000000054948,
				["type"] = 0,
				["name"] = "Flatland Cougar",
				["clock"] = "19:03:56",
			}, -- [1]
			{
				["elapsed"] = 9.145999999949709,
				["type"] = 0,
				["name"] = "Flatland Cougar",
				["clock"] = "19:03:38",
			}, -- [2]
			{
				["elapsed"] = 25.84999999997672,
				["type"] = 0,
				["name"] = "Elder Plainstrider",
				["clock"] = "18:46:17",
			}, -- [3]
			{
				["elapsed"] = 14.32600000000093,
				["type"] = 0,
				["name"] = "Prairie Wolf Alpha",
				["clock"] = "18:45:50",
			}, -- [4]
			{
				["elapsed"] = 12.93900000001304,
				["type"] = 0,
				["name"] = "Flatland Prowler",
				["clock"] = "18:45:23",
			}, -- [5]
			{
				["elapsed"] = 16.20799999998417,
				["type"] = 0,
				["name"] = "Flatland Prowler",
				["clock"] = "18:45:02",
			}, -- [6]
			{
				["elapsed"] = 13.00899999996182,
				["type"] = 0,
				["name"] = "Prairie Wolf Alpha",
				["clock"] = "18:44:30",
			}, -- [7]
			{
				["elapsed"] = 36.98300000000745,
				["type"] = 0,
				["name"] = "Arra'chea",
				["clock"] = "18:43:11",
			}, -- [8]
			{
				["elapsed"] = 17.74600000004284,
				["type"] = 0,
				["name"] = "Prairie Wolf Alpha",
				["clock"] = "18:36:24",
			}, -- [9]
			{
				["elapsed"] = 14.34799999999814,
				["type"] = 0,
				["name"] = "The Rake",
				["clock"] = "18:34:29",
			}, -- [10]
		},
		["data_fim"] = "19:04:02",
		["overall_enemy_name"] = "-- x -- x --",
		["frags"] = {
		},
		["cleu_timeline"] = {
		},
		["start_time"] = 570099.256,
		["TimeData"] = {
		},
		["trinketProcs"] = {
		},
	},
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["enabled"] = true,
			["animate"] = false,
			["hide_pull_bar"] = false,
			["author"] = "Terciob",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["usefocus"] = false,
			["updatespeed"] = 1,
			["useclasscolors"] = false,
			["showamount"] = false,
			["useplayercolor"] = false,
			["absolute_mode"] = false,
			["playSound"] = false,
			["playSoundFile"] = "Details Threat Warning Volume 3",
			["disable_gouge"] = false,
		},
		["DETAILS_PLUGIN_COMPARETWO_WINDOW"] = {
			["enabled"] = true,
			["author"] = "Terciob",
		},
		["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
			["use_square_mode"] = false,
			["is_first_run"] = false,
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["arrow_anchor_y"] = 0,
			["main_frame_size"] = {
				300.0000610351563, -- [1]
				499.9999389648438, -- [2]
			},
			["minimap"] = {
				["minimapPos"] = 304.022555701998,
				["radius"] = 160,
				["hide"] = true,
			},
			["main_frame_locked"] = false,
			["arrow_anchor_x"] = 0,
			["use_spark"] = true,
			["row_texture"] = "Details Serenity",
			["square_grow_direction"] = "right",
			["row_color"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.1, -- [3]
				0.4, -- [4]
			},
			["author"] = "Terciob",
			["square_amount"] = 5,
			["enabled"] = false,
			["arrow_size"] = 10,
			["y"] = -1.52587890625e-05,
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.2, -- [4]
			},
			["main_frame_strata"] = "LOW",
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["font_size"] = 10,
			["per_second"] = {
				["enabled"] = false,
				["point"] = "CENTER",
				["scale"] = 1,
				["font_shadow"] = true,
				["y"] = -3.0517578125e-05,
				["x"] = 0.0001220703125,
				["attribute_type"] = 1,
				["update_speed"] = 0.05,
				["size"] = 32,
			},
			["x"] = 3.0517578125e-05,
			["font_face"] = "Friz Quadrata TT",
			["square_size"] = 32,
			["point"] = "CENTER",
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["row_height"] = 20,
			["scale"] = 1,
		},
	},
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["on_death_menu"] = false,
	["announce_cooldowns"] = {
		["ignored_cooldowns"] = {
		},
		["enabled"] = false,
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["cached_roles"] = {
	},
	["cached_specs"] = {
	},
}

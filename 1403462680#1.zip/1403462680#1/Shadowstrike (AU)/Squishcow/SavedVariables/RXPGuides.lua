
RXPCData = {
	["completedWaypoints"] = {
		[155] = {
		},
		["tip"] = {
		},
	},
	["currentStep"] = 155,
	["questObjectivesCache"] = {
		[0] = 30,
		[756] = {
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Stalker Claws: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Cougar Claws: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[757] = {
			{
				["type"] = "item",
				["numRequired"] = 12,
				["text"] = "Bristleback Belt: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[833] = {
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Bristleback Interloper slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[758] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Cleanse the Thunderhorn Water Well",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[743] = {
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Windfury Talon: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[759] = {
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Prairie Alpha Tooth: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[744] = {
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Azure Feather: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Bronze Feather: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[760] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Cleanse the Wildmane Well",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[745] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Palemane Tanner slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Palemane Skinner slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 5,
				["text"] = "Palemane Poacher slain: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[761] = {
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Trophy Swoop Quill: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[746] = {
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Broken Tools: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[870] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Explore the waters of the Forgotten Pools",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[747] = {
			{
				["type"] = "item",
				["numRequired"] = 7,
				["text"] = "Plainstrider Meat: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 7,
				["text"] = "Plainstrider Feather: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[771] = {
			{
				["type"] = "item",
				["numRequired"] = 2,
				["text"] = "Well Stone: 0/2",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 2,
				["text"] = "Ambercorn: 0/2",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[748] = {
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Prairie Wolf Paw: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 4,
				["text"] = "Plainstrider Talon: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[764] = {
			{
				["type"] = "monster",
				["numRequired"] = 14,
				["text"] = "Venture Co. Worker slain: 13/14",
				["finished"] = false,
				["numFulfilled"] = 13,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 6,
				["text"] = "Venture Co. Supervisor slain: 3/6",
				["finished"] = false,
				["numFulfilled"] = 3,
			}, -- [2]
		},
		[780] = {
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Battleboar Snout: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Battleboar Flank: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[765] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Fizsprocket's Clipboard: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[750] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Mountain Cougar Pelt: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[766] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Prairie Wolf Heart: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Flatland Cougar Femur: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Plainstrider Scale: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Swoop Gizzard: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [4]
		},
		[6002] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Face Lunaclaw and earn the strength of body and heart it possesses.",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[5930] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Seek out the Great Bear Spirit and learn what it has to share with you about the nature of the bear.",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[3376] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Chief Sharptusk Thornmantle's Head: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[861] = {
			{
				["type"] = "item",
				["numRequired"] = 4,
				["text"] = "Flatland Prowler Claw: 4/4",
				["finished"] = true,
				["numFulfilled"] = 4,
			}, -- [1]
		},
		[753] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Water Pitcher: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[77648] = {
			{
				["type"] = "spell",
				["numRequired"] = 1,
				["text"] = "Learn Spell: Engrave Chest - Fury of Stormrage",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[754] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Cleanse the Winterhoof Water Well",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[770] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["generated"] = true,
				["text"] = "Objective Complete",
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[848] = {
			{
				["type"] = "item",
				["numRequired"] = 4,
				["text"] = "Fungal Spores: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[776] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Horn of Arra'chea: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
	},
	["currentGuideGroup"] = "RestedXP Speedrun Guide (H)",
	["flightPaths"] = {
		[25] = "Crossroads, The Barrens",
		[77] = "Camp Taurajo, The Barrens",
		[22] = "Thunder Bluff, Mulgore",
	},
	["questNameCache"] = {
		[761] = "Swoop Hunting",
		[5723] = "Testing an Enemy's Strength",
		[77648] = "Relics of the Tauren",
		[771] = "Rite of Vision",
		[1656] = "A Task Unfinished",
		[775] = "Journey into Thunder Bluff",
		[781] = "Attack on Camp Narache",
		[848] = "Fungal Spores",
		[3376] = "Break Sharptusk!",
		[744] = "Preparation for Ceremony",
		[746] = "Dwarven Digging",
		[748] = "Poison Water",
		[750] = "The Hunt Continues",
		[752] = "A Humble Task",
		[754] = "Winterhoof Cleansing",
		[756] = "Thunderhorn Totem",
		[3094] = "Verdant Note",
		[760] = "Wildmane Cleansing",
		[764] = "The Venture Co.",
		[766] = "Mazzranache",
		[833] = "A Sacred Burial",
		[6361] = "A Bundle of Hides",
		[765] = "Supervisor Fizsprocket",
		[776] = "Rites of the Earthmother",
		[6363] = "Tal the Wind Rider Master",
		[780] = "The Battleboars",
		[755] = "Rites of the Earthmother",
		[5928] = "Heeding the Call",
		[877] = "The Stagnant Oasis",
		[6364] = "Return to Jahan",
		[6002] = "Body and Heart",
		[886] = "The Barrens Oases",
		[853] = "Apothecary Zamah",
		[758] = "Thunderhorn Cleansing",
		[861] = "The Hunter's Way",
		[770] = "The Demon Scarred Cloak",
		[870] = "The Forgotten Pools",
		[5930] = "Great Bear Spirit",
		[743] = "Dangers of the Windfury",
		[745] = "Sharing the Land",
		[747] = "The Hunt Begins",
		[749] = "The Ravaged Caravan",
		[751] = "The Ravaged Caravan",
		[753] = "A Humble Task",
		[5722] = "Searching for the Lost Satchel",
		[757] = "Rite of Strength",
		[759] = "Wildmane Totem",
		[860] = "Sergra Darkthorn",
	},
	["currentGuideName"] = "06-12 Mulgore",
	["stepSkip"] = {
		[106] = true,
		[38] = true,
		[3] = true,
		[54] = true,
		[150] = true,
		[92] = true,
		[39] = true,
		[12] = true,
		[109] = true,
		[16] = true,
		[94] = true,
		[32] = true,
		[79] = true,
		[95] = true,
		[56] = true,
		[81] = true,
		[129] = true,
		[130] = true,
		[25] = true,
		[29] = true,
		[67] = true,
		[115] = true,
		[100] = true,
		[9] = true,
		[11] = true,
		[51] = true,
		[49] = true,
		[138] = true,
		[131] = true,
		[97] = true,
		[30] = true,
		[140] = true,
		[44] = true,
		[52] = true,
		[119] = true,
		[72] = true,
		[34] = true,
		[53] = true,
		[89] = true,
		[60] = true,
		[45] = true,
		[145] = true,
		[121] = true,
		[19] = true,
		[114] = true,
		[149] = true,
	},
	["currentStepId"] = 3097039300,
}
RXPCTrackingData = {
	["profileKeys"] = {
		["Squishcow - Shadowstrike (AU)"] = "Squishcow - Shadowstrike (AU)",
	},
	["profiles"] = {
		["Squishcow - Shadowstrike (AU)"] = {
			["levels"] = {
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 18,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 1,
							["year"] = 2024,
							["hour"] = 17,
							["minute"] = 43,
						},
						["started"] = 0,
					},
					["quests"] = {
					},
				}, -- [1]
				[14] = {
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Mulgore"] = {
							["xp"] = 558,
							["count"] = 4,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 19,
							["minute"] = 43,
						},
						["started"] = 26031,
					},
					["quests"] = {
						["Thunder Bluff"] = {
							[776] = 1875,
							[861] = 1275,
						},
					},
				},
				[13] = {
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Mulgore"] = {
							["xp"] = 618,
							["count"] = 3,
						},
					},
					["timestamp"] = {
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 19,
							["minute"] = 43,
						},
						["finished"] = 26030,
					},
					["quests"] = {
						["Thunder Bluff"] = {
							[744] = 1312,
						},
						["Mulgore"] = {
							[760] = 1575,
							[770] = 1350,
						},
					},
				},
				[18] = {
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
					},
					["timestamp"] = {
					},
					["quests"] = {
					},
				},
			},
			["trackedGuid"] = "Player-5818-00A9759E",
		},
	},
}
RXPCComms = {
	["profileKeys"] = {
		["Squishcow - Shadowstrike (AU)"] = "Squishcow - Shadowstrike (AU)",
	},
	["profiles"] = {
		["Squishcow - Shadowstrike (AU)"] = {
			["announcements"] = {
				["06-12 Mulgore"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
			},
		},
	},
}
RXPCSettings = nil

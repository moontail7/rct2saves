
TrinketMenuPerOptions = {
	["Visible"] = "ON",
	["MainScale"] = 1,
	["XPos"] = 700.444580078125,
	["Alpha"] = 1,
	["MainOrient"] = "HORIZONTAL",
	["FirstUse"] = true,
	["ItemsUsed"] = {
		["211450"] = 0,
		["18850"] = 0,
	},
	["Hidden"] = {
	},
	["MenuScale"] = 1,
	["MainDock"] = "BOTTOMRIGHT",
	["YPos"] = 193.7780914306641,
	["MenuDock"] = "BOTTOMLEFT",
	["MenuOrient"] = "VERTICAL",
}
TrinketMenuQueue = {
	["Enabled"] = {
	},
	["Stats"] = {
	},
	["Sort"] = {
		{
			0, -- [1]
			"18850", -- [2]
			"211450", -- [3]
		}, -- [1]
		[0] = {
			0, -- [1]
			"18850", -- [2]
			"211450", -- [3]
		},
	},
	["Profiles"] = {
	},
}

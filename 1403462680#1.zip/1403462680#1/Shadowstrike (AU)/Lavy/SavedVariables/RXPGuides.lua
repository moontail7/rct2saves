
RXPCData = {
	["completedWaypoints"] = {
		[25] = {
		},
		["tip"] = {
		},
	},
	["currentStep"] = 25,
	["questObjectivesCache"] = {
		[6282] = {
			{
				["type"] = "monster",
				["numRequired"] = 7,
				["text"] = "Bloodfury Harpy slain: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 7,
				["text"] = "Bloodfury Ambusher slain: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 7,
				["text"] = "Bloodfury Slayer slain: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
			{
				["type"] = "monster",
				["numRequired"] = 7,
				["text"] = "Bloodfury Roguefeather slain: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [4]
		},
		[6981] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Speak with someone in Ratchet about the Glowing Shard",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6283] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Bloodfury Ripper's Remains: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6284] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Besseleth's Fang: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[528] = {
			{
				["type"] = "monster",
				["numRequired"] = 15,
				["text"] = "Hillsbrad Peasant slain: 0/15",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[1096] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Gerenzo's Mechanical Arm: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6544] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Take Silverwing Outpost.",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[846] = {
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Nitroglycerin: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Wood Pulp: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Sodium Nitrate: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[6482] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Escort Ruul from the Thistlefurs.",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[878] = {
			{
				["type"] = "monster",
				["numRequired"] = 6,
				["text"] = "Bristleback Water Seeker slain: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 12,
				["text"] = "Bristleback Thornweaver slain: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 12,
				["text"] = "Bristleback Geomancer slain: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[1013] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "The Book of Ur: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6548] = {
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Grimtotem Ruffian slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 6,
				["text"] = "Grimtotem Mercenary slain: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[529] = {
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Blacksmith Verringtan slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 4,
				["text"] = "Hillsbrad Apprentice Blacksmith slain: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Shipment of Iron: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[4021] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Piece of Krom'zar's Banner: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[3261] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["generated"] = true,
				["text"] = "Objective Complete",
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[501] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Mountain Lion Blood: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[879] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Kuz's Skull: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Nak's Skull: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Lok's Skull: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[1014] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Head of Arugal: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[1068] = {
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "XT:4 slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "XT:9 slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[546] = {
			{
				["type"] = "item",
				["numRequired"] = 30,
				["text"] = "Hillsbrad Human Skull: 0/30",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[1513] = {
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Summoned Succubus slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[959] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "99-Year-Old Port: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[1069] = {
			{
				["type"] = "item",
				["numRequired"] = 15,
				["text"] = "Deepmoss Egg: 0/15",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[880] = {
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Altered Snapjaw Shell: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6629] = {
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Grundig Darkcloud slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 6,
				["text"] = "Grimtotem Brute slain: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[1086] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Place the Toxic Fogger",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6503] = {
			{
				["type"] = "monster",
				["numRequired"] = 9,
				["text"] = "Ashenvale Outrunner slain: 0/9",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6504] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Shredder Operating Manual - Chapter 1: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Shredder Operating Manual - Chapter 2: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Shredder Operating Manual - Chapter 3: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[6441] = {
			{
				["type"] = "item",
				["numRequired"] = 16,
				["text"] = "Satyr Horns: 0/16",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[849] = {
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Bael Modan Flying Machine destroyed: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[857] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Tear of the Moons: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[1087] = {
			{
				["type"] = "monster",
				["numRequired"] = 4,
				["text"] = "Son of Cenarius slain: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 4,
				["text"] = "Daughter of Cenarius slain: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 4,
				["text"] = "Cenarion Botanist slain: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[873] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Heart of Isha Awak: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6381] = {
			{
				["type"] = "object",
				["numRequired"] = 10,
				["text"] = "Gaea seed planted: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6382] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["generated"] = true,
				["text"] = "Objective Complete",
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[913] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Thunderhawk Wings: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[1088] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Ordanus' Head: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6641] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Defeat Vorsha the Lasher",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[1486] = {
			{
				["type"] = "item",
				["numRequired"] = 20,
				["text"] = "Deviate Hide: 0/20",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[882] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Ishamuhale's Fang: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[914] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Gem of Cobrahn: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Gem of Anacondra: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Gem of Pythas: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Gem of Serpentis: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [4]
		},
		[1090] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Keep Piznik safe while he mines the mysterious ore",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[1487] = {
			{
				["type"] = "monster",
				["numRequired"] = 7,
				["text"] = "Deviate Ravager slain: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 7,
				["text"] = "Deviate Viper slain: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 7,
				["text"] = "Deviate Shambler slain: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
			{
				["type"] = "monster",
				["numRequired"] = 7,
				["text"] = "Deviate Dreadfang slain: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [4]
		},
		[6393] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Incendrites: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[962] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Serpentbloom: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[843] = {
			{
				["type"] = "monster",
				["numRequired"] = 15,
				["text"] = "Bael'dun Excavator slain: 0/15",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 5,
				["text"] = "Bael'dun Foreman slain: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Khazgorm's Journal: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[65601] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["generated"] = true,
				["text"] = "Objective Complete",
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6523] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Kaya Escorted to Camp Aparaje",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[899] = {
			{
				["type"] = "item",
				["numRequired"] = 60,
				["text"] = "Bristleback Quilboar Tusk: 0/60",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6461] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Deepmoss Creeper slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 7,
				["text"] = "Deepmoss Venomspitter slain: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[25] = {
			{
				["type"] = "monster",
				["numRequired"] = 12,
				["text"] = "Befouled Water Elemental slain: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Scout the gazebo on Mystral Lake that overlooks the nearby Alliance outpost.",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[6462] = {
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Troll Charm: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[821] = {
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Savannah Lion Tusk: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Plainstrider Kidney: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Thunder Lizard Horn: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[0] = 72,
		[1489] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["generated"] = true,
				["text"] = "Objective Complete",
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[1066] = {
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Vial of Innocent Blood: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6442] = {
			{
				["type"] = "item",
				["numRequired"] = 20,
				["text"] = "Wrathtail Head: 0/20",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[549] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Syndicate Rogue slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Syndicate Watchman slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[907] = {
			{
				["type"] = "item",
				["numRequired"] = 3,
				["text"] = "Thunder Lizard Blood: 0/3",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[496] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Gray Bear Tongue: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Creeper Ichor: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[1507] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["generated"] = true,
				["text"] = "Objective Complete",
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[868] = {
			{
				["type"] = "item",
				["numRequired"] = 12,
				["text"] = "Silithid Egg: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[876] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Serena's Head: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[216] = {
			{
				["type"] = "monster",
				["numRequired"] = 12,
				["text"] = "Thistlefur Avenger slain: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 12,
				["text"] = "Thistlefur Shaman slain: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[1093] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Super Reaper 6000 Blueprints: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6301] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Gaea Seed: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[527] = {
			{
				["type"] = "monster",
				["numRequired"] = 6,
				["text"] = "Hillsbrad Farmer slain: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 6,
				["text"] = "Hillsbrad Farmhand slain: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Farmer Ray slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Farmer Getz slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [4]
		},
		[1062] = {
			{
				["type"] = "monster",
				["numRequired"] = 15,
				["text"] = "Venture Co. Logger slain: 0/15",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[1058] = {
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Stonetalon Sap: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Twilight Whisker: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 30,
				["text"] = "Courser Eye: 0/30",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Fey Dragon Scale: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [4]
		},
		[498] = {
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Rescue Drull: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Rescue Tog'thar: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[1491] = {
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Wailing Essence: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[567] = {
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Clerk Horrace Whitesteed slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Citizen Wilkes slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Miner Hackett slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Farmer Kalaba slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [4]
		},
		[1195] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Filled Etched Phial: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
	},
	["currentGuideGroup"] = "RestedXP Speedrun Guide (H)",
	["flightPaths"] = {
		[61] = "Splintertree Post, Ashenvale",
		[77] = "Camp Taurajo, The Barrens",
		[29] = "Sun Rock Retreat, Stonetalon Mountains",
		[58] = "Zoram'gar Outpost, Ashenvale",
		[13] = "Tarren Mill, Hillsbrad",
		[10] = "The Sepulcher, Silverpine Forest",
		[80] = "Ratchet, The Barrens",
		[11] = "Undercity, Tirisfal",
		[22] = "Thunder Bluff, Mulgore",
		[23] = "Orgrimmar, Durotar",
		[25] = "Crossroads, The Barrens",
	},
	["questNameCache"] = {
		[6282] = "Harpies Threaten",
		[6981] = "The Glowing Shard",
		[6283] = "Bloodfury Bloodline",
		[1063] = "The Elder Crone",
		[6284] = "Arachnophobia",
		[1095] = "Further Instructions",
		[1508] = "Blind Cazul",
		[528] = "Battle of Hillsbrad",
		[1064] = "Forsaken Aid",
		[1096] = "Gerenzo Wrenchwhistle",
		[1509] = "News of Dogran",
		[6544] = "Torek's Assault",
		[846] = "Revenge of Gann",
		[1065] = "Journey to Tarren Mill",
		[878] = "Tribes at War",
		[1510] = "News of Dogran",
		[6548] = "Avenge My Village",
		[529] = "Battle of Hillsbrad",
		[4021] = "Counterattack!",
		[1098] = "Deathstalkers in Shadowfang",
		[1511] = "Ken'zigla's Draught",
		[855] = "Centaur Bracers",
		[501] = "Elixir of Pain",
		[879] = "Betrayal from Within",
		[1512] = "Love's Gift",
		[2] = "Sharptalon's Claw",
		[1507] = "Devourer of Souls",
		[742] = "The Ashenvale Hunt",
		[1068] = "Shredding Machines",
		[546] = "Souvenirs of Death",
		[235] = "The Ashenvale Hunt",
		[865] = "Raptor Horns",
		[1513] = "The Binding",
		[959] = "Trouble at the Docks",
		[821] = "Chen's Empty Keg",
		[6301] = "Cycle of Rebirth",
		[216] = "Between a Rock and a Thistlefur",
		[6562] = "Trouble in the Deeps",
		[6504] = "The Lost Pages",
		[880] = "Altered Beings",
		[888] = "Stolen Booty",
		[1195] = "The Sacred Flame",
		[493] = "Journey to Hillsbrad Foothills",
		[1490] = "Nara Wildmane",
		[6629] = "Kill Grundig Darkcloud",
		[1086] = "The Flying Machine Airport",
		[1483] = "Ziz Fizziks",
		[868] = "Egg Hunt",
		[1515] = "Dogran's Captivity",
		[6441] = "Satyr Horns",
		[857] = "The Tear of the Moons",
		[6442] = "Naga at the Zoram Strand",
		[494] = "Time To Strike",
		[498] = "The Rescue",
		[502] = "Elixir of Pain",
		[3261] = "Jorn Skyseer",
		[6381] = "New Life",
		[897] = "The Harvester",
		[264] = "Until Death Do Us Part",
		[913] = "Cry of the Thunderhawk",
		[6383] = "The Ashenvale Hunt",
		[1088] = "Ordanus",
		[3301] = "Mura Runetotem",
		[873] = "Isha Awak",
		[1067] = "Return to Thunder Bluff",
		[5052] = "Blood Shards of Agamaggan",
		[1069] = "Deepmoss Spider Eggs",
		[874] = "Mahren Skyseer",
		[6641] = "Vorsha the Lasher",
		[6324] = "Return to Podrig",
		[1486] = "Deviate Hides",
		[3369] = "In Nightmares",
		[914] = "Leaders of the Fang",
		[1090] = "Gerenzo's Orders",
		[1060] = "Letter to Jin'Zil",
		[1058] = "Jin'Zil's Forest Magic",
		[25] = "Stonetalon Standstill",
		[549] = "WANTED: Syndicate Personnel",
		[1487] = "Deviate Eradication",
		[899] = "Consumed by Hatred",
		[6393] = "Elemental War",
		[962] = "Serpentbloom",
		[23] = "Ursangous's Paw",
		[1066] = "Blood of Innocents",
		[875] = "Harpy Lieutenants",
		[499] = "Elixir of Suffering",
		[6523] = "Protect Kaya",
		[883] = "Lakota'mani",
		[496] = "Elixir of Suffering",
		[6461] = "Blood Feeders",
		[907] = "Enraged Thunder Lizards",
		[6462] = "Troll Charm",
		[843] = "Gann's Reclamation",
		[1014] = "Arugal Must Die",
		[1489] = "Hamuul Runetotem",
		[882] = "Ishamuhale",
		[1013] = "The Book of Ur",
		[1918] = "The Befouled Element",
		[1087] = "Cenarius' Legacy",
		[852] = "Hezrul Bloodmark",
		[6382] = "The Ashenvale Hunt",
		[1093] = "Super Reaper 6000",
		[876] = "Serena Bloodfeather",
		[884] = "Owatanka",
		[849] = "Revenge of Gann",
		[6503] = "Ashenvale Outrunners",
		[527] = "Battle of Hillsbrad",
		[1062] = "Goblin Invaders",
		[6482] = "Freedom to Ruul",
		[1094] = "Further Instructions",
		[1491] = "Smart Drinks",
		[567] = "Dangerous!",
		[885] = "Washte Pawne",
	},
	["currentGuideName"] = "26-28 Ashenvale",
	["stepSkip"] = {
		[17] = true,
		[15] = true,
		[10] = true,
		[8] = true,
		[23] = true,
		[16] = true,
	},
	["currentStepId"] = 3799321854,
}
RXPCTrackingData = {
	["profileKeys"] = {
		["Falseclaimin - Shadowstrike (AU)"] = "Falseclaimin - Shadowstrike (AU)",
		["Lavy - Shadowstrike (AU)"] = "Lavy - Shadowstrike (AU)",
	},
	["profiles"] = {
		["Falseclaimin - Shadowstrike (AU)"] = {
			["levels"] = {
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 408,
							["count"] = 6,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 1,
							["day"] = 0,
							["month"] = 12,
							["minute"] = 26,
							["year"] = 2023,
							["hour"] = 8,
							["weekday"] = 6,
						},
						["finished"] = 1379,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 5,
							["year"] = 2024,
							["hour"] = 0,
							["weekday"] = 3,
						},
						["started"] = 0,
					},
					["quests"] = {
						["Durotar"] = {
							[4641] = 40,
						},
					},
				}, -- [1]
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 676,
							["count"] = 14,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 5,
							["year"] = 2024,
							["hour"] = 0,
							["weekday"] = 3,
						},
						["finished"] = 2039,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 16,
							["year"] = 2024,
							["hour"] = 0,
							["weekday"] = 3,
						},
						["started"] = 1380,
					},
					["quests"] = {
						["Durotar"] = {
							[790] = 450,
						},
					},
				}, -- [2]
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 846,
							["count"] = 14,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 16,
							["year"] = 2024,
							["hour"] = 0,
							["weekday"] = 3,
						},
						["finished"] = 2647,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 26,
							["year"] = 2024,
							["hour"] = 0,
							["weekday"] = 3,
						},
						["started"] = 2040,
					},
					["quests"] = {
						["Durotar"] = {
							[788] = 170,
							[804] = 110,
							[3086] = 40,
						},
					},
				}, -- [3]
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 871,
							["count"] = 16,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 26,
							["year"] = 2024,
							["hour"] = 0,
							["weekday"] = 3,
						},
						["finished"] = 3127,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 34,
							["year"] = 2024,
							["hour"] = 0,
							["weekday"] = 3,
						},
						["started"] = 2648,
					},
					["quests"] = {
						["Durotar"] = {
							[4402] = 380,
							[789] = 250,
							[792] = 450,
						},
					},
				}, -- [4]
				{
					["groupExperience"] = 450,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 1302,
							["count"] = 27,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 34,
							["year"] = 2024,
							["hour"] = 0,
							["weekday"] = 3,
						},
						["finished"] = 4626,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 0,
							["year"] = 2024,
							["hour"] = 1,
							["weekday"] = 3,
						},
						["started"] = 3128,
					},
					["quests"] = {
						["Durotar"] = {
							[5441] = 450,
							[6394] = 450,
						},
					},
				}, -- [5]
				{
					["groupExperience"] = 4091,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 2401,
							["count"] = 33,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 0,
							["year"] = 2024,
							["hour"] = 1,
							["weekday"] = 3,
						},
						["finished"] = 6134,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 25,
							["year"] = 2024,
							["hour"] = 1,
							["weekday"] = 3,
						},
						["started"] = 4627,
					},
					["quests"] = {
						["Durotar"] = {
							[77643] = 85,
							[805] = 230,
							[786] = 700,
							[794] = 675,
						},
					},
				}, -- [6]
				{
					["groupExperience"] = 4517,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 2212,
							["count"] = 35,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 25,
							["year"] = 2024,
							["hour"] = 1,
							["weekday"] = 3,
						},
						["finished"] = 7361,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 45,
							["year"] = 2024,
							["hour"] = 1,
							["weekday"] = 3,
						},
						["started"] = 6135,
					},
					["quests"] = {
						["Durotar"] = {
							[2161] = 110,
							[784] = 625,
							[823] = 320,
							[830] = 625,
							[791] = 625,
						},
					},
				}, -- [7]
				{
					["groupExperience"] = 2850,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 3949,
							["count"] = 56,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 45,
							["year"] = 2024,
							["hour"] = 1,
							["weekday"] = 3,
						},
						["finished"] = 9570,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 3,
							["year"] = 2024,
							["hour"] = 2,
							["minute"] = 25,
						},
						["started"] = 7362,
					},
					["quests"] = {
						["Durotar"] = {
							[825] = 700,
							[815] = 700,
						},
					},
				}, -- [8]
				{
					["groupExperience"] = 0,
					["deaths"] = 1,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 3474,
							["count"] = 46,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 3,
							["year"] = 2024,
							["hour"] = 2,
							["minute"] = 25,
						},
						["finished"] = 11645,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 36,
							["year"] = 2024,
							["hour"] = 11,
							["weekday"] = 3,
						},
						["started"] = 9571,
					},
					["quests"] = {
						["Durotar"] = {
							[818] = 625,
							[826] = 850,
							[808] = 775,
							[817] = 700,
						},
					},
				}, -- [9]
				{
					["groupExperience"] = 5576,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 4085,
							["count"] = 56,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 36,
							["year"] = 2024,
							["hour"] = 11,
							["weekday"] = 3,
						},
						["finished"] = 14957,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 31,
							["year"] = 2024,
							["hour"] = 12,
							["weekday"] = 3,
						},
						["started"] = 11646,
					},
					["quests"] = {
						["Durotar"] = {
							[828] = 90,
							[837] = 625,
							[834] = 775,
							[827] = 900,
							[806] = 900,
						},
					},
				}, -- [10]
				{
					["groupExperience"] = 674,
					["deaths"] = 1,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 1668,
							["count"] = 22,
						},
						["Tirisfal Glades"] = {
							["xp"] = 2731,
							["count"] = 66,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 31,
							["year"] = 2024,
							["hour"] = 12,
							["weekday"] = 3,
						},
						["finished"] = 19874,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 53,
							["year"] = 2024,
							["hour"] = 13,
							["weekday"] = 3,
						},
						["started"] = 14958,
					},
					["quests"] = {
						["Durotar"] = {
							[835] = 875,
						},
						["Tirisfal Glades"] = {
							[404] = 410,
							[367] = 550,
							[427] = 700,
						},
						["Undercity"] = {
							[1881] = 85,
						},
						["Orgrimmar"] = {
							[829] = 460,
							[831] = 625,
							[78611] = 70,
						},
					},
				}, -- [11]
				{
					["groupExperience"] = 0,
					["deaths"] = 1,
					["mobs"] = {
						["Tirisfal Glades"] = {
							["xp"] = 4015,
							["count"] = 74,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 53,
							["year"] = 2024,
							["hour"] = 13,
							["weekday"] = 3,
						},
						["finished"] = 22892,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 3,
							["year"] = 2024,
							["hour"] = 14,
							["minute"] = 47,
						},
						["started"] = 19875,
					},
					["quests"] = {
						["Tirisfal Glades"] = {
							[426] = 875,
							[398] = 850,
							[354] = 875,
							[370] = 775,
							[358] = 700,
							[359] = 200,
							[361] = 480,
							[362] = 420,
							[368] = 775,
							[355] = 85,
						},
					},
				}, -- [12]
				{
					["groupExperience"] = 1828,
					["deaths"] = 0,
					["mobs"] = {
						["Ragefire Chasm"] = {
							["xp"] = 468,
							["count"] = 6,
						},
						["Tirisfal Glades"] = {
							["xp"] = 1898,
							["count"] = 31,
						},
						["Silverpine Forest"] = {
							["xp"] = 1117,
							["count"] = 10,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 3,
							["year"] = 2024,
							["hour"] = 14,
							["minute"] = 47,
						},
						["finished"] = 26589,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 52,
							["year"] = 2024,
							["hour"] = 15,
							["weekday"] = 3,
						},
						["started"] = 22893,
					},
					["quests"] = {
						["Orgrimmar"] = {
							[5726] = 900,
							[5727] = 460,
						},
						["Undercity"] = {
							[1882] = 850,
							[78611] = 70,
							[405] = 180,
						},
						["Tirisfal Glades"] = {
							[360] = 390,
							[375] = 700,
							[369] = 220,
							[356] = 650,
							[371] = 850,
							[492] = 875,
							[374] = 500,
						},
						["Silverpine Forest"] = {
							[445] = 625,
						},
					},
				}, -- [13]
				{
					["groupExperience"] = 12647,
					["deaths"] = 0,
					["mobs"] = {
						["Ragefire Chasm"] = {
							["xp"] = 7848,
							["count"] = 102,
						},
						["Durotar"] = {
							["xp"] = 64,
							["count"] = 1,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 52,
							["year"] = 2024,
							["hour"] = 15,
							["weekday"] = 3,
						},
						["finished"] = 30310,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 54,
							["year"] = 2024,
							["hour"] = 16,
							["weekday"] = 3,
						},
						["started"] = 26590,
					},
					["quests"] = {
						["Ragefire Chasm"] = {
							[5722] = 875,
						},
						["Orgrimmar"] = {
							[5728] = 1150,
							[5729] = 110,
							[5730] = 1450,
							[5761] = 1150,
						},
					},
				}, -- [14]
				{
					["groupExperience"] = 8701,
					["deaths"] = 1,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 7466,
							["count"] = 104,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 54,
							["year"] = 2024,
							["hour"] = 16,
							["weekday"] = 3,
						},
						["finished"] = 34802,
						["dateFinished"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 3,
							["year"] = 2024,
							["hour"] = 23,
							["minute"] = 51,
						},
						["started"] = 30311,
					},
					["quests"] = {
						["The Barrens"] = {
							[809] = 460,
							[871] = 900,
							[819] = 1050,
							[1492] = 440,
							[840] = 460,
							[842] = 900,
							[844] = 900,
							[924] = 1250,
							[6365] = 210,
						},
					},
				}, -- [15]
				{
					["groupExperience"] = 0,
					["deaths"] = 2,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 9887,
							["count"] = 107,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 23,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 3,
							["year"] = 2024,
							["hour"] = 23,
							["minute"] = 51,
						},
						["finished"] = 40963,
						["dateFinished"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 42,
							["year"] = 2024,
							["hour"] = 1,
							["weekday"] = 4,
						},
						["started"] = 34803,
					},
					["quests"] = {
						["The Barrens"] = {
							[887] = 750,
							[5041] = 975,
							[892] = 100,
							[872] = 1050,
							[895] = 1150,
							[890] = 100,
							[850] = 875,
							[845] = 900,
						},
					},
				}, -- [16]
				{
					["groupExperience"] = 1040,
					["deaths"] = 0,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 7269,
							["count"] = 73,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 42,
							["year"] = 2024,
							["hour"] = 1,
							["weekday"] = 4,
						},
						["finished"] = 44993,
						["dateFinished"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 4,
							["year"] = 2024,
							["hour"] = 18,
							["minute"] = 4,
						},
						["started"] = 40964,
					},
					["quests"] = {
						["The Barrens"] = {
							[848] = 1050,
							[867] = 1050,
							[869] = 900,
							[901] = 750,
							[903] = 1050,
							[894] = 750,
							[1061] = 320,
							[870] = 675,
							[900] = 490,
						},
						["Thunder Bluff"] = {
							[5723] = 1050,
							[5724] = 1450,
						},
					},
				}, -- [17]
				{
					["groupExperience"] = 123,
					["deaths"] = 0,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 7138,
							["count"] = 73,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 4,
							["year"] = 2024,
							["hour"] = 18,
							["minute"] = 4,
						},
						["finished"] = 51368,
						["dateFinished"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 4,
							["year"] = 2024,
							["hour"] = 20,
							["minute"] = 7,
						},
						["started"] = 44994,
					},
					["quests"] = {
						["The Barrens"] = {
							[4921] = 1150,
							[852] = 1100,
							[3281] = 1350,
							[905] = 1250,
							[877] = 1150,
							[881] = 1450,
							[883] = 1300,
							[902] = 1150,
							[896] = 1700,
							[851] = 1000,
						},
					},
				}, -- [18]
				{
					["groupExperience"] = 1870,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 420,
							["count"] = 6,
						},
						["The Barrens"] = {
							["xp"] = 1207,
							["count"] = 11,
						},
						["Ashenvale"] = {
							["xp"] = 6730,
							["count"] = 23,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 4,
							["year"] = 2024,
							["hour"] = 20,
							["minute"] = 7,
						},
						["finished"] = 63609,
						["dateFinished"] = {
							["monthDay"] = 27,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 18,
							["minute"] = 34,
						},
						["started"] = 51369,
					},
					["quests"] = {
						["Thunder Bluff"] = {
							[1489] = 290,
							[1490] = 120,
							[853] = 800,
						},
						["Undercity"] = {
							[5725] = 1450,
						},
						["The Barrens"] = {
							[880] = 1150,
							[3261] = 140,
							[821] = 1350,
							[865] = 1350,
							[888] = 1150,
							[855] = 1250,
							[3921] = 490,
						},
					},
				}, -- [19]
				{
					["groupExperience"] = 21631,
					["deaths"] = 1,
					["mobs"] = {
						["The Wailing Caverns"] = {
							["xp"] = 16556,
							["count"] = 296,
						},
						["Stonetalon Mountains"] = {
							["xp"] = 1449,
							["count"] = 19,
						},
						["The Barrens"] = {
							["xp"] = 1018,
							["count"] = 7,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 27,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 18,
							["minute"] = 34,
						},
						["finished"] = 73556,
						["dateFinished"] = {
							["monthDay"] = 27,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 23,
							["minute"] = 26,
						},
						["started"] = 63610,
					},
					["quests"] = {
						["Silverpine Forest"] = {
							[3301] = 1050,
							[264] = 550,
						},
						["The Barrens"] = {
							[1491] = 1350,
							[6386] = 110,
							[6548] = 1350,
						},
						["Orgrimmar"] = {
							[6385] = 20,
							[832] = 270,
							[6384] = 40,
						},
					},
				}, -- [20]
				{
					["groupExperience"] = 24412,
					["deaths"] = 0,
					["mobs"] = {
						["The Wailing Caverns"] = {
							["xp"] = 12562,
							["count"] = 191,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 27,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 23,
							["minute"] = 26,
						},
						["finished"] = 78253,
						["dateFinished"] = {
							["monthDay"] = 28,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 1,
							["year"] = 2024,
							["hour"] = 0,
							["minute"] = 44,
						},
						["started"] = 73557,
					},
					["quests"] = {
						["The Wailing Caverns"] = {
							[1487] = 2050,
							[1486] = 1600,
						},
						["The Barrens"] = {
							[6981] = 2650,
							[959] = 1350,
						},
						["Thunder Bluff"] = {
							[914] = 2200,
							[3369] = 2000,
						},
					},
				}, -- [21]
				{
					["groupExperience"] = 27065,
					["deaths"] = 0,
					["mobs"] = {
						["Shadowfang Keep"] = {
							["xp"] = 23365,
							["count"] = 235,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 28,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 1,
							["year"] = 2024,
							["hour"] = 0,
							["minute"] = 44,
						},
						["finished"] = 85023,
						["dateFinished"] = {
							["monthDay"] = 28,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 1,
							["year"] = 2024,
							["hour"] = 20,
							["minute"] = 15,
						},
						["started"] = 78254,
					},
					["quests"] = {
						["Thunder Bluff"] = {
							[962] = 1700,
						},
						["Shadowfang Keep"] = {
							[1098] = 2000,
						},
					},
				}, -- [22]
				{
					["groupExperience"] = 23212,
					["deaths"] = 2,
					["mobs"] = {
						["Shadowfang Keep"] = {
							["xp"] = 21719,
							["count"] = 239,
						},
						["Hillsbrad Foothills"] = {
							["xp"] = 1270,
							["count"] = 11,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 28,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 1,
							["year"] = 2024,
							["hour"] = 20,
							["minute"] = 15,
						},
						["finished"] = 94712,
						["dateFinished"] = {
							["monthDay"] = 29,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 2,
							["year"] = 2024,
							["hour"] = 11,
							["minute"] = 29,
						},
						["started"] = 85024,
					},
					["quests"] = {
						["Undercity"] = {
							[1013] = 2100,
						},
						["Hillsbrad Foothills"] = {
							[494] = 775,
						},
						["Silverpine Forest"] = {
							[1014] = 3300,
						},
					},
				}, -- [23]
				{
					["groupExperience"] = 12,
					["deaths"] = 5,
					["mobs"] = {
						["Hillsbrad Foothills"] = {
							["xp"] = 4387,
							["count"] = 32,
						},
						["The Barrens"] = {
							["xp"] = 6423,
							["count"] = 63,
						},
						["Ashenvale"] = {
							["xp"] = 2253,
							["count"] = 24,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 29,
							["day"] = 0,
							["month"] = 1,
							["weekday"] = 2,
							["year"] = 2024,
							["hour"] = 11,
							["minute"] = 29,
						},
						["finished"] = 105993,
						["dateFinished"] = {
							["monthDay"] = 29,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 50,
							["year"] = 2024,
							["hour"] = 14,
							["weekday"] = 2,
						},
						["started"] = 94713,
					},
					["quests"] = {
						["Thunder Bluff"] = {
							[79100] = 20,
						},
						["The Barrens"] = {
							[5052] = 1250,
							[882] = 1800,
							[884] = 1450,
							[907] = 1350,
							[913] = 1950,
							[4021] = 1950,
							[878] = 1650,
							[899] = 1950,
						},
						["Hillsbrad Foothills"] = {
							[493] = 1150,
						},
						["Ashenvale"] = {
							[6641] = 2300,
							[6442] = 1450,
						},
					},
				}, -- [24]
				{
					["groupExperience"] = 986,
					["deaths"] = 21,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 986,
							["count"] = 9,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 29,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 50,
							["year"] = 2024,
							["hour"] = 14,
							["weekday"] = 2,
						},
						["started"] = 105994,
					},
					["quests"] = {
					},
				}, -- [25]
			},
			["trackedGuid"] = "Player-5818-009C3C1B",
		},
		["Lavy - Shadowstrike (AU)"] = {
			["levels"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Tirisfal Glades"] = {
							["xp"] = 994,
							["count"] = 13,
						},
					},
					["timestamp"] = {
						["dateFinished"] = {
							["monthDay"] = 16,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 15,
							["year"] = 2024,
							["hour"] = 23,
							["weekday"] = 6,
						},
						["finished"] = 6737,
						["started"] = 3,
					},
					["quests"] = {
						["Tirisfal Glades"] = {
							[3901] = 375,
						},
					},
				}, -- [4]
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Tirisfal Glades"] = {
							["xp"] = 903,
							["count"] = 13,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 16,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 15,
							["year"] = 2024,
							["hour"] = 23,
							["weekday"] = 6,
						},
						["finished"] = 7824,
						["dateFinished"] = {
							["monthDay"] = 16,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 34,
							["year"] = 2024,
							["hour"] = 23,
							["weekday"] = 6,
						},
						["started"] = 6738,
					},
					["quests"] = {
						["Tirisfal Glades"] = {
							[376] = 255,
							[77672] = 127,
							[3902] = 480,
						},
					},
				}, -- [5]
				{
					["groupExperience"] = 0,
					["deaths"] = 2,
					["mobs"] = {
						["Tirisfal Glades"] = {
							["xp"] = 1417,
							["count"] = 28,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 16,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 34,
							["year"] = 2024,
							["hour"] = 23,
							["weekday"] = 6,
						},
						["finished"] = 8898,
						["dateFinished"] = {
							["monthDay"] = 16,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 51,
							["year"] = 2024,
							["hour"] = 23,
							["weekday"] = 6,
						},
						["started"] = 7825,
					},
					["quests"] = {
						["Tirisfal Glades"] = {
							[380] = 540,
							[381] = 540,
							[6395] = 675,
						},
					},
				}, -- [6]
				{
					["groupExperience"] = 120,
					["deaths"] = 2,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 120,
							["count"] = 1,
						},
						["Tirisfal Glades"] = {
							["xp"] = 2382,
							["count"] = 25,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 16,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 51,
							["year"] = 2024,
							["hour"] = 23,
							["weekday"] = 6,
						},
						["finished"] = 12795,
						["dateFinished"] = {
							["monthDay"] = 17,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 12,
							["minute"] = 33,
						},
						["started"] = 8899,
					},
					["quests"] = {
						["Tirisfal Glades"] = {
							[382] = 1012,
							[8] = 165,
							[404] = 615,
							[5481] = 345,
							[383] = 510,
						},
					},
				}, -- [7]
				{
					["groupExperience"] = 5044,
					["deaths"] = 0,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 4195,
							["count"] = 92,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 17,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 12,
							["minute"] = 33,
						},
						["finished"] = 15538,
						["dateFinished"] = {
							["monthDay"] = 17,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 13,
							["minute"] = 18,
						},
						["started"] = 12796,
					},
					["quests"] = {
						["Durotar"] = {
							[786] = 1050,
						},
					},
				}, -- [8]
				{
					["groupExperience"] = 6360,
					["deaths"] = 1,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 2904,
							["count"] = 62,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 17,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 13,
							["minute"] = 18,
						},
						["finished"] = 18420,
						["dateFinished"] = {
							["monthDay"] = 17,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 33,
							["year"] = 2024,
							["hour"] = 15,
							["weekday"] = 7,
						},
						["started"] = 15539,
					},
					["quests"] = {
						["Durotar"] = {
							[2161] = 165,
							[784] = 937,
							[823] = 480,
							[830] = 937,
							[791] = 937,
						},
					},
				}, -- [9]
				{
					["groupExperience"] = 6859,
					["deaths"] = 2,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 1385,
							["count"] = 17,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 17,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 33,
							["year"] = 2024,
							["hour"] = 15,
							["weekday"] = 7,
						},
						["finished"] = 20968,
						["dateFinished"] = {
							["monthDay"] = 17,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 2,
							["year"] = 2024,
							["hour"] = 17,
							["weekday"] = 7,
						},
						["started"] = 18421,
					},
					["quests"] = {
						["Durotar"] = {
							[817] = 1050,
							[826] = 1275,
							[818] = 937,
							[808] = 1162,
							[825] = 1050,
						},
					},
				}, -- [10]
				{
					["groupExperience"] = 9178,
					["deaths"] = 3,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 4544,
							["count"] = 91,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 17,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 2,
							["year"] = 2024,
							["hour"] = 17,
							["weekday"] = 7,
						},
						["finished"] = 23560,
						["dateFinished"] = {
							["monthDay"] = 17,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 46,
							["year"] = 2024,
							["hour"] = 17,
							["weekday"] = 7,
						},
						["started"] = 20969,
					},
					["quests"] = {
						["Durotar"] = {
							[828] = 135,
							[837] = 937,
							[806] = 1350,
							[815] = 1050,
							[834] = 1162,
						},
					},
				}, -- [11]
				{
					["groupExperience"] = 10347,
					["deaths"] = 2,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 4678,
							["count"] = 88,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 17,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 46,
							["year"] = 2024,
							["hour"] = 17,
							["weekday"] = 7,
						},
						["finished"] = 28383,
						["dateFinished"] = {
							["monthDay"] = 17,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 5,
							["year"] = 2024,
							["hour"] = 22,
							["weekday"] = 7,
						},
						["started"] = 23561,
					},
					["quests"] = {
						["Durotar"] = {
							[827] = 1350,
							[835] = 1312,
						},
						["The Barrens"] = {
							[840] = 690,
							[809] = 690,
						},
						["Orgrimmar"] = {
							[829] = 690,
							[831] = 937,
						},
					},
				}, -- [12]
				{
					["groupExperience"] = 11104,
					["deaths"] = 6,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 7054,
							["count"] = 97,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 17,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 5,
							["year"] = 2024,
							["hour"] = 22,
							["weekday"] = 7,
						},
						["finished"] = 32409,
						["dateFinished"] = {
							["monthDay"] = 17,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 13,
							["year"] = 2024,
							["hour"] = 23,
							["weekday"] = 7,
						},
						["started"] = 28384,
					},
					["quests"] = {
						["The Barrens"] = {
							[842] = 1350,
							[844] = 1350,
							[871] = 1350,
						},
					},
				}, -- [13]
				{
					["groupExperience"] = 12390,
					["deaths"] = 0,
					["mobs"] = {
						["Ragefire Chasm"] = {
							["xp"] = 9243,
							["count"] = 94,
						},
						["Durotar"] = {
							["xp"] = 1107,
							["count"] = 26,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 17,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 13,
							["year"] = 2024,
							["hour"] = 23,
							["weekday"] = 7,
						},
						["finished"] = 36719,
						["dateFinished"] = {
							["monthDay"] = 18,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 24,
							["year"] = 2024,
							["hour"] = 0,
							["weekday"] = 1,
						},
						["started"] = 32410,
					},
					["quests"] = {
						["Orgrimmar"] = {
							[5726] = 1350,
							[5727] = 690,
						},
					},
				}, -- [14]
				{
					["groupExperience"] = 12657,
					["deaths"] = 6,
					["mobs"] = {
						["Ragefire Chasm"] = {
							["xp"] = 5469,
							["count"] = 54,
						},
						["The Barrens"] = {
							["xp"] = 3123,
							["count"] = 52,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 18,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 24,
							["year"] = 2024,
							["hour"] = 0,
							["weekday"] = 1,
						},
						["finished"] = 41448,
						["dateFinished"] = {
							["monthDay"] = 18,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 1,
							["year"] = 2024,
							["hour"] = 12,
							["minute"] = 39,
						},
						["started"] = 36720,
					},
					["quests"] = {
						["Orgrimmar"] = {
							[5728] = 1725,
							[5729] = 165,
							[5730] = 2175,
							[5761] = 1725,
						},
					},
				}, -- [15]
				{
					["groupExperience"] = 14973,
					["deaths"] = 0,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 5351,
							["count"] = 79,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 18,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 1,
							["year"] = 2024,
							["hour"] = 12,
							["minute"] = 39,
						},
						["finished"] = 46153,
						["dateFinished"] = {
							["monthDay"] = 18,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 1,
							["year"] = 2024,
							["hour"] = 15,
							["minute"] = 37,
						},
						["started"] = 41449,
					},
					["quests"] = {
						["The Barrens"] = {
							[1492] = 660,
							[924] = 1875,
							[872] = 1575,
							[819] = 1575,
							[5041] = 1462,
							[845] = 1350,
							[887] = 1125,
						},
					},
				}, -- [16]
				{
					["groupExperience"] = 18026,
					["deaths"] = 0,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 13016,
							["count"] = 198,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 18,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 1,
							["year"] = 2024,
							["hour"] = 15,
							["minute"] = 37,
						},
						["finished"] = 51275,
						["dateFinished"] = {
							["monthDay"] = 18,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 7,
							["year"] = 2024,
							["hour"] = 17,
							["weekday"] = 1,
						},
						["started"] = 46154,
					},
					["quests"] = {
						["The Barrens"] = {
							[894] = 1125,
							[900] = 735,
							[895] = 1725,
							[890] = 150,
							[892] = 150,
							[901] = 1125,
						},
					},
				}, -- [17]
				{
					["groupExperience"] = 19088,
					["deaths"] = 2,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 5551,
							["count"] = 51,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 18,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 7,
							["year"] = 2024,
							["hour"] = 17,
							["weekday"] = 1,
						},
						["finished"] = 55436,
						["dateFinished"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 1,
							["minute"] = 46,
						},
						["started"] = 51276,
					},
					["quests"] = {
						["The Barrens"] = {
							[867] = 1575,
							[903] = 1575,
							[870] = 1012,
							[869] = 1350,
							[881] = 2175,
							[848] = 1575,
							[902] = 1725,
							[896] = 2550,
						},
					},
				}, -- [18]
				{
					["groupExperience"] = 20366,
					["deaths"] = 2,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 5949,
							["count"] = 61,
						},
						["Stonetalon Mountains"] = {
							["xp"] = 1090,
							["count"] = 20,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 7,
							["year"] = 2024,
							["hour"] = 1,
							["minute"] = 46,
						},
						["finished"] = 59799,
						["dateFinished"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 14,
							["year"] = 2024,
							["hour"] = 17,
							["weekday"] = 7,
						},
						["started"] = 55437,
					},
					["quests"] = {
						["The Barrens"] = {
							[4921] = 1725,
							[850] = 1312,
							[3281] = 2025,
							[905] = 1875,
							[6548] = 2025,
							[883] = 1950,
							[1061] = 480,
							[3261] = 210,
							[877] = 1725,
						},
					},
				}, -- [19]
				{
					["groupExperience"] = 22256,
					["deaths"] = 0,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 9836,
							["count"] = 118,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 14,
							["year"] = 2024,
							["hour"] = 17,
							["weekday"] = 7,
						},
						["finished"] = 64616,
						["dateFinished"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 21,
							["year"] = 2024,
							["hour"] = 19,
							["weekday"] = 7,
						},
						["started"] = 59800,
					},
					["quests"] = {
						["The Barrens"] = {
							[880] = 1725,
							[821] = 2025,
							[865] = 2025,
							[888] = 1725,
							[899] = 2925,
							[1509] = 585,
						},
						["Orgrimmar"] = {
							[65601] = 585,
							[1507] = 240,
							[1508] = 585,
						},
					},
				}, -- [20]
				{
					["groupExperience"] = 24908,
					["deaths"] = 0,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 4822,
							["count"] = 47,
						},
						["The Wailing Caverns"] = {
							["xp"] = 3796,
							["count"] = 39,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 21,
							["year"] = 2024,
							["hour"] = 19,
							["weekday"] = 7,
						},
						["finished"] = 69424,
						["dateFinished"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 16,
							["year"] = 2024,
							["hour"] = 22,
							["weekday"] = 7,
						},
						["started"] = 64617,
					},
					["quests"] = {
						["The Barrens"] = {
							[882] = 2700,
							[884] = 2175,
							[907] = 2550,
							[5052] = 1875,
							[878] = 2475,
							[913] = 2925,
						},
						["Thunder Bluff"] = {
							[1489] = 435,
							[1490] = 180,
							[853] = 975,
						},
					},
				}, -- [21]
				{
					["groupExperience"] = 26649,
					["deaths"] = 0,
					["mobs"] = {
						["The Wailing Caverns"] = {
							["xp"] = 23522,
							["count"] = 241,
						},
						["The Barrens"] = {
							["xp"] = 52,
							["count"] = 1,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 16,
							["year"] = 2024,
							["hour"] = 22,
							["weekday"] = 7,
						},
						["finished"] = 74321,
						["dateFinished"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 38,
							["year"] = 2024,
							["hour"] = 23,
							["weekday"] = 7,
						},
						["started"] = 69425,
					},
					["quests"] = {
						["The Wailing Caverns"] = {
							[1487] = 3075,
						},
					},
				}, -- [22]
				{
					["groupExperience"] = 24634,
					["deaths"] = 0,
					["mobs"] = {
						["The Wailing Caverns"] = {
							["xp"] = 714,
							["count"] = 6,
						},
						["Hillsbrad Foothills"] = {
							["xp"] = 1052,
							["count"] = 10,
						},
						["Silverpine Forest"] = {
							["xp"] = 2881,
							["count"] = 25,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 24,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 38,
							["year"] = 2024,
							["hour"] = 23,
							["weekday"] = 7,
						},
						["finished"] = 83073,
						["dateFinished"] = {
							["monthDay"] = 25,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 1,
							["year"] = 2024,
							["hour"] = 13,
							["minute"] = 11,
						},
						["started"] = 74322,
					},
					["quests"] = {
						["The Wailing Caverns"] = {
							[1486] = 1950,
						},
						["Thunder Bluff"] = {
							[914] = 3300,
							[3369] = 3000,
							[962] = 2550,
						},
						["Hillsbrad Foothills"] = {
							[494] = 1162,
						},
						["The Barrens"] = {
							[959] = 2025,
							[6981] = 3975,
							[1491] = 2025,
						},
					},
				}, -- [23]
				{
					["groupExperience"] = 10233,
					["deaths"] = 0,
					["mobs"] = {
						["Hillsbrad Foothills"] = {
							["xp"] = 8508,
							["count"] = 30,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 25,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 1,
							["year"] = 2024,
							["hour"] = 13,
							["minute"] = 11,
						},
						["finished"] = 88932,
						["dateFinished"] = {
							["monthDay"] = 8,
							["day"] = 0,
							["month"] = 3,
							["minute"] = 58,
							["year"] = 2024,
							["hour"] = 19,
							["weekday"] = 6,
						},
						["started"] = 83074,
					},
					["quests"] = {
						["Hillsbrad Foothills"] = {
							[493] = 1725,
						},
					},
				}, -- [24]
				{
					["groupExperience"] = 33389,
					["deaths"] = 2,
					["mobs"] = {
						["Hillsbrad Foothills"] = {
							["xp"] = 30109,
							["count"] = 136,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 8,
							["day"] = 0,
							["month"] = 3,
							["minute"] = 58,
							["year"] = 2024,
							["hour"] = 19,
							["weekday"] = 6,
						},
						["finished"] = 93071,
						["dateFinished"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 3,
							["minute"] = 13,
							["year"] = 2024,
							["hour"] = 11,
							["weekday"] = 7,
						},
						["started"] = 88933,
					},
					["quests"] = {
						["Hillsbrad Foothills"] = {
							[527] = 3900,
						},
					},
				}, -- [25]
				{
					["groupExperience"] = 31761,
					["deaths"] = 4,
					["mobs"] = {
						["Hillsbrad Foothills"] = {
							["xp"] = 5712,
							["count"] = 46,
						},
						["Shadowfang Keep"] = {
							["xp"] = 15449,
							["count"] = 89,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 3,
							["minute"] = 13,
							["year"] = 2024,
							["hour"] = 11,
							["weekday"] = 7,
						},
						["finished"] = 101337,
						["dateFinished"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 3,
							["minute"] = 31,
							["year"] = 2024,
							["hour"] = 13,
							["weekday"] = 7,
						},
						["started"] = 93072,
					},
					["quests"] = {
						["Shadowfang Keep"] = {
							[1098] = 4000,
						},
						["Silverpine Forest"] = {
							[1014] = 6600,
						},
					},
				}, -- [26]
				{
					["groupExperience"] = 35591,
					["deaths"] = 0,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 451,
							["count"] = 4,
						},
						["Hillsbrad Foothills"] = {
							["xp"] = 10633,
							["count"] = 86,
						},
						["Ashenvale"] = {
							["xp"] = 2687,
							["count"] = 19,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 3,
							["minute"] = 31,
							["year"] = 2024,
							["hour"] = 13,
							["weekday"] = 7,
						},
						["finished"] = 107001,
						["dateFinished"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 3,
							["minute"] = 37,
							["year"] = 2024,
							["hour"] = 21,
							["weekday"] = 7,
						},
						["started"] = 101338,
					},
					["quests"] = {
						["Undercity"] = {
							[1013] = 4200,
						},
						["Hillsbrad Foothills"] = {
							[546] = 5100,
							[496] = 360,
							[528] = 4000,
							[499] = 3500,
							[529] = 4200,
						},
						["Ashenvale"] = {
							[6382] = 460,
						},
					},
				}, -- [27]
				{
					["groupExperience"] = 7430,
					["deaths"] = 2,
					["mobs"] = {
						["Ashenvale"] = {
							["xp"] = 3530,
							["count"] = 31,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 3,
							["minute"] = 37,
							["year"] = 2024,
							["hour"] = 21,
							["weekday"] = 7,
						},
						["started"] = 107002,
					},
					["quests"] = {
						["Ashenvale"] = {
							[6503] = 3900,
						},
					},
				}, -- [28]
			},
			["trackedGuid"] = "Player-5818-00A95D83",
		},
	},
}
RXPCComms = {
	["profileKeys"] = {
		["Falseclaimin - Shadowstrike (AU)"] = "Falseclaimin - Shadowstrike (AU)",
		["Lavy - Shadowstrike (AU)"] = "Lavy - Shadowstrike (AU)",
	},
	["profiles"] = {
		["Falseclaimin - Shadowstrike (AU)"] = {
			["announcements"] = {
				["06-10 Durotar"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["12-17 The Barrens"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["01-06 Durotar"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["10-12 Durotar"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
			},
			["players"] = {
				["Klink"] = {
					["level"] = 25,
					["lastSeen"] = 120862.549,
					["xpPercentage"] = 2,
					["class"] = "WARRIOR",
					["timePlayed"] = 0,
					["isRxp"] = true,
				},
				["Tuglife"] = {
					["timePlayed"] = 17239.71800000001,
					["class"] = "SHAMAN",
					["xp"] = 138,
				},
				["Kryo"] = {
					["level"] = 25,
					["lastSeen"] = 122899.717,
					["xpPercentage"] = 0,
					["class"] = "MAGE",
					["timePlayed"] = 0,
					["isRxp"] = true,
				},
				["Bàsil"] = {
					["timePlayed"] = 0,
					["class"] = "DRUID",
					["xp"] = 12,
				},
				["Fistoncider"] = {
					["class"] = "WARRIOR",
					["lastSeen"] = 42074.195,
					["xpPercentage"] = 62,
					["isRxp"] = true,
					["timePlayed"] = 0,
					["level"] = 24,
				},
				["Wardale"] = {
					["isRxp"] = true,
					["lastSeen"] = 268249.528,
					["xpPercentage"] = 0,
					["level"] = 25,
					["timePlayed"] = 0,
					["class"] = "HUNTER",
				},
				["Joban"] = {
					["level"] = 22,
					["lastSeen"] = 41411.353,
					["xpPercentage"] = 52,
					["class"] = "WARLOCK",
					["timePlayed"] = 564.8430000000008,
					["isRxp"] = true,
				},
				["Duexbaguette"] = {
					["isRxp"] = true,
					["lastSeen"] = 117375.028,
					["xpPercentage"] = 0,
					["level"] = 25,
					["timePlayed"] = 0,
					["class"] = "SHAMAN",
				},
				["Touchytim"] = {
					["isRxp"] = true,
					["lastSeen"] = 114179.571,
					["xpPercentage"] = 0,
					["level"] = 25,
					["timePlayed"] = 0,
					["class"] = "PRIEST",
				},
				["Boomtoon"] = {
					["timePlayed"] = 15053.29500000001,
					["class"] = "DRUID",
					["xp"] = 138,
				},
				["Tesfaye"] = {
					["timePlayed"] = 3670.655000000007,
					["class"] = "PRIEST",
					["xp"] = 128,
				},
				["Filthyfrank"] = {
					["class"] = "PRIEST",
					["lastSeen"] = 112617.819,
					["xpPercentage"] = 2,
					["isRxp"] = true,
					["timePlayed"] = 0,
					["level"] = 25,
				},
				["Sluglmao"] = {
					["timePlayed"] = 854.2910000000011,
					["class"] = "WARLOCK",
					["xp"] = 60,
				},
				["Bluerippers"] = {
					["class"] = "SHAMAN",
					["lastSeen"] = 131456.172,
					["xpPercentage"] = 0,
					["isRxp"] = true,
					["timePlayed"] = 0,
					["level"] = 25,
				},
				["Antibiotix"] = {
					["timePlayed"] = 2904.866000000002,
					["class"] = "DRUID",
					["xp"] = 122,
				},
				["Steelcow"] = {
					["isRxp"] = true,
					["lastSeen"] = 117803.772,
					["xpPercentage"] = 7,
					["level"] = 25,
					["timePlayed"] = 0,
					["class"] = "WARRIOR",
				},
				["Harakai"] = {
					["isRxp"] = true,
					["lastSeen"] = 117803.549,
					["xpPercentage"] = 0,
					["level"] = 25,
					["timePlayed"] = 0,
					["class"] = "SHAMAN",
				},
				["Facetonk"] = {
					["timePlayed"] = 3427.103000000003,
					["class"] = "WARRIOR",
					["xp"] = 85,
				},
				["ßlackout"] = {
					["timePlayed"] = 22.14400000002934,
					["class"] = "PRIEST",
					["xp"] = 55,
				},
				["Sagginudders"] = {
					["timePlayed"] = 0,
					["class"] = "DRUID",
					["xp"] = 900,
				},
				["Kastaa"] = {
					["class"] = "MAGE",
					["lastSeen"] = 268906.18,
					["xpPercentage"] = 94,
					["isRxp"] = true,
					["timePlayed"] = 2023.132000000041,
					["level"] = 14,
				},
				["Opràwindfury"] = {
					["timePlayed"] = 2244.962000000058,
					["class"] = "SHAMAN",
					["xp"] = 900,
				},
				["Westkanye"] = {
					["timePlayed"] = 1635.551000000007,
					["class"] = "SHAMAN",
					["xp"] = 49,
				},
				["Gtm"] = {
					["level"] = 24,
					["lastSeen"] = 44927.292,
					["xpPercentage"] = 88,
					["class"] = "HUNTER",
					["timePlayed"] = 27881.32600000002,
					["isRxp"] = true,
				},
				["Minich"] = {
					["timePlayed"] = 41.57299999999668,
					["class"] = "MAGE",
					["xp"] = 49,
				},
				["Krallitos"] = {
					["timePlayed"] = 0,
					["class"] = "WARLOCK",
					["xp"] = 35,
				},
				["Kaballah"] = {
					["level"] = 11,
					["lastSeen"] = 215413.641,
					["xpPercentage"] = 61,
					["class"] = "HUNTER",
					["timePlayed"] = 529.4189999999944,
					["isRxp"] = true,
				},
				["Rosabelle"] = {
					["timePlayed"] = 4418.842000000001,
					["class"] = "WARLOCK",
					["xp"] = 138,
				},
				["Mikeg"] = {
					["isRxp"] = true,
					["lastSeen"] = 254731.582,
					["xpPercentage"] = 80,
					["level"] = 22,
					["timePlayed"] = 352.3459999999614,
					["class"] = "MAGE",
				},
				["Kah"] = {
					["timePlayed"] = 0,
					["class"] = "WARRIOR",
					["xp"] = 49,
				},
				["Grunden"] = {
					["timePlayed"] = 2144.058000000019,
					["class"] = "DRUID",
					["xp"] = 460,
				},
			},
		},
		["Lavy - Shadowstrike (AU)"] = {
			["announcements"] = {
				["12-17 The Barrens"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["17-22 Stonetalon/Barrens/Ashenvale"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["22-24 Hillsbrad"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["01-06 Tirisfal Glades"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["26-28 Ashenvale"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["06-11 Tirisfal Glades"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["10-12 Durotar"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["24-26 Southern Barrens/Stonetalon"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["06-10 Durotar"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
			},
			["players"] = {
				["Rookiesupre"] = {
					["level"] = 20,
					["lastSeen"] = 107717.874,
					["xpPercentage"] = 25,
					["class"] = "HUNTER",
					["timePlayed"] = 1365.460999999996,
					["isRxp"] = true,
				},
				["Izamak"] = {
					["level"] = 18,
					["lastSeen"] = 127316.695,
					["xpPercentage"] = 52,
					["class"] = "PRIEST",
					["timePlayed"] = 191.2079999999987,
					["isRxp"] = true,
				},
				["Falseclaimin"] = {
					["isRxp"] = true,
					["lastSeen"] = 639046.952,
					["xpPercentage"] = 12,
					["level"] = 30,
					["timePlayed"] = 0,
					["class"] = "MAGE",
				},
				["Gânks"] = {
					["timePlayed"] = 936.2780000000057,
					["class"] = "MAGE",
					["xp"] = 54,
				},
				["Whoscotgreen"] = {
					["timePlayed"] = 1871.970000000001,
					["class"] = "MAGE",
					["xp"] = 1350,
				},
				["Frosteh"] = {
					["timePlayed"] = 1610.591,
					["class"] = "MAGE",
					["xp"] = 177,
				},
				["Aleigor"] = {
					["timePlayed"] = 1365.460999999996,
					["class"] = "WARRIOR",
					["xp"] = 1725,
				},
				["Daddybigmilk"] = {
					["level"] = 10,
					["lastSeen"] = 25098.519,
					["xpPercentage"] = 53,
					["class"] = "WARLOCK",
					["timePlayed"] = 0,
					["isRxp"] = true,
				},
				["Dolch"] = {
					["timePlayed"] = 1365.460999999996,
					["class"] = "ROGUE",
					["xp"] = 1725,
				},
				["Heyjie"] = {
					["timePlayed"] = 91.06499999994412,
					["class"] = "HUNTER",
					["xp"] = 86,
				},
				["Bse"] = {
					["level"] = 25,
					["class"] = "DRUID",
					["lastSeen"] = 656766.41,
					["timePlayed"] = 31.64899999997579,
					["isRxp"] = true,
					["xp"] = 87,
					["xpPercentage"] = 5,
				},
				["Tpainwarpigs"] = {
					["class"] = "SHAMAN",
					["lastSeen"] = 60076.567,
					["xpPercentage"] = 84,
					["isRxp"] = true,
					["timePlayed"] = 50056.43199999988,
					["level"] = 28,
				},
				["Shazzah"] = {
					["isRxp"] = true,
					["lastSeen"] = 18779.736,
					["xpPercentage"] = 26,
					["level"] = 27,
					["timePlayed"] = 968.5280000000021,
					["class"] = "SHAMAN",
				},
				["Mitch"] = {
					["timePlayed"] = 1871.970000000001,
					["class"] = "MAGE",
					["xp"] = 1350,
				},
				["Ketamíne"] = {
					["timePlayed"] = 29.10000000000218,
					["isRxp"] = true,
					["lastSeen"] = 18779.486,
					["xpPercentage"] = 69,
					["class"] = "PRIEST",
					["xp"] = 128,
					["level"] = 24,
				},
				["Bigshock"] = {
					["level"] = 31,
					["lastSeen"] = 1063631.134,
					["xpPercentage"] = 30,
					["class"] = "SHAMAN",
					["timePlayed"] = 0,
					["isRxp"] = true,
				},
				["Qasi"] = {
					["timePlayed"] = 3908.183999999892,
					["class"] = "MAGE",
					["xp"] = 26,
				},
				["Bisshu"] = {
					["timePlayed"] = 153.1330000000016,
					["class"] = "DRUID",
					["xp"] = 50,
				},
				["Taureau"] = {
					["class"] = "WARRIOR",
					["lastSeen"] = 666152.52,
					["xpPercentage"] = 21,
					["isRxp"] = true,
					["timePlayed"] = 3908.183999999892,
					["level"] = 24,
				},
				["Tlp"] = {
					["timePlayed"] = 4042.749999999884,
					["class"] = "PRIEST",
					["xp"] = 86,
				},
				["Wargra"] = {
					["timePlayed"] = 1871.970000000001,
					["class"] = "SHAMAN",
					["xp"] = 1350,
				},
				["Lolstabbed"] = {
					["timePlayed"] = 47.93400000000838,
					["class"] = "ROGUE",
					["xp"] = 230,
				},
				["Holladoss"] = {
					["timePlayed"] = 1610.591,
					["class"] = "SHAMAN",
					["xp"] = 177,
				},
				["Dangerdann"] = {
					["timePlayed"] = 1610.591,
					["class"] = "PRIEST",
					["xp"] = 177,
				},
			},
		},
	},
}
RXPCSettings = nil

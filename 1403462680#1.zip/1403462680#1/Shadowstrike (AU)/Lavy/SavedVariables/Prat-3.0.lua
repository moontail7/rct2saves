
Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["scrollback"] = {
		["ChatFrame5"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 26,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[19:54:54]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["serverTime"] = 1709941979,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:52:51]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["g"] = 1,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973243,
					["b"] = 0.250980406999588,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:29:52]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Mikeg-Shadowstrike(AU):952:GUILD|h|cffd84e4e40|r:|cff3fc6eaMikeg|r|h|cffd8d8d8]|r: [NWB] Stranglethorn event starts in 30 minutes.",
					["extraData"] = {
						5, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709944200,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 0.250980406999588,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:44:51]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Mikeg-Shadowstrike(AU):1205:GUILD|h|cffd84e4e40|r:|cff3fc6eaMikeg|r|h|cffd8d8d8]|r: [NWB] Stranglethorn event starts in 15 minutes.",
					["extraData"] = {
						5, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709945099,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 0.250980406999588,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:44:51]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Mikeg-Shadowstrike(AU):2519:GUILD|h|cffd84e4e40|r:|cff3fc6eaMikeg|r|h|cffd8d8d8]|r: [NWB] Ashenvale event starts in 15 minutes.",
					["extraData"] = {
						5, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709948699,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 0.250980406999588,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:45:11]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Mikeg-Shadowstrike(AU):2530:GUILD|h|cffd84e4e40|r:|cff3fc6eaMikeg|r|h|cffd8d8d8]|r: 4 scrolls down",
					["extraData"] = {
						5, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709948719,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 0.250980406999588,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:45:12]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Mikeg-Shadowstrike(AU):2531:GUILD|h|cffd84e4e40|r:|cff3fc6eaMikeg|r|h|cffd8d8d8]|r: this is *!@#ed",
					["extraData"] = {
						5, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709948720,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 0.250980406999588,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:53]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["serverTime"] = 1709976365,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:44:34]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):232:GUILD|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: yo craig",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973884,
					["extraData"] = {
						5, -- [1]
						42, -- [2]
						43, -- [3]
						["n"] = 3,
					},
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:44:37]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):233:GUILD|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: have a good race",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973887,
					["extraData"] = {
						5, -- [1]
						42, -- [2]
						43, -- [3]
						["n"] = 3,
					},
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:44:43]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Craiglowndes-Shadowstrike(AU):234:GUILD|h|cff65b26524|r:|cff0070ddCraiglowndes|r|h|cffd8d8d8]|r: thanks mate",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973893,
					["extraData"] = {
						5, -- [1]
						42, -- [2]
						44, -- [3]
						["n"] = 3,
					},
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:44:48]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):235:GUILD|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: all g",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973898,
					["extraData"] = {
						5, -- [1]
						42, -- [2]
						43, -- [3]
						["n"] = 3,
					},
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:45:01]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):239:GUILD|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |cffffffff|Hurl:https://www.youtube.com/watch?v=vgPrHYUjJGs&ab_channel=yeeTWOsduck|h[https://www.youtube.com/watch?v=vgPrHYUjJGs&ab_channel=yeeTWOsduck]|h|r",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973911,
					["extraData"] = {
						5, -- [1]
						42, -- [2]
						43, -- [3]
						["n"] = 3,
					},
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:25:54]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709976815,
					["r"] = 0.250980406999588,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:33:25]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["serverTime"] = 1709980013,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:40:49]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Craiglowndes-Shadowstrike(AU):1542:GUILD|h|cff65b26524|r:|cff0070ddCraiglowndes|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t RestedXP Guides: I just leveled from 24 to 25 in 1 hour 45 minutes 33 seconds",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						18, -- [2]
						19, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977259,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:41:28]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):1553:GUILD|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: huge",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						18, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977298,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:41:32]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):1554:GUILD|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: best laptme",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						18, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977302,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:41:55]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):1563:GUILD|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: apparently ems mum loves craig irl",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						18, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977325,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:42:04]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):1566:GUILD|h|cffd8d83f27|r:|cff8787edLavy|r|h|cffd8d8d8]|r: big fan",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						18, -- [2]
						21, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977334,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:44:46]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Craiglowndes-Shadowstrike(AU):1616:GUILD|h|cffd8d83f25|r:|cff0070ddCraiglowndes|r|h|cffd8d8d8]|r: we getting pbs out here",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						18, -- [2]
						19, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977496,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:26:43]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["g"] = 1,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982655,
					["b"] = 0.250980406999588,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:10:45]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["serverTime"] = 1709984174,
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [23]
				{
					["message"] = "0 days, 0 hours, 0 minutes, 0 seconds",
					["timestamp"] = 60064.747,
				}, -- [24]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 60064.747,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:36:03]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 60064.631,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [26]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame10"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 10,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["b"] = 0,
					["r"] = 1,
					["serverTime"] = 1709941979,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [1]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["g"] = 1,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973243,
					["b"] = 0,
				}, -- [2]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["b"] = 0,
					["serverTime"] = 1709976365,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [3]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709976815,
					["r"] = 1,
				}, -- [4]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["b"] = 0,
					["r"] = 1,
					["serverTime"] = 1709980013,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [5]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["g"] = 1,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982655,
					["b"] = 0,
				}, -- [6]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["serverTime"] = 1709984174,
					["r"] = 1,
					["b"] = 0,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [7]
				{
					["message"] = "0 days, 0 hours, 0 minutes, 0 seconds",
					["timestamp"] = 60064.747,
				}, -- [8]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 60064.747,
				}, -- [9]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 60058.598,
					["g"] = 1,
					["b"] = 0,
				}, -- [10]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame7"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame6"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 9,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:07]|h|r [W To] |cffd8d8d8[|r|Hplayer:Backbitter-Shadowstrike(AU):997:WHISPER:BACKBITTER-SHADOWSTRIKE(AU)|h|cffd84e4e40|r:|cfffff468Backbitter|r|h|cffd8d8d8]|r: can u help click a summ <3",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975717,
					["extraData"] = {
						10, -- [1]
						66, -- [2]
						67, -- [3]
						["n"] = 3,
					},
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:14]|h|r [W To] |cffd8d8d8[|r|Hplayer:Tantrymbank-Shadowstrike(AU):1005:WHISPER:TANTRYMBANK-SHADOWSTRIKE(AU)|h|cffd84e4e40|r:|cffc69b6dTantrymbank|r|h|cffd8d8d8]|r: can u help click a summ <3",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975724,
					["extraData"] = {
						10, -- [1]
						68, -- [2]
						69, -- [3]
						["n"] = 3,
					},
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:19]|h|r [W To] |cffd8d8d8[|r|Hplayer:Staba-Shadowstrike(AU):1010:WHISPER:STABA-SHADOWSTRIKE(AU)|h|cffd84e4e40|r:|cfffff468Staba|r|h|cffd8d8d8]|r: v",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975729,
					["extraData"] = {
						10, -- [1]
						70, -- [2]
						71, -- [3]
						["n"] = 3,
					},
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:22]|h|r [W To] |cffd8d8d8[|r|Hplayer:Staba-Shadowstrike(AU):1014:WHISPER:STABA-SHADOWSTRIKE(AU)|h|cffd84e4e40|r:|cfffff468Staba|r|h|cffd8d8d8]|r: can u help click a summ <3",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975732,
					["extraData"] = {
						10, -- [1]
						70, -- [2]
						71, -- [3]
						["n"] = 3,
					},
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:31]|h|r [W To] |cffd8d8d8[|r|Hplayer:Alucid-Shadowstrike(AU):1031:WHISPER:ALUCID-SHADOWSTRIKE(AU)|h|cffd8d83f26|r:|cffc69b6dAlucid|r|h|cffd8d8d8]|r: can u help click a summ <3",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975741,
					["extraData"] = {
						10, -- [1]
						78, -- [2]
						79, -- [3]
						["n"] = 3,
					},
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:33]|h|r [W From] |cffd8d8d8[|r|Hplayer:Tantrymbank-Shadowstrike(AU):1033:WHISPER:TANTRYMBANK-SHADOWSTRIKE(AU)|h|cffd84e4e40|r:|cffc69b6dTantrymbank|r|h|cffd8d8d8]|r: yup",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975743,
					["extraData"] = {
						0, -- [1]
						68, -- [2]
						80, -- [3]
						["n"] = 3,
					},
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:40]|h|r [W From] |cffd8d8d8[|r|Hplayer:Alucid-Shadowstrike(AU):1048:WHISPER:ALUCID-SHADOWSTRIKE(AU)|h|cffd8d83f26|r:|cffc69b6dAlucid|r|h|cffd8d8d8]|r: sure",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975750,
					["extraData"] = {
						0, -- [1]
						78, -- [2]
						82, -- [3]
						["n"] = 3,
					},
				}, -- [7]
				{
					["message"] = "0 days, 2 hours, 20 minutes, 24 seconds",
					["timestamp"] = 60064.747,
				}, -- [8]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 60064.747,
				}, -- [9]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame8"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 127,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:28]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):40:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: wrod",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942136,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:57:28]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Shazzah-Shadowstrike(AU):98:PARTY|h|cffd8d83f27|r:|cff0070ddShazzah|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t RestedXP Guides: I just leveled from 26 to 27 in 1 hour 59 minutes 43 seconds",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						14, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942256,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:58:34]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):122:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: brah",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942322,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:58:39]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):123:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: i havent seen wilkes in years",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942327,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:59:30]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):155:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: hes up",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942378,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:59:31]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):157:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: inside",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942379,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:03]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):183:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Citizen Wilkes for |Hquestie:567:Player-5818-00A95F60|h|cFFFF8040[|r|cFFFF8040[28] Dangerous!|r|cFFFF8040]|r|h!",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942411,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:03]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):184:PARTY|h|cffd8d83f25|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Citizen Wilkes for |Hquestie:567:Player-5818-00A95D83|h|cFFFF8040[|r|cFFFF8040[28] Dangerous!|r|cFFFF8040]|r|h!",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942411,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:02:51]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):298:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Farmer Kalaba for |Hquestie:567:Player-5818-00A95F60|h|cFFFF8040[|r|cFFFF8040[28] Dangerous!|r|cFFFF8040]|r|h!",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942579,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:02:51]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):299:PARTY|h|cffd8d83f25|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Farmer Kalaba for |Hquestie:567:Player-5818-00A95D83|h|cFFFF8040[|r|cFFFF8040[28] Dangerous!|r|cFFFF8040]|r|h!",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942579,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:05:49]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):427:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: inc",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942757,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:05:58]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):430:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: actually",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942766,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:06:09]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):435:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: be free big dps man",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942777,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:06:43]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):468:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: fk",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942811,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:06:47]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):472:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: i rez",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942815,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:12]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):598:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: XDDD",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943020,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:15]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):600:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: my hero",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943023,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:40]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):612:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: i havent been saved harder in wow in years",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943048,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:44]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Shazzah-Shadowstrike(AU):613:PARTY|h|cffd8d83f27|r:|cff0070ddShazzah|r|h|cffd8d8d8]|r: i have got 2 skulls since iv been here",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						14, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943052,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:47]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):617:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: wtf",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943055,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:51]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Shazzah-Shadowstrike(AU):619:PARTY|h|cffd8d83f27|r:|cff0070ddShazzah|r|h|cffd8d8d8]|r: this is aids",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						14, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943059,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:53]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):620:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: yes it is",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943061,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:11:11]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Shazzah-Shadowstrike(AU):627:PARTY|h|cffd8d83f27|r:|cff0070ddShazzah|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 15/15 Hillsbrad Peasant for |Hquestie:528:Player-5818-009E3F5D|h|cFFFFFF00[|r|cFFFFFF00[25] Battle of Hillsbrad |cFF00ff00(Complete)|r|r|cFFFFFF00]|r|h!",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						14, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943079,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:11:11]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):628:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 15/15 Hillsbrad Peasant for |Hquestie:528:Player-5818-00A95F60|h|cFFFFFF00[|r|cFFFFFF00[25] Battle of Hillsbrad |cFF00ff00(Complete)|r|r|cFFFFFF00]|r|h!",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943079,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:11:11]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):629:PARTY|h|cffd8d83f25|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 15/15 Hillsbrad Peasant for |Hquestie:528:Player-5818-00A95D83|h|cFFFFFF00[|r|cFFFFFF00[25] Battle of Hillsbrad |cFF00ff00(Complete)|r|r|cFFFFFF00]|r|h!",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943079,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:11:37]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Shazzah-Shadowstrike(AU):648:PARTY|h|cffd8d83f27|r:|cff0070ddShazzah|r|h|cffd8d8d8]|r: im out ty",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						14, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943105,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:11:40]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):650:PARTY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: GG",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943108,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:11:44]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):652:PARTY|h|cffd8d83f25|r:|cff8787edLavy|r|h|cffd8d8d8]|r: gg",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943112,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:16]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):693:PARTY|h|cffd8d83f26|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t RestedXP Guides: I just leveled from 25 to 26 in 1 hour 8 minutes 58 seconds",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943264,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:30:17]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):963:PARTY|h|cffd8d83f26|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 10/10 Gray Bear Tongue for |Hquestie:496:Player-5818-00A95D83|h|cFF40C040[|r|cFF40C040[22] Elixir of Suffering |cFF00ff00(Complete)|r|r|cFF40C040]|r|h!",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709944225,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:25:28]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2096:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: lets *!@#",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709947536,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:25:34]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Frosteh-Shadowstrike(AU):2100:PARTY|h|cffd8d83f24|r:|cff3fc6eaFrosteh|r|h|cffd8d8d8]|r: yessir",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						107, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709947542,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:25:48]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2101:PARTY|h|cffd8d83f26|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: oh $%^& we got tpain :D",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709947556,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:25:59]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2107:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: im back on the game after my successful music career",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709947567,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:26:07]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2109:PARTY|h|cffd8d83f26|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: glad to see",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709947575,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:26:09]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2110:PARTY|h|cffd8d83f26|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: xD",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709947577,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:26:38]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Frosteh-Shadowstrike(AU):2117:PARTY|h|cffd8d83f24|r:|cff3fc6eaFrosteh|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Valdred's Hands for |Hquestie:530:Player-5818-00A644C5|h|cFF40C040[|r|cFF40C040[20] A Husband's Revenge|r|cFF40C040]|r|h!",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						107, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709947606,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:27:45]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2126:PARTY|h|cffd8d83f26|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: reset?",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709947673,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:27:53]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2130:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |HNITCustomLink:instancelog|h[NIT]|h|r |HNITCustomLink:instancelog|hShadowfang Keep has been reset.|h",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709947681,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:28:00]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2131:PARTY|h|cffd8d83f26|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: <3",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709947688,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:32:45]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2222:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: cancer",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709947973,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:32:48]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Frosteh-Shadowstrike(AU):2224:PARTY|h|cffd8d83f24|r:|cff3fc6eaFrosteh|r|h|cffd8d8d8]|r: yep",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						107, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709947976,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:32:54]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2230:PARTY|h|cffd8d83f26|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: agreed",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709947982,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:11]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2239:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: sec i just clear for this quest",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709947999,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:35]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2346:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: dumb pull",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948203,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:38]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2347:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: inc",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948206,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:42]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Frosteh-Shadowstrike(AU):2349:PARTY|h|cffd8d83f24|r:|cff3fc6eaFrosteh|r|h|cffd8d8d8]|r: yay",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						107, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948210,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:45]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2350:PARTY|h|cffd8d83f27|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: xD",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948213,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [48]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:50]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2353:PARTY|h|cffd8d83f27|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: lets get stupid",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948218,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [49]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:52]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2354:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: after this idiot",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948220,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [50]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:37:28]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Frosteh-Shadowstrike(AU):2370:PARTY|h|cffd8d83f24|r:|cff3fc6eaFrosteh|r|h|cffd8d8d8]|r: soz",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						107, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948256,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [51]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:37:36]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Frosteh-Shadowstrike(AU):2373:PARTY|h|cffd8d83f24|r:|cff3fc6eaFrosteh|r|h|cffd8d8d8]|r: mb",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						107, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948264,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [52]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:37:55]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Frosteh-Shadowstrike(AU):2378:PARTY|h|cffd8d83f24|r:|cff3fc6eaFrosteh|r|h|cffd8d8d8]|r: my fault",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						107, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948283,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [53]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:38:28]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2391:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: well",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948316,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [54]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:38:43]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2396:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: that was a pull",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948331,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [55]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:38:48]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):2397:PARTY|h|cffd8d83f26|r:|cff8787edLavy|r|h|cffd8d8d8]|r: ahaha",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948336,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [56]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:38:58]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2399:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: i shouldnt have got dazed",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948346,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [57]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:38:59]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2400:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: it was all over then",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948347,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [58]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:45:05]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2528:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: pullin back",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948713,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [59]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:45:09]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2529:PARTY|h|cffd8d83f27|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: sorry havin billy",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948717,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [60]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:45:14]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Frosteh-Shadowstrike(AU):2533:PARTY|h|cffd8d83f24|r:|cff3fc6eaFrosteh|r|h|cffd8d8d8]|r: LOL nice",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						107, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948722,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [61]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:45:52]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2542:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: back they silence",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948760,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [62]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:45:55]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Frosteh-Shadowstrike(AU):2543:PARTY|h|cffd8d83f24|r:|cff3fc6eaFrosteh|r|h|cffd8d8d8]|r: $%^&ing silence lol",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						107, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948763,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [63]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:45:57]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2545:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: ye",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948765,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [64]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:47:19]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2589:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: sick",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948847,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [65]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:47:21]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2590:PARTY|h|cffd8d83f27|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: gz",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948849,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [66]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:51:02]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2679:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: im getting DECKED",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949070,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [67]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:51:09]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Frosteh-Shadowstrike(AU):2687:PARTY|h|cffd8d83f24|r:|cff3fc6eaFrosteh|r|h|cffd8d8d8]|r: yesssir",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						107, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949077,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [68]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:51:09]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2688:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: oh",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949077,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [69]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:51:09]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2689:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: gz",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949077,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [70]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:51:20]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2691:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: can u decurse me frosty sir",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949088,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [71]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:51:25]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2694:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: <333",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949093,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [72]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:51:27]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2696:PARTY|h|cffd8d83f27|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: you dont want to know what i had on",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949095,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [73]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:51:31]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2697:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: lmaoo",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949099,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [74]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:51:36]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2698:PARTY|h|cffd8d83f27|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: xD",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949104,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [75]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:52:19]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2709:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: if u get aggro",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949147,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [76]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:52:20]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2711:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: run in",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949148,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [77]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:52:22]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2713:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: not back",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949150,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [78]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:37]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Dangerdann-Shadowstrike(AU):2944:PARTY|h|cffd8d83f25|r:|cffffffffDangerdann|r|h|cffd8d8d8]|r: de curse",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						111, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949645,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [79]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:48]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2946:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: ty",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949656,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [80]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:49]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2947:PARTY|h|cffd8d83f27|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: Purge",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949657,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [81]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:54]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2949:PARTY|h|cffd8d83f27|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: ?",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949662,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [82]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:55]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2950:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: i dont think u can pruge it",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949663,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [83]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:58]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2952:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: its only decurse",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949666,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [84]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:59]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2953:PARTY|h|cffd8d83f27|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: oh ok",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949667,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [85]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:12]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2979:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Head of Arugal for |Hquestie:1014:Player-5818-00A95F60|h|cFFFFFF00[|r|cFFFFFF00[27D] Arugal Must Die|r|cFFFFFF00]|r|h!",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949740,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [86]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:21]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):2985:PARTY|h|cffd8d83f26|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Head of Arugal for |Hquestie:1014:Player-5818-00A95D83|h|cFFFFFF00[|r|cFFFFFF00[27D] Arugal Must Die |cFF00ff00(Complete)|r|r|cFFFFFF00]|r|h!",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949749,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [87]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:34]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2995:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: own",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949762,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [88]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:52]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Dangerdann-Shadowstrike(AU):2996:PARTY|h|cffd8d83f25|r:|cffffffffDangerdann|r|h|cffd8d8d8]|r: gg guys",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						111, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949780,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [89]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:55]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2997:PARTY|h|cffd8d83f27|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: gg",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949783,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [90]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:56]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Frosteh-Shadowstrike(AU):2998:PARTY|h|cffd8d83f24|r:|cff3fc6eaFrosteh|r|h|cffd8d8d8]|r: gg ty",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						107, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949784,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [91]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:58]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holladoss-Shadowstrike(AU):2999:PARTY|h|cffd8d83f27|r:|cff0070ddHolladoss|r|h|cffd8d8d8]|r: tyty",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						108, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949786,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [92]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:03:11]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):3001:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 The Book of Ur for |Hquestie:1013:Player-5818-00A95F60|h|cFFFFFF00[|r|cFFFFFF00[26D] The Book of Ur|r|cFFFFFF00]|r|h!",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949799,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [93]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:03:44]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):3011:PARTY|h|cffd8d83f26|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 The Book of Ur for |Hquestie:1013:Player-5818-00A95D83|h|cFFFFFF00[|r|cFFFFFF00[26D] The Book of Ur |cFF00ff00(Complete)|r|r|cFFFFFF00]|r|h!",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949832,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [94]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:04:35]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):3021:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: ggs",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949883,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [95]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:32:01]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):3399:PARTY|h|cffd8d83f27|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t RestedXP Guides: I just leveled from 26 to 27 in 2 hours 17 minutes 45 seconds",
					["extraData"] = {
						3, -- [1]
						12, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709951529,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [96]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:21]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):3423:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Filled Red Waterskin for |Hquestie:1536:Player-5818-00A95F60|h|cFF40C040[|r|cFF40C040[22] Call of Water|r|cFF40C040]|r|h!",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709951609,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [97]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:21]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):3424:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 10/10 Gray Bear Tongue for |Hquestie:496:Player-5818-00A95F60|h|cFF40C040[|r|cFF40C040[22] Elixir of Suffering |cFF00ff00(Complete)|r|r|cFF40C040]|r|h!",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709951609,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [98]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:21]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):3425:PARTY|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Creeper Ichor for |Hquestie:496:Player-5818-00A95F60|h|cFF40C040[|r|cFF40C040[22] Elixir of Suffering |cFF00ff00(Complete)|r|r|cFF40C040]|r|h!",
					["extraData"] = {
						50, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709951609,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [99]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:00]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):275:PARTY|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Blacksmith Verringtan for |Hquestie:529:Player-5818-00A95F60|h|cFFFFFF00[|r|cFFFFFF00[26] Battle of Hillsbrad|r|cFFFFFF00]|r|h!",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973970,
					["extraData"] = {
						50, -- [1]
						45, -- [2]
						46, -- [3]
						["n"] = 3,
					},
				}, -- [100]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:00]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):276:PARTY|h|cffd8d83f27|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Blacksmith Verringtan for |Hquestie:529:Player-5818-00A95D83|h|cFFFFFF00[|r|cFFFFFF00[26] Battle of Hillsbrad|r|cFFFFFF00]|r|h!",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973970,
					["extraData"] = {
						3, -- [1]
						45, -- [2]
						47, -- [3]
						["n"] = 3,
					},
				}, -- [101]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:40]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):312:PARTY|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Shipment of Iron for |Hquestie:529:Player-5818-00A95F60|h|cFFFFFF00[|r|cFFFFFF00[26] Battle of Hillsbrad|r|cFFFFFF00]|r|h!",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974010,
					["extraData"] = {
						50, -- [1]
						45, -- [2]
						46, -- [3]
						["n"] = 3,
					},
				}, -- [102]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:47]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):314:PARTY|h|cffd8d83f27|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Shipment of Iron for |Hquestie:529:Player-5818-00A95D83|h|cFFFFFF00[|r|cFFFFFF00[26] Battle of Hillsbrad|r|cFFFFFF00]|r|h!",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974017,
					["extraData"] = {
						3, -- [1]
						45, -- [2]
						47, -- [3]
						["n"] = 3,
					},
				}, -- [103]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:48:15]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):360:PARTY|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 4/4 Hillsbrad Apprentice Blacksmith for |Hquestie:529:Player-5818-00A95F60|h|cFFFFFF00[|r|cFFFFFF00[26] Battle of Hillsbrad |cFF00ff00(Complete)|r|r|cFFFFFF00]|r|h!",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974105,
					["extraData"] = {
						50, -- [1]
						45, -- [2]
						46, -- [3]
						["n"] = 3,
					},
				}, -- [104]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:48:15]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):362:PARTY|h|cffd8d83f27|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 4/4 Hillsbrad Apprentice Blacksmith for |Hquestie:529:Player-5818-00A95D83|h|cFFFFFF00[|r|cFFFFFF00[26] Battle of Hillsbrad |cFF00ff00(Complete)|r|r|cFFFFFF00]|r|h!",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974105,
					["extraData"] = {
						3, -- [1]
						45, -- [2]
						47, -- [3]
						["n"] = 3,
					},
				}, -- [105]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:05:25]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):809:PARTY|h|cffd8d83f27|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 30/30 Hillsbrad Human Skull for |Hquestie:546:Player-5818-00A95D83|h|cFFFFFF00[|r|cFFFFFF00[25] Souvenirs of Death |cFF00ff00(Complete)|r|r|cFFFFFF00]|r|h!",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975135,
					["extraData"] = {
						3, -- [1]
						45, -- [2]
						47, -- [3]
						["n"] = 3,
					},
				}, -- [106]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:06:58]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):850:PARTY|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 30/30 Hillsbrad Human Skull for |Hquestie:546:Player-5818-00A95F60|h|cFFFFFF00[|r|cFFFFFF00[25] Souvenirs of Death |cFF00ff00(Complete)|r|r|cFFFFFF00]|r|h!",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975228,
					["extraData"] = {
						50, -- [1]
						45, -- [2]
						46, -- [3]
						["n"] = 3,
					},
				}, -- [107]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:52]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):1068:PARTY|h|cffd8d83f27|r:|cff8787edLavy|r|h|cffd8d8d8]|r: ty friends",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975762,
					["extraData"] = {
						50, -- [1]
						45, -- [2]
						83, -- [3]
						["n"] = 3,
					},
				}, -- [108]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:16:01]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Tantrymbank-Shadowstrike(AU):1081:PARTY|h|cffd84e4e40|r:|cffc69b6dTantrymbank|r|h|cffd8d8d8]|r: gnight",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975771,
					["extraData"] = {
						3, -- [1]
						45, -- [2]
						84, -- [3]
						["n"] = 3,
					},
				}, -- [109]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:27:30]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):1255:PARTY|h|cffd8d83f27|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t RestedXP Guides: Flying to 77 ETA 1 minute 27 seconds",
					["serverTime"] = 1709976460,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						14, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [110]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:38:23]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):1496:PARTY|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Thunderhawk Saliva Gland for |Hquestie:822:Player-5818-00A95F60|h|cFF21CCE7[|r|cFF21CCE7[24] Chen's Empty Keg|r|cFF21CCE7]|r|h!",
					["r"] = 0.4627451300621033,
					["b"] = 1,
					["g"] = 0.7843137979507446,
					["timestamp"] = 60064.747,
					["extraData"] = {
						50, -- [1]
						14, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977113,
				}, -- [111]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:34:19]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):2110:PARTY|h|cffd8d83f27|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 9/9 Ashenvale Outrunner for |Hquestie:6503:Player-5818-00A95D83|h|cFF40C040[|r|cFF40C040[24] Ashenvale Outrunners |cFF00ff00(Complete)|r|r|cFF40C040]|r|h!",
					["extraData"] = {
						3, -- [1]
						9, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709980469,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [112]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:34:19]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2111:PARTY|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 9/9 Ashenvale Outrunner for |Hquestie:6503:Player-5818-00A95F60|h|cFF40C040[|r|cFF40C040[24] Ashenvale Outrunners |cFF00ff00(Complete)|r|r|cFF40C040]|r|h!",
					["extraData"] = {
						50, -- [1]
						9, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709980469,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [113]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:35:56]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):2145:PARTY|h|cffd8d83f27|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: Picked up |cff1eff00|Hitem:16305::::::::27:::::::::|h[Sharptalon's Claw]|h|r which starts |Hquestie:2:Player-5818-00A95D83|h|cFFFF8040[|r|cFFFF8040[30] Sharptalon's Claw|r|cFFFF8040]|r|h!",
					["extraData"] = {
						3, -- [1]
						9, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709980566,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [114]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:35:57]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2148:PARTY|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: Picked up |cff1eff00|Hitem:16305::::::::28:::::::::|h[Sharptalon's Claw]|h|r which starts |Hquestie:2:Player-5818-00A95F60|h|cFFFF8040[|r|cFFFF8040[30] Sharptalon's Claw|r|cFFFF8040]|r|h!",
					["extraData"] = {
						50, -- [1]
						9, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709980567,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [115]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:37:48]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):2184:PARTY|h|cffd8d83f28|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t RestedXP Guides: I just leveled from 27 to 28 in 1 hour 34 minutes 23 seconds",
					["extraData"] = {
						3, -- [1]
						9, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709980678,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [116]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:43:57]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2300:PARTY|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Scout the gazebo on Mystral Lake that overlooks the nearby Alliance outpost. for |Hquestie:25:Player-5818-00A95F60|h|cFF40C040[|r|cFF40C040[25] Stonetalon Standstill|r|cFF40C040]|r|h!",
					["extraData"] = {
						50, -- [1]
						9, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709981047,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [117]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:44:06]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):2303:PARTY|h|cffd8d83f28|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Scout the gazebo on Mystral Lake that overlooks the nearby Alliance outpost. for |Hquestie:25:Player-5818-00A95D83|h|cFF40C040[|r|cFF40C040[25] Stonetalon Standstill|r|cFF40C040]|r|h!",
					["extraData"] = {
						3, -- [1]
						9, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709981056,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [118]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:49:42]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):2460:PARTY|h|cffd8d83f28|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: Picked up |cff1eff00|Hitem:16408::::::::28:::::::::|h[Befouled Water Globe]|h|r which starts |Hquestie:1918:Player-5818-00A95D83|h|cFFFFFF00[|r|cFFFFFF00[27] The Befouled Element|r|cFFFFFF00]|r|h!",
					["extraData"] = {
						3, -- [1]
						9, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709981392,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0.6666666865348816,
				}, -- [119]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:49:46]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2464:PARTY|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: Picked up |cff1eff00|Hitem:16408::::::::28:::::::::|h[Befouled Water Globe]|h|r which starts |Hquestie:1918:Player-5818-00A95F60|h|cFFFFFF00[|r|cFFFFFF00[27] The Befouled Element|r|cFFFFFF00]|r|h!",
					["extraData"] = {
						50, -- [1]
						9, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709981396,
					["timestamp"] = 60064.747,
					["g"] = 0.7843137979507446,
					["r"] = 0.4627451300621033,
				}, -- [120]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:13:01]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):2547:PARTY|h|cffd8d83f28|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 12/12 Befouled Water Elemental for |Hquestie:25:Player-5818-00A95D83|h|cFF40C040[|r|cFF40C040[25] Stonetalon Standstill |cFF00ff00(Complete)|r|r|cFF40C040]|r|h!",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982791,
					["extraData"] = {
						3, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
				}, -- [121]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:23:50]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2725:PARTY|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: Picked up |cff1eff00|Hitem:16303::::::::28:::::::::|h[Ursangous's Paw]|h|r which starts |Hquestie:23:Player-5818-00A95F60|h|cFF40C040[|r|cFF40C040[24] Ursangous's Paw|r|cFF40C040]|r|h!",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983440,
					["extraData"] = {
						50, -- [1]
						5, -- [2]
						14, -- [3]
						["n"] = 3,
					},
				}, -- [122]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:23:50]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):2728:PARTY|h|cffd8d83f28|r:|cff8787edLavy|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: Picked up |cff1eff00|Hitem:16303::::::::28:::::::::|h[Ursangous's Paw]|h|r which starts |Hquestie:23:Player-5818-00A95D83|h|cFF40C040[|r|cFF40C040[24] Ursangous's Paw|r|cFF40C040]|r|h!",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983440,
					["extraData"] = {
						3, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
				}, -- [123]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:25:34]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2764:PARTY|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Filled Blue Waterskin for |Hquestie:1534:Player-5818-00A95F60|h|cFF40C040[|r|cFF40C040[23] Call of Water|r|cFF40C040]|r|h!",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983544,
					["extraData"] = {
						50, -- [1]
						5, -- [2]
						14, -- [3]
						["n"] = 3,
					},
				}, -- [124]
				{
					["message"] = "0 days, 0 hours, 10 minutes, 30 seconds",
					["timestamp"] = 60064.747,
				}, -- [125]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 60064.747,
				}, -- [126]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:51:09]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):3357:PARTY|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: Picked up |cffffffff|Hitem:12564::::::::28:::::::::|h[Assassination Note]|h|r which starts |Hquestie:4881:Player-5818-00A95F60|h|cFFFFFF00[|r|cFFFFFF00[28] Assassination Plot|r|cFFFFFF00]|r|h!",
					["serverTime"] = 1709985079,
					["r"] = 0.4627451300621033,
					["extraData"] = {
						50, -- [1]
						39, -- [2]
						40, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60969.896,
					["g"] = 0.7843137979507446,
					["b"] = 1,
				}, -- [127]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame9"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 1542,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[19:54:54]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["serverTime"] = 1709941979,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:52:51]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["g"] = 1,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973243,
					["b"] = 0.250980406999588,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:53:13]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Soîl:3:CHANNEL:2|h|cffaad372Soîl|r|h|cffd8d8d8]|r: anyone for |Hquestie:541:Player-5818-00A76E56|h|cFFFF1A1A[|r|cFFFF1A1A[30+] Battle of Hillsbrad|r|cFFFF1A1A]|r|h",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709942001,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:54:07]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942055,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:54:16]|h|r You loot 37 Copper",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942064,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:54:26]|h|r |cffd8d8d8[|r|Hplayer:Tpainwarpigs:15|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r has come online.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942074,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:54:32]|h|r |cffd8d8d8[|r|Hplayer:Tpainwarpigs:18|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r has invited you to join a group.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942080,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:54:34]|h|r Dungeon difficulty set to Normal",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942082,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:54:58]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942106,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:01]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942109,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:12]|h|r Your share of the loot is 39 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942120,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:22]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942130,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:22]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942130,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:25]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942133,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:26]|h|r Shazzah joins the party.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942134,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:26]|h|r Interface action failed because of an AddOn",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709942134,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:26]|h|r Your share of the loot is 16 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942134,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:40]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Soîl-Shadowstrike(AU):43:CHANNEL:2|h|cffaad372Soîl|r|h|cffd8d8d8]|r: LFM |Hquestie:541:Player-5818-00A76E56|h|cFFFF1A1A[|r|cFFFF1A1A[30+] Battle of Hillsbrad|r|cFFFF1A1A]|r|h",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709942148,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:42]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942150,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:43]|h|r |HlootHistory:1|h[Loot]|h: |cff1eff00|Hitem:6580::::::1191:1447216896:25:::::::::|h[Defender Tunic of the Bear]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942151,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:44]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:211853::::::::25:::::::::|h[Scroll: VOCE WELL]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942152,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:44]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:4538::::::::25:::::::::|h[Snapvine Watermelon]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942152,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:44]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942152,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:45]|h|r Your share of the loot is 46 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942153,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:45]|h|r |HlootHistory:1|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Greed for: |cff1eff00|Hitem:6580::::::1191:1447216896:25:::::::::|h[Defender Tunic of the Bear]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942153,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:48]|h|r |HlootHistory:1|h[Loot]|h: |cff0070ddShazzah|r has selected Greed for: |cff1eff00|Hitem:6580::::::1191:1447216896:25:::::::::|h[Defender Tunic of the Bear]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942156,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:52]|h|r |HlootHistory:1|h[Loot]|h: You have selected Greed for: |cff1eff00|Hitem:6580::::::1191:1447216896:25:::::::::|h[Defender Tunic of the Bear]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942160,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:52]|h|r |HlootHistory:1|h[Loot]|h: Greed Roll - 57 for |cff1eff00|Hitem:6580::::::1191:1447216896:25:::::::::|h[Defender Tunic of the Bear]|h|r by |cff00ff00Lavy|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942160,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:52]|h|r |HlootHistory:1|h[Loot]|h: Greed Roll - 89 for |cff1eff00|Hitem:6580::::::1191:1447216896:25:::::::::|h[Defender Tunic of the Bear]|h|r by |cff0070ddShazzah|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942160,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:52]|h|r |HlootHistory:1|h[Loot]|h: Greed Roll - 13 for |cff1eff00|Hitem:6580::::::1191:1447216896:25:::::::::|h[Defender Tunic of the Bear]|h|r by |cff0070ddTpainwarpigs|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942160,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:52]|h|r |HlootHistory:1|h[Loot]|h: |cff0070ddShazzah|r won: |cff1eff00|Hitem:6580::::::1191:1447216896:25:::::::::|h[Defender Tunic of the Bear]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942160,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:55:53]|h|r |cff0070ddShazzah|r receives loot: |cff1eff00|Hitem:6580::::::1191:1447216896:25:::::::::|h[Defender Tunic of the Bear]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942161,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:56:18]|h|r |cff0070ddShazzah|r receives loot: |cff9d9d9d|Hitem:1485::::::::25:::::::::|h[Pitchfork]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942186,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:56:18]|h|r Your share of the loot is 12 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942186,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:56:20]|h|r You receive loot: |cffffffff|Hitem:2592::::::::25:::::::::|h[Wool Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942188,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:56:21]|h|r Your share of the loot is 41 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942189,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:56:39]|h|r You receive loot: |cff9d9d9d|Hitem:1485::::::::25:::::::::|h[Pitchfork]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942207,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:56:39]|h|r You receive loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942207,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:56:39]|h|r |cff0070ddShazzah|r receives loot: |cffffffff|Hitem:2592::::::::25:::::::::|h[Wool Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942207,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:56:40]|h|r Your share of the loot is 24 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942208,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:56:49]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942217,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:56:54]|h|r Your share of the loot is 28 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942222,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:57:05]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942233,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:57:06]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942234,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:57:08]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942236,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:57:09]|h|r Your share of the loot is 32 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942237,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:57:12]|h|r Your share of the loot is 28 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942240,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:57:14]|h|r |cff0070ddShazzah|r receives loot: |cffffffff|Hitem:929::::::::25:::::::::|h[Healing Potion]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942242,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [48]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:57:14]|h|r Your share of the loot is 11 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942242,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [49]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:57:23]|h|r Stanley sniffs the elixir then eagerly digs in!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942251,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [50]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:57:42]|h|r |cff0070ddShazzah|r receives loot: |cffffffff|Hitem:2318::::::::25:::::::::|h[Light Leather]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942270,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [51]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:57:58]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942286,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [52]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:58:11]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942299,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [53]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:58:16]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942304,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [54]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:58:23]|h|r You receive loot: |cffffffff|Hitem:422::::::::25:::::::::|h[Dwarven Mild]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942311,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [55]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:58:23]|h|r You receive loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942311,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [56]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:58:24]|h|r |cff0070ddShazzah|r receives loot: |cffffffff|Hitem:2592::::::::25:::::::::|h[Wool Cloth]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942312,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [57]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:58:24]|h|r Your share of the loot is 36 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942312,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [58]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:58:28]|h|r Your share of the loot is 12 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942316,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [59]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:58:30]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:4306::::::::25:::::::::|h[Silk Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942318,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [60]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:58:30]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942318,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [61]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:58:31]|h|r Your share of the loot is 21 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942319,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [62]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:58:55]|h|r |cff0070ddShazzah|r receives loot: |cff9d9d9d|Hitem:1485::::::::25:::::::::|h[Pitchfork]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942343,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [63]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:58:56]|h|r Your share of the loot is 15 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942344,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [64]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:59:19]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942367,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [65]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:59:24]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942372,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [66]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:59:30]|h|r |cff0070ddShazzah|r receives loot: |cffffffff|Hitem:2592::::::::25:::::::::|h[Wool Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942378,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [67]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:59:31]|h|r Your share of the loot is 21 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942379,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [68]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:59:48]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942396,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [69]
				{
					["message"] = "|cff979797|Hpratcopy|h[09:59:49]|h|r Your share of the loot is 33 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942397,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [70]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:03]|h|r Citizen Wilkes attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942411,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [71]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:15]|h|r Hillsbrad Footman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942423,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [72]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:17]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942425,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [73]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:21]|h|r Hillsbrad Footman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942429,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [74]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:27]|h|r Hillsbrad Councilman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942435,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [75]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:30]|h|r Your share of the loot is 13 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942438,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [76]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:41]|h|r You receive loot: |cffffffff|Hitem:2589::::::::25:::::::::|h[Linen Cloth]|h|rx3.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942449,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [77]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:42]|h|r Your share of the loot is 29 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942450,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [78]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:45]|h|r You create: |cffffffff|Hitem:6265::::::::25:::::::::|h[Soul Shard]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942453,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [79]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:47]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:422::::::::25:::::::::|h[Dwarven Mild]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942455,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [80]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:48]|h|r Your share of the loot is 14 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942456,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [81]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:51]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:1485::::::::25:::::::::|h[Pitchfork]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942459,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [82]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:52]|h|r Your share of the loot is 24 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942460,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [83]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:54]|h|r Your share of the loot is 6 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942462,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [84]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:56]|h|r |HlootHistory:2|h[Loot]|h: |cff1eff00|Hitem:211838::::::::25:::::::::|h[Waylaid Supplies: Heavy Wool Bandages]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942464,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [85]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:57]|h|r |cff0070ddShazzah|r receives loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942465,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [86]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:57]|h|r |cff0070ddShazzah|r receives loot: |cffffffff|Hitem:2592::::::::25:::::::::|h[Wool Cloth]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942465,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [87]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:58]|h|r Your share of the loot is 38 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942466,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [88]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:00:59]|h|r |HlootHistory:2|h[Loot]|h: You have selected Need for: |cff1eff00|Hitem:211838::::::::25:::::::::|h[Waylaid Supplies: Heavy Wool Bandages]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942467,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [89]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:03]|h|r |HlootHistory:2|h[Loot]|h: |cff0070ddShazzah|r has selected Greed for: |cff1eff00|Hitem:211838::::::::25:::::::::|h[Waylaid Supplies: Heavy Wool Bandages]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942471,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [90]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:18]|h|r |HlootHistory:2|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Greed for: |cff1eff00|Hitem:211838::::::::25:::::::::|h[Waylaid Supplies: Heavy Wool Bandages]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942486,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [91]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:18]|h|r |HlootHistory:2|h[Loot]|h: Need Roll - 47 for |cff1eff00|Hitem:211838::::::::25:::::::::|h[Waylaid Supplies: Heavy Wool Bandages]|h|r by |cff00ff00Lavy|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942486,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [92]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:18]|h|r |HlootHistory:2|h[Loot]|h: You won: |cff1eff00|Hitem:211838::::::::25:::::::::|h[Waylaid Supplies: Heavy Wool Bandages]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942486,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [93]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:18]|h|r You receive loot: |cff1eff00|Hitem:211838::::::::25:::::::::|h[Waylaid Supplies: Heavy Wool Bandages]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942486,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [94]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:20]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942488,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [95]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:29]|h|r You receive loot: |cffffffff|Hitem:2592::::::::25:::::::::|h[Wool Cloth]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942497,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [96]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:29]|h|r You receive loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942497,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [97]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:29]|h|r Your share of the loot is 30 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942497,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [98]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:30]|h|r Your share of the loot is 30 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942498,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [99]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:33]|h|r You receive loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942501,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [100]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:34]|h|r Your share of the loot is 18 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942502,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [101]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:35]|h|r Hillsbrad Footman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942503,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [102]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:36]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942504,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [103]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:37]|h|r Your share of the loot is 25 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942505,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [104]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:01:57]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942525,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [105]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:02:00]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942528,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [106]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:02:05]|h|r Your share of the loot is 5 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942533,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [107]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:02:05]|h|r You receive loot: |cffffffff|Hitem:2592::::::::25:::::::::|h[Wool Cloth]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942533,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [108]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:02:05]|h|r You receive loot: |cffffffff|Hitem:422::::::::25:::::::::|h[Dwarven Mild]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942533,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [109]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:02:06]|h|r Your share of the loot is 30 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942534,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [110]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:02:10]|h|r Your share of the loot is 13 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942538,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [111]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:02:24]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942552,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [112]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:02:29]|h|r Your share of the loot is 23 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942557,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [113]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:02:30]|h|r You receive loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942558,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [114]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:02:31]|h|r Your share of the loot is 24 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942559,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [115]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:02:44]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942572,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [116]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:02:58]|h|r You create: |cffffffff|Hitem:6265::::::::25:::::::::|h[Soul Shard]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942586,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [117]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:02:59]|h|r Your share of the loot is 23 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942587,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [118]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:03:01]|h|r |cff0070ddShazzah|r receives loot: |cffffffff|Hitem:2592::::::::25:::::::::|h[Wool Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942589,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [119]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:03:02]|h|r Your share of the loot is 13 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942590,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [120]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:03:02]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942590,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [121]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:03:03]|h|r Your share of the loot is 19 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942591,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [122]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:03:05]|h|r You receive loot: |cffffffff|Hitem:4306::::::::25:::::::::|h[Silk Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942593,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [123]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:03:05]|h|r You receive loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942593,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [124]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:03:06]|h|r Your share of the loot is 12 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942594,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [125]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:03:26]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942614,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [126]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:03:31]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942619,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [127]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:03:49]|h|r Hillsbrad Footman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942637,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [128]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:03:49]|h|r You feel normal.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942637,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [129]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:03:59]|h|r Your share of the loot is 36 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942647,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [130]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:03:59]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2589::::::::25:::::::::|h[Linen Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942647,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [131]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:03:59]|h|r |cff0070ddShazzah|r receives loot: |cffffffff|Hitem:422::::::::25:::::::::|h[Dwarven Mild]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942647,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [132]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:04:00]|h|r Your share of the loot is 24 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942648,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [133]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:04:00]|h|r You receive loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942648,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [134]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:04:01]|h|r Your share of the loot is 40 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942649,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [135]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:04:09]|h|r Your share of the loot is 10 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942657,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [136]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:04:34]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942682,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [137]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:04:37]|h|r Your share of the loot is 8 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942685,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [138]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:04:44]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Hugs:386:CHANNEL:4|h|cff8787edHugs|r|h|cffd8d8d8]|r: LFG |Hquestie:1051:Player-5818-009BBD32|h|cFFFF1A1A[|r|cFFFF1A1A[33+] Vorrel's Revenge|r|cFFFF1A1A]|r|h",
					["extraData"] = {
						73, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709942692,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [139]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:04:49]|h|r Hillsbrad Tailor attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942697,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [140]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:04:50]|h|r Hillsbrad Tailor attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942698,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [141]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:04:51]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942699,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [142]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:04:52]|h|r Your share of the loot is 16 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942700,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [143]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:04:54]|h|r You receive loot: |cffffffff|Hitem:2592::::::::25:::::::::|h[Wool Cloth]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942702,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [144]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:04:54]|h|r You receive loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942702,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [145]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:04:55]|h|r Your share of the loot is 7 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942703,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [146]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:05:15]|h|r Hillsbrad Footman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942723,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [147]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:05:20]|h|r Your share of the loot is 15 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942728,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [148]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:05:28]|h|r You receive loot: |cffffffff|Hitem:2592::::::::25:::::::::|h[Wool Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942736,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [149]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:05:29]|h|r Your share of the loot is 8 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942737,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [150]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:06:22]|h|r Hillsbrad Councilman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942790,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [151]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:06:27]|h|r Your share of the loot is 29 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942795,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [152]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:06:30]|h|r Your skill in Wands has increased to 125.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942798,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [153]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:06:33]|h|r Hillsbrad Footman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942801,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [154]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:06:41]|h|r |cff0070ddShazzah|r has died.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942809,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [155]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:06:43]|h|r Hillsbrad Footman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942811,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [156]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:06:46]|h|r You receive loot: |cffffffff|Hitem:4306::::::::25:::::::::|h[Silk Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942814,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [157]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:06:46]|h|r You receive loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942814,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [158]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:06:47]|h|r Your share of the loot is 19 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942815,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [159]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:07:09]|h|r Your skill in Defense has increased to 106.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942837,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [160]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:07:26]|h|r Hillsbrad Footman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942854,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [161]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:07:31]|h|r Your share of the loot is 59 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942859,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [162]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:07:49]|h|r [S] |cffd8d8d8[|r|Hplayer:Ketamíne-Shadowstrike(AU):491:SAY|h|cffd8d83f24|r:|cffffffffKetamíne|r|h|cffd8d8d8]|r: inv",
					["extraData"] = {
						2, -- [1]
						21, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942877,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [163]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:07:52]|h|r Citizen Wilkes attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942880,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [164]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:07:54]|h|r |cffffffffKetamíne|r joins the party.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942882,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [165]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:08:00]|h|r [S] |cffd8d8d8[|r|Hplayer:Ketamíne-Shadowstrike(AU):497:SAY|h|cffd8d83f24|r:|cffffffffKetamíne|r|h|cffd8d8d8]|r: ty <3",
					["extraData"] = {
						2, -- [1]
						21, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942888,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [166]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:08:08]|h|r [S] |cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):498:SAY|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: ez",
					["extraData"] = {
						2, -- [1]
						21, -- [2]
						23, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942896,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [167]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:08:10]|h|r |cffffffffKetamíne|r leaves the party.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942898,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [168]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:08:12]|h|r [S] |cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):500:SAY|h|cffd8d83f25|r:|cff8787edLavy|r|h|cffd8d8d8]|r: <3",
					["extraData"] = {
						2, -- [1]
						21, -- [2]
						24, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709942900,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [169]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:08:22]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Pkmnmaster-Shadowstrike(AU):504:CHANNEL:2|h|cffaad372Pkmnmaster|r|h|cffd8d8d8]|r: lfm |Hquestie:547:Player-5818-00A2DAB7|h|cFFFF1A1A[|r|cFFFF1A1A[30+] Humbert's Sword|r|cFFFF1A1A]|r|h",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						25, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709942910,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [170]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:08:28]|h|r You receive loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942916,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [171]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:08:29]|h|r Your share of the loot is 26 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942917,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [172]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:08:32]|h|r Your share of the loot is 49 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942920,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [173]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:08:32]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942920,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [174]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:08:33]|h|r Your share of the loot is 9 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942921,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [175]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:08:48]|h|r Hillsbrad Councilman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942936,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [176]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:08:54]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942942,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [177]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:08:56]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942944,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [178]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:02]|h|r You receive loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942950,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [179]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:03]|h|r Your share of the loot is 11 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942951,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [180]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:03]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:422::::::::25:::::::::|h[Dwarven Mild]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942951,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [181]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:04]|h|r Your share of the loot is 34 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942952,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [182]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:05]|h|r |cff0070ddShazzah|r receives loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942953,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [183]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:05]|h|r Your share of the loot is 8 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942953,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [184]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:10]|h|r You receive loot: |cffffffff|Hitem:2592::::::::25:::::::::|h[Wool Cloth]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942958,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [185]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:11]|h|r Your share of the loot is 37 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942959,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [186]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:24]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2589::::::::25:::::::::|h[Linen Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942972,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [187]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:25]|h|r Your share of the loot is 15 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942973,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [188]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:30]|h|r Hillsbrad Footman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942978,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [189]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:34]|h|r Hillsbrad Footman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709942982,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [190]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:37]|h|r You receive loot: |cffffffff|Hitem:2592::::::::25:::::::::|h[Wool Cloth]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942985,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [191]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:37]|h|r You receive loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942985,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [192]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:38]|h|r Your share of the loot is 39 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942986,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [193]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:40]|h|r |cff0070ddShazzah|r receives loot: |cffffffff|Hitem:2589::::::::25:::::::::|h[Linen Cloth]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942988,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [194]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:09:40]|h|r Your share of the loot is 20 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709942988,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [195]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:07]|h|r Hillsbrad Footman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709943015,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [196]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:08]|h|r Hillsbrad Footman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709943016,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [197]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:08]|h|r Hillsbrad Councilman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709943016,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [198]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:23]|h|r Your share of the loot is 40 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943031,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [199]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:26]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943034,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [200]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:27]|h|r Your share of the loot is 35 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943035,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [201]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:33]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:4306::::::::25:::::::::|h[Silk Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943041,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [202]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:34]|h|r Your share of the loot is 19 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943042,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [203]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:47]|h|r Hillsbrad Footman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709943055,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [204]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:10:50]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Thîef:618:CHANNEL:4|h|cfffff468Thîef|r|h|cffd8d8d8]|r: dps lfg sfk",
					["extraData"] = {
						73, -- [1]
						16, -- [2]
						27, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709943058,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [205]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:11:10]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709943078,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [206]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:11:15]|h|r |cff0070ddShazzah|r receives loot: |cffffffff|Hitem:2592::::::::25:::::::::|h[Wool Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943083,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [207]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:11:16]|h|r Your share of the loot is 35 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943084,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [208]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:11:31]|h|r Hillsbrad Footman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709943099,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [209]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:11:35]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::25:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943103,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [210]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:11:36]|h|r Your share of the loot is 18 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943104,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [211]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:11:38]|h|r Your share of the loot is 41 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943106,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [212]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:11:45]|h|r |cff0070ddShazzah|r leaves the party.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943113,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [213]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:11:52]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709943120,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [214]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:12:02]|h|r Your share of the loot is 23 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943130,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [215]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:12:36]|h|r Hillsbrad Footman attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709943164,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [216]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:12:38]|h|r |cff8787edHoused|r has gone offline.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943166,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [217]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:13:32]|h|r Pizpep says: [Demonic] Tor gul O rikk ul maz gular parn ante kanrethad, kazile archim gul o kieldaz?",
					["extraData"] = {
						13, -- [1]
						29, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["b"] = 0.6235294342041016,
					["serverTime"] = 1709943220,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [218]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:13:37]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3496::::::::25:::::::::|h[Mountain Lion Blood]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943225,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [219]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:10]|h|r Congratulations, you have reached level 26!",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709943258,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [220]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:10]|h|r You have gained 24 hit points and 47 mana.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709943258,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [221]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:10]|h|r You have gained 1 talent point.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709943258,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [222]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:10]|h|r Your Stamina increases by 1.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709943258,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [223]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:10]|h|r Your Intellect increases by 1.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709943258,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [224]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:10]|h|r Your Spirit increases by 1.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709943258,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [225]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:11]|h|r Your skill in Destruction has increased to 130.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943259,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [226]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:11]|h|r Your skill in Demonology has increased to 130.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943259,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [227]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:11]|h|r Your skill in Affliction has increased to 130.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943259,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [228]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:11]|h|r You create: |cffffffff|Hitem:6265::::::::26:::::::::|h[Soul Shard]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943259,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [229]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:11]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3730::::::::26:::::::::|h[Big Bear Meat]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943259,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [230]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:15]|h|r You receive loot: |cff9d9d9d|Hitem:5135::::::::26:::::::::|h[Thin Black Claw]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943263,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [231]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:15]|h|r You receive loot: |cffffffff|Hitem:3731::::::::26:::::::::|h[Lion Meat]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943263,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [232]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:42]|h|r You create: |cffffffff|Hitem:5511::::::::26:::::::::|h[Lesser Healthstone]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943290,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [233]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:14:54]|h|r You have requested to trade with |cff0070ddTpainwarpigs|r.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943302,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [234]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:15:09]|h|r You create: |cffffffff|Hitem:5511::::::::26:::::::::|h[Lesser Healthstone]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943317,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [235]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:15:23]|h|r You receive loot: |cff9d9d9d|Hitem:5136::::::::26:::::::::|h[Torn Furry Ear]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943331,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [236]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:15:44]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3730::::::::26:::::::::|h[Big Bear Meat]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943352,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [237]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:16:15]|h|r Your skill in Wands has increased to 126.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943383,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [238]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:16:24]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3496::::::::26:::::::::|h[Mountain Lion Blood]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943392,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [239]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:16:25]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:2940::::::::26:::::::::|h[Bloody Bear Paw]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943393,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [240]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:16:25]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:11407::::::::26:::::::::|h[Torn Bear Pelt]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943393,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [241]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:16:27]|h|r You receive loot: |cffffffff|Hitem:3476::::::::26:::::::::|h[Gray Bear Tongue]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943395,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [242]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:16:38]|h|r You receive loot: |cffffffff|Hitem:3496::::::::26:::::::::|h[Mountain Lion Blood]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943406,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [243]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:16:54]|h|r You receive loot: |cffffffff|Hitem:3476::::::::26:::::::::|h[Gray Bear Tongue]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943422,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [244]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:17:06]|h|r Your skill in Defense has increased to 107.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943434,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [245]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:17:20]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:11406::::::::26:::::::::|h[Rotting Bear Carcass]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943448,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [246]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:17:24]|h|r You receive loot: |cffffffff|Hitem:11407::::::::26:::::::::|h[Torn Bear Pelt]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943452,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [247]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:17:24]|h|r You receive loot: |cffffffff|Hitem:3730::::::::26:::::::::|h[Big Bear Meat]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943452,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [248]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:17:38]|h|r Your skill in Wands has increased to 127.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943466,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [249]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:17:47]|h|r You receive loot: |cff9d9d9d|Hitem:11406::::::::26:::::::::|h[Rotting Bear Carcass]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943475,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [250]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:17:47]|h|r You receive loot: |cffffffff|Hitem:3730::::::::26:::::::::|h[Big Bear Meat]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943475,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [251]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:18:08]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:11406::::::::26:::::::::|h[Rotting Bear Carcass]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943496,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [252]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:18:08]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:3702::::::::26:::::::::|h[Bear Gall Bladder]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943496,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [253]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:18:10]|h|r You receive loot: |cffffffff|Hitem:3476::::::::26:::::::::|h[Gray Bear Tongue]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943498,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [254]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:18:48]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:2940::::::::26:::::::::|h[Bloody Bear Paw]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943536,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [255]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:18:48]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3730::::::::26:::::::::|h[Big Bear Meat]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943536,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [256]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:18:50]|h|r You receive loot: |cffffffff|Hitem:3476::::::::26:::::::::|h[Gray Bear Tongue]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943538,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [257]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:19:07]|h|r You receive loot: |cff9d9d9d|Hitem:5135::::::::26:::::::::|h[Thin Black Claw]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943555,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [258]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:19:25]|h|r Your skill in Wands has increased to 128.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943573,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [259]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:19:48]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:11406::::::::26:::::::::|h[Rotting Bear Carcass]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943596,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [260]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:20:14]|h|r Your skill in Defense has increased to 108.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943622,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [261]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:20:25]|h|r You receive loot: |cffffffff|Hitem:3730::::::::26:::::::::|h[Big Bear Meat]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943633,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [262]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:20:32]|h|r Pizpep says: Just release me already! I've had enough!",
					["extraData"] = {
						13, -- [1]
						29, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["b"] = 0.6235294342041016,
					["serverTime"] = 1709943640,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [263]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:21:53]|h|r You receive loot: |cff9d9d9d|Hitem:2940::::::::26:::::::::|h[Bloody Bear Paw]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943721,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [264]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:21:53]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:5136::::::::26:::::::::|h[Torn Furry Ear]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943721,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [265]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:22:05]|h|r |cff3fc6eaMikeg|r has gone offline.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943733,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [266]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:22:28]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:2940::::::::26:::::::::|h[Bloody Bear Paw]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943756,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [267]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:22:28]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3730::::::::26:::::::::|h[Big Bear Meat]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943756,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [268]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:23:05]|h|r You receive loot: |cffffffff|Hitem:3496::::::::26:::::::::|h[Mountain Lion Blood]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943793,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [269]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:23:29]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:2940::::::::26:::::::::|h[Bloody Bear Paw]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943817,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [270]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:23:30]|h|r You create: |cffffffff|Hitem:6265::::::::26:::::::::|h[Soul Shard]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943818,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [271]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:23:34]|h|r You receive loot: |cff9d9d9d|Hitem:5136::::::::26:::::::::|h[Torn Furry Ear]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943822,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [272]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:23:34]|h|r You receive loot: |cffffffff|Hitem:3496::::::::26:::::::::|h[Mountain Lion Blood]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943822,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [273]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:23:59]|h|r |cffd8d8d8[|r|Hplayer:Mikeg:854|h|cffd84e4e40|r:|cff3fc6eaMikeg|r|h|cffd8d8d8]|r has come online.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943847,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [274]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:24:26]|h|r You receive loot: |cffffffff|Hitem:3730::::::::26:::::::::|h[Big Bear Meat]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943874,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [275]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:24:54]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3730::::::::26:::::::::|h[Big Bear Meat]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943902,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [276]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:24:54]|h|r You receive loot: |cff9d9d9d|Hitem:11406::::::::26:::::::::|h[Rotting Bear Carcass]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943902,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [277]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:24:54]|h|r You receive loot: |cffffffff|Hitem:11407::::::::26:::::::::|h[Torn Bear Pelt]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709943902,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [278]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:24:59]|h|r Helcular's Remains yells: Southshore shall pay in blood!",
					["extraData"] = {
						15, -- [1]
						31, -- [2]
						32, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709943907,
					["timestamp"] = 60064.747,
					["g"] = 0.250980406999588,
					["r"] = 1,
				}, -- [279]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:25:37]|h|r Your skill in Defense has increased to 109.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943945,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [280]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:25:54]|h|r Your skill in Wands has increased to 129.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709943962,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [281]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:26:37]|h|r Your skill in Defense has increased to 110.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709944005,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [282]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:26:40]|h|r You receive loot: |cff9d9d9d|Hitem:5136::::::::26:::::::::|h[Torn Furry Ear]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944008,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [283]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:27:04]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:2940::::::::26:::::::::|h[Bloody Bear Paw]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944032,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [284]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:27:34]|h|r You receive loot: |cff9d9d9d|Hitem:2940::::::::26:::::::::|h[Bloody Bear Paw]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944062,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [285]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:27:34]|h|r You receive loot: |cffffffff|Hitem:11407::::::::26:::::::::|h[Torn Bear Pelt]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944062,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [286]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:28:19]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:11406::::::::26:::::::::|h[Rotting Bear Carcass]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944107,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [287]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:28:20]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:5136::::::::26:::::::::|h[Torn Furry Ear]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944108,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [288]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:28:20]|h|r You receive loot: |cff9d9d9d|Hitem:5136::::::::26:::::::::|h[Torn Furry Ear]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944108,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [289]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:28:20]|h|r You receive loot: |cffffffff|Hitem:3496::::::::26:::::::::|h[Mountain Lion Blood]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944108,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [290]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:28:51]|h|r [Y] |cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):930:YELL|h|cffd8d83f26|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: ty",
					["extraData"] = {
						7, -- [1]
						33, -- [2]
						34, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709944139,
					["timestamp"] = 60064.747,
					["g"] = 0.250980406999588,
					["r"] = 1,
				}, -- [291]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:28:57]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:2940::::::::26:::::::::|h[Bloody Bear Paw]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944145,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [292]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:28:57]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3730::::::::26:::::::::|h[Big Bear Meat]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944145,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [293]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:28:59]|h|r You receive loot: |cffffffff|Hitem:3476::::::::26:::::::::|h[Gray Bear Tongue]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944147,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [294]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:29:00]|h|r You receive loot: |cff9d9d9d|Hitem:3702::::::::26:::::::::|h[Bear Gall Bladder]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944148,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [295]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:29:00]|h|r You receive loot: |cffffffff|Hitem:3730::::::::26:::::::::|h[Big Bear Meat]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944148,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [296]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:29:00]|h|r You receive loot: |cffffffff|Hitem:3476::::::::26:::::::::|h[Gray Bear Tongue]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944148,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [297]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:29:22]|h|r Pizpep says: [Demonic] Tor gul O rikk ul maz gular parn ante kanrethad, kazile archim gul o kieldaz?",
					["extraData"] = {
						13, -- [1]
						29, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["b"] = 0.6235294342041016,
					["serverTime"] = 1709944170,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [298]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:29:29]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Minacious-Shadowstrike(AU):945:CHANNEL:2|h|cffaad372Minacious|r|h|cffd8d8d8]|r: |Hquestie:547:Player-5818-00A962B8|h|cFFFF8040[|r|cFFFF8040[30+] Humbert's Sword|r|cFFFF8040]|r|h anyone?",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						35, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709944177,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [299]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:29:32]|h|r Your skill in Defense has increased to 111.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709944180,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [300]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:29:52]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Mikeg-Shadowstrike(AU):952:GUILD|h|cffd84e4e40|r:|cff3fc6eaMikeg|r|h|cffd8d8d8]|r: [NWB] Stranglethorn event starts in 30 minutes.",
					["extraData"] = {
						5, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709944200,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 0.250980406999588,
				}, -- [301]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:30:17]|h|r You receive loot: |cff9d9d9d|Hitem:11406::::::::26:::::::::|h[Rotting Bear Carcass]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944225,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [302]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:30:17]|h|r You receive loot: |cffffffff|Hitem:3476::::::::26:::::::::|h[Gray Bear Tongue]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944225,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [303]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:32:03]|h|r You create: |cffffffff|Hitem:6265::::::::26:::::::::|h[Soul Shard]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944331,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [304]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:32:04]|h|r You receive loot: |cffffffff|Hitem:3730::::::::26:::::::::|h[Big Bear Meat]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709944332,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [305]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:38:27]|h|r Pizpep says: This better be the last one!",
					["extraData"] = {
						13, -- [1]
						29, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["b"] = 0.6235294342041016,
					["serverTime"] = 1709944715,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [306]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:38:37]|h|r Your skill in Defense has increased to 112.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709944725,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [307]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:39:13]|h|r [S] |cffd8d8d8[|r|Hplayer:Hughiegods-Shadowstrike(AU):1104:SAY|h|cffd8d83f26|r:|cff0070ddHughiegods|r|h|cffd8d8d8]|r: yummy",
					["extraData"] = {
						2, -- [1]
						21, -- [2]
						39, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709944761,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [308]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:39:17]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Bigpillies:1106:CHANNEL:2|h|cff0070ddBigpillies|r|h|cffd8d8d8]|r: druid Kitty in yeti caves",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						40, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709944765,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [309]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:39:23]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Bigpillies-Shadowstrike(AU):1107:CHANNEL:2|h|cff0070ddBigpillies|r|h|cffd8d8d8]|r: KoS\\",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						40, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709944771,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [310]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:39:43]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Minacious-Shadowstrike(AU):1114:CHANNEL:2|h|cffaad372Minacious|r|h|cffd8d8d8]|r: what lvl",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						35, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709944791,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [311]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:39:46]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Bigpillies-Shadowstrike(AU):1116:CHANNEL:2|h|cff0070ddBigpillies|r|h|cffd8d8d8]|r: 37",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						40, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709944794,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [312]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:41:32]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Minacious-Shadowstrike(AU):1145:CHANNEL:2|h|cffaad372Minacious|r|h|cffd8d8d8]|r: LFM |Hquestie:547:Player-5818-00A962B8|h|cFFFF8040[|r|cFFFF8040[30+] Humbert's Sword|r|cFFFF8040]|r|h",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						35, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709944900,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [313]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:44:02]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Feraldo:1190:CHANNEL:2|h|cffff7c0aFeraldo|r|h|cffd8d8d8]|r: anyone near thoradins wall who can help me for 2 minutes?",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						42, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945050,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [314]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:44:26]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Berzurk:1197:CHANNEL:2|h|cff0070ddBerzurk|r|h|cffd8d8d8]|r: anyone want to group for |Hquestie:552:Player-5818-00A9D89A|h|cFFFF1A1A[|r|cFFFF1A1A[33] Helcular's Revenge|r|cFFFF1A1A]|r|h?",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						44, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945074,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [315]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:44:51]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Mikeg-Shadowstrike(AU):1205:GUILD|h|cffd84e4e40|r:|cff3fc6eaMikeg|r|h|cffd8d8d8]|r: [NWB] Stranglethorn event starts in 15 minutes.",
					["extraData"] = {
						5, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709945099,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 0.250980406999588,
				}, -- [316]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:45:43]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Alterac Mountains]|h",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						46, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945151,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [317]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:45:43]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Alterac Mountains]|h",
					["extraData"] = {
						73, -- [1]
						16, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945151,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [318]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:46:41]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Tirisfal Glades]|h",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						46, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945209,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [319]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:46:41]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Tirisfal Glades]|h",
					["extraData"] = {
						73, -- [1]
						16, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945209,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [320]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:47:18]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Undercity]|h",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						46, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945246,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [321]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:47:18]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Undercity]|h",
					["extraData"] = {
						73, -- [1]
						16, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945246,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [322]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:47:22]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Tazlu-Shadowstrike(AU):1277:CHANNEL:3|h|cffc69b6dTazlu|r|h|cffd8d8d8]|r: DROP A BOON PLEASE",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945250,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [323]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:47:24]|h|r You feel rested.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709945252,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [324]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:47:35]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Kelanx:1280:CHANNEL:3|h|cffff7c0aKelanx|r|h|cffd8d8d8]|r: LF1M DPS BFD Quick XP Run",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						53, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945263,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [325]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:47:45]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Eirä:1289:CHANNEL:3|h|cffffffffEirä|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_6:0|t || Max Enchanter LFW. ALL recipes. Your mats or mine (for a cost). Pst || |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_6:0|t |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945273,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [326]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:48:12]|h|r [Y] |cffd8d8d8[|r|Hplayer:Floobs-Shadowstrike(AU):1299:YELL|h|cffff7c0aFloobs|r|h|cffd8d8d8]|r: wtb org port",
					["extraData"] = {
						7, -- [1]
						33, -- [2]
						57, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709945300,
					["timestamp"] = 60064.747,
					["g"] = 0.250980406999588,
					["r"] = 1,
				}, -- [327]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:49:46]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Soîl-Shadowstrike(AU):1377:CHANNEL:2|h|cffaad372Soîl|r|h|cffd8d8d8]|r: Any ports to org ::D",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945394,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [328]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:49:59]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Eirä-Shadowstrike(AU):1385:CHANNEL:3|h|cffffffffEirä|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_6:0|t || Max Enchanter LFW. ALL recipes. Your mats or mine (for a cost). Pst || |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_6:0|t |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945407,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [329]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:50:03]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Prejudice:1388:CHANNEL:3|h|cffffffffPrejudice|r|h|cffd8d8d8]|r: WTB Port from Org to UC",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						58, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945411,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [330]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:50:17]|h|r [Y] |cffd8d8d8[|r|Hplayer:Johnnyhoward-Shadowstrike(AU):1400:YELL|h|cff3fc6eaJohnnyhoward|r|h|cffd8d8d8]|r: Come get your El' Porto's! Message me (UC/Org)",
					["extraData"] = {
						7, -- [1]
						33, -- [2]
						60, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709945425,
					["timestamp"] = 60064.747,
					["g"] = 0.250980406999588,
					["r"] = 1,
				}, -- [331]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:50:17]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Johnnyhoward-Shadowstrike(AU):1401:CHANNEL:3|h|cff3fc6eaJohnnyhoward|r|h|cffd8d8d8]|r: Message me for El Porto's! (Cooking up UC or Org)",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						61, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945425,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [332]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:50:38]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Promage:1412:CHANNEL:3|h|cff3fc6eaPromage|r|h|cffd8d8d8]|r: SELLING PORTS!",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						63, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945446,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [333]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:51:40]|h|r You have learned a new spell: Corruption (Rank 3).",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709945508,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [334]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:51:40]|h|r You have learned a new spell: Drain Mana (Rank 1).",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709945508,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [335]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:51:40]|h|r You have learned a new spell: Drain Soul (Rank 2).",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709945508,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [336]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:51:40]|h|r You have learned a new spell: Curse of Tongues (Rank 1).",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709945508,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [337]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:51:40]|h|r You have learned a new spell: Life Tap (Rank 3).",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709945508,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [338]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:51:40]|h|r You have learned a new ability: Sense Demons.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709945508,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [339]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:51:40]|h|r You have learned a new spell: Detect Lesser Invisibility.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709945508,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [340]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:51:41]|h|r You have learned a new spell: Searing Pain (Rank 2).",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709945509,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [341]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:51:45]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Kolac:1437:CHANNEL:3|h|cffaad372Kolac|r|h|cffd8d8d8]|r: WTB port to TB 1g tip",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						65, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945513,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [342]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:52:26]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Kolac-Shadowstrike(AU):1444:CHANNEL:3|h|cffaad372Kolac|r|h|cffd8d8d8]|r: ty",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						65, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945554,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [343]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:52:35]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Promage-Shadowstrike(AU):1446:CHANNEL:3|h|cff3fc6eaPromage|r|h|cffd8d8d8]|r: SELLING PORTS!",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						63, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945563,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [344]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:52:39]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Johnnyhoward-Shadowstrike(AU):1447:CHANNEL:3|h|cff3fc6eaJohnnyhoward|r|h|cffd8d8d8]|r: Message me for El Porto's! (Cooking up UC or Org)",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						61, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945567,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [345]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:53:17]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Pells-Shadowstrike(AU):1459:CHANNEL:2|h|cffffffffPells|r|h|cffd8d8d8]|r: priest heals lf GNOMERANG GROUP",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						67, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945605,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [346]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:53:43]|h|r Your auction of |cffffffff|Hitem:4306::::::::26:::::::::|h[Silk Cloth]|h|r has sold for |cffffffff8|r|cffc7c7cfs|r |cffffffff63|r|cffeda55fc|r!",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709945631,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [347]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:54:43]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Barbatus:1483:CHANNEL:3|h|cffc69b6dBarbatus|r|h|cffd8d8d8]|r: Warrior lfg stv",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						69, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945691,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [348]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:54:50]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Marni:1489:CHANNEL:3|h|cffc69b6dMarni|r|h|cffd8d8d8]|r: Any RFC?",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						71, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945698,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [349]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:56:53]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Promage-Shadowstrike(AU):1523:CHANNEL:3|h|cff3fc6eaPromage|r|h|cffd8d8d8]|r: SELLING PORTS!",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						63, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945821,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [350]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:57:10]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Femaleqt:1527:CHANNEL:3|h|cffffffffFemaleqt|r|h|cffd8d8d8]|r: Max Enchanter with every recipe LFW Org.",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						73, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945838,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [351]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:57:25]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Brucejenner-Shadowstrike(AU):1529:CHANNEL:3|h|cffc69b6dBrucejenner|r|h|cffd8d8d8]|r: LF Enchanter in UC +5 to 2H",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						75, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945853,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [352]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:57:41]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Lootlord:1532:CHANNEL:3|h|cffc69b6dLootlord|r|h|cffd8d8d8]|r: WTS |cff0070dd|Hitem:2276::::::::39:::::::::|h[Swampwalker Boots]|h|r cheaper than AH",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						77, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945869,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [353]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:57:53]|h|r You create: |cffffffff|Hitem:5232::::::::26:::::::::|h[Minor Soulstone]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709945881,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [354]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:58:08]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Femaleqt-Shadowstrike(AU):1543:CHANNEL:3|h|cffffffffFemaleqt|r|h|cffd8d8d8]|r: Max Enchanter with every recipe LFW Org.",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						73, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945896,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [355]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:58:23]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Brucejenner-Shadowstrike(AU):1545:CHANNEL:3|h|cffc69b6dBrucejenner|r|h|cffd8d8d8]|r: LF Enchanter in UC +5 to 2H",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						75, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945911,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [356]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:58:34]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Bangtrollz-Shadowstrike(AU):1551:CHANNEL:3|h|cffd8d83f27|r:|cff0070ddBangtrollz|r|h|cffd8d8d8]|r: Sell |cff0070dd|Hitem:9392::::::::27:::::::::|h[Annealed Blade]|h|r",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						79, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945922,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [357]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:58:37]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Promage-Shadowstrike(AU):1552:CHANNEL:3|h|cff3fc6eaPromage|r|h|cffd8d8d8]|r: SELLING PORTS!",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						63, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945925,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [358]
				{
					["message"] = "|cff979797|Hpratcopy|h[10:59:00]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Femaleqt-Shadowstrike(AU):1558:CHANNEL:3|h|cffffffffFemaleqt|r|h|cffd8d8d8]|r: Max Enchanter with every recipe LFW Org.",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						73, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709945948,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [359]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:00:09]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Femaleqt-Shadowstrike(AU):1574:CHANNEL:3|h|cffffffffFemaleqt|r|h|cffd8d8d8]|r: Max Enchanter with every recipe LFW Org.",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						73, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946017,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [360]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:00:14]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Nra:1576:CHANNEL:3|h|cffffffffNra|r|h|cffd8d8d8]|r: Nra's Enchants || /w me !enchants || @ ORG|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8:0|t",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						81, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946022,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [361]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:01:00]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Bangtrollz-Shadowstrike(AU):1588:CHANNEL:3|h|cffd8d83f27|r:|cff0070ddBangtrollz|r|h|cffd8d8d8]|r: WTS |cff0070dd|Hitem:9392::::::::27:::::::::|h[Annealed Blade]|h|r",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						79, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946068,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [362]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:01:30]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Promage-Shadowstrike(AU):1595:CHANNEL:3|h|cff3fc6eaPromage|r|h|cffd8d8d8]|r: SELLING PORTS!",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						63, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946098,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [363]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:01:41]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Nra-Shadowstrike(AU):1598:CHANNEL:3|h|cffffffffNra|r|h|cffd8d8d8]|r: Nra's Enchants || /w me !enchants || @ ORG|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8:0|t",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						81, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946109,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [364]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:02:28]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Gustert-Shadowstrike(AU):1608:CHANNEL:3|h|cff8787edGustert|r|h|cffd8d8d8]|r: wtb port from tb to uc",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						83, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946156,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [365]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:12]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946260,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [366]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:13]|h|r Your skill in First Aid has increased to 99.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946261,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [367]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:15]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946263,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [368]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:18]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946266,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [369]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:19]|h|r Your skill in First Aid has increased to 100.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946267,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [370]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:22]|h|r Your skill in First Aid has increased to 101.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946270,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [371]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:22]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946270,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [372]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:25]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946273,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [373]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:25]|h|r Your skill in First Aid has increased to 102.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946273,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [374]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:28]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946276,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [375]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:31]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946279,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [376]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:31]|h|r Your skill in First Aid has increased to 103.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946279,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [377]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:34]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946282,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [378]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:37]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946285,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [379]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:37]|h|r Your skill in First Aid has increased to 104.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946285,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [380]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:40]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946288,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [381]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:40]|h|r Your skill in First Aid has increased to 105.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946288,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [382]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:43]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946291,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [383]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:43]|h|r Your skill in First Aid has increased to 106.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946291,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [384]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:46]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946294,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [385]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:46]|h|r Your skill in First Aid has increased to 107.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946294,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [386]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:49]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946297,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [387]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:50]|h|r Your skill in First Aid has increased to 108.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946298,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [388]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:52]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946300,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [389]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:52]|h|r Your skill in First Aid has increased to 109.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946300,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [390]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:55]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946303,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [391]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:55]|h|r Your skill in First Aid has increased to 110.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946303,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [392]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:04:58]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946306,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [393]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:01]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946309,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [394]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:02]|h|r Your skill in First Aid has increased to 111.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946310,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [395]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:04]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946312,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [396]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:05]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Promage-Shadowstrike(AU):1695:CHANNEL:3|h|cff3fc6eaPromage|r|h|cffd8d8d8]|r: SELLING PORTS!",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						63, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946313,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [397]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:05]|h|r Your skill in First Aid has increased to 112.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946313,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [398]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:08]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946316,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [399]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:08]|h|r Your skill in First Aid has increased to 113.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946316,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [400]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:09]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Uzi:1701:CHANNEL:3|h|cff3fc6eaUzi|r|h|cffd8d8d8]|r: LFW Ench - Portal UC/OG PM \"inv\" +3 agi cloak, dismantle, all recipes - freewater",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						85, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946317,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [401]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:11]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946319,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [402]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:13]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Frostpopz-Shadowstrike(AU):1705:CHANNEL:3|h|cff3fc6eaFrostpopz|r|h|cffd8d8d8]|r: Enchanter LFW All p2 enchants Including Dismantle 60-90 damage to Mech, Also selling 1g Ports",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						87, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946321,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [403]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:14]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946322,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [404]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:14]|h|r Your skill in First Aid has increased to 114.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946322,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [405]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:17]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946325,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [406]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:17]|h|r Your skill in First Aid has increased to 115.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946325,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [407]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:20]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946328,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [408]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:23]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946331,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [409]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:26]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946334,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [410]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:26]|h|r Your skill in First Aid has increased to 116.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946334,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [411]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:29]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946337,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [412]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:30]|h|r Your skill in First Aid has increased to 117.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946338,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [413]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:32]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946340,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [414]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:35]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946343,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [415]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:36]|h|r Your skill in First Aid has increased to 118.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946344,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [416]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:38]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946346,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [417]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:38]|h|r Your skill in First Aid has increased to 119.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946346,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [418]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:41]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946349,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [419]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:42]|h|r Your skill in First Aid has increased to 120.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946350,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [420]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:44]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946352,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [421]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:45]|h|r Your skill in First Aid has increased to 121.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946353,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [422]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:48]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946356,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [423]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:48]|h|r Your skill in First Aid has increased to 122.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946356,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [424]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:51]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946359,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [425]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:51]|h|r Your skill in First Aid has increased to 123.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946359,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [426]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:54]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946362,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [427]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:05:57]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946365,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [428]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:00]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946368,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [429]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:00]|h|r Your skill in First Aid has increased to 124.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946368,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [430]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:03]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946371,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [431]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:03]|h|r Your skill in First Aid has increased to 125.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946371,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [432]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:06]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946374,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [433]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:06]|h|r Your skill in First Aid has increased to 126.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946374,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [434]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:09]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946377,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [435]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:09]|h|r Your skill in First Aid has increased to 127.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946377,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [436]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:12]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946380,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [437]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:12]|h|r Your skill in First Aid has increased to 128.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946380,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [438]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:15]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946383,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [439]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:15]|h|r Your skill in First Aid has increased to 129.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709946383,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [440]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:18]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946386,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [441]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:21]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946389,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [442]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:24]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946392,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [443]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:27]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946395,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [444]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:30]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946398,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [445]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:34]|h|r You create: |cffffffff|Hitem:3530::::::::26:::::::::|h[Wool Bandage]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946402,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [446]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:06:55]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Roknfok:1801:CHANNEL:3|h|cff8787edRoknfok|r|h|cffd8d8d8]|r: lfg sm gy/lib dps",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						89, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946423,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [447]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:07:00]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Nra-Shadowstrike(AU):1802:CHANNEL:3|h|cffffffffNra|r|h|cffd8d8d8]|r: Nra's Enchants || /w me !enchants || @ ORG|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8:0|t",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						81, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946428,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [448]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:07:11]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Promage-Shadowstrike(AU):1804:CHANNEL:3|h|cff3fc6eaPromage|r|h|cffd8d8d8]|r: SELLING PORTS!",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						63, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946439,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [449]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:07:25]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Uzi-Shadowstrike(AU):1808:CHANNEL:3|h|cff3fc6eaUzi|r|h|cffd8d8d8]|r: LFW Ench - Portal UC/OG PM \"inv\" +3 agi cloak, dismantle, all recipes - freewater",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						85, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946453,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [450]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:10:01]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Roknfok-Shadowstrike(AU):1835:CHANNEL:3|h|cff8787edRoknfok|r|h|cffd8d8d8]|r: lfg sm gy/lib dps",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						89, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946609,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [451]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:10:03]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Uzi-Shadowstrike(AU):1837:CHANNEL:3|h|cff3fc6eaUzi|r|h|cffd8d8d8]|r: LFW Ench - Portal UC/OG PM \"inv\" +3 agi cloak, dismantle, all recipes - freewater",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						85, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946611,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [452]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:10:05]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Promage-Shadowstrike(AU):1838:CHANNEL:3|h|cff3fc6eaPromage|r|h|cffd8d8d8]|r: SELLING PORTS!",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						63, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946613,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [453]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:11:16]|h|r Bid accepted.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946684,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [454]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:11:17]|h|r You won an auction for |cffffffff|Hitem:929::::::::26:::::::::|h[Healing Potion]|h|rx1 for |cffffffff3|r|cffc7c7cfs|r |cffffffff10|r|cffeda55fc|r",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946685,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [455]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:11:30]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fuentes-Shadowstrike(AU):1884:CHANNEL:2|h|cff3fc6eaFuentes|r|h|cffd8d8d8]|r: LF1M Arms/Cath Spellcleave Healer or DPS",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						91, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946698,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [456]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:11:50]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Uzi-Shadowstrike(AU):1899:CHANNEL:3|h|cff3fc6eaUzi|r|h|cffd8d8d8]|r: LFW Ench - Portal UC/OG PM \"inv\" +3 agi cloak, dismantle, all recipes - freewater",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						85, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946718,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [457]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:12:12]|h|r You receive item: |cffffffff|Hitem:4238::::::::26:::::::::|h[Linen Bag]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946740,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [458]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:12:13]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Habibipibi:1913:CHANNEL:3|h|cff3fc6eaHabibipibi|r|h|cffd8d8d8]|r: WTB SUMMONS TO DUSTWALLOW MARSH",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						93, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946741,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [459]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:12:20]|h|r You receive item: |cffffffff|Hitem:929::::::::26:::::::::|h[Healing Potion]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946748,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [460]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:13:16]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Tirisfal Glades]|h",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						46, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946804,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [461]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:13:16]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. Trade - City]|h",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						95, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946804,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [462]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:13:16]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Tirisfal Glades]|h",
					["extraData"] = {
						73, -- [1]
						16, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946804,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [463]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:13:32]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Gibaoe:1947:CHANNEL:2|h|cff3fc6eaGibaoe|r|h|cffd8d8d8]|r: such a troll",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						97, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946820,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [464]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:13:33]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Silverpine Forest]|h",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						46, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946821,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [465]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:13:33]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Silverpine Forest]|h",
					["extraData"] = {
						73, -- [1]
						16, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946821,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [466]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:14:38]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Vánagandr-Shadowstrike(AU):1958:CHANNEL:2|h|cffff7c0aVánagandr|r|h|cffd8d8d8]|r: LF1M Tank/DPS SFK",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						99, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946886,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [467]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:16:00]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Vánagandr-Shadowstrike(AU):1972:CHANNEL:2|h|cffff7c0aVánagandr|r|h|cffd8d8d8]|r: LF1M Tank/DPS SFK",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						99, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709946968,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [468]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:16:09]|h|r Quest accepted: Prove Your Worth",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946977,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [469]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:16:10]|h|r Quest accepted: Arugal Must Die",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709946978,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [470]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:17:09]|h|r Quest accepted: Lost Deathstalkers",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947037,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [471]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:17:09]|h|r Quest accepted: The Dead Fields",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947037,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [472]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:17:09]|h|r Quest accepted: Deathstalkers in Shadowfang",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947037,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [473]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:18:17]|h|r Your group has been disbanded.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947105,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [474]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:18:54]|h|r |cffd8d8d8[|r|Hplayer:Tpainwarpigs:2015|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r has invited you to join a group.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947142,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [475]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:19:06]|h|r Dungeon difficulty set to Normal",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947154,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [476]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:19:07]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Frosteh:2019:CHANNEL:2|h|cff3fc6eaFrosteh|r|h|cffd8d8d8]|r: LF tank SFK",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						101, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709947155,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [477]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:21:31]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2046:CHANNEL:2|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: LF3M 2 dps 1 heal SFK",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						103, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709947299,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [478]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:22:23]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Frosteh-Shadowstrike(AU):2056:CHANNEL:2|h|cff3fc6eaFrosteh|r|h|cffd8d8d8]|r: LF tank SFK",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						101, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709947351,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [479]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:24:04]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Dangerdann-Shadowstrike(AU):2071:CHANNEL:2|h|cffffffffDangerdann|r|h|cffd8d8d8]|r: LF1M TANK SFK",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						105, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709947452,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [480]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:24:16]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):2075:CHANNEL:2|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: i can tank ur sfk groups u just need to make space for my warlock friend LMOA",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						103, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709947464,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [481]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:25:09]|h|r You are now the group leader.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947517,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [482]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:25:09]|h|r Your group has been disbanded.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947517,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [483]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:25:23]|h|r |cffd8d8d8[|r|Hplayer:Tpainwarpigs:2093|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r has invited you to join a group.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947531,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [484]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:25:24]|h|r Dungeon difficulty set to Normal",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947532,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [485]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:25:24]|h|r Looting changed to free-for-all.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947532,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [486]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:26:23]|h|r Discovered Olsen's Farthing: 49 experience gained",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947591,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [487]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:26:38]|h|r |cff3fc6eaFrosteh|r receives loot: |cffffffff|Hitem:2592::::::::26:::::::::|h[Wool Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947606,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [488]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:26:38]|h|r |cff3fc6eaFrosteh|r receives loot: |cffffffff|Hitem:3613::::::::26:::::::::|h[Valdred's Hands]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947606,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [489]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:27:52]|h|r Discovered Shadowfang Keep: 86 experience gained",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947680,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [490]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:28:36]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Shadowfang Keep]|h",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						46, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709947724,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [491]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:28:36]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Shadowfang Keep]|h",
					["extraData"] = {
						73, -- [1]
						16, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709947724,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [492]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:28:43]|h|r |cff0070ddTpainwarpigs|r has initiated a ready check",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947731,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [493]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:28:45]|h|r |cff3fc6eaFrosteh|r creates: |cffffffff|Hitem:2136::::::::26:::::::::|h[Conjured Purified Water]|h|rx10.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947733,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [494]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:29:17]|h|r |cff3fc6eaFrosteh|r receives loot: |cff9d9d9d|Hitem:3377::::::::26:::::::::|h[Canvas Bracers]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947765,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [495]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:29:18]|h|r |cff3fc6eaFrosteh|r receives loot: |cffffffff|Hitem:1015::::::::26:::::::::|h[Lean Wolf Flank]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947766,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [496]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:29:18]|h|r Your share of the loot is 26 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947766,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [497]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:29:19]|h|r Your share of the loot is 57 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947767,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [498]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:04]|h|r You feel normal.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947812,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [499]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:08]|h|r Sorcerer Ashcrombe says: [Common] Lon vrum E melka lars nud... uden.",
					["extraData"] = {
						13, -- [1]
						29, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["b"] = 0.6235294342041016,
					["serverTime"] = 1709947816,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [500]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:09]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:1816::::::::26:::::::::|h[Unbalanced Axe]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947817,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [501]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:10]|h|r Your share of the loot is 31 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947818,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [502]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:16]|h|r |cff3fc6eaFrosteh|r receives loot: |cffffffff|Hitem:5254::::::::26:::::::::|h[Rugged Spaulders]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947824,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [503]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:17]|h|r Your share of the loot is 30 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947825,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [504]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:17]|h|r |cff3fc6eaFrosteh|r receives loot: |cff1eff00|Hitem:6536::::::135:1242121600:26:::::::::|h[Willow Vest of Stamina]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947825,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [505]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:18]|h|r |cff3fc6eaFrosteh|r receives loot: |cffffffff|Hitem:1015::::::::26:::::::::|h[Lean Wolf Flank]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947826,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [506]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:18]|h|r Your share of the loot is 19 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947826,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [507]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:19]|h|r |cff3fc6eaFrosteh|r receives loot: |cff1eff00|Hitem:4293::::::::26:::::::::|h[Pattern: Hillman's Leather Vest]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947827,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [508]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:20]|h|r |cff3fc6eaFrosteh|r receives loot: |cff9d9d9d|Hitem:3301::::::::26:::::::::|h[Sharp Canine]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947828,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [509]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:20]|h|r |cff3fc6eaFrosteh|r receives loot: |cffffffff|Hitem:1015::::::::26:::::::::|h[Lean Wolf Flank]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947828,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [510]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:27]|h|r Deathstalker Adamant says: Free from this wretched cell at last! Let me show you to the courtyard....",
					["extraData"] = {
						13, -- [1]
						29, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["b"] = 0.6235294342041016,
					["serverTime"] = 1709947835,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [511]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:33]|h|r Looting changed to group loot.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947841,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [512]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:42]|h|r You receive loot: |cff9d9d9d|Hitem:2217::::::::26:::::::::|h[Rectangular Shield]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947850,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [513]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:42]|h|r |cff0070ddHolladoss|r receives loot: |cffffffff|Hitem:2589::::::::26:::::::::|h[Linen Cloth]|h|rx5.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947850,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [514]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:43]|h|r Your share of the loot is 51 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947851,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [515]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:59]|h|r Deathstalker Adamant says: You are indeed courageous for wanting to brave the horrors that lie beyond this door.",
					["extraData"] = {
						13, -- [1]
						29, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["b"] = 0.6235294342041016,
					["serverTime"] = 1709947867,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [516]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:30:59]|h|r Deathstalker Adamant fumbles with the rusty lock on the courtyard door.",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709947867,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [517]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:31:05]|h|r Deathstalker Adamant says: There we go!",
					["extraData"] = {
						13, -- [1]
						29, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["b"] = 0.6235294342041016,
					["serverTime"] = 1709947873,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [518]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:31:08]|h|r Deathstalker Adamant says: Good luck with Arugal. I must hurry back to Hadrec now.",
					["extraData"] = {
						13, -- [1]
						29, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["b"] = 0.6235294342041016,
					["serverTime"] = 1709947876,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [519]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:31:44]|h|r |cff3fc6eaFrosteh|r receives loot: |cffffffff|Hitem:1015::::::::26:::::::::|h[Lean Wolf Flank]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947912,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [520]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:32:50]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:1769::::::::26:::::::::|h[Canvas Shoulderpads]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947978,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [521]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:32:51]|h|r Your share of the loot is 22 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947979,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [522]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:32:53]|h|r Your share of the loot is 12 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947981,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [523]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:32:57]|h|r Your share of the loot is 34 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709947985,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [524]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:15]|h|r |cff3fc6eaFrosteh|r receives loot: |cff9d9d9d|Hitem:1816::::::::26:::::::::|h[Unbalanced Axe]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948003,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [525]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:17]|h|r Your share of the loot is 28 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948005,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [526]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:21]|h|r Your share of the loot is 19 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948009,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [527]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:41]|h|r Your Undercity reputation has increased by 100.",
					["extraData"] = {
						36, -- [1]
						109, -- [2]
						110, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709948029,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 0.501960813999176,
				}, -- [528]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:41]|h|r You receive item: |cff1eff00|Hitem:3324::::::::26:::::::::|h[Ghostly Mantle]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948029,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [529]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:41]|h|r Deathstalkers in Shadowfang completed.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948029,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [530]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:41]|h|r Experience gained: 4000.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948029,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [531]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:41]|h|r Received 54 Silver.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948029,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [532]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:43]|h|r |cff0070ddHolladoss|r receives loot: |cffffffff|Hitem:1015::::::::26:::::::::|h[Lean Wolf Flank]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948031,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [533]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:46]|h|r Your share of the loot is 10 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948034,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [534]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:51]|h|r |cff0070ddHolladoss|r receives loot: |cffffffff|Hitem:2319::::::::26:::::::::|h[Medium Leather]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948039,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [535]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:53]|h|r Your share of the loot is 28 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948041,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [536]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:56]|h|r You receive loot: |cff9d9d9d|Hitem:1792::::::::26:::::::::|h[Patched Leather Pants]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948044,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [537]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:56]|h|r You receive loot: |cffffffff|Hitem:954::::::::26:::::::::|h[Scroll of Strength]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948044,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [538]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:33:57]|h|r Your share of the loot is 23 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948045,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [539]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:34:45]|h|r |cff3fc6eaFrosteh|r receives loot: |cffffffff|Hitem:1015::::::::26:::::::::|h[Lean Wolf Flank]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948093,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [540]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:34:49]|h|r Your share of the loot is 36 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948097,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [541]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:34:52]|h|r Your share of the loot is 37 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948100,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [542]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:13]|h|r Your share of the loot is 34 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948121,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [543]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:16]|h|r |cffffffffDangerdann|r receives loot: |cff9d9d9d|Hitem:5871::::::::26:::::::::|h[Large Hoof]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948124,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [544]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:52]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2592::::::::26:::::::::|h[Wool Cloth]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948160,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [545]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:52]|h|r |HlootHistory:3|h[Loot]|h: |cff1eff00|Hitem:9780::::::760:1892892928:26:::::::::|h[Bandit Gloves of the Owl]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948160,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [546]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:53]|h|r Your share of the loot is 69 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948161,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [547]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:53]|h|r |cff0070ddHolladoss|r receives loot: |cffffffff|Hitem:2592::::::::26:::::::::|h[Wool Cloth]|h|rx3.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948161,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [548]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:54]|h|r |HlootHistory:3|h[Loot]|h: |cff3fc6eaFrosteh|r has selected Greed for: |cff1eff00|Hitem:9780::::::760:1892892928:26:::::::::|h[Bandit Gloves of the Owl]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948162,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [549]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:54]|h|r Your share of the loot is 13 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948162,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [550]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:56]|h|r |cff3fc6eaFrosteh|r receives loot: |cffffffff|Hitem:2592::::::::26:::::::::|h[Wool Cloth]|h|rx4.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948164,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [551]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:57]|h|r Your share of the loot is 9 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948165,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [552]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:57]|h|r |HlootHistory:3|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Greed for: |cff1eff00|Hitem:9780::::::760:1892892928:26:::::::::|h[Bandit Gloves of the Owl]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948165,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [553]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:57]|h|r |HlootHistory:3|h[Loot]|h: You have selected Greed for: |cff1eff00|Hitem:9780::::::760:1892892928:26:::::::::|h[Bandit Gloves of the Owl]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948165,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [554]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:58]|h|r |HlootHistory:3|h[Loot]|h: |cffffffffDangerdann|r has selected Greed for: |cff1eff00|Hitem:9780::::::760:1892892928:26:::::::::|h[Bandit Gloves of the Owl]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948166,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [555]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:58]|h|r |HlootHistory:3|h[Loot]|h: |cff0070ddHolladoss|r has selected Greed for: |cff1eff00|Hitem:9780::::::760:1892892928:26:::::::::|h[Bandit Gloves of the Owl]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948166,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [556]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:58]|h|r |HlootHistory:3|h[Loot]|h: Greed Roll - 1 for |cff1eff00|Hitem:9780::::::760:1892892928:26:::::::::|h[Bandit Gloves of the Owl]|h|r by |cff00ff00Lavy|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948166,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [557]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:58]|h|r |HlootHistory:3|h[Loot]|h: Greed Roll - 80 for |cff1eff00|Hitem:9780::::::760:1892892928:26:::::::::|h[Bandit Gloves of the Owl]|h|r by |cff0070ddTpainwarpigs|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948166,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [558]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:58]|h|r |HlootHistory:3|h[Loot]|h: Greed Roll - 75 for |cff1eff00|Hitem:9780::::::760:1892892928:26:::::::::|h[Bandit Gloves of the Owl]|h|r by |cffffffffDangerdann|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948166,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [559]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:58]|h|r |HlootHistory:3|h[Loot]|h: Greed Roll - 100 for |cff1eff00|Hitem:9780::::::760:1892892928:26:::::::::|h[Bandit Gloves of the Owl]|h|r by |cff0070ddHolladoss|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948166,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [560]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:58]|h|r |HlootHistory:3|h[Loot]|h: Greed Roll - 16 for |cff1eff00|Hitem:9780::::::760:1892892928:26:::::::::|h[Bandit Gloves of the Owl]|h|r by |cff3fc6eaFrosteh|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948166,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [561]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:58]|h|r |HlootHistory:3|h[Loot]|h: |cff0070ddHolladoss|r won: |cff1eff00|Hitem:9780::::::760:1892892928:26:::::::::|h[Bandit Gloves of the Owl]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948166,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [562]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:35:58]|h|r |cff0070ddHolladoss|r receives loot: |cff1eff00|Hitem:9780::::::760:1892892928:26:::::::::|h[Bandit Gloves of the Owl]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948166,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [563]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:01]|h|r |cffffffffDangerdann|r receives loot: |cff9d9d9d|Hitem:2217::::::::26:::::::::|h[Rectangular Shield]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948169,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [564]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:02]|h|r Your share of the loot is 34 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948170,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [565]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:19]|h|r |HlootHistory:4|h[Loot]|h: |cff1eff00|Hitem:6633::::::::26:::::::::|h[Butcher's Slicer]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948187,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [566]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:21]|h|r Your share of the loot is 24 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948189,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [567]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:22]|h|r |HlootHistory:4|h[Loot]|h: |cff3fc6eaFrosteh|r has selected Greed for: |cff1eff00|Hitem:6633::::::::26:::::::::|h[Butcher's Slicer]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948190,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [568]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:22]|h|r |HlootHistory:4|h[Loot]|h: |cff0070ddHolladoss|r has selected Greed for: |cff1eff00|Hitem:6633::::::::26:::::::::|h[Butcher's Slicer]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948190,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [569]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:22]|h|r |HlootHistory:4|h[Loot]|h: |cffffffffDangerdann|r has selected Greed for: |cff1eff00|Hitem:6633::::::::26:::::::::|h[Butcher's Slicer]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948190,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [570]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:23]|h|r |HlootHistory:4|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Greed for: |cff1eff00|Hitem:6633::::::::26:::::::::|h[Butcher's Slicer]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948191,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [571]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:25]|h|r |HlootHistory:4|h[Loot]|h: You passed on: |cff1eff00|Hitem:6633::::::::26:::::::::|h[Butcher's Slicer]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948193,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [572]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:25]|h|r |HlootHistory:4|h[Loot]|h: Greed Roll - 55 for |cff1eff00|Hitem:6633::::::::26:::::::::|h[Butcher's Slicer]|h|r by |cff0070ddTpainwarpigs|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948193,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [573]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:25]|h|r |HlootHistory:4|h[Loot]|h: Greed Roll - 99 for |cff1eff00|Hitem:6633::::::::26:::::::::|h[Butcher's Slicer]|h|r by |cffffffffDangerdann|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948193,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [574]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:25]|h|r |HlootHistory:4|h[Loot]|h: Greed Roll - 72 for |cff1eff00|Hitem:6633::::::::26:::::::::|h[Butcher's Slicer]|h|r by |cff0070ddHolladoss|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948193,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [575]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:25]|h|r |HlootHistory:4|h[Loot]|h: Greed Roll - 87 for |cff1eff00|Hitem:6633::::::::26:::::::::|h[Butcher's Slicer]|h|r by |cff3fc6eaFrosteh|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948193,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [576]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:25]|h|r |HlootHistory:4|h[Loot]|h: |cffffffffDangerdann|r won: |cff1eff00|Hitem:6633::::::::26:::::::::|h[Butcher's Slicer]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948193,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [577]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:36:25]|h|r |cffffffffDangerdann|r receives loot: |cff1eff00|Hitem:6633::::::::26:::::::::|h[Butcher's Slicer]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948193,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [578]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:37:01]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:1774::::::::26:::::::::|h[Brocade Cloak]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948229,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [579]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:37:01]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3770::::::::26:::::::::|h[Mutton Chop]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948229,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [580]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:37:02]|h|r Your share of the loot is 46 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948230,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [581]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:37:27]|h|r |cffffffffDangerdann|r has died.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948255,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [582]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:37:47]|h|r |cff3fc6eaFrosteh|r has died.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948275,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [583]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:38:09]|h|r |cff0070ddTpainwarpigs|r has died.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948297,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [584]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:38:13]|h|r |cff0070ddHolladoss|r has died.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948301,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [585]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:38:17]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Silverpine Forest]|h",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						46, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709948305,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [586]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:38:17]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Silverpine Forest]|h",
					["extraData"] = {
						73, -- [1]
						16, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709948305,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [587]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:40:45]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Shadowfang Keep]|h",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						46, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709948453,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [588]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:40:45]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Shadowfang Keep]|h",
					["extraData"] = {
						73, -- [1]
						16, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709948453,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [589]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:41:02]|h|r You create: |cffffffff|Hitem:5511::::::::26:::::::::|h[Lesser Healthstone]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948470,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [590]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:41:40]|h|r |cff3fc6eaFrosteh|r creates: |cffffffff|Hitem:2136::::::::26:::::::::|h[Conjured Purified Water]|h|rx10.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948508,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [591]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:42:19]|h|r |cff0070ddHolladoss|r receives loot: |cff9d9d9d|Hitem:1753::::::::26:::::::::|h[Linked Chain Vest]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948547,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [592]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:42:19]|h|r Your share of the loot is 58 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948547,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [593]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:42:48]|h|r |HlootHistory:5|h[Loot]|h: |cff1eff00|Hitem:3199::::::511:676225536:26:::::::::|h[Battle Slayer of the Wolf]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948576,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [594]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:42:49]|h|r Your share of the loot is 68 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948577,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [595]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:42:50]|h|r |cff0070ddHolladoss|r receives loot: |cffffffff|Hitem:1205::::::::26:::::::::|h[Melon Juice]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948578,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [596]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:42:50]|h|r |HlootHistory:5|h[Loot]|h: |cff3fc6eaFrosteh|r has selected Greed for: |cff1eff00|Hitem:3199::::::511:676225536:26:::::::::|h[Battle Slayer of the Wolf]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948578,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [597]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:42:51]|h|r Your share of the loot is 17 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948579,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [598]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:42:52]|h|r |HlootHistory:5|h[Loot]|h: |cffffffffDangerdann|r has selected Greed for: |cff1eff00|Hitem:3199::::::511:676225536:26:::::::::|h[Battle Slayer of the Wolf]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948580,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [599]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:42:56]|h|r |HlootHistory:5|h[Loot]|h: You passed on: |cff1eff00|Hitem:3199::::::511:676225536:26:::::::::|h[Battle Slayer of the Wolf]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948584,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [600]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:11]|h|r |HlootHistory:5|h[Loot]|h: |cff0070ddHolladoss|r has selected Greed for: |cff1eff00|Hitem:3199::::::511:676225536:26:::::::::|h[Battle Slayer of the Wolf]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948599,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [601]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:31]|h|r |HlootHistory:5|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Greed for: |cff1eff00|Hitem:3199::::::511:676225536:26:::::::::|h[Battle Slayer of the Wolf]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948619,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [602]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:31]|h|r |HlootHistory:5|h[Loot]|h: Greed Roll - 23 for |cff1eff00|Hitem:3199::::::511:676225536:26:::::::::|h[Battle Slayer of the Wolf]|h|r by |cff3fc6eaFrosteh|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948619,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [603]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:31]|h|r |HlootHistory:5|h[Loot]|h: Greed Roll - 100 for |cff1eff00|Hitem:3199::::::511:676225536:26:::::::::|h[Battle Slayer of the Wolf]|h|r by |cff0070ddTpainwarpigs|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948619,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [604]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:31]|h|r |HlootHistory:5|h[Loot]|h: Greed Roll - 25 for |cff1eff00|Hitem:3199::::::511:676225536:26:::::::::|h[Battle Slayer of the Wolf]|h|r by |cffffffffDangerdann|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948619,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [605]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:31]|h|r |HlootHistory:5|h[Loot]|h: Greed Roll - 68 for |cff1eff00|Hitem:3199::::::511:676225536:26:::::::::|h[Battle Slayer of the Wolf]|h|r by |cff0070ddHolladoss|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948619,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [606]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:31]|h|r |HlootHistory:5|h[Loot]|h: |cff0070ddTpainwarpigs|r won: |cff1eff00|Hitem:3199::::::511:676225536:26:::::::::|h[Battle Slayer of the Wolf]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948619,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [607]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:31]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff1eff00|Hitem:3199::::::511:676225536:26:::::::::|h[Battle Slayer of the Wolf]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948619,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [608]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:33]|h|r |HlootHistory:6|h[Loot]|h: |cff1eff00|Hitem:6323::::::::26:::::::::|h[Baron's Scepter]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948621,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [609]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:33]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2592::::::::26:::::::::|h[Wool Cloth]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948621,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [610]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:33]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:1205::::::::26:::::::::|h[Melon Juice]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948621,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [611]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:33]|h|r Your share of the loot is 30 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948621,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [612]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:36]|h|r |HlootHistory:6|h[Loot]|h: You passed on: |cff1eff00|Hitem:6323::::::::26:::::::::|h[Baron's Scepter]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948624,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [613]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:36]|h|r |HlootHistory:6|h[Loot]|h: |cffffffffDangerdann|r has selected Greed for: |cff1eff00|Hitem:6323::::::::26:::::::::|h[Baron's Scepter]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948624,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [614]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:36]|h|r |HlootHistory:6|h[Loot]|h: |cff3fc6eaFrosteh|r has selected Greed for: |cff1eff00|Hitem:6323::::::::26:::::::::|h[Baron's Scepter]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948624,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [615]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:39]|h|r |HlootHistory:6|h[Loot]|h: |cff0070ddHolladoss|r has selected Greed for: |cff1eff00|Hitem:6323::::::::26:::::::::|h[Baron's Scepter]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948627,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [616]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:45]|h|r |cffffffffDangerdann|r receives loot: |cffffffff|Hitem:2592::::::::26:::::::::|h[Wool Cloth]|h|rx3.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948633,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [617]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:45]|h|r |HlootHistory:6|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Need for: |cff1eff00|Hitem:6323::::::::26:::::::::|h[Baron's Scepter]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948633,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [618]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:45]|h|r |HlootHistory:6|h[Loot]|h: Need Roll - 59 for |cff1eff00|Hitem:6323::::::::26:::::::::|h[Baron's Scepter]|h|r by |cff0070ddTpainwarpigs|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948633,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [619]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:45]|h|r |HlootHistory:6|h[Loot]|h: |cff0070ddTpainwarpigs|r won: |cff1eff00|Hitem:6323::::::::26:::::::::|h[Baron's Scepter]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948633,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [620]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:45]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff1eff00|Hitem:6323::::::::26:::::::::|h[Baron's Scepter]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948633,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [621]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:45]|h|r |cffffffffDangerdann|r receives loot: |cff9d9d9d|Hitem:1819::::::::26:::::::::|h[Gouging Pick]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948633,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [622]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:43:46]|h|r Your share of the loot is 31 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948634,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [623]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:44:19]|h|r Your share of the loot is 11 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948667,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [624]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:44:32]|h|r Your share of the loot is 22 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948680,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [625]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:44:51]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Mikeg-Shadowstrike(AU):2519:GUILD|h|cffd84e4e40|r:|cff3fc6eaMikeg|r|h|cffd8d8d8]|r: [NWB] Ashenvale event starts in 15 minutes.",
					["extraData"] = {
						5, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709948699,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 0.250980406999588,
				}, -- [626]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:45:04]|h|r Your share of the loot is 20 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948712,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [627]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:45:11]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Mikeg-Shadowstrike(AU):2530:GUILD|h|cffd84e4e40|r:|cff3fc6eaMikeg|r|h|cffd8d8d8]|r: 4 scrolls down",
					["extraData"] = {
						5, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709948719,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 0.250980406999588,
				}, -- [628]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:45:12]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Mikeg-Shadowstrike(AU):2531:GUILD|h|cffd84e4e40|r:|cff3fc6eaMikeg|r|h|cffd8d8d8]|r: this is *!@#ed",
					["extraData"] = {
						5, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709948720,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 0.250980406999588,
				}, -- [629]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:45:39]|h|r Pizpep says: Alright I'm going! Stop yelling!",
					["extraData"] = {
						13, -- [1]
						29, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["b"] = 0.6235294342041016,
					["serverTime"] = 1709948747,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [630]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:46:04]|h|r Your share of the loot is 14 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948772,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [631]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:46:04]|h|r |cff0070ddHolladoss|r receives loot: |cffffffff|Hitem:2592::::::::26:::::::::|h[Wool Cloth]|h|rx3.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948772,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [632]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:46:05]|h|r |cff3fc6eaFrosteh|r receives loot: |cff9d9d9d|Hitem:3378::::::::26:::::::::|h[Brocade Belt]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948773,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [633]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:46:05]|h|r Your share of the loot is 1 Silver.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948773,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [634]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:46:22]|h|r Your share of the loot is 17 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948790,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [635]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:47:10]|h|r You create: |cffffffff|Hitem:6265::::::::26:::::::::|h[Soul Shard]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948838,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [636]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:47:10]|h|r |HlootHistory:7|h[Loot]|h: |cff0070dd|Hitem:6320::::::::26:::::::::|h[Commander's Crest]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948838,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [637]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:47:10]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2589::::::::26:::::::::|h[Linen Cloth]|h|rx4.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948838,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [638]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:47:11]|h|r Your share of the loot is 38 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948839,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [639]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:47:12]|h|r |HlootHistory:7|h[Loot]|h: |cff3fc6eaFrosteh|r has selected Greed for: |cff0070dd|Hitem:6320::::::::26:::::::::|h[Commander's Crest]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948840,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [640]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:47:12]|h|r Your share of the loot is 38 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948840,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [641]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:47:13]|h|r |HlootHistory:7|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Need for: |cff0070dd|Hitem:6320::::::::26:::::::::|h[Commander's Crest]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948841,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [642]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:47:13]|h|r |HlootHistory:7|h[Loot]|h: |cffffffffDangerdann|r has selected Greed for: |cff0070dd|Hitem:6320::::::::26:::::::::|h[Commander's Crest]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948841,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [643]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:47:14]|h|r |HlootHistory:7|h[Loot]|h: |cff0070ddHolladoss|r has selected Greed for: |cff0070dd|Hitem:6320::::::::26:::::::::|h[Commander's Crest]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948842,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [644]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:47:15]|h|r |HlootHistory:7|h[Loot]|h: You passed on: |cff0070dd|Hitem:6320::::::::26:::::::::|h[Commander's Crest]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948843,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [645]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:47:15]|h|r |HlootHistory:7|h[Loot]|h: Need Roll - 13 for |cff0070dd|Hitem:6320::::::::26:::::::::|h[Commander's Crest]|h|r by |cff0070ddTpainwarpigs|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948843,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [646]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:47:15]|h|r |HlootHistory:7|h[Loot]|h: |cff0070ddTpainwarpigs|r won: |cff0070dd|Hitem:6320::::::::26:::::::::|h[Commander's Crest]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948843,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [647]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:47:16]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff0070dd|Hitem:6320::::::::26:::::::::|h[Commander's Crest]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948844,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [648]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:48:29]|h|r |cff3fc6eaFrosteh|r receives loot: |cff9d9d9d|Hitem:1753::::::::26:::::::::|h[Linked Chain Vest]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948917,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [649]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:48:29]|h|r |cff3fc6eaFrosteh|r receives loot: |cffffffff|Hitem:2592::::::::26:::::::::|h[Wool Cloth]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948917,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [650]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:48:30]|h|r Your share of the loot is 42 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948918,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [651]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:48:30]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2592::::::::26:::::::::|h[Wool Cloth]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948918,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [652]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:48:31]|h|r Your share of the loot is 31 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948919,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [653]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:49:42]|h|r |HlootHistory:8|h[Loot]|h: |cff1eff00|Hitem:6319::::::::26:::::::::|h[Girdle of the Blindwatcher]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948990,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [654]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:49:43]|h|r Your share of the loot is 42 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948991,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [655]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:49:45]|h|r |HlootHistory:8|h[Loot]|h: |cff3fc6eaFrosteh|r has selected Greed for: |cff1eff00|Hitem:6319::::::::26:::::::::|h[Girdle of the Blindwatcher]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948993,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [656]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:49:45]|h|r |cff3fc6eaFrosteh|r receives loot: |cff9d9d9d|Hitem:11391::::::::26:::::::::|h[Spined Bat Wing]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948993,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [657]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:49:46]|h|r |HlootHistory:8|h[Loot]|h: |cffffffffDangerdann|r has selected Greed for: |cff1eff00|Hitem:6319::::::::26:::::::::|h[Girdle of the Blindwatcher]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948994,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [658]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:49:47]|h|r |HlootHistory:8|h[Loot]|h: |cff0070ddHolladoss|r has selected Greed for: |cff1eff00|Hitem:6319::::::::26:::::::::|h[Girdle of the Blindwatcher]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948995,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [659]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:49:48]|h|r |HlootHistory:8|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Need for: |cff1eff00|Hitem:6319::::::::26:::::::::|h[Girdle of the Blindwatcher]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948996,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [660]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:49:49]|h|r |HlootHistory:8|h[Loot]|h: You passed on: |cff1eff00|Hitem:6319::::::::26:::::::::|h[Girdle of the Blindwatcher]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948997,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [661]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:49:49]|h|r |HlootHistory:8|h[Loot]|h: Need Roll - 46 for |cff1eff00|Hitem:6319::::::::26:::::::::|h[Girdle of the Blindwatcher]|h|r by |cff0070ddTpainwarpigs|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948997,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [662]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:49:49]|h|r |HlootHistory:8|h[Loot]|h: |cff0070ddTpainwarpigs|r won: |cff1eff00|Hitem:6319::::::::26:::::::::|h[Girdle of the Blindwatcher]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948997,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [663]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:49:49]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff1eff00|Hitem:6319::::::::26:::::::::|h[Girdle of the Blindwatcher]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948997,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [664]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:49:50]|h|r |cff3fc6eaFrosteh|r receives loot: |cffffffff|Hitem:4694::::::::26:::::::::|h[Burnished Pauldrons]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709948998,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [665]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:49:53]|h|r |cff3fc6eaFrosteh|r receives loot: |cff9d9d9d|Hitem:6298::::::::26:::::::::|h[Bloody Bat Fang]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949001,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [666]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:50:46]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:1750::::::::26:::::::::|h[Linked Chain Gloves]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949054,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [667]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:50:46]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2589::::::::26:::::::::|h[Linen Cloth]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949054,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [668]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:50:47]|h|r Your share of the loot is 17 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949055,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [669]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:50:49]|h|r |HlootHistory:9|h[Loot]|h: |cff1eff00|Hitem:3057::::::::26:::::::::|h[Forest Leather Boots]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949057,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [670]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:50:50]|h|r Your share of the loot is 50 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949058,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [671]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:50:52]|h|r |HlootHistory:9|h[Loot]|h: |cff3fc6eaFrosteh|r has selected Greed for: |cff1eff00|Hitem:3057::::::::26:::::::::|h[Forest Leather Boots]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949060,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [672]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:50:52]|h|r |HlootHistory:9|h[Loot]|h: You passed on: |cff1eff00|Hitem:3057::::::::26:::::::::|h[Forest Leather Boots]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949060,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [673]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:50:53]|h|r |HlootHistory:9|h[Loot]|h: |cffffffffDangerdann|r has selected Greed for: |cff1eff00|Hitem:3057::::::::26:::::::::|h[Forest Leather Boots]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949061,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [674]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:50:54]|h|r Your share of the loot is 74 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949062,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [675]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:50:56]|h|r |HlootHistory:9|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Need for: |cff1eff00|Hitem:3057::::::::26:::::::::|h[Forest Leather Boots]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949064,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [676]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:50:59]|h|r Your share of the loot is 40 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949067,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [677]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:51:06]|h|r |HlootHistory:9|h[Loot]|h: |cff0070ddHolladoss|r has selected Need for: |cff1eff00|Hitem:3057::::::::26:::::::::|h[Forest Leather Boots]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949074,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [678]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:51:06]|h|r |HlootHistory:9|h[Loot]|h: Need Roll - 89 for |cff1eff00|Hitem:3057::::::::26:::::::::|h[Forest Leather Boots]|h|r by |cff0070ddHolladoss|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949074,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [679]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:51:06]|h|r |HlootHistory:9|h[Loot]|h: Need Roll - 23 for |cff1eff00|Hitem:3057::::::::26:::::::::|h[Forest Leather Boots]|h|r by |cff0070ddTpainwarpigs|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949074,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [680]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:51:06]|h|r |HlootHistory:9|h[Loot]|h: |cff0070ddHolladoss|r won: |cff1eff00|Hitem:3057::::::::26:::::::::|h[Forest Leather Boots]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949074,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [681]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:51:06]|h|r |cff0070ddHolladoss|r receives loot: |cff1eff00|Hitem:3057::::::::26:::::::::|h[Forest Leather Boots]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949074,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [682]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:51:22]|h|r Your share of the loot is 54 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949090,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [683]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:52:42]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:3402::::::::26:::::::::|h[Soft Patch of Fur]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949170,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [684]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:52:43]|h|r You receive loot: |cff9d9d9d|Hitem:2765::::::::26:::::::::|h[Hunting Knife]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949171,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [685]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:52:43]|h|r You receive loot: |cffffffff|Hitem:1205::::::::26:::::::::|h[Melon Juice]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949171,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [686]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:52:43]|h|r |cff3fc6eaFrosteh|r receives loot: |cff9d9d9d|Hitem:2782::::::::26:::::::::|h[Mishandled Recurve Bow]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949171,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [687]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:52:43]|h|r |cff3fc6eaFrosteh|r receives loot: |cffffffff|Hitem:3770::::::::26:::::::::|h[Mutton Chop]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949171,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [688]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:52:43]|h|r |cff0070ddHolladoss|r receives loot: |cff9d9d9d|Hitem:1777::::::::26:::::::::|h[Brocade Shoulderpads]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949171,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [689]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:52:44]|h|r Your share of the loot is 1 Silver, 30 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949172,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [690]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:53:37]|h|r |HlootHistory:10|h[Loot]|h: |cff1eff00|Hitem:8183::::::::26:::::::::|h[Precision Bow]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949225,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [691]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:53:38]|h|r Your share of the loot is 28 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949226,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [692]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:53:39]|h|r |HlootHistory:10|h[Loot]|h: |cff0070ddHolladoss|r has selected Greed for: |cff1eff00|Hitem:8183::::::::26:::::::::|h[Precision Bow]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949227,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [693]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:53:40]|h|r |HlootHistory:10|h[Loot]|h: |cffffffffDangerdann|r has selected Greed for: |cff1eff00|Hitem:8183::::::::26:::::::::|h[Precision Bow]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949228,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [694]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:53:45]|h|r |HlootHistory:11|h[Loot]|h: |cff1eff00|Hitem:15223::::::1180:309386112:26:::::::::|h[Jagged Star of the Bear]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949233,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [695]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:53:45]|h|r |HlootHistory:10|h[Loot]|h: |cff3fc6eaFrosteh|r has selected Greed for: |cff1eff00|Hitem:8183::::::::26:::::::::|h[Precision Bow]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949233,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [696]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:53:46]|h|r Your share of the loot is 22 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949234,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [697]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:53:47]|h|r |HlootHistory:11|h[Loot]|h: |cffffffffDangerdann|r has selected Greed for: |cff1eff00|Hitem:15223::::::1180:309386112:26:::::::::|h[Jagged Star of the Bear]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949235,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [698]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:53:50]|h|r |HlootHistory:11|h[Loot]|h: |cff0070ddHolladoss|r has selected Greed for: |cff1eff00|Hitem:15223::::::1180:309386112:26:::::::::|h[Jagged Star of the Bear]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949238,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [699]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:53:52]|h|r |HlootHistory:11|h[Loot]|h: |cff3fc6eaFrosteh|r has selected Greed for: |cff1eff00|Hitem:15223::::::1180:309386112:26:::::::::|h[Jagged Star of the Bear]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949240,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [700]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:01]|h|r |HlootHistory:10|h[Loot]|h: You passed on: |cff1eff00|Hitem:8183::::::::26:::::::::|h[Precision Bow]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949249,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [701]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:01]|h|r |HlootHistory:11|h[Loot]|h: You passed on: |cff1eff00|Hitem:15223::::::1180:309386112:26:::::::::|h[Jagged Star of the Bear]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949249,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [702]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:03]|h|r |HlootHistory:12|h[Loot]|h: |cff1eff00|Hitem:3056::::::::26:::::::::|h[Forest Leather Pants]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949251,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [703]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:05]|h|r You receive loot: |cff9d9d9d|Hitem:3402::::::::26:::::::::|h[Soft Patch of Fur]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949253,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [704]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:05]|h|r You receive loot: |cffffffff|Hitem:1015::::::::26:::::::::|h[Lean Wolf Flank]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949253,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [705]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:05]|h|r |HlootHistory:12|h[Loot]|h: |cff3fc6eaFrosteh|r has selected Greed for: |cff1eff00|Hitem:3056::::::::26:::::::::|h[Forest Leather Pants]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949253,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [706]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:05]|h|r |HlootHistory:12|h[Loot]|h: |cffffffffDangerdann|r has selected Greed for: |cff1eff00|Hitem:3056::::::::26:::::::::|h[Forest Leather Pants]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949253,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [707]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:06]|h|r |HlootHistory:12|h[Loot]|h: |cff0070ddHolladoss|r has selected Greed for: |cff1eff00|Hitem:3056::::::::26:::::::::|h[Forest Leather Pants]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949254,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [708]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:06]|h|r |HlootHistory:10|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Greed for: |cff1eff00|Hitem:8183::::::::26:::::::::|h[Precision Bow]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949254,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [709]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:06]|h|r |HlootHistory:10|h[Loot]|h: Greed Roll - 9 for |cff1eff00|Hitem:8183::::::::26:::::::::|h[Precision Bow]|h|r by |cff3fc6eaFrosteh|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949254,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [710]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:06]|h|r |HlootHistory:10|h[Loot]|h: Greed Roll - 77 for |cff1eff00|Hitem:8183::::::::26:::::::::|h[Precision Bow]|h|r by |cff0070ddTpainwarpigs|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949254,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [711]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:06]|h|r |HlootHistory:10|h[Loot]|h: Greed Roll - 23 for |cff1eff00|Hitem:8183::::::::26:::::::::|h[Precision Bow]|h|r by |cffffffffDangerdann|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949254,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [712]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:06]|h|r |HlootHistory:10|h[Loot]|h: Greed Roll - 6 for |cff1eff00|Hitem:8183::::::::26:::::::::|h[Precision Bow]|h|r by |cff0070ddHolladoss|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949254,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [713]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:06]|h|r |HlootHistory:10|h[Loot]|h: |cff0070ddTpainwarpigs|r won: |cff1eff00|Hitem:8183::::::::26:::::::::|h[Precision Bow]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949254,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [714]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:06]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff1eff00|Hitem:8183::::::::26:::::::::|h[Precision Bow]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949254,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [715]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:06]|h|r |HlootHistory:11|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Greed for: |cff1eff00|Hitem:15223::::::1180:309386112:26:::::::::|h[Jagged Star of the Bear]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949254,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [716]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:06]|h|r |HlootHistory:11|h[Loot]|h: Greed Roll - 59 for |cff1eff00|Hitem:15223::::::1180:309386112:26:::::::::|h[Jagged Star of the Bear]|h|r by |cff0070ddHolladoss|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949254,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [717]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:06]|h|r |HlootHistory:11|h[Loot]|h: Greed Roll - 55 for |cff1eff00|Hitem:15223::::::1180:309386112:26:::::::::|h[Jagged Star of the Bear]|h|r by |cff0070ddTpainwarpigs|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949254,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [718]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:06]|h|r |HlootHistory:11|h[Loot]|h: Greed Roll - 26 for |cff1eff00|Hitem:15223::::::1180:309386112:26:::::::::|h[Jagged Star of the Bear]|h|r by |cffffffffDangerdann|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949254,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [719]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:06]|h|r |HlootHistory:11|h[Loot]|h: Greed Roll - 89 for |cff1eff00|Hitem:15223::::::1180:309386112:26:::::::::|h[Jagged Star of the Bear]|h|r by |cff3fc6eaFrosteh|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949254,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [720]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:06]|h|r |HlootHistory:11|h[Loot]|h: |cff3fc6eaFrosteh|r won: |cff1eff00|Hitem:15223::::::1180:309386112:26:::::::::|h[Jagged Star of the Bear]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949254,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [721]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:07]|h|r |cff3fc6eaFrosteh|r receives loot: |cff1eff00|Hitem:15223::::::1180:309386112:26:::::::::|h[Jagged Star of the Bear]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949255,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [722]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:07]|h|r |HlootHistory:12|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Greed for: |cff1eff00|Hitem:3056::::::::26:::::::::|h[Forest Leather Pants]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949255,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [723]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:08]|h|r |HlootHistory:12|h[Loot]|h: You passed on: |cff1eff00|Hitem:3056::::::::26:::::::::|h[Forest Leather Pants]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949256,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [724]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:08]|h|r |HlootHistory:12|h[Loot]|h: Greed Roll - 79 for |cff1eff00|Hitem:3056::::::::26:::::::::|h[Forest Leather Pants]|h|r by |cff0070ddTpainwarpigs|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949256,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [725]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:08]|h|r |HlootHistory:12|h[Loot]|h: Greed Roll - 10 for |cff1eff00|Hitem:3056::::::::26:::::::::|h[Forest Leather Pants]|h|r by |cffffffffDangerdann|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949256,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [726]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:08]|h|r |HlootHistory:12|h[Loot]|h: Greed Roll - 100 for |cff1eff00|Hitem:3056::::::::26:::::::::|h[Forest Leather Pants]|h|r by |cff0070ddHolladoss|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949256,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [727]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:08]|h|r |HlootHistory:12|h[Loot]|h: Greed Roll - 1 for |cff1eff00|Hitem:3056::::::::26:::::::::|h[Forest Leather Pants]|h|r by |cff3fc6eaFrosteh|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949256,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [728]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:08]|h|r |HlootHistory:12|h[Loot]|h: |cff0070ddHolladoss|r won: |cff1eff00|Hitem:3056::::::::26:::::::::|h[Forest Leather Pants]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949256,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [729]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:08]|h|r |cff0070ddHolladoss|r receives loot: |cff1eff00|Hitem:3056::::::::26:::::::::|h[Forest Leather Pants]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949256,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [730]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:53]|h|r You receive loot: |cffffffff|Hitem:1015::::::::26:::::::::|h[Lean Wolf Flank]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949301,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [731]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:54:54]|h|r Your share of the loot is 51 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949302,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [732]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:55:02]|h|r Your share of the loot is 30 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949310,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [733]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:55:11]|h|r You have requested to trade with |cff0070ddTpainwarpigs|r.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949319,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [734]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:55:16]|h|r |cff3fc6eaFrosteh|r creates: |cffffffff|Hitem:2136::::::::26:::::::::|h[Conjured Purified Water]|h|rx10.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949324,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [735]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:04]|h|r Your share of the loot is 28 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949372,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [736]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:24]|h|r |HlootHistory:13|h[Loot]|h: |cff1eff00|Hitem:3230::::::::26:::::::::|h[Black Wolf Bracers]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949392,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [737]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:24]|h|r |cff0070ddHolladoss|r receives loot: |cff9d9d9d|Hitem:3402::::::::26:::::::::|h[Soft Patch of Fur]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949392,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [738]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:24]|h|r Archmage Arugal yells: Who dares interfere with the Sons of Arugal?",
					["extraData"] = {
						15, -- [1]
						31, -- [2]
						32, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709949392,
					["timestamp"] = 60064.747,
					["g"] = 0.250980406999588,
					["r"] = 1,
				}, -- [739]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:24]|h|r |cff0070ddHolladoss|r receives loot: |cffffffff|Hitem:1015::::::::26:::::::::|h[Lean Wolf Flank]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949392,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [740]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:28]|h|r |HlootHistory:13|h[Loot]|h: You passed on: |cff1eff00|Hitem:3230::::::::26:::::::::|h[Black Wolf Bracers]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949396,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [741]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:28]|h|r |HlootHistory:13|h[Loot]|h: |cffffffffDangerdann|r has selected Greed for: |cff1eff00|Hitem:3230::::::::26:::::::::|h[Black Wolf Bracers]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949396,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [742]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:29]|h|r |HlootHistory:13|h[Loot]|h: |cff3fc6eaFrosteh|r has selected Greed for: |cff1eff00|Hitem:3230::::::::26:::::::::|h[Black Wolf Bracers]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949397,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [743]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:32]|h|r |HlootHistory:13|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Greed for: |cff1eff00|Hitem:3230::::::::26:::::::::|h[Black Wolf Bracers]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949400,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [744]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:40]|h|r |HlootHistory:13|h[Loot]|h: |cff0070ddHolladoss|r has selected Greed for: |cff1eff00|Hitem:3230::::::::26:::::::::|h[Black Wolf Bracers]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949408,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [745]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:40]|h|r |HlootHistory:13|h[Loot]|h: Greed Roll - 59 for |cff1eff00|Hitem:3230::::::::26:::::::::|h[Black Wolf Bracers]|h|r by |cff0070ddHolladoss|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949408,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [746]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:40]|h|r |HlootHistory:13|h[Loot]|h: Greed Roll - 90 for |cff1eff00|Hitem:3230::::::::26:::::::::|h[Black Wolf Bracers]|h|r by |cff0070ddTpainwarpigs|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949408,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [747]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:40]|h|r |HlootHistory:13|h[Loot]|h: Greed Roll - 75 for |cff1eff00|Hitem:3230::::::::26:::::::::|h[Black Wolf Bracers]|h|r by |cffffffffDangerdann|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949408,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [748]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:40]|h|r |HlootHistory:13|h[Loot]|h: Greed Roll - 50 for |cff1eff00|Hitem:3230::::::::26:::::::::|h[Black Wolf Bracers]|h|r by |cff3fc6eaFrosteh|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949408,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [749]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:40]|h|r |HlootHistory:13|h[Loot]|h: |cff0070ddTpainwarpigs|r won: |cff1eff00|Hitem:3230::::::::26:::::::::|h[Black Wolf Bracers]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949408,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [750]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:56:40]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff1eff00|Hitem:3230::::::::26:::::::::|h[Black Wolf Bracers]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949408,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [751]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:57:25]|h|r Your share of the loot is 60 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949453,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [752]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:07]|h|r You create: |cffffffff|Hitem:6265::::::::26:::::::::|h[Soul Shard]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949555,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [753]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:13]|h|r Your skill in Staves has increased to 19.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949561,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [754]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:14]|h|r |HlootHistory:14|h[Loot]|h: |cff1eff00|Hitem:6314::::::::26:::::::::|h[Wolfmaster Cape]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949562,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [755]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:14]|h|r |cff3fc6eaFrosteh|r receives loot: |cff9d9d9d|Hitem:3402::::::::26:::::::::|h[Soft Patch of Fur]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949562,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [756]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:15]|h|r |cff3fc6eaFrosteh|r receives loot: |cffffffff|Hitem:1015::::::::26:::::::::|h[Lean Wolf Flank]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949563,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [757]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:15]|h|r Your share of the loot is 11 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949563,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [758]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:17]|h|r |HlootHistory:14|h[Loot]|h: |cffffffffDangerdann|r has selected Greed for: |cff1eff00|Hitem:6314::::::::26:::::::::|h[Wolfmaster Cape]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949565,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [759]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:19]|h|r |HlootHistory:14|h[Loot]|h: |cff3fc6eaFrosteh|r has selected Greed for: |cff1eff00|Hitem:6314::::::::26:::::::::|h[Wolfmaster Cape]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949567,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [760]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:22]|h|r |HlootHistory:14|h[Loot]|h: |cff0070ddHolladoss|r has selected Greed for: |cff1eff00|Hitem:6314::::::::26:::::::::|h[Wolfmaster Cape]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949570,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [761]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:25]|h|r |HlootHistory:14|h[Loot]|h: You passed on: |cff1eff00|Hitem:6314::::::::26:::::::::|h[Wolfmaster Cape]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949573,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [762]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:27]|h|r |HlootHistory:14|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Need for: |cff1eff00|Hitem:6314::::::::26:::::::::|h[Wolfmaster Cape]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949575,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [763]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:27]|h|r |HlootHistory:14|h[Loot]|h: Need Roll - 89 for |cff1eff00|Hitem:6314::::::::26:::::::::|h[Wolfmaster Cape]|h|r by |cff0070ddTpainwarpigs|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949575,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [764]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:27]|h|r |HlootHistory:14|h[Loot]|h: |cff0070ddTpainwarpigs|r won: |cff1eff00|Hitem:6314::::::::26:::::::::|h[Wolfmaster Cape]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949575,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [765]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:27]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff1eff00|Hitem:6314::::::::26:::::::::|h[Wolfmaster Cape]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949575,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [766]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:33]|h|r |cff3fc6eaFrosteh|r receives loot: |cff9d9d9d|Hitem:3402::::::::26:::::::::|h[Soft Patch of Fur]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949581,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [767]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:36]|h|r You receive loot: |cffffffff|Hitem:1015::::::::26:::::::::|h[Lean Wolf Flank]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949584,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [768]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:19]|h|r |HlootHistory:15|h[Loot]|h: |cff1eff00|Hitem:4709::::::::26:::::::::|h[Forest Leather Mantle]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949627,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [769]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:20]|h|r Your share of the loot is 64 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949628,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [770]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:21]|h|r |HlootHistory:15|h[Loot]|h: |cff3fc6eaFrosteh|r has selected Greed for: |cff1eff00|Hitem:4709::::::::26:::::::::|h[Forest Leather Mantle]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949629,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [771]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:21]|h|r |HlootHistory:15|h[Loot]|h: |cffffffffDangerdann|r has selected Greed for: |cff1eff00|Hitem:4709::::::::26:::::::::|h[Forest Leather Mantle]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949629,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [772]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:22]|h|r |HlootHistory:15|h[Loot]|h: You passed on: |cff1eff00|Hitem:4709::::::::26:::::::::|h[Forest Leather Mantle]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949630,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [773]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:25]|h|r Your share of the loot is 60 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949633,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [774]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:26]|h|r |HlootHistory:15|h[Loot]|h: |cff0070ddHolladoss|r has selected Greed for: |cff1eff00|Hitem:4709::::::::26:::::::::|h[Forest Leather Mantle]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949634,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [775]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:31]|h|r |HlootHistory:15|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Greed for: |cff1eff00|Hitem:4709::::::::26:::::::::|h[Forest Leather Mantle]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949639,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [776]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:31]|h|r |HlootHistory:15|h[Loot]|h: Greed Roll - 91 for |cff1eff00|Hitem:4709::::::::26:::::::::|h[Forest Leather Mantle]|h|r by |cff0070ddTpainwarpigs|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949639,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [777]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:31]|h|r |HlootHistory:15|h[Loot]|h: Greed Roll - 29 for |cff1eff00|Hitem:4709::::::::26:::::::::|h[Forest Leather Mantle]|h|r by |cffffffffDangerdann|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949639,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [778]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:31]|h|r |HlootHistory:15|h[Loot]|h: Greed Roll - 59 for |cff1eff00|Hitem:4709::::::::26:::::::::|h[Forest Leather Mantle]|h|r by |cff0070ddHolladoss|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949639,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [779]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:31]|h|r |HlootHistory:15|h[Loot]|h: Greed Roll - 97 for |cff1eff00|Hitem:4709::::::::26:::::::::|h[Forest Leather Mantle]|h|r by |cff3fc6eaFrosteh|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949639,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [780]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:31]|h|r |HlootHistory:15|h[Loot]|h: |cff3fc6eaFrosteh|r won: |cff1eff00|Hitem:4709::::::::26:::::::::|h[Forest Leather Mantle]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949639,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [781]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:31]|h|r |cff3fc6eaFrosteh|r receives loot: |cff1eff00|Hitem:4709::::::::26:::::::::|h[Forest Leather Mantle]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949639,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [782]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:01:05]|h|r Archmage Arugal yells: You, too, shall serve!",
					["extraData"] = {
						15, -- [1]
						31, -- [2]
						32, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709949673,
					["timestamp"] = 60064.747,
					["g"] = 0.250980406999588,
					["r"] = 1,
				}, -- [783]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:01:56]|h|r |cffd8d8d8[|r|Hplayer:Drargon:2968|h|cffd88b6530|r:|cff0070ddDrargon|r|h|cffd8d8d8]|r has come online.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949724,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [784]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:02]|h|r Archmage Arugal yells: Release your rage!",
					["extraData"] = {
						15, -- [1]
						31, -- [2]
						32, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709949730,
					["timestamp"] = 60064.747,
					["g"] = 0.250980406999588,
					["r"] = 1,
				}, -- [785]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:05]|h|r Your skill in Staves has increased to 20.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709949733,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [786]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:05]|h|r |HlootHistory:16|h[Loot]|h: |cff0070dd|Hitem:6392::::::::26:::::::::|h[Belt of Arugal]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949733,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [787]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:06]|h|r Your share of the loot is 27 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949734,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [788]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:09]|h|r |HlootHistory:16|h[Loot]|h: |cffffffffDangerdann|r has selected Need for: |cff0070dd|Hitem:6392::::::::26:::::::::|h[Belt of Arugal]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949737,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [789]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:10]|h|r |HlootHistory:16|h[Loot]|h: |cff3fc6eaFrosteh|r has selected Need for: |cff0070dd|Hitem:6392::::::::26:::::::::|h[Belt of Arugal]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949738,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [790]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:11]|h|r |cff3fc6eaFrosteh|r receives loot: |cffffffff|Hitem:3385::::::::26:::::::::|h[Lesser Mana Potion]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949739,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [791]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:12]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:5442::::::::26:::::::::|h[Head of Arugal]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949740,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [792]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:15]|h|r |HlootHistory:16|h[Loot]|h: |cff0070ddHolladoss|r has selected Need for: |cff0070dd|Hitem:6392::::::::26:::::::::|h[Belt of Arugal]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949743,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [793]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:15]|h|r |HlootHistory:16|h[Loot]|h: You have selected Need for: |cff0070dd|Hitem:6392::::::::26:::::::::|h[Belt of Arugal]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949743,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [794]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:21]|h|r You receive loot: |cffffffff|Hitem:5442::::::::26:::::::::|h[Head of Arugal]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949749,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [795]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:24]|h|r |HlootHistory:16|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Greed for: |cff0070dd|Hitem:6392::::::::26:::::::::|h[Belt of Arugal]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949752,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [796]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:24]|h|r |HlootHistory:16|h[Loot]|h: Need Roll - 73 for |cff0070dd|Hitem:6392::::::::26:::::::::|h[Belt of Arugal]|h|r by |cff3fc6eaFrosteh|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949752,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [797]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:24]|h|r |HlootHistory:16|h[Loot]|h: Need Roll - 10 for |cff0070dd|Hitem:6392::::::::26:::::::::|h[Belt of Arugal]|h|r by |cffffffffDangerdann|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949752,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [798]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:24]|h|r |HlootHistory:16|h[Loot]|h: Need Roll - 84 for |cff0070dd|Hitem:6392::::::::26:::::::::|h[Belt of Arugal]|h|r by |cff0070ddHolladoss|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949752,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [799]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:24]|h|r |HlootHistory:16|h[Loot]|h: Need Roll - 68 for |cff0070dd|Hitem:6392::::::::26:::::::::|h[Belt of Arugal]|h|r by |cff00ff00Lavy|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949752,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [800]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:24]|h|r |HlootHistory:16|h[Loot]|h: |cff0070ddHolladoss|r won: |cff0070dd|Hitem:6392::::::::26:::::::::|h[Belt of Arugal]|h|r",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949752,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [801]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:02:24]|h|r |cff0070ddHolladoss|r receives loot: |cff0070dd|Hitem:6392::::::::26:::::::::|h[Belt of Arugal]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949752,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [802]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:03:11]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:6283::::::::26:::::::::|h[The Book of Ur]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949799,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [803]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:03:21]|h|r |cffffffffDangerdann|r leaves the party.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949809,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [804]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:03:44]|h|r You receive loot: |cffffffff|Hitem:6283::::::::26:::::::::|h[The Book of Ur]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949832,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [805]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:03:56]|h|r |cff3fc6eaFrosteh|r leaves the party.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949844,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [806]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:04:02]|h|r |cff0070ddDrargon|r has gone offline.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949850,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [807]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:04:38]|h|r |cff0070ddHolladoss|r leaves the party.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949886,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [808]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:04:51]|h|r Your auction of |cff9d9d9d|Hitem:5136::::::::26:::::::::|h[Torn Furry Ear]|h|r has sold for |cffffffff4|r|cffc7c7cfs|r |cffffffff00|r|cffeda55fc|r!",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949899,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [809]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:05:18]|h|r Your auction of |cff9d9d9d|Hitem:2765::::::::26:::::::::|h[Hunting Knife]|h|r has sold for |cffffffff8|r|cffc7c7cfs|r |cffffffff00|r|cffeda55fc|r!",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709949926,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [810]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:08:59]|h|r Wolfguard Worg attempts to run away in fear!",
					["extraData"] = {
						17, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709950147,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [811]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:09:15]|h|r Your skill in Staves has increased to 21.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709950163,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [812]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:09:16]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:1770::::::::26:::::::::|h[Canvas Vest]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709950164,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [813]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:09:16]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:5635::::::::26:::::::::|h[Sharp Claw]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709950164,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [814]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:09:17]|h|r Your share of the loot is 93 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709950165,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [815]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:09:35]|h|r Your share of the loot is 71 Copper.",
					["extraData"] = {
						29, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709950183,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [816]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:10:25]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Silverpine Forest]|h",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						46, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709950233,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [817]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:10:25]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Silverpine Forest]|h",
					["extraData"] = {
						73, -- [1]
						16, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709950233,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [818]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:11:23]|h|r You create: |cffffffff|Hitem:5511::::::::26:::::::::|h[Lesser Healthstone]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709950291,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [819]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:12:10]|h|r Your skill in Defense has increased to 113.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709950338,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [820]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:15:05]|h|r Your Undercity reputation has increased by 200.",
					["extraData"] = {
						36, -- [1]
						109, -- [2]
						110, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709950513,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 0.501960813999176,
				}, -- [821]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:15:05]|h|r Arugal Must Die completed.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709950513,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [822]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:15:05]|h|r Experience gained: 6600.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709950513,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [823]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:15:05]|h|r You receive item: |cff0070dd|Hitem:6414::::::::26:::::::::|h[Seal of Sylvanas]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709950513,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [824]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:15:05]|h|r Quest accepted: Prove Your Worth",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709950513,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [825]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:16:01]|h|r You receive item: |cffffffff|Hitem:1179::::::::26:::::::::|h[Ice Cold Milk]|h|rx5.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709950569,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [826]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:16:02]|h|r You receive item: |cffffffff|Hitem:1179::::::::26:::::::::|h[Ice Cold Milk]|h|rx5.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709950570,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [827]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:20:24]|h|r |cff3fc6eaMikeg|r has gone offline.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709950832,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [828]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:20:33]|h|r |cffd8d8d8[|r|Hplayer:Mikeg:3196|h|cffd84e4e40|r:|cff3fc6eaMikeg|r|h|cffd8d8d8]|r has come online.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709950841,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [829]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:29:16]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Tirisfal Glades]|h",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						46, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951364,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [830]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:29:16]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Tirisfal Glades]|h",
					["extraData"] = {
						73, -- [1]
						16, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951364,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [831]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:29:32]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Undercity]|h",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						46, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951380,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [832]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:29:32]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. Trade - City]|h",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						95, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951380,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [833]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:29:32]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Undercity]|h",
					["extraData"] = {
						73, -- [1]
						16, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951380,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [834]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:29:39]|h|r You feel rested.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709951387,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [835]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:29:42]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Scarfi:3337:CHANNEL:3|h|cffffffffScarfi|r|h|cffd8d8d8]|r: Enchanter lfw @ org - All recipes, tips not required",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						112, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951390,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [836]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:29:56]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Creamylate-Shadowstrike(AU):3344:CHANNEL:3|h|cffaad372Creamylate|r|h|cffd8d8d8]|r: wts|cff1eff00|Hitem:3187::::::681:1233554816:40:::::::::|h[Sacrificial Kris of the Tiger]|h|r",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						114, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951404,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [837]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:30:01]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Jacobwarrior:3346:CHANNEL:3|h|cffc69b6dJacobwarrior|r|h|cffd8d8d8]|r: WTS |cffffffff|Hitem:12217::::::::40:::::::::|h[Dragonbreath Chili]|h|r 70s per - have 40+",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						116, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951409,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [838]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:30:03]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Wagor:3347:CHANNEL:3|h|cffc69b6dWagor|r|h|cffd8d8d8]|r: LF guild charter signing, will tip",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						118, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951411,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [839]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:30:15]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Grazza:3351:CHANNEL:3|h|cff0070ddGrazza|r|h|cffd8d8d8]|r: LF enchanter strength to gloves, lesser stats chest and dismantle, have mats, will tip",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						120, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951423,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [840]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:30:43]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Scarfi-Shadowstrike(AU):3361:CHANNEL:3|h|cffffffffScarfi|r|h|cffd8d8d8]|r: Enchanter lfw @ org - All recipes, tips not required",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						112, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951451,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [841]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:11]|h|r |Hplayer:Ninjewtsu:0:TEXT_EMOTE:|hNinjewtsu|h dances with Cokeaholic.",
					["extraData"] = {
						12, -- [1]
						122, -- [2]
						123, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709951479,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [842]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:18]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Yayadub:3378:CHANNEL:3|h|cffaad372Yayadub|r|h|cffd8d8d8]|r: RIP Jackie Chan",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						124, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951486,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [843]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:30]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Dingecat-Shadowstrike(AU):3384:CHANNEL:3|h|cffff7c0aDingecat|r|h|cffd8d8d8]|r: 40 Druid Healer LFG BFD",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						126, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951498,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [844]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:50]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Dochaelthus:3387:CHANNEL:3|h|cffffffffDochaelthus|r|h|cffd8d8d8]|r: WTS|cff1eff00|Hitem:14634::::::::2:::::::::|h[Recipe: Frost Oil]|h|r 99s",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						128, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951518,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [845]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:54]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Scarfi-Shadowstrike(AU):3388:CHANNEL:3|h|cffffffffScarfi|r|h|cffd8d8d8]|r: Enchanter lfw @ org - All recipes, tips not required",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						112, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951522,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [846]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:56]|h|r Congratulations, you have reached level 27!",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709951524,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [847]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:56]|h|r You have gained 25 hit points and 48 mana.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709951524,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [848]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:56]|h|r You have gained 1 talent point.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709951524,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [849]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:56]|h|r Your Strength increases by 1.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709951524,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [850]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:56]|h|r Your Intellect increases by 2.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709951524,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [851]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:56]|h|r Your Spirit increases by 1.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709951524,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [852]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:56]|h|r Your Undercity reputation has increased by 100.",
					["extraData"] = {
						36, -- [1]
						109, -- [2]
						110, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709951524,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 0.501960813999176,
				}, -- [853]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:56]|h|r Your skill in Destruction has increased to 135.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709951524,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [854]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:56]|h|r Your skill in Demonology has increased to 135.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709951524,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [855]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:56]|h|r Your skill in Affliction has increased to 135.",
					["extraData"] = {
						27, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709951524,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [856]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:56]|h|r You receive item: |cff1eff00|Hitem:6335::::::::27:::::::::|h[Grizzled Boots]|h|r.",
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709951524,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [857]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:56]|h|r The Book of Ur completed.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709951524,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [858]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:31:56]|h|r Experience gained: 4200.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709951524,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [859]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:32:45]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Scarfi-Shadowstrike(AU):3406:CHANNEL:3|h|cffffffffScarfi|r|h|cffd8d8d8]|r: Enchanter lfw @ org - All recipes, tips not required",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						112, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951573,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [860]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:33:42]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Scarfi-Shadowstrike(AU):3447:CHANNEL:3|h|cffffffffScarfi|r|h|cffd8d8d8]|r: Enchanter lfw @ org - All recipes, tips not required",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						112, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951630,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [861]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:34:17]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Jacobwarrior-Shadowstrike(AU):3472:CHANNEL:3|h|cffc69b6dJacobwarrior|r|h|cffd8d8d8]|r: WTS |cffffffff|Hitem:12217::::::::40:::::::::|h[Dragonbreath Chili]|h|r 70s per - have 40+",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						116, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951665,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [862]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:34:18]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Dingecat-Shadowstrike(AU):3475:CHANNEL:3|h|cffff7c0aDingecat|r|h|cffd8d8d8]|r: Resto Druid LFG BFD",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						126, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951666,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [863]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:34:23]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Yeffyhuntz-Shadowstrike(AU):3479:CHANNEL:3|h|cffaad372Yeffyhuntz|r|h|cffd8d8d8]|r: wts |cff0070dd|Hitem:12992::::::::28:::::::::|h[Searing Blade]|h|r",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						130, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951671,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [864]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:34:46]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Frosteh-Shadowstrike(AU):3497:CHANNEL:3|h|cff3fc6eaFrosteh|r|h|cffd8d8d8]|r: LFG BFD - dps",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						132, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951694,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [865]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:35:17]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Dingecat-Shadowstrike(AU):3523:CHANNEL:3|h|cffff7c0aDingecat|r|h|cffd8d8d8]|r: healer LFG BFD",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						126, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951725,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [866]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:35:24]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Dagatt-Shadowstrike(AU):3527:CHANNEL:3|h|cffaad372Dagatt|r|h|cffd8d8d8]|r: LFG BFD",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						134, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951732,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [867]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:35:36]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Jacobwarrior-Shadowstrike(AU):3535:CHANNEL:3|h|cffc69b6dJacobwarrior|r|h|cffd8d8d8]|r: WTS |cffffffff|Hitem:12217::::::::40:::::::::|h[Dragonbreath Chili]|h|r 70s per - have 30+",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						116, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951744,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [868]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:35:36]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Shtdispel-Shadowstrike(AU):3536:CHANNEL:3|h|cffffffffShtdispel|r|h|cffd8d8d8]|r: LF Tank RFC pst",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						136, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951744,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [869]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:36:22]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Dagatt-Shadowstrike(AU):3559:CHANNEL:3|h|cffaad372Dagatt|r|h|cffd8d8d8]|r: hi",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						134, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951790,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [870]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:38:28]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Flayed:3624:CHANNEL:3|h|cffffffffFlayed|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t Max Tailor/Enchanter (can do dismantle and 3 agi to cloak) LFW in Org pst |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						138, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709951916,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [871]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:38:40]|h|r You are now AFK: Away from Keyboard",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709951928,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [872]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:38:43]|h|r You are no longer AFK.",
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709951931,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [873]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:40:08]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Scarfi-Shadowstrike(AU):3653:CHANNEL:3|h|cffffffffScarfi|r|h|cffd8d8d8]|r: Enchanter lfw @ org - All recipes, tips not required",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						112, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709952016,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [874]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:40:14]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Mcv:3656:CHANNEL:3|h|cfffff468Mcv|r|h|cffd8d8d8]|r: any org booners",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						140, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709952022,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [875]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:40:29]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Ketameme-Shadowstrike(AU):3660:CHANNEL:3|h|cff3fc6eaKetameme|r|h|cffd8d8d8]|r: LFM BFD - Staff rez",
					["extraData"] = {
						72, -- [1]
						50, -- [2]
						142, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709952037,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [876]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:40:52]|h|r [Y] |cffd8d8d8[|r|Hplayer:Monkeydluffy-Shadowstrike(AU):3666:YELL|h|cfffff468Monkeydluffy|r|h|cffd8d8d8]|r: WTB Port to org?! pst me",
					["extraData"] = {
						7, -- [1]
						33, -- [2]
						144, -- [3]
						["n"] = 3,
					},
					["b"] = 0.250980406999588,
					["serverTime"] = 1709952060,
					["timestamp"] = 60064.747,
					["g"] = 0.250980406999588,
					["r"] = 1,
				}, -- [877]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:41:01]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Bambe-Shadowstrike(AU):3670:CHANNEL:2|h|cffc69b6dBambe|r|h|cffd8d8d8]|r: DPS LFG RFD LVL 40 FUR WARR, 3/3 Cleave (Consume, Full Pre Bis Phase 2, Enchanted)",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						145, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709952069,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [878]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:53]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["serverTime"] = 1709976365,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [879]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:11]|h|r |cffd8d8d8[|r|Hplayer:Tpainwarpigs:2|h|cffd8d83f27|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r has invited you to join a group.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973261,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [880]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:13]|h|r Dungeon difficulty set to Normal",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973263,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [881]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:17]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Quell:4:CHANNEL:3|h|cfffff468Quell|r|h|cffd8d8d8]|r: their is no remedy for that",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973267,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [882]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:34]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Necrocism:12:CHANNEL:3|h|cff0070ddNecrocism|r|h|cffd8d8d8]|r: LFG BFD",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973284,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						6, -- [3]
						["n"] = 3,
					},
				}, -- [883]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:36]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Quell-Shadowstrike(AU):14:CHANNEL:3|h|cfffff468Quell|r|h|cffd8d8d8]|r: she must be going somewhere else",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973286,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [884]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:36]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Magoral:15:CHANNEL:3|h|cff0070ddMagoral|r|h|cffd8d8d8]|r: Margartias -- but the balance is hard.",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973286,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [885]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:53]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Harlia:21:CHANNEL:3|h|cffffffffHarlia|r|h|cffd8d8d8]|r: anyone able to do dismantle for me?",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973303,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						10, -- [3]
						["n"] = 3,
					},
				}, -- [886]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:56]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Rhokdoomlar:23:CHANNEL:3|h|cffaad372Rhokdoomlar|r|h|cffd8d8d8]|r: lol",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973306,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						12, -- [3]
						["n"] = 3,
					},
				}, -- [887]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:16]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Quell-Shadowstrike(AU):26:CHANNEL:3|h|cfffff468Quell|r|h|cffd8d8d8]|r: I am sorry my friend",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973326,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [888]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:24]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Liftmeup:28:CHANNEL:3|h|cffffffffLiftmeup|r|h|cffd8d8d8]|r: Chanter & Tailor LFW||2H +5 dmg||1H +3 dmg or +7 frost dmg, Dismantle||Chest +50 hp/mp or +2 stats Retricution||Bracer +5 str/stam/int||Boots 8%  speed, +5 stam, +3 Agi||Gloves +5 str/agi, +5 herb/skin/mine||Cloak +3 Agi||Shield +5 stam, 2% block",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973334,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						14, -- [3]
						["n"] = 3,
					},
				}, -- [889]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:45]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Quell-Shadowstrike(AU):42:CHANNEL:3|h|cfffff468Quell|r|h|cffd8d8d8]|r: Lockpicker in town, come get those box's opened, tips appreciated. Currently next to Supply Officer in Org. If u dont see me invite me to your Layer.",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973355,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [890]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:53]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Karlness:50:CHANNEL:3|h|cffaad372Karlness|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_6:0|t|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7:0|tAFP|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7:0|t|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_6:0|t Azeroth Federal Police is LFM |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|tHealers - Priest/Shaman/Drood  |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8:0|t Active PVP Guild - Multiple Raid teams full clearing. If you're new that's okay, just be willing to learn!",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973363,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [891]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:02]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Yasskween:56:CHANNEL:3|h|cffaad372Yasskween|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_5:0|t|cffffffff<|r|cff00ff00Valhalla|r|cffffffff>|r|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_5:0|t One of the biggest guilds on Shadowstrike is recruiting raid teams + leads, raiders in preparation for P3.  CURRENT PRIO for shamans, healers and ranged dps. We're at 13 teams (NZ, AU, SEA raid times), and 900+ members, PST 4 inv",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973372,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [892]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:12]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Grimezz-Shadowstrike(AU):64:CHANNEL:3|h|cff3fc6eaGrimezz|r|h|cffd8d8d8]|r: mage LFG gnomer, exp, boon, consum, etc",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973382,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						20, -- [3]
						["n"] = 3,
					},
				}, -- [893]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:36]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Tirisfal Glades]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973406,
					["extraData"] = {
						71, -- [1]
						22, -- [2]
						23, -- [3]
						["n"] = 3,
					},
				}, -- [894]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:36]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. Trade - City]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973406,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						25, -- [3]
						["n"] = 3,
					},
				}, -- [895]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:36]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Tirisfal Glades]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973406,
					["extraData"] = {
						73, -- [1]
						27, -- [2]
						28, -- [3]
						["n"] = 3,
					},
				}, -- [896]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:58]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Silverpine Forest]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973428,
					["extraData"] = {
						71, -- [1]
						22, -- [2]
						23, -- [3]
						["n"] = 3,
					},
				}, -- [897]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:58]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Silverpine Forest]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973428,
					["extraData"] = {
						73, -- [1]
						27, -- [2]
						28, -- [3]
						["n"] = 3,
					},
				}, -- [898]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:37:30]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Alterac Mountains]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973460,
					["extraData"] = {
						71, -- [1]
						22, -- [2]
						23, -- [3]
						["n"] = 3,
					},
				}, -- [899]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:37:30]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Alterac Mountains]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973460,
					["extraData"] = {
						73, -- [1]
						27, -- [2]
						28, -- [3]
						["n"] = 3,
					},
				}, -- [900]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:18]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Hillsbrad Foothills]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973508,
					["extraData"] = {
						71, -- [1]
						22, -- [2]
						23, -- [3]
						["n"] = 3,
					},
				}, -- [901]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:18]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Hillsbrad Foothills]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973508,
					["extraData"] = {
						73, -- [1]
						27, -- [2]
						28, -- [3]
						["n"] = 3,
					},
				}, -- [902]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:42]|h|r Elixir of Suffering completed.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973532,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [903]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:42]|h|r Experience gained: 360.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973532,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [904]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:42]|h|r Received 4 Silver, 50 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973532,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [905]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:42]|h|r Your Undercity reputation has increased by 25.",
					["b"] = 1,
					["r"] = 0.501960813999176,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973532,
					["extraData"] = {
						36, -- [1]
						30, -- [2]
						31, -- [3]
						["n"] = 3,
					},
				}, -- [906]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:42]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Yeffyhuntz:111:CHANNEL:2|h|cffaad372Yeffyhuntz|r|h|cffd8d8d8]|r: 35 hunters killing at fields if anyone wants to deal with him",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973532,
					["extraData"] = {
						71, -- [1]
						22, -- [2]
						32, -- [3]
						["n"] = 3,
					},
				}, -- [907]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:42]|h|r Quest accepted: Elixir of Suffering",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973532,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [908]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:42]|h|r You receive item: |cffffffff|Hitem:3495::::::::27:::::::::|h[Elixir of Suffering]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973532,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [909]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:45]|h|r Your Undercity reputation has increased by 100.",
					["b"] = 1,
					["r"] = 0.501960813999176,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973535,
					["extraData"] = {
						36, -- [1]
						30, -- [2]
						31, -- [3]
						["n"] = 3,
					},
				}, -- [910]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:45]|h|r Elixir of Suffering completed.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973535,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [911]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:45]|h|r Experience gained: 3500.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973535,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [912]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:46]|h|r Umpi says: Croak!",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973536,
					["extraData"] = {
						13, -- [1]
						36, -- [2]
						37, -- [3]
						["n"] = 3,
					},
				}, -- [913]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:57]|h|r Your Undercity reputation has increased by 100.",
					["b"] = 1,
					["r"] = 0.501960813999176,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973547,
					["extraData"] = {
						36, -- [1]
						30, -- [2]
						31, -- [3]
						["n"] = 3,
					},
				}, -- [914]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:57]|h|r Battle of Hillsbrad completed.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973547,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [915]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:57]|h|r Experience gained: 4000.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973547,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [916]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:57]|h|r Received 54 Silver.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973547,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [917]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:57]|h|r Quest accepted: Battle of Hillsbrad",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973547,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [918]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:39:39]|h|r Umpi says: Croak!",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973589,
					["extraData"] = {
						13, -- [1]
						36, -- [2]
						37, -- [3]
						["n"] = 3,
					},
				}, -- [919]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:40:58]|h|r |Hplayer:Kugiisaki:0:TEXT_EMOTE:|hKugiisaki|h thanks Cronny.",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973668,
					["extraData"] = {
						12, -- [1]
						38, -- [2]
						39, -- [3]
						["n"] = 3,
					},
				}, -- [920]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:42:01]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:1081::::::::27:::::::::|h[Crisp Spider Meat]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973731,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [921]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:42:17]|h|r You receive loot: |cffffffff|Hitem:2251::::::::27:::::::::|h[Gooey Spider Leg]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973747,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [922]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:43:24]|h|r Your skill in Wands has increased to 130.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973814,
					["extraData"] = {
						27, -- [1]
						40, -- [2]
						41, -- [3]
						["n"] = 3,
					},
				}, -- [923]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:43:33]|h|r Looting changed to free-for-all.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973823,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [924]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:43:51]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3730::::::::27:::::::::|h[Big Bear Meat]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973841,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [925]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:43:51]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:11407::::::::27:::::::::|h[Torn Bear Pelt]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973841,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [926]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:44:20]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:2940::::::::27:::::::::|h[Bloody Bear Paw]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973870,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [927]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:44:34]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):232:GUILD|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: yo craig",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973884,
					["extraData"] = {
						5, -- [1]
						42, -- [2]
						43, -- [3]
						["n"] = 3,
					},
				}, -- [928]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:44:37]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):233:GUILD|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: have a good race",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973887,
					["extraData"] = {
						5, -- [1]
						42, -- [2]
						43, -- [3]
						["n"] = 3,
					},
				}, -- [929]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:44:43]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Craiglowndes-Shadowstrike(AU):234:GUILD|h|cff65b26524|r:|cff0070ddCraiglowndes|r|h|cffd8d8d8]|r: thanks mate",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973893,
					["extraData"] = {
						5, -- [1]
						42, -- [2]
						44, -- [3]
						["n"] = 3,
					},
				}, -- [930]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:44:48]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):235:GUILD|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: all g",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973898,
					["extraData"] = {
						5, -- [1]
						42, -- [2]
						43, -- [3]
						["n"] = 3,
					},
				}, -- [931]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:45:01]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):239:GUILD|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: |cffffffff|Hurl:https://www.youtube.com/watch?v=vgPrHYUjJGs&ab_channel=yeeTWOsduck|h[https://www.youtube.com/watch?v=vgPrHYUjJGs&ab_channel=yeeTWOsduck]|h|r",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973911,
					["extraData"] = {
						5, -- [1]
						42, -- [2]
						43, -- [3]
						["n"] = 3,
					},
				}, -- [932]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:45:04]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:11406::::::::27:::::::::|h[Rotting Bear Carcass]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973914,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [933]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:45:04]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:3702::::::::27:::::::::|h[Bear Gall Bladder]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973914,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [934]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:45:04]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3730::::::::27:::::::::|h[Big Bear Meat]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973914,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [935]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:45:21]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3730::::::::27:::::::::|h[Big Bear Meat]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973931,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [936]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:06]|h|r Your skill in Wands has increased to 131.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973976,
					["extraData"] = {
						27, -- [1]
						40, -- [2]
						41, -- [3]
						["n"] = 3,
					},
				}, -- [937]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:07]|h|r Hillsbrad Apprentice Blacksmith attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973977,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [938]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:08]|h|r You feel normal.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973978,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [939]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:09]|h|r You receive loot: |cffffffff|Hitem:4306::::::::27:::::::::|h[Silk Cloth]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973979,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [940]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:10]|h|r Your share of the loot is 26 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973980,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [941]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:10]|h|r You receive loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973980,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [942]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:11]|h|r Your share of the loot is 26 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973981,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [943]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:26]|h|r Hillsbrad Apprentice Blacksmith attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709973996,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [944]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:31]|h|r Hillsbrad Apprentice Blacksmith attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974001,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [945]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:34]|h|r You receive loot: |cffffffff|Hitem:4306::::::::27:::::::::|h[Silk Cloth]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974004,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [946]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:36]|h|r Your share of the loot is 52 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974006,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [947]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:38]|h|r You receive loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974008,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [948]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:39]|h|r Your share of the loot is 13 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974009,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [949]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:40]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3564::::::::27:::::::::|h[Shipment of Iron]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974010,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [950]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:46]|h|r You receive loot: |cffffffff|Hitem:3564::::::::27:::::::::|h[Shipment of Iron]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974016,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [951]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:49]|h|r Pizpep says: Alright I'm going! Stop yelling!",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974019,
					["extraData"] = {
						13, -- [1]
						36, -- [2]
						37, -- [3]
						["n"] = 3,
					},
				}, -- [952]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:57]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974027,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [953]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:57]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974027,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [954]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:46:58]|h|r Your share of the loot is 31 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974028,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [955]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:47:24]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:422::::::::27:::::::::|h[Dwarven Mild]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974054,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [956]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:47:24]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974054,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [957]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:47:25]|h|r Your share of the loot is 56 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974055,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [958]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:47:42]|h|r Hillsbrad Footman attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974072,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [959]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:47:43]|h|r You receive loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|rx2.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974073,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [960]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:47:43]|h|r You receive loot: |cffffffff|Hitem:422::::::::27:::::::::|h[Dwarven Mild]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974073,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [961]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:47:44]|h|r Your share of the loot is 10 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974074,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [962]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:48:02]|h|r Your share of the loot is 34 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974092,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [963]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:48:14]|h|r Hillsbrad Apprentice Blacksmith attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974104,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [964]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:48:16]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974106,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [965]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:48:17]|h|r Your share of the loot is 18 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974107,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [966]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:48:41]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974131,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [967]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:48:47]|h|r Your share of the loot is 21 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974137,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [968]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:48:56]|h|r Your auction of Torn Bear Pelt has expired.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974146,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [969]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:49:12]|h|r Hillsbrad Footman attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974162,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [970]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:49:23]|h|r Hillsbrad Footman attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974173,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [971]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:49:28]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974178,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [972]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:49:29]|h|r Your share of the loot is 53 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974179,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [973]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:49:48]|h|r You create: |cffffffff|Hitem:5232::::::::27:::::::::|h[Minor Soulstone]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974198,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [974]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:49:51]|h|r You create: |cffffffff|Hitem:5511::::::::27:::::::::|h[Lesser Healthstone]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974201,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [975]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:49:56]|h|r You have requested to trade with |cff0070ddTpainwarpigs|r.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974206,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [976]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:50:31]|h|r You create: |cffffffff|Hitem:5232::::::::27:::::::::|h[Minor Soulstone]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974241,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [977]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:50:37]|h|r Your share of the loot is 13 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974247,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [978]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:50:50]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974260,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [979]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:50:53]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|rx2.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974263,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [980]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:50:54]|h|r Your share of the loot is 1 Silver, 2 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974264,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [981]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:51:20]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974290,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [982]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:51:27]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Stinkypinkie-Shadowstrike(AU):426:CHANNEL:2|h|cffffffffStinkypinkie|r|h|cffd8d8d8]|r: mob 3 alli camping synduicate",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974297,
					["extraData"] = {
						71, -- [1]
						22, -- [2]
						52, -- [3]
						["n"] = 3,
					},
				}, -- [983]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:51:28]|h|r Your skill in Defense has increased to 114.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974298,
					["extraData"] = {
						27, -- [1]
						40, -- [2]
						41, -- [3]
						["n"] = 3,
					},
				}, -- [984]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:51:36]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Stinkypinkie-Shadowstrike(AU):428:CHANNEL:2|h|cffffffffStinkypinkie|r|h|cffd8d8d8]|r: syndicate",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974306,
					["extraData"] = {
						71, -- [1]
						22, -- [2]
						52, -- [3]
						["n"] = 3,
					},
				}, -- [985]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:51:37]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974307,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [986]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:51:52]|h|r Your share of the loot is 50 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974322,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [987]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:52:00]|h|r Hillsbrad Tailor attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974330,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [988]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:52:02]|h|r Pizpep says: What? You mean you can't kill this one by yourself?",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974332,
					["extraData"] = {
						13, -- [1]
						36, -- [2]
						37, -- [3]
						["n"] = 3,
					},
				}, -- [989]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:52:07]|h|r Your share of the loot is 22 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974337,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [990]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:52:17]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974347,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [991]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:52:22]|h|r Your share of the loot is 45 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974352,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [992]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:52:29]|h|r Your skill in Wands has increased to 132.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974359,
					["extraData"] = {
						27, -- [1]
						40, -- [2]
						41, -- [3]
						["n"] = 3,
					},
				}, -- [993]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:52:41]|h|r Hillsbrad Tailor attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974371,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [994]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:52:47]|h|r Hillsbrad Tailor attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974377,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [995]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:52:53]|h|r You receive loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974383,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [996]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:52:53]|h|r You receive loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974383,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [997]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:52:54]|h|r Your share of the loot is 62 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974384,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [998]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:52:55]|h|r You receive loot: |cffffffff|Hitem:2589::::::::27:::::::::|h[Linen Cloth]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974385,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [999]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:52:55]|h|r You receive loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974385,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1000]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:52:56]|h|r Your share of the loot is 31 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974386,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1001]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:53:09]|h|r You have requested to trade with |cff0070ddTpainwarpigs|r.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974399,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1002]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:53:17]|h|r You have requested to trade with |cff0070ddTpainwarpigs|r.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974407,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1003]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:53:26]|h|r You receive loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974416,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1004]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:53:27]|h|r Your share of the loot is 11 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974417,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1005]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:53:27]|h|r You receive loot: |cff1eff00|Hitem:211819::::::::27:::::::::|h[Waylaid Supplies: Bronze Bars]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974417,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1006]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:53:40]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974430,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1007]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:53:42]|h|r You receive loot: |cff9d9d9d|Hitem:1778::::::::27:::::::::|h[Brocade Vest]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974432,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1008]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:53:42]|h|r You receive loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|rx2.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974432,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1009]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:53:43]|h|r Your share of the loot is 20 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974433,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1010]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:53:57]|h|r Hillsbrad Tailor attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974447,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1011]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:54:03]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974453,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1012]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:54:03]|h|r Hillsbrad Tailor attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974453,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1013]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:54:08]|h|r Your share of the loot is 28 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974458,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1014]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:54:10]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974460,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1015]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:54:11]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|rx2.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974461,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1016]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:54:11]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974461,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1017]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:54:11]|h|r Your share of the loot is 74 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974461,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1018]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:54:52]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974502,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1019]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:55:01]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974511,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1020]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:55:01]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974511,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1021]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:55:05]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974515,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1022]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:55:15]|h|r You receive loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|rx2.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974525,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1023]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:55:15]|h|r You receive loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974525,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1024]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:55:16]|h|r Your share of the loot is 22 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974526,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1025]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:55:21]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974531,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1026]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:55:30]|h|r Your share of the loot is 16 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974540,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1027]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:55:33]|h|r You receive loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|rx2.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974543,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1028]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:55:34]|h|r Your share of the loot is 45 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974544,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1029]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:55:52]|h|r Your share of the loot is 11 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974562,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1030]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:55:57]|h|r Your share of the loot is 38 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974567,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1031]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:56:05]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974575,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1032]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:56:10]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974580,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1033]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:56:13]|h|r You receive loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974583,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1034]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:56:14]|h|r Your share of the loot is 9 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974584,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1035]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:56:17]|h|r Your skill in Defense has increased to 115.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974587,
					["extraData"] = {
						27, -- [1]
						40, -- [2]
						41, -- [3]
						["n"] = 3,
					},
				}, -- [1036]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:56:33]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974603,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1037]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:56:38]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:2783::::::::27:::::::::|h[Shoddy Blunderbuss]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974608,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1038]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:56:39]|h|r Your share of the loot is 8 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974609,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1039]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:56:46]|h|r Your share of the loot is 42 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974616,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1040]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:56:59]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974629,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1041]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:57:00]|h|r Your share of the loot is 30 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974630,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1042]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:57:20]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974650,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1043]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:57:27]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|rx2.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974657,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1044]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:57:28]|h|r Your share of the loot is 13 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974658,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1045]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:57:43]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974673,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1046]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:57:45]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974675,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1047]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:57:55]|h|r Pizpep says: Just release me already! I've had enough!",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974685,
					["extraData"] = {
						13, -- [1]
						36, -- [2]
						37, -- [3]
						["n"] = 3,
					},
				}, -- [1048]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:14]|h|r [Y] |cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):601:YELL|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: TY",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.250980406999588,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974704,
					["extraData"] = {
						7, -- [1]
						54, -- [2]
						55, -- [3]
						["n"] = 3,
					},
				}, -- [1049]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:20]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974710,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1050]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:23]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:4306::::::::27:::::::::|h[Silk Cloth]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974713,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1051]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:24]|h|r Your share of the loot is 39 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974714,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1052]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:25]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|rx2.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974715,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1053]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:25]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:4538::::::::27:::::::::|h[Snapvine Watermelon]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974715,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1054]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:25]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:1775::::::::27:::::::::|h[Brocade Gloves]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974715,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1055]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:25]|h|r You receive loot: |cffffffff|Hitem:4306::::::::27:::::::::|h[Silk Cloth]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974715,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1056]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:25]|h|r You receive loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974715,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1057]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:26]|h|r Your share of the loot is 80 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974716,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1058]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:29]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:211853::::::::27:::::::::|h[Scroll: VOCE WELL]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974719,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1059]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:29]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:929::::::::27:::::::::|h[Healing Potion]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974719,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1060]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:29]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974719,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1061]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:30]|h|r Your share of the loot is 34 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974720,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1062]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:33]|h|r Your share of the loot is 51 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974723,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1063]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:41]|h|r You receive loot: |cffffffff|Hitem:929::::::::27:::::::::|h[Healing Potion]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974731,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1064]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:58:42]|h|r Your share of the loot is 24 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974732,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1065]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:59:19]|h|r You receive loot: |cffffffff|Hitem:5635::::::::27:::::::::|h[Sharp Claw]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974769,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1066]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:59:19]|h|r You receive loot: |cffffffff|Hitem:3731::::::::27:::::::::|h[Lion Meat]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974769,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1067]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:59:19]|h|r You receive loot: |cffffffff|Hitem:3496::::::::27:::::::::|h[Mountain Lion Blood]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974769,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1068]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:59:56]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974806,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1069]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:59:56]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974806,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1070]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:59:56]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974806,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1071]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:59:59]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974809,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1072]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:05]|h|r You receive loot: |cff1eff00|Hitem:4661::::::::27:::::::::|h[Bright Mantle]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974815,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1073]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:06]|h|r You receive loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974816,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1074]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:06]|h|r Your share of the loot is 67 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974816,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1075]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:07]|h|r Your skill in Wands has increased to 133.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974817,
					["extraData"] = {
						27, -- [1]
						40, -- [2]
						41, -- [3]
						["n"] = 3,
					},
				}, -- [1076]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:12]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974822,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1077]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:15]|h|r You receive loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|rx2.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974825,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1078]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:15]|h|r You receive loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974825,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1079]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:16]|h|r Your share of the loot is 32 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974826,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1080]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:36]|h|r You receive loot: |cff9d9d9d|Hitem:1778::::::::27:::::::::|h[Brocade Vest]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974846,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1081]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:36]|h|r You receive loot: |cffffffff|Hitem:4538::::::::27:::::::::|h[Snapvine Watermelon]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974846,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1082]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:36]|h|r You receive loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974846,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1083]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:37]|h|r Your share of the loot is 8 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974847,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1084]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:45]|h|r Your skill in Defense has increased to 116.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974855,
					["extraData"] = {
						27, -- [1]
						40, -- [2]
						41, -- [3]
						["n"] = 3,
					},
				}, -- [1085]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:46]|h|r You receive loot: |cff9d9d9d|Hitem:1824::::::::27:::::::::|h[Shiny War Axe]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974856,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1086]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:47]|h|r Your share of the loot is 32 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974857,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1087]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:51]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974861,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1088]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:00:55]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974865,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1089]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:03]|h|r You receive loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|rx2.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974873,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1090]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:04]|h|r Your share of the loot is 7 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974874,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1091]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:06]|h|r You receive loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|rx2.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974876,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1092]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:07]|h|r Your share of the loot is 36 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974877,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1093]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:19]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Yeffyhuntz-Shadowstrike(AU):696:CHANNEL:2|h|cffaad372Yeffyhuntz|r|h|cffd8d8d8]|r: LF |Hquestie:517:Player-5818-00A8688F|h|cFFFF8040[|r|cFFFF8040[30] Elixir of Agony|r|cFFFF8040]|r|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974889,
					["extraData"] = {
						71, -- [1]
						22, -- [2]
						32, -- [3]
						["n"] = 3,
					},
				}, -- [1094]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:21]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974891,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1095]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:23]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974893,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1096]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:30]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974900,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1097]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:31]|h|r You receive loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974901,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1098]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:32]|h|r Your share of the loot is 33 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974902,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1099]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:39]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974909,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1100]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:40]|h|r Your share of the loot is 10 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974910,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1101]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:46]|h|r You receive loot: |cffffffff|Hitem:4538::::::::27:::::::::|h[Snapvine Watermelon]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974916,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1102]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:46]|h|r You receive loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974916,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1103]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:47]|h|r Your share of the loot is 47 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974917,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1104]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:01:52]|h|r Your share of the loot is 23 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974922,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1105]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:02:20]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974950,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1106]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:02:20]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974950,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1107]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:02:22]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974952,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1108]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:02:24]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974954,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1109]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:02:25]|h|r Your share of the loot is 16 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974955,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1110]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:02:29]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|rx2.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974959,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1111]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:02:30]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:1818::::::::27:::::::::|h[Standard Claymore]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974960,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1112]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:02:30]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:4306::::::::27:::::::::|h[Silk Cloth]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974960,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1113]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:02:30]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974960,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1114]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:02:30]|h|r Your share of the loot is 45 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974960,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1115]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:02:31]|h|r Your share of the loot is 49 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974961,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1116]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:02:57]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974987,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1117]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:03:02]|h|r Your share of the loot is 17 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974992,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1118]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:03:04]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:4538::::::::27:::::::::|h[Snapvine Watermelon]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974994,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1119]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:03:05]|h|r Your share of the loot is 48 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709974995,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1120]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:03:16]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Yeffyhuntz-Shadowstrike(AU):750:CHANNEL:2|h|cffaad372Yeffyhuntz|r|h|cffd8d8d8]|r: LF |Hquestie:517:Player-5818-00A8688F|h|cFFFF8040[|r|cFFFF8040[30+] Elixir of Agony|r|cFFFF8040]|r|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975006,
					["extraData"] = {
						71, -- [1]
						22, -- [2]
						32, -- [3]
						["n"] = 3,
					},
				}, -- [1121]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:03:33]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975023,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1122]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:03:37]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975027,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1123]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:03:38]|h|r Your share of the loot is 9 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975028,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1124]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:03:58]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975048,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1125]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:04:03]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975053,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1126]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:04:03]|h|r Hillsbrad Tailor attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975053,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1127]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:04:09]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975059,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1128]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:04:12]|h|r Your share of the loot is 20 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975062,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1129]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:04:13]|h|r You receive loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975063,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1130]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:04:14]|h|r Your share of the loot is 49 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975064,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1131]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:04:28]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975078,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1132]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:04:30]|h|r You receive loot: |cffffffff|Hitem:422::::::::27:::::::::|h[Dwarven Mild]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975080,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1133]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:04:30]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:422::::::::27:::::::::|h[Dwarven Mild]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975080,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1134]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:04:31]|h|r Your share of the loot is 31 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975081,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1135]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:04:38]|h|r Your share of the loot is 12 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975088,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1136]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:04:54]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975104,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1137]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:05:04]|h|r You receive loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975114,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1138]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:05:05]|h|r Your share of the loot is 56 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975115,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1139]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:05:16]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975126,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1140]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:05:25]|h|r You receive loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975135,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1141]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:05:26]|h|r Your share of the loot is 9 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975136,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1142]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:05:38]|h|r Hillsbrad Farmhand attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975148,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1143]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:05:43]|h|r Your share of the loot is 33 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975153,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1144]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:06:04]|h|r Your share of the loot is 32 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975174,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1145]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:06:27]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975197,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1146]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:06:28]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975198,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1147]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:06:34]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3385::::::::27:::::::::|h[Lesser Mana Potion]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975204,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1148]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:06:34]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975204,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1149]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:06:35]|h|r Your share of the loot is 39 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975205,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1150]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:06:39]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975209,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1151]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:06:40]|h|r Your share of the loot is 48 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975210,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1152]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:06:52]|h|r Hillsbrad Farmer attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975222,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1153]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:06:56]|h|r Hillsbrad Peasant attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975226,
					["extraData"] = {
						17, -- [1]
						48, -- [2]
						49, -- [3]
						["n"] = 3,
					},
				}, -- [1154]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:06:57]|h|r Your share of the loot is 8 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975227,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1155]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:06:58]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:422::::::::27:::::::::|h[Dwarven Mild]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975228,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1156]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:06:58]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3692::::::::27:::::::::|h[Hillsbrad Human Skull]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975228,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1157]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:06:59]|h|r Your share of the loot is 38 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975229,
					["extraData"] = {
						29, -- [1]
						50, -- [2]
						51, -- [3]
						["n"] = 3,
					},
				}, -- [1158]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:07:38]|h|r You receive loot: |cffffffff|Hitem:3496::::::::27:::::::::|h[Mountain Lion Blood]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975268,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1159]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:08:27]|h|r [Y] |cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):870:YELL|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: TY",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.250980406999588,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975317,
					["extraData"] = {
						7, -- [1]
						54, -- [2]
						55, -- [3]
						["n"] = 3,
					},
				}, -- [1160]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:08:28]|h|r [S] |cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):871:SAY|h|cffd8d83f27|r:|cff8787edLavy|r|h|cffd8d8d8]|r: <3",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975318,
					["extraData"] = {
						2, -- [1]
						56, -- [2]
						57, -- [3]
						["n"] = 3,
					},
				}, -- [1161]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:08:47]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3730::::::::27:::::::::|h[Big Bear Meat]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975337,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1162]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:09:10]|h|r You receive loot: |cff9d9d9d|Hitem:11406::::::::27:::::::::|h[Rotting Bear Carcass]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975360,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1163]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:09:52]|h|r You receive loot: |cffffffff|Hitem:3730::::::::27:::::::::|h[Big Bear Meat]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975402,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1164]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:10:24]|h|r Souvenirs of Death completed.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975434,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1165]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:10:24]|h|r Experience gained: 5100.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975434,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1166]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:10:24]|h|r Your Undercity reputation has increased by 150.",
					["b"] = 1,
					["r"] = 0.501960813999176,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975434,
					["extraData"] = {
						36, -- [1]
						30, -- [2]
						31, -- [3]
						["n"] = 3,
					},
				}, -- [1167]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:10:24]|h|r You receive item: |cff1eff00|Hitem:3739::::::::27:::::::::|h[Skull Ring]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975434,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1168]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:10:30]|h|r Your Undercity reputation has increased by 100.",
					["b"] = 1,
					["r"] = 0.501960813999176,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975440,
					["extraData"] = {
						36, -- [1]
						30, -- [2]
						31, -- [3]
						["n"] = 3,
					},
				}, -- [1169]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:10:30]|h|r Battle of Hillsbrad completed.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975440,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1170]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:10:30]|h|r Experience gained: 4200.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975440,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1171]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:10:30]|h|r Received 60 Silver.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975440,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1172]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:10:31]|h|r Quest accepted: Battle of Hillsbrad",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975441,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1173]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:12:34]|h|r You receive item: |cffffffff|Hitem:11407::::::::27:::::::::|h[Torn Bear Pelt]|h|rx3.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975564,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1174]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:12:45]|h|r You receive item: |cffffffff|Hitem:1179::::::::27:::::::::|h[Ice Cold Milk]|h|rx5.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975575,
					["extraData"] = {
						28, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [1175]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:13:54]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Shammah-Shadowstrike(AU):949:CHANNEL:2|h|cffc69b6dShammah|r|h|cffd8d8d8]|r: any1 ayone doing cycolnian?",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975644,
					["extraData"] = {
						71, -- [1]
						22, -- [2]
						58, -- [3]
						["n"] = 3,
					},
				}, -- [1176]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:13:56]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Thunder Bluff]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975646,
					["extraData"] = {
						71, -- [1]
						22, -- [2]
						23, -- [3]
						["n"] = 3,
					},
				}, -- [1177]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:13:56]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. Trade - City]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975646,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						25, -- [3]
						["n"] = 3,
					},
				}, -- [1178]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:13:56]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Thunder Bluff]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975646,
					["extraData"] = {
						73, -- [1]
						27, -- [2]
						28, -- [3]
						["n"] = 3,
					},
				}, -- [1179]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:14:01]|h|r You feel rested.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975651,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1180]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:14:03]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Sokaris:959:CHANNEL:3|h|cffffffffSokaris|r|h|cffd8d8d8]|r: anyone selling bulk bronze bars? pst.",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975653,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						60, -- [3]
						["n"] = 3,
					},
				}, -- [1181]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:14:22]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Bambe:965:CHANNEL:3|h|cffc69b6dBambe|r|h|cffd8d8d8]|r: whats with everyone buying bronze bars",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975672,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						62, -- [3]
						["n"] = 3,
					},
				}, -- [1182]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:14:30]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Chickendud:967:CHANNEL:3|h|cffaad372Chickendud|r|h|cffd8d8d8]|r: boooooooonnnnnnnnnnnnnn",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975680,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						64, -- [3]
						["n"] = 3,
					},
				}, -- [1183]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:14:36]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Chickendud-Shadowstrike(AU):969:CHANNEL:3|h|cffaad372Chickendud|r|h|cffd8d8d8]|r: where be boooooooon",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975686,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						64, -- [3]
						["n"] = 3,
					},
				}, -- [1184]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:00]|h|r You are now the group leader.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975710,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1185]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:07]|h|r [W To] |cffd8d8d8[|r|Hplayer:Backbitter-Shadowstrike(AU):997:WHISPER:BACKBITTER-SHADOWSTRIKE(AU)|h|cffd84e4e40|r:|cfffff468Backbitter|r|h|cffd8d8d8]|r: can u help click a summ <3",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975717,
					["extraData"] = {
						10, -- [1]
						66, -- [2]
						67, -- [3]
						["n"] = 3,
					},
				}, -- [1186]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:14]|h|r [W To] |cffd8d8d8[|r|Hplayer:Tantrymbank-Shadowstrike(AU):1005:WHISPER:TANTRYMBANK-SHADOWSTRIKE(AU)|h|cffd84e4e40|r:|cffc69b6dTantrymbank|r|h|cffd8d8d8]|r: can u help click a summ <3",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975724,
					["extraData"] = {
						10, -- [1]
						68, -- [2]
						69, -- [3]
						["n"] = 3,
					},
				}, -- [1187]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:19]|h|r [W To] |cffd8d8d8[|r|Hplayer:Staba-Shadowstrike(AU):1010:WHISPER:STABA-SHADOWSTRIKE(AU)|h|cffd84e4e40|r:|cfffff468Staba|r|h|cffd8d8d8]|r: v",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975729,
					["extraData"] = {
						10, -- [1]
						70, -- [2]
						71, -- [3]
						["n"] = 3,
					},
				}, -- [1188]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:21]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Cute:1013:CHANNEL:3|h|cff0070ddCute|r|h|cffd8d8d8]|r: you need 16 turbochargers for ratchet rune, an average of about 22 salvagers at 6 bronze bars each",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975731,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						72, -- [3]
						["n"] = 3,
					},
				}, -- [1189]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:22]|h|r [W To] |cffd8d8d8[|r|Hplayer:Staba-Shadowstrike(AU):1014:WHISPER:STABA-SHADOWSTRIKE(AU)|h|cffd84e4e40|r:|cfffff468Staba|r|h|cffd8d8d8]|r: can u help click a summ <3",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975732,
					["extraData"] = {
						10, -- [1]
						70, -- [2]
						71, -- [3]
						["n"] = 3,
					},
				}, -- [1190]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:24]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Clarryfray-Shadowstrike(AU):1021:CHANNEL:3|h|cffffffffClarryfray|r|h|cffd8d8d8]|r: LF2M DPS RFC",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975734,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						74, -- [3]
						["n"] = 3,
					},
				}, -- [1191]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:26]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Nra:1024:CHANNEL:3|h|cffffffffNra|r|h|cffd8d8d8]|r: Nra's Enchants || /w me !enchants || @ ORG|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8:0|t",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975736,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						76, -- [3]
						["n"] = 3,
					},
				}, -- [1192]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:31]|h|r [W To] |cffd8d8d8[|r|Hplayer:Alucid-Shadowstrike(AU):1031:WHISPER:ALUCID-SHADOWSTRIKE(AU)|h|cffd8d83f26|r:|cffc69b6dAlucid|r|h|cffd8d8d8]|r: can u help click a summ <3",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975741,
					["extraData"] = {
						10, -- [1]
						78, -- [2]
						79, -- [3]
						["n"] = 3,
					},
				}, -- [1193]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:33]|h|r [W From] |cffd8d8d8[|r|Hplayer:Tantrymbank-Shadowstrike(AU):1033:WHISPER:TANTRYMBANK-SHADOWSTRIKE(AU)|h|cffd84e4e40|r:|cffc69b6dTantrymbank|r|h|cffd8d8d8]|r: yup",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975743,
					["extraData"] = {
						0, -- [1]
						68, -- [2]
						80, -- [3]
						["n"] = 3,
					},
				}, -- [1194]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:34]|h|r [S] |cffd8d8d8[|r|Hplayer:Backbitter-Shadowstrike(AU):1036:SAY|h|cffd84e4e40|r:|cfffff468Backbitter|r|h|cffd8d8d8]|r: what am i clicking?",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975744,
					["extraData"] = {
						2, -- [1]
						56, -- [2]
						81, -- [3]
						["n"] = 3,
					},
				}, -- [1195]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:36]|h|r You have invited |cffc69b6dTantrymbank|r to join your group.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975746,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1196]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:38]|h|r |cffc69b6dTantrymbank|r joins the party.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975748,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1197]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:38]|h|r You have invited |cfffff468Backbitter|r to join your group.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975748,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1198]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:39]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Cute-Shadowstrike(AU):1046:CHANNEL:3|h|cff0070ddCute|r|h|cffd8d8d8]|r: so about 130 bronze bars for an alt's ratchet rune if its one your spec needs",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975749,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						72, -- [3]
						["n"] = 3,
					},
				}, -- [1199]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:40]|h|r [W From] |cffd8d8d8[|r|Hplayer:Alucid-Shadowstrike(AU):1048:WHISPER:ALUCID-SHADOWSTRIKE(AU)|h|cffd8d83f26|r:|cffc69b6dAlucid|r|h|cffd8d8d8]|r: sure",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975750,
					["extraData"] = {
						0, -- [1]
						78, -- [2]
						82, -- [3]
						["n"] = 3,
					},
				}, -- [1200]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:41]|h|r |cfffff468Backbitter|r joins the party.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975751,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1201]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:15:55]|h|r [S] |cffd8d8d8[|r|Hplayer:Backbitter-Shadowstrike(AU):1073:SAY|h|cffd84e4e40|r:|cfffff468Backbitter|r|h|cffd8d8d8]|r: allg",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975765,
					["extraData"] = {
						2, -- [1]
						56, -- [2]
						81, -- [3]
						["n"] = 3,
					},
				}, -- [1202]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:16:03]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Eirä:1084:CHANNEL:3|h|cffffffffEirä|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_6:0|t || Max Enchanter LFW. ALL recipes. Your mats or mine (for a cost). Pst || |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_6:0|t |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975773,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						85, -- [3]
						["n"] = 3,
					},
				}, -- [1203]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:16:03]|h|r |cffc69b6dTantrymbank|r leaves the party.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975773,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1204]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:16:07]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Goathurder:1091:CHANNEL:3|h|cffaad372Goathurder|r|h|cffd8d8d8]|r: LF1 HEALS + 6 DPS (melee) for BFD, lets go",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975777,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						87, -- [3]
						["n"] = 3,
					},
				}, -- [1205]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:16:07]|h|r |cfffff468Backbitter|r leaves the party.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975777,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1206]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:16:07]|h|r Bashana Runetotem yells: Denizens of Kalimdor, the dread beast Aku'mai has been slain and Ashenvale has been cleansed of the blight of the Old Gods' influence. Feel the boon of Blackfathom, and bask in the warmth of the Earth Mother's gaze!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.250980406999588,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975777,
					["extraData"] = {
						15, -- [1]
						89, -- [2]
						90, -- [3]
						["n"] = 3,
					},
				}, -- [1207]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:16:08]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Goathurder-Shadowstrike(AU):1095:CHANNEL:3|h|cffaad372Goathurder|r|h|cffd8d8d8]|r: LF1 HEALS + 6 DPS (melee) for BFD, lets go",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975778,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						87, -- [3]
						["n"] = 3,
					},
				}, -- [1208]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:16:19]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Nra-Shadowstrike(AU):1111:CHANNEL:3|h|cffffffffNra|r|h|cffd8d8d8]|r: Nra's Enchants || /w me !enchants || @ ORG|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8:0|t",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975789,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						76, -- [3]
						["n"] = 3,
					},
				}, -- [1209]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:16:33]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. General - Thunder Bluff]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975803,
					["extraData"] = {
						71, -- [1]
						22, -- [2]
						23, -- [3]
						["n"] = 3,
					},
				}, -- [1210]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:16:33]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. Trade - City]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975803,
					["extraData"] = {
						72, -- [1]
						3, -- [2]
						25, -- [3]
						["n"] = 3,
					},
				}, -- [1211]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:16:33]|h|r |Hchannel:channel:4|h[4] |h Left Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Thunder Bluff]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709975803,
					["extraData"] = {
						73, -- [1]
						27, -- [2]
						28, -- [3]
						["n"] = 3,
					},
				}, -- [1212]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:25:54]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709976815,
					["r"] = 0.250980406999588,
				}, -- [1213]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:25:56]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Goathurder-Shadowstrike(AU):1137:CHANNEL:3|h|cffaad372Goathurder|r|h|cffd8d8d8]|r: LF4 DPS (melee, no hunters) for BFD, lets go",
					["serverTime"] = 1709976366,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1214]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:25:57]|h|r |cffd8d8d8[|r|Hplayer:Tpainwarpigs:1141|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1709976367,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 1,
					["b"] = 0,
				}, -- [1215]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:26:09]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Habibb:1163:CHANNEL:3|h|cff3fc6eaHabibb|r|h|cffd8d8d8]|r: LFM PUMPERS BFD",
					["serverTime"] = 1709976379,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						1, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1216]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:26:34]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Nra-Shadowstrike(AU):1193:CHANNEL:3|h|cffffffffNra|r|h|cffd8d8d8]|r: Nra's Enchants || /w me !enchants || @ ORG|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8:0|t",
					["serverTime"] = 1709976404,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						1, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1217]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:26:37]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Goathurder-Shadowstrike(AU):1196:CHANNEL:3|h|cffaad372Goathurder|r|h|cffd8d8d8]|r: LF4 DPS (melee, no hunters) for BFD, lets go",
					["serverTime"] = 1709976407,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1218]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:26:44]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Harlio:1202:CHANNEL:3|h|cffff7c0aHarlio|r|h|cffd8d8d8]|r: 6/6 Boomy/Restokin LFG Gnomer, Pref guild run",
					["serverTime"] = 1709976414,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						1, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1219]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:27:10]|h|r |cffd8d8d8[|r|Hplayer:Tpainwarpigs:1222|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r has invited you to join a group.",
					["serverTime"] = 1709976440,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 1,
					["b"] = 0,
				}, -- [1220]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:27:12]|h|r Dungeon difficulty set to Normal",
					["serverTime"] = 1709976442,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 1,
					["b"] = 0,
				}, -- [1221]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:27:15]|h|r Quest accepted: The Sacred Flame",
					["serverTime"] = 1709976445,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 1,
					["b"] = 0,
				}, -- [1222]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:27:17]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Vazax:1234:CHANNEL:3|h|cfffff468Vazax|r|h|cffd8d8d8]|r: DPS LFG SM GY",
					["serverTime"] = 1709976447,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						1, -- [2]
						12, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1223]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:27:36]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Dotsfordays:1261:CHANNEL:3|h|cff8787edDotsfordays|r|h|cffd8d8d8]|r: LF Alch - 10x lesser arcane elixirs my matts",
					["serverTime"] = 1709976466,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						1, -- [2]
						16, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1224]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:27:44]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Nra-Shadowstrike(AU):1262:CHANNEL:3|h|cffffffffNra|r|h|cffd8d8d8]|r: Nra's Enchants || /w me !enchants || @ ORG|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8:0|t",
					["serverTime"] = 1709976474,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						1, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1225]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:27:45]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Mulgore]|h",
					["serverTime"] = 1709976475,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						18, -- [2]
						19, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1226]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:27:45]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. Trade - City]|h",
					["serverTime"] = 1709976475,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						1, -- [2]
						21, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1227]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:27:45]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Mulgore]|h",
					["serverTime"] = 1709976475,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						23, -- [2]
						24, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1228]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:28:48]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - The Barrens]|h",
					["serverTime"] = 1709976538,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						18, -- [2]
						19, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1229]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:28:48]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - The Barrens]|h",
					["serverTime"] = 1709976538,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						23, -- [2]
						24, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1230]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:29:39]|h|r Quest accepted: Betrayal from Within",
					["serverTime"] = 1709976589,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 1,
					["b"] = 0,
				}, -- [1231]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:30:07]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. General - The Barrens]|h",
					["serverTime"] = 1709976617,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						18, -- [2]
						19, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1232]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:30:07]|h|r |Hchannel:channel:4|h[4] |h Left Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - The Barrens]|h",
					["serverTime"] = 1709976617,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						23, -- [2]
						24, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1233]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:33:25]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["serverTime"] = 1709980013,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
				}, -- [1234]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:33:26]|h|r Dungeon difficulty set to Normal",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709976816,
				}, -- [1235]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:33:35]|h|r Camp Taurajo is now your home.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709976825,
				}, -- [1236]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:34:03]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Milquetoast-Shadowstrike(AU):1391:CHANNEL:2|h|cff3fc6eaMilquetoast|r|h|cffd8d8d8]|r: LFM WC Quest run need all",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709976853,
				}, -- [1237]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:35:02]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Colt-Shadowstrike(AU):1405:CHANNEL:2|h|cffc69b6dColt|r|h|cffd8d8d8]|r: LF2M healer, dps WC",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709976912,
				}, -- [1238]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:36:29]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Lirielbaenre-Shadowstrike(AU):1439:CHANNEL:2|h|cff3fc6eaLirielbaenre|r|h|cffd8d8d8]|r: mage lfg for Wc  Or Sfk ,invite ty.",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709976999,
				}, -- [1239]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:37:07]|h|r You feel normal.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977037,
				}, -- [1240]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:37:09]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:3402::::::::27:::::::::|h[Soft Patch of Fur]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977039,
				}, -- [1241]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:37:24]|h|r |HlootHistory:1|h[Loot]|h: |cff1eff00|Hitem:15211::::::672:657143040:27:::::::::|h[Militant Shortsword of the Tiger]|h|r",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977054,
				}, -- [1242]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:37:25]|h|r You receive loot: |cffffffff|Hitem:17056::::::::27:::::::::|h[Light Feather]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977055,
				}, -- [1243]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:37:26]|h|r |HlootHistory:1|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Greed for: |cff1eff00|Hitem:15211::::::672:657143040:27:::::::::|h[Militant Shortsword of the Tiger]|h|r",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977056,
				}, -- [1244]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:37:28]|h|r |HlootHistory:1|h[Loot]|h: You passed on: |cff1eff00|Hitem:15211::::::672:657143040:27:::::::::|h[Militant Shortsword of the Tiger]|h|r",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977058,
				}, -- [1245]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:37:28]|h|r |HlootHistory:1|h[Loot]|h: Greed Roll - 18 for |cff1eff00|Hitem:15211::::::672:657143040:27:::::::::|h[Militant Shortsword of the Tiger]|h|r by |cff0070ddTpainwarpigs|r",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977058,
				}, -- [1246]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:37:28]|h|r |HlootHistory:1|h[Loot]|h: |cff0070ddTpainwarpigs|r won: |cff1eff00|Hitem:15211::::::672:657143040:27:::::::::|h[Militant Shortsword of the Tiger]|h|r",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977058,
				}, -- [1247]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:37:28]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff1eff00|Hitem:15211::::::672:657143040:27:::::::::|h[Militant Shortsword of the Tiger]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977058,
				}, -- [1248]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:37:52]|h|r Pizpep says: Alright I'm going! Stop yelling!",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						13, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977082,
				}, -- [1249]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:37:57]|h|r Discovered Blackthorn Ridge: 139 experience gained",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977087,
				}, -- [1250]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:38:03]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Lirielbaenre-Shadowstrike(AU):1488:CHANNEL:2|h|cff3fc6eaLirielbaenre|r|h|cffd8d8d8]|r: mage lfg for Wc  Or Sfk ,invite ty.",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977093,
				}, -- [1251]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:38:23]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:4897::::::::27:::::::::|h[Thunderhawk Saliva Gland]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977113,
				}, -- [1252]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:40:05]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Niteranger:1526:CHANNEL:2|h|cffaad372Niteranger|r|h|cffd8d8d8]|r: anyone for |Hquestie:857:Player-5818-00A9F029|h|cFFFF8040[|r|cFFFF8040[30] The Tear of the Moons|r|cFFFF8040]|r|h? :D",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						16, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977215,
				}, -- [1253]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:40:49]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Craiglowndes-Shadowstrike(AU):1542:GUILD|h|cff65b26524|r:|cff0070ddCraiglowndes|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t RestedXP Guides: I just leveled from 24 to 25 in 1 hour 45 minutes 33 seconds",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						18, -- [2]
						19, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977259,
				}, -- [1254]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:41:28]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):1553:GUILD|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: huge",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						18, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977298,
				}, -- [1255]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:41:32]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):1554:GUILD|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: best laptme",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						18, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977302,
				}, -- [1256]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:41:55]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Tpainwarpigs-Shadowstrike(AU):1563:GUILD|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r: apparently ems mum loves craig irl",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						18, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977325,
				}, -- [1257]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:42:04]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Lavy-Shadowstrike(AU):1566:GUILD|h|cffd8d83f27|r:|cff8787edLavy|r|h|cffd8d8d8]|r: big fan",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						18, -- [2]
						21, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977334,
				}, -- [1258]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:44:46]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Craiglowndes-Shadowstrike(AU):1616:GUILD|h|cffd8d83f25|r:|cff0070ddCraiglowndes|r|h|cffd8d8d8]|r: we getting pbs out here",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						18, -- [2]
						19, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977496,
				}, -- [1259]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:47:16]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Orgrimmar]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977646,
				}, -- [1260]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:47:16]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Orgrimmar]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						73, -- [1]
						24, -- [2]
						25, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977646,
				}, -- [1261]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:47:26]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Baltod:1661:CHANNEL:2|h|cffaad372Baltod|r|h|cffd8d8d8]|r: LF enchanter +5 agi on hand",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						27, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977656,
				}, -- [1262]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:47:38]|h|r You feel rested.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977668,
				}, -- [1263]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:47:40]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Midgetits-Shadowstrike(AU):1673:CHANNEL:3|h|cffc69b6dMidgetits|r|h|cffd8d8d8]|r: lfm sm cath need tank+heals",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						72, -- [1]
						29, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977670,
				}, -- [1264]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:48:14]|h|r [Y] |cffd8d8d8[|r|Hplayer:Callous-Shadowstrike(AU):1687:YELL|h|cfffff468Callous|r|h|cffd8d8d8]|r: Max lockpicking bank roof - free no tips req",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 60064.747,
					["extraData"] = {
						7, -- [1]
						32, -- [2]
						33, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977704,
				}, -- [1265]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:48:19]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Cinerea:1688:CHANNEL:2|h|cff8787edCinerea|r|h|cffd8d8d8]|r: LFG RFC",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						34, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977709,
				}, -- [1266]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:49:19]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Midgetits-Shadowstrike(AU):1716:CHANNEL:3|h|cffc69b6dMidgetits|r|h|cffd8d8d8]|r: lfm sm cath need tank+heals",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						72, -- [1]
						29, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977769,
				}, -- [1267]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:49:34]|h|r Nogg yells: Alright everyone listen up. Some stooge... uh, I mean \"brave adventurer\" brought me a whole huge pile of secret gnomish tech and once we finish applying our superior goblin ingenuity to it we are going to use it to BLOW SO MUCH STUFF UP. Gather 'round and let's party!",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 60064.747,
					["extraData"] = {
						15, -- [1]
						36, -- [2]
						37, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977784,
				}, -- [1268]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:49:51]|h|r [Y] |cffd8d8d8[|r|Hplayer:Wangstain-Shadowstrike(AU):1743:YELL|h|cffff7c0aWangstain|r|h|cffd8d8d8]|r: LF enchanter dismantle/stam to boots",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 60064.747,
					["extraData"] = {
						7, -- [1]
						32, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977801,
				}, -- [1269]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:50:11]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Wangstain-Shadowstrike(AU):1756:CHANNEL:3|h|cffff7c0aWangstain|r|h|cffd8d8d8]|r: LF enchanter for dismantle/stam to boots",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						72, -- [1]
						29, -- [2]
						39, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977821,
				}, -- [1270]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:51:16]|h|r You have learned how to create a new item: Anti-Venom.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977886,
				}, -- [1271]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:51:16]|h|r You have learned how to create a new item: Heavy Wool Bandage.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977886,
				}, -- [1272]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:52:30]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Cinerea-Shadowstrike(AU):1815:CHANNEL:2|h|cff8787edCinerea|r|h|cffd8d8d8]|r: RFC anyone?",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						34, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977960,
				}, -- [1273]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:52:39]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Jekk:1820:CHANNEL:3|h|cffff7c0aJekk|r|h|cffd8d8d8]|r: LF BS in org to apply my counterweight, tipping!",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						72, -- [1]
						29, -- [2]
						41, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977969,
				}, -- [1274]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:52:43]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - The Barrens]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977973,
				}, -- [1275]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:52:43]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						72, -- [1]
						29, -- [2]
						43, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977973,
				}, -- [1276]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:52:43]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - The Barrens]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						73, -- [1]
						24, -- [2]
						25, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977973,
				}, -- [1277]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:52:54]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Azshara]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977984,
				}, -- [1278]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:52:54]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Azshara]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						73, -- [1]
						24, -- [2]
						25, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977984,
				}, -- [1279]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:52:59]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Ashenvale]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977989,
				}, -- [1280]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:52:59]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Ashenvale]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						73, -- [1]
						24, -- [2]
						25, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977989,
				}, -- [1281]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:53:07]|h|r |Hchannel:channel:4|h[4] |h |cffffff00Warsong Lumber Camp is under attack!|r",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						73, -- [1]
						24, -- [2]
						45, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709977997,
				}, -- [1282]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:54:05]|h|r You feel normal.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978055,
				}, -- [1283]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:54:39]|h|r You create: |cffffffff|Hitem:6265::::::::27:::::::::|h[Soul Shard]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978089,
				}, -- [1284]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:54:40]|h|r You receive loot: |cff9d9d9d|Hitem:878::::::::27:::::::::|h[Fist-sized Spinneret]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978090,
				}, -- [1285]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:54:47]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2251::::::::27:::::::::|h[Gooey Spider Leg]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978097,
				}, -- [1286]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:56:41]|h|r Discovered Felfire Hill: 235 experience gained",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978211,
				}, -- [1287]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:56:49]|h|r Your share of the loot is 60 Copper.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						29, -- [1]
						47, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978219,
				}, -- [1288]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:56:50]|h|r Your share of the loot is 47 Copper.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						29, -- [1]
						47, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978220,
				}, -- [1289]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:58:11]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:4784::::::::27:::::::::|h[Lifeless Stone]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978301,
				}, -- [1290]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:58:53]|h|r You receive loot: |cff9d9d9d|Hitem:5741::::::::27:::::::::|h[Rock Chip]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978343,
				}, -- [1291]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:58:53]|h|r You receive loot: |cff9d9d9d|Hitem:4784::::::::27:::::::::|h[Lifeless Stone]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["extraData"] = {
						28, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978343,
				}, -- [1292]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:59:55]|h|r Discovered Splintertree Post: 200 experience gained",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978405,
				}, -- [1293]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:00:03]|h|r |Hchannel:channel:4|h[4] |h |cffffff00Nightsong Woods is under attack!|r",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						73, -- [1]
						24, -- [2]
						45, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978413,
				}, -- [1294]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:00:12]|h|r Your Thunder Bluff reputation has increased by 15.",
					["r"] = 0.501960813999176,
					["b"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 60064.747,
					["extraData"] = {
						36, -- [1]
						49, -- [2]
						50, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978422,
				}, -- [1295]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:00:12]|h|r The Ashenvale Hunt completed.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978422,
				}, -- [1296]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:00:12]|h|r Experience gained: 460.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978422,
				}, -- [1297]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:00:12]|h|r The Ashenvale Hunt completed.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978422,
				}, -- [1298]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:00:13]|h|r |cff0070ddTpainwarpigs|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978423,
				}, -- [1299]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:00:34]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. General - Ashenvale]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978444,
				}, -- [1300]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:00:34]|h|r |Hchannel:channel:4|h[4] |h Left Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Ashenvale]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["extraData"] = {
						73, -- [1]
						24, -- [2]
						25, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1709978444,
				}, -- [1301]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:26:43]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["g"] = 1,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982655,
					["b"] = 0.250980406999588,
				}, -- [1302]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:26:49]|h|r |cffd8d8d8[|r|Hplayer:Tpainwarpigs:1999|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r has invited you to join a group.",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980019,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1303]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:27:03]|h|r Dungeon difficulty set to Normal",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980033,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1304]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:28:42]|h|r Quest accepted: Ashenvale Outrunners",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980132,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1305]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:30:15]|h|r Quest accepted: Stonetalon Standstill",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980225,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1306]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:30:19]|h|r Splintertree Post is now your home.",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980229,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1307]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:30:30]|h|r Quest accepted: Satyr Horns",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980240,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1308]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:31:39]|h|r You feel normal.",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980309,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1309]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:31:40]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:4306::::::::27:::::::::|h[Silk Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980310,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1310]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:31:41]|h|r Your share of the loot is 44 Copper.",
					["extraData"] = {
						29, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980311,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1311]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:32:04]|h|r Discovered The Dor'Danil Barrow Den: 245 experience gained",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980334,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1312]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:32:15]|h|r Your share of the loot is 20 Copper.",
					["extraData"] = {
						29, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980345,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1313]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:32:27]|h|r |HlootHistory:2|h[Loot]|h: |cff1eff00|Hitem:14179::::::1014:2019207552:27:::::::::|h[Watcher's Cape of the Whale]|h|r",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980357,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1314]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:32:28]|h|r Your share of the loot is 22 Copper.",
					["extraData"] = {
						29, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980358,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1315]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:32:35]|h|r |HlootHistory:2|h[Loot]|h: |cff0070ddTpainwarpigs|r has selected Greed for: |cff1eff00|Hitem:14179::::::1014:2019207552:27:::::::::|h[Watcher's Cape of the Whale]|h|r",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980365,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1316]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:32:36]|h|r |HlootHistory:2|h[Loot]|h: You passed on: |cff1eff00|Hitem:14179::::::1014:2019207552:27:::::::::|h[Watcher's Cape of the Whale]|h|r",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980366,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1317]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:32:36]|h|r |HlootHistory:2|h[Loot]|h: Greed Roll - 92 for |cff1eff00|Hitem:14179::::::1014:2019207552:27:::::::::|h[Watcher's Cape of the Whale]|h|r by |cff0070ddTpainwarpigs|r",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980366,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1318]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:32:36]|h|r |HlootHistory:2|h[Loot]|h: |cff0070ddTpainwarpigs|r won: |cff1eff00|Hitem:14179::::::1014:2019207552:27:::::::::|h[Watcher's Cape of the Whale]|h|r",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980366,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1319]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:32:36]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff1eff00|Hitem:14179::::::1014:2019207552:27:::::::::|h[Watcher's Cape of the Whale]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980366,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1320]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:33:04]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:16649::::::::27:::::::::|h[Shredder Operating Manual - Page 5]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980394,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1321]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:33:05]|h|r Your share of the loot is 31 Copper.",
					["extraData"] = {
						29, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980395,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1322]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:33:28]|h|r Your skill in Wands has increased to 134.",
					["extraData"] = {
						27, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709980418,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [1323]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:33:36]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2592::::::::27:::::::::|h[Wool Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980426,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1324]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:33:37]|h|r Your share of the loot is 44 Copper.",
					["extraData"] = {
						29, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980427,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1325]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:34:00]|h|r You receive loot: |cffffffff|Hitem:211855::::::::27:::::::::|h[Scroll: STHENIC LUNATE]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980450,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1326]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:34:01]|h|r Your share of the loot is 34 Copper.",
					["extraData"] = {
						29, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980451,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1327]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:34:19]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:4306::::::::27:::::::::|h[Silk Cloth]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980469,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1328]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:34:20]|h|r Your share of the loot is 17 Copper.",
					["extraData"] = {
						29, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980470,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1329]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:35:15]|h|r |cff0070ddCraiglowndes|r has gone offline.",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980525,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1330]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:35:30]|h|r Your skill in Defense has increased to 117.",
					["extraData"] = {
						27, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709980540,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [1331]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:35:56]|h|r You receive loot: |cff1eff00|Hitem:16305::::::::27:::::::::|h[Sharptalon's Claw]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980566,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1332]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:35:56]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff1eff00|Hitem:16305::::::::27:::::::::|h[Sharptalon's Claw]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980566,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1333]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:35:56]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:5116::::::::27:::::::::|h[Long Tail Feather]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980566,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1334]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:36:03]|h|r Quest accepted: Sharptalon's Claw",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980573,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1335]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:37:43]|h|r Congratulations, you have reached level 28!",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709980673,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1336]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:37:43]|h|r You have gained 26 hit points and 49 mana.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709980673,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1337]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:37:43]|h|r You have gained 1 talent point.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709980673,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1338]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:37:43]|h|r Your Agility increases by 1.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709980673,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1339]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:37:43]|h|r Your Stamina increases by 1.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709980673,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1340]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:37:43]|h|r Your Intellect increases by 1.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709980673,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1341]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:37:43]|h|r Your Spirit increases by 2.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709980673,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1342]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:37:43]|h|r Your Darkspear Trolls reputation has increased by 100.",
					["extraData"] = {
						36, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709980673,
					["timestamp"] = 60064.747,
					["g"] = 0.501960813999176,
					["r"] = 0.501960813999176,
				}, -- [1343]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:37:43]|h|r Your skill in Destruction has increased to 140.",
					["extraData"] = {
						27, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709980673,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [1344]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:37:43]|h|r Your skill in Demonology has increased to 140.",
					["extraData"] = {
						27, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709980673,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [1345]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:37:43]|h|r Your skill in Affliction has increased to 140.",
					["extraData"] = {
						27, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709980673,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [1346]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:37:43]|h|r Ashenvale Outrunners completed.",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980673,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1347]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:37:43]|h|r Experience gained: 3900.",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980673,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1348]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:37:48]|h|r Quest accepted: Warsong Supplies",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980678,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1349]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:40:00]|h|r Looting changed to free-for-all.",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980810,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1350]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:40:00]|h|r Interface action failed because of an AddOn",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["serverTime"] = 1709980810,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1351]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:40:04]|h|r Your skill in Staves has increased to 22.",
					["extraData"] = {
						27, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709980814,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [1352]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:40:05]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:1015::::::::28:::::::::|h[Lean Wolf Flank]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980815,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1353]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:40:09]|h|r You receive loot: |cffffffff|Hitem:1015::::::::28:::::::::|h[Lean Wolf Flank]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980819,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1354]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:40:50]|h|r Your skill in Wands has increased to 135.",
					["extraData"] = {
						27, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709980860,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [1355]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:41:10]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3174::::::::28:::::::::|h[Spider Ichor]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980880,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1356]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:41:10]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3182::::::::28:::::::::|h[Spider's Silk]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980880,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1357]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:41:10]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:2251::::::::28:::::::::|h[Gooey Spider Leg]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980880,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1358]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:41:10]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:1288::::::::28:::::::::|h[Large Venom Sac]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980880,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1359]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:41:22]|h|r Discovered Mystral Lake: 200 experience gained",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980892,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1360]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:41:28]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Protosmage:2242:CHANNEL:2|h|cff3fc6eaProtosmage|r|h|cffd8d8d8]|r: inv",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709980898,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1361]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:41:52]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3174::::::::28:::::::::|h[Spider Ichor]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980922,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1362]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:41:52]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:4428::::::::28:::::::::|h[Spider Palp]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980922,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1363]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:42:10]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Asiaface:2257:CHANNEL:2|h|cffc69b6dAsiaface|r|h|cffd8d8d8]|r: LFG BFD",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709980940,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1364]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:42:14]|h|r Your skill in Defense has increased to 118.",
					["extraData"] = {
						27, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1709980944,
					["timestamp"] = 60064.747,
					["g"] = 0.3333333432674408,
					["r"] = 0.3333333432674408,
				}, -- [1365]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:42:19]|h|r You receive loot: |cffffffff|Hitem:9451::::::::28:::::::::|h[Bubbling Water]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980949,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1366]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:42:33]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:9451::::::::28:::::::::|h[Bubbling Water]|h|rx3.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980963,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1367]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:42:40]|h|r Pizpep says: What? You mean you can't kill this one by yourself?",
					["extraData"] = {
						13, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 0.6235294342041016,
					["serverTime"] = 1709980970,
					["timestamp"] = 60064.747,
					["g"] = 1,
					["r"] = 1,
				}, -- [1368]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:42:49]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:16652::::::::28:::::::::|h[Shredder Operating Manual - Page 8]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980979,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1369]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:42:50]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:9451::::::::28:::::::::|h[Bubbling Water]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709980980,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1370]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:43:34]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:9451::::::::28:::::::::|h[Bubbling Water]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709981024,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1371]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:43:34]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:9451::::::::28:::::::::|h[Bubbling Water]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709981024,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1372]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:43:35]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Lanfeàr:2294:CHANNEL:2|h|cfffff468Lanfeàr|r|h|cffd8d8d8]|r: any groups for PVP event?",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						21, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981025,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1373]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:44:52]|h|r You receive loot: |cff9d9d9d|Hitem:5446::::::::28:::::::::|h[Broken Elemental Bracer]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709981102,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1374]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:44:52]|h|r You receive loot: |cffffffff|Hitem:9451::::::::28:::::::::|h[Bubbling Water]|h|rx2.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709981102,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1375]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:45:14]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Claine-Shadowstrike(AU):2323:CHANNEL:2|h|cff8787edClaine|r|h|cffd8d8d8]|r: LFG Splint or zoram",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						23, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981124,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1376]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:45:14]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Papijin-Shadowstrike(AU):2324:CHANNEL:2|h|cffffffffPapijin|r|h|cffd8d8d8]|r: LFG Ashenvale",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						25, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981124,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1377]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:45:34]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Decimation:2334:CHANNEL:2|h|cffaad372Decimation|r|h|cffd8d8d8]|r: Inv zoram",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						27, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981144,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1378]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:45:41]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Hystericjoy:2336:CHANNEL:2|h|cffc69b6dHystericjoy|r|h|cffd8d8d8]|r: anyone for shadumbra?",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						29, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981151,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1379]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:45:45]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:5447::::::::28:::::::::|h[Damaged Elemental Bracer]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709981155,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1380]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:45:52]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Ereko-Shadowstrike(AU):2345:CHANNEL:2|h|cff0070ddEreko|r|h|cffd8d8d8]|r: me",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						31, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981162,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1381]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:46:17]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Bigidiot-Shadowstrike(AU):2352:CHANNEL:2|h|cff0070ddBigidiot|r|h|cffd8d8d8]|r: LFM SPLINT",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						33, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981187,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1382]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:46:33]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:16648::::::::28:::::::::|h[Shredder Operating Manual - Page 4]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709981203,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1383]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:46:33]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:9451::::::::28:::::::::|h[Bubbling Water]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709981203,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1384]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:46:37]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Natty:2367:CHANNEL:2|h|cffff7c0aNatty|r|h|cffd8d8d8]|r: inv zoram",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						35, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981207,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1385]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:46:49]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Wwoolooloo:2374:CHANNEL:2|h|cffffffffWwoolooloo|r|h|cffd8d8d8]|r: lfg bfd healer",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						37, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981219,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1386]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:47:32]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Buku:2381:CHANNEL:2|h|cfffff468Buku|r|h|cffd8d8d8]|r: inv",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						39, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981262,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1387]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:47:34]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Shroomskip:2385:CHANNEL:2|h|cffff7c0aShroomskip|r|h|cffd8d8d8]|r: inv splint",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						41, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981264,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1388]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:47:38]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Lanfeàr-Shadowstrike(AU):2388:CHANNEL:2|h|cfffff468Lanfeàr|r|h|cffd8d8d8]|r: inv zoram",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						21, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981268,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1389]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:47:43]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Natty-Shadowstrike(AU):2391:CHANNEL:2|h|cffff7c0aNatty|r|h|cffd8d8d8]|r: inv zoram",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						35, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981273,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1390]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:47:44]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Wwoolooloo-Shadowstrike(AU):2392:CHANNEL:2|h|cffffffffWwoolooloo|r|h|cffd8d8d8]|r: LFG BFD HEALS",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						37, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981274,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1391]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:47:52]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Diyapriest:2396:CHANNEL:2|h|cffffffffDiyapriest|r|h|cffd8d8d8]|r: inv split",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						43, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981282,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1392]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:48:01]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Feãr:2402:CHANNEL:2|h|cff3fc6eaFeãr|r|h|cffd8d8d8]|r: inv splint",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						45, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981291,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1393]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:48:09]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Xiiao:2404:CHANNEL:2|h|cff3fc6eaXiiao|r|h|cffd8d8d8]|r: inv splint :)",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						47, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981299,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1394]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:48:21]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Wwoolooloo-Shadowstrike(AU):2410:CHANNEL:2|h|cffffffffWwoolooloo|r|h|cffd8d8d8]|r: LFG BFD HEALS",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						37, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981311,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1395]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:48:31]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Seanat-Shadowstrike(AU):2413:CHANNEL:2|h|cfffff468Seanat|r|h|cffd8d8d8]|r: lfg splint",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						49, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981321,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1396]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:48:40]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Ayri:2416:CHANNEL:2|h|cff0070ddAyri|r|h|cffd8d8d8]|r: inv splint",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						51, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981330,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1397]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:48:41]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Strangelives:2417:CHANNEL:2|h|cfffff468Strangelives|r|h|cffd8d8d8]|r: inv any",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						53, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981331,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1398]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:48:42]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Bigidiot-Shadowstrike(AU):2418:CHANNEL:2|h|cff0070ddBigidiot|r|h|cffd8d8d8]|r: 3 spots left for splint",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						33, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981332,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1399]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:48:45]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Tazzerface-Shadowstrike(AU):2420:CHANNEL:2|h|cffaad372Tazzerface|r|h|cffd8d8d8]|r: inv",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981335,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1400]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:48:50]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Tazzerface-Shadowstrike(AU):2425:CHANNEL:2|h|cffaad372Tazzerface|r|h|cffd8d8d8]|r: zoram",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981340,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1401]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:48:52]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Magoral-Shadowstrike(AU):2428:CHANNEL:2|h|cff0070ddMagoral|r|h|cffd8d8d8]|r: LF4M for BFD",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						57, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981342,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1402]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:48:53]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Strykr:2429:CHANNEL:2|h|cffaad372Strykr|r|h|cffd8d8d8]|r: lfg splin",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981343,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1403]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:48:55]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Rahzool-Shadowstrike(AU):2431:CHANNEL:2|h|cffc69b6dRahzool|r|h|cffd8d8d8]|r: LFM ---BFD---",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						61, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981345,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1404]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:49:07]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Bigidiot-Shadowstrike(AU):2435:CHANNEL:2|h|cff0070ddBigidiot|r|h|cffd8d8d8]|r: start new splint, group 1 full",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						33, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981357,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1405]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:49:11]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Bigidiot-Shadowstrike(AU):2437:CHANNEL:2|h|cff0070ddBigidiot|r|h|cffd8d8d8]|r: or go zoram",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						33, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981361,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1406]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:49:14]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Feeshes-Shadowstrike(AU):2439:CHANNEL:2|h|cff0070ddFeeshes|r|h|cffd8d8d8]|r: need more at zoram",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						63, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981364,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1407]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:49:20]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Strykr-Shadowstrike(AU):2441:CHANNEL:2|h|cffaad372Strykr|r|h|cffd8d8d8]|r: inv splin",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981370,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1408]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:49:30]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Lootenscoot:2447:CHANNEL:2|h|cffff7c0aLootenscoot|r|h|cffd8d8d8]|r: splnt inv pls",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						65, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981380,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1409]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:49:38]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Tazzerface-Shadowstrike(AU):2453:CHANNEL:2|h|cffaad372Tazzerface|r|h|cffd8d8d8]|r: INV",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981388,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1410]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:49:41]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Gaypox:2455:CHANNEL:2|h|cff8787edGaypox|r|h|cffd8d8d8]|r: more zoram chads plz",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						67, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981391,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1411]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:49:42]|h|r You receive loot: |cff1eff00|Hitem:16408::::::::28:::::::::|h[Befouled Water Globe]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709981392,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1412]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:49:42]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Mertrude-Shadowstrike(AU):2459:CHANNEL:2|h|cffffffffMertrude|r|h|cffd8d8d8]|r: inv zoram",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						69, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981392,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1413]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:49:45]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Natty-Shadowstrike(AU):2462:CHANNEL:2|h|cffff7c0aNatty|r|h|cffd8d8d8]|r: inv zoram",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						35, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981395,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1414]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:49:46]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff1eff00|Hitem:16408::::::::28:::::::::|h[Befouled Water Globe]|h|r.",
					["extraData"] = {
						28, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1709981396,
					["timestamp"] = 60064.747,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [1415]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:50:00]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Tazzerface-Shadowstrike(AU):2465:CHANNEL:2|h|cffaad372Tazzerface|r|h|cffd8d8d8]|r: INVITE ZORAM",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981410,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1416]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:50:07]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Magoral-Shadowstrike(AU):2468:CHANNEL:2|h|cff0070ddMagoral|r|h|cffd8d8d8]|r: LF4M dps for BFD",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						57, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981417,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1417]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:50:23]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Strangelives-Shadowstrike(AU):2479:CHANNEL:2|h|cfffff468Strangelives|r|h|cffd8d8d8]|r: WHisper Canberra 4 inv to zoram",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						53, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981433,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1418]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:50:32]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Canberra-Shadowstrike(AU):2481:CHANNEL:2|h|cff0070ddCanberra|r|h|cffd8d8d8]|r: PST 'INV' FOR ZORAM GROUP",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						71, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981442,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1419]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:50:33]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Strangelives-Shadowstrike(AU):2482:CHANNEL:2|h|cfffff468Strangelives|r|h|cffd8d8d8]|r: whiastper inv i mean",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						53, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981443,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1420]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:50:37]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Rahzool-Shadowstrike(AU):2484:CHANNEL:2|h|cffc69b6dRahzool|r|h|cffd8d8d8]|r: LF DPS --BFD--",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						61, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981447,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1421]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:50:44]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Stabbyscrot-Shadowstrike(AU):2485:CHANNEL:2|h|cfffff468Stabbyscrot|r|h|cffd8d8d8]|r: inv splint",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						73, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981454,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1422]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:50:55]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Stabbyscrot-Shadowstrike(AU):2490:CHANNEL:2|h|cfffff468Stabbyscrot|r|h|cffd8d8d8]|r: inv splint",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						73, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981465,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1423]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:50:56]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Stabbyscrot-Shadowstrike(AU):2491:CHANNEL:2|h|cfffff468Stabbyscrot|r|h|cffd8d8d8]|r: inv splint",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						73, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981466,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1424]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:50:57]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Stabbyscrot-Shadowstrike(AU):2492:CHANNEL:2|h|cfffff468Stabbyscrot|r|h|cffd8d8d8]|r: inv splint",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						73, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981467,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1425]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:50:58]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Stabbyscrot-Shadowstrike(AU):2493:CHANNEL:2|h|cfffff468Stabbyscrot|r|h|cffd8d8d8]|r: inv splint",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						73, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981468,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1426]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:50:59]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Stabbyscrot-Shadowstrike(AU):2494:CHANNEL:2|h|cfffff468Stabbyscrot|r|h|cffd8d8d8]|r: inv splint",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						73, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981469,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1427]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:51:00]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Stabbyscrot-Shadowstrike(AU):2495:CHANNEL:2|h|cfffff468Stabbyscrot|r|h|cffd8d8d8]|r: inv splint",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						73, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981470,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1428]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:51:06]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Decimation-Shadowstrike(AU):2497:CHANNEL:2|h|cffaad372Decimation|r|h|cffd8d8d8]|r: Inv zoram",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						27, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981476,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1429]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:51:09]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Strykr-Shadowstrike(AU):2498:CHANNEL:2|h|cffaad372Strykr|r|h|cffd8d8d8]|r: inv splint",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981479,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1430]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:51:09]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Bigidiot-Shadowstrike(AU):2499:CHANNEL:2|h|cff0070ddBigidiot|r|h|cffd8d8d8]|r: start a new splint if you want",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						33, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981479,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1431]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:51:13]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Bigidiot-Shadowstrike(AU):2500:CHANNEL:2|h|cff0070ddBigidiot|r|h|cffd8d8d8]|r: g1 full",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						33, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981483,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1432]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:51:14]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Chuffmuff-Shadowstrike(AU):2503:CHANNEL:2|h|cffaad372Chuffmuff|r|h|cffd8d8d8]|r: inv splint",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						75, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981484,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1433]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:51:25]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Stabbyscrot-Shadowstrike(AU):2506:CHANNEL:2|h|cfffff468Stabbyscrot|r|h|cffd8d8d8]|r: inv splint",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						73, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981495,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1434]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:51:29]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. General - Ashenvale]|h",
					["extraData"] = {
						71, -- [1]
						14, -- [2]
						77, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981499,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1435]
				{
					["message"] = "|cff979797|Hpratcopy|h[20:51:29]|h|r |Hchannel:channel:4|h[4] |h Left Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Ashenvale]|h",
					["extraData"] = {
						73, -- [1]
						79, -- [2]
						80, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1709981499,
					["timestamp"] = 60064.747,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [1436]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:10:45]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["serverTime"] = 1709984174,
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["timestamp"] = 60064.747,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [1437]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:10:46]|h|r Interface action failed because of an AddOn",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982656,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [1438]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:10:49]|h|r Your skill in Defense has increased to 119.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982659,
					["extraData"] = {
						27, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1439]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:11:06]|h|r |cffd8d8d8[|r|Hplayer:Tpainwarpigs:2515|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982676,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [1440]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:11:09]|h|r Your skill in Defense has increased to 120.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982679,
					["extraData"] = {
						27, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1441]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:12:01]|h|r |cffd8d8d8[|r|Hplayer:Tpainwarpigs:2530|h|cffd8d83f28|r:|cff0070ddTpainwarpigs|r|h|cffd8d8d8]|r has invited you to join a group.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982731,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [1442]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:12:03]|h|r Dungeon difficulty set to Normal",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982733,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [1443]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:13:00]|h|r You feel normal.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982790,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [1444]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:13:03]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:9451::::::::28:::::::::|h[Bubbling Water]|h|rx2.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982793,
					["extraData"] = {
						28, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [1445]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:13:03]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:5448::::::::28:::::::::|h[Fractured Elemental Bracer]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982793,
					["extraData"] = {
						28, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [1446]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:13:12]|h|r Your skill in Wands has increased to 136.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982802,
					["extraData"] = {
						27, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1447]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:13:18]|h|r You receive loot: |cff9d9d9d|Hitem:5451::::::::28:::::::::|h[Crushed Elemental Bracer]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982808,
					["extraData"] = {
						28, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [1448]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:13:18]|h|r You receive loot: |cffffffff|Hitem:9451::::::::28:::::::::|h[Bubbling Water]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982808,
					["extraData"] = {
						28, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [1449]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:14:02]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:9451::::::::28:::::::::|h[Bubbling Water]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982852,
					["extraData"] = {
						28, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [1450]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:14:10]|h|r Quest accepted: The Befouled Element",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982860,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [1451]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:16:09]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Vore-Shadowstrike(AU):2596:CHANNEL:2|h|cffffffffVore|r|h|cffd8d8d8]|r: did we win?",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982979,
					["extraData"] = {
						71, -- [1]
						9, -- [2]
						10, -- [3]
						["n"] = 3,
					},
				}, -- [1452]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:16:17]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Hepayy:2599:CHANNEL:2|h|cfffff468Hepayy|r|h|cffd8d8d8]|r: betcha  sweet !@#",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982987,
					["extraData"] = {
						71, -- [1]
						9, -- [2]
						12, -- [3]
						["n"] = 3,
					},
				}, -- [1453]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:16:21]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Vore-Shadowstrike(AU):2602:CHANNEL:2|h|cffffffffVore|r|h|cffd8d8d8]|r: hell yeahhhhhhhhhh",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709982991,
					["extraData"] = {
						71, -- [1]
						9, -- [2]
						10, -- [3]
						["n"] = 3,
					},
				}, -- [1454]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:16:59]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:2940::::::::28:::::::::|h[Bloody Bear Paw]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983029,
					["extraData"] = {
						28, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [1455]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:16:59]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff9d9d9d|Hitem:3702::::::::28:::::::::|h[Bear Gall Bladder]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983029,
					["extraData"] = {
						28, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [1456]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:16:59]|h|r |cff0070ddTpainwarpigs|r receives loot: |cffffffff|Hitem:3730::::::::28:::::::::|h[Big Bear Meat]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983029,
					["extraData"] = {
						28, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [1457]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:23:48]|h|r You create: |cffffffff|Hitem:6265::::::::28:::::::::|h[Soul Shard]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983438,
					["extraData"] = {
						28, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [1458]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:23:50]|h|r |cff0070ddTpainwarpigs|r receives loot: |cff1eff00|Hitem:16303::::::::28:::::::::|h[Ursangous's Paw]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983440,
					["extraData"] = {
						28, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [1459]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:23:50]|h|r You receive loot: |cff1eff00|Hitem:16303::::::::28:::::::::|h[Ursangous's Paw]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983440,
					["extraData"] = {
						28, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [1460]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:23:50]|h|r You receive loot: |cff9d9d9d|Hitem:2940::::::::28:::::::::|h[Bloody Bear Paw]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983440,
					["extraData"] = {
						28, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [1461]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:23:55]|h|r Quest accepted: Ursangous's Paw",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983445,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [1462]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:24:31]|h|r Discovered The Ruins of Stardust: 185 experience gained",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983481,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [1463]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:25:38]|h|r You create: |cffffffff|Hitem:6265::::::::28:::::::::|h[Soul Shard]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983548,
					["extraData"] = {
						28, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [1464]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:25:41]|h|r Your share of the loot is 44 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983551,
					["extraData"] = {
						29, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [1465]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:26:07]|h|r You receive loot: |cffffffff|Hitem:2453::::::::28:::::::::|h[Bruiseweed]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983577,
					["extraData"] = {
						28, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [1466]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:26:08]|h|r Your share of the loot is 49 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983578,
					["extraData"] = {
						29, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [1467]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:27:04]|h|r Discovered Astranaar: 131 experience gained",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983634,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [1468]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:27:31]|h|r |Hchannel:channel:4|h[4] |h|cffd8d8d8[|r|Hplayer:Pepisham-Shadowstrike(AU):2797:CHANNEL:4|h|cff0070ddPepisham|r|h|cffd8d8d8]|r: LF1M BFD Dps - Trinket res",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983661,
					["extraData"] = {
						73, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [1469]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:29:31]|h|r Discovered Maestra's Post: 116 experience gained",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983781,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [1470]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:32:29]|h|r Discovered The Zoram Strand: 131 experience gained",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709983959,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [1471]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:33:50]|h|r Quest accepted: The Essence of Aku'Mai",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 60064.747,
					["serverTime"] = 1709984040,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [1472]
				{
					["message"] = "0 days, 0 hours, 2 minutes, 14 seconds",
					["timestamp"] = 60064.747,
				}, -- [1473]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 60064.747,
				}, -- [1474]
				{
					["message"] = "|cFFFF1C1C Loaded: LFG Bulletin Board 3.17 by Vyscî-Whitemane",
					["timestamp"] = 60058.598,
				}, -- [1475]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Dominos Detected, please make sure Dominos Elements are disabled in MoveAny!",
					["timestamp"] = 60058.598,
				}, -- [1476]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Click the MoveAny Minimap Button to open the settings.",
					["timestamp"] = 60058.598,
				}, -- [1477]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Or tap /move or /moveany in chat to open the settings.",
					["timestamp"] = 60058.598,
				}, -- [1478]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 To hide these messages deactivate tips in the MoveAny menu.",
					["timestamp"] = 60058.598,
				}, -- [1479]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:36:00]|h|r Error parsing guide 12-17 The Barrens: Invalid function call (.isQuestTurnIn)\n.isQuestTurnIn 858",
					["timestamp"] = 60058.598,
				}, -- [1480]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:36:02]|h|r |cFF00FFB0WeaponSwingTimer: |rThank you for installing WeaponSwingTimer Version 7.2.4 by WatchYourSixx! Use |cFFFFC300/wst|r for more options.",
					["timestamp"] = 60058.598,
				}, -- [1481]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:36:03]|h|r Guild Message of the Day: Shoutout miss waterloo and warrick walkerbear",
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 60064.631,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [1482]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:36:04]|h|r |cffffff99<aux> loaded - /aux",
					["timestamp"] = 60064.747,
				}, -- [1483]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:36:04]|h|r |c00FFAA00ThreatClassic2 v2.50 - Type /tc2 for options.|r",
					["timestamp"] = 60064.747,
					["serverTime"] = 1709984174,
				}, -- [1484]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:36:04]|h|r |cffe6cc80 [Whoa Thick Frames |cFF0070FFClassic|r |cffe6cc80v1.5d ] |cffffffffis now loaded. Use |cffffff00'/whoaf' |cffffffffto view options.",
					["timestamp"] = 60064.747,
					["serverTime"] = 1709984174,
				}, -- [1485]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:36:05]|h|r Dungeon difficulty set to Normal",
					["serverTime"] = 1709984175,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60066.09400000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [1486]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:36:08]|h|r RestedXP Guides: TotemTimers has known incompatibilities with the Waypoint Arrow. Disable it if you're experiencing navigation issues.",
					["timestamp"] = 60068.785,
					["serverTime"] = 1709984178,
				}, -- [1487]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:36:13]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|h|HNWBCustomLink:timers|hYou are on a layered realm.|h|h",
					["timestamp"] = 60074.75,
					["serverTime"] = 1709984183,
				}, -- [1488]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:36:13]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|h|HNWBCustomLink:timers|hClick here to view current timers.|h|h",
					["timestamp"] = 60074.75,
					["serverTime"] = 1709984183,
				}, -- [1489]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:39:08]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - The Barrens]|h",
					["serverTime"] = 1709984358,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60249.016,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1490]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:39:08]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - The Barrens]|h",
					["serverTime"] = 1709984358,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60249.016,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1491]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:41:57]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Mulgore]|h",
					["serverTime"] = 1709984527,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60417.915,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1492]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:41:57]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Mulgore]|h",
					["serverTime"] = 1709984527,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60417.915,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1493]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:55]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Thunder Bluff]|h",
					["serverTime"] = 1709984585,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60476.681,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1494]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:55]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Thunder Bluff]|h",
					["serverTime"] = 1709984585,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60476.681,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1495]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:43:01]|h|r You feel rested.",
					["serverTime"] = 1709984591,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60482.665,
					["g"] = 1,
					["b"] = 0,
				}, -- [1496]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:43:15]|h|r You are now AFK: Away from Keyboard",
					["serverTime"] = 1709984605,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60496.415,
					["g"] = 1,
					["b"] = 0,
				}, -- [1497]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:43:19]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Uzi:3053:CHANNEL:3|h|cff3fc6eaUzi|r|h|cffd8d8d8]|r: LFW Ench - Portal UC/OG PM \"inv\" +3 agi cloak, dismantle, all recipes - freewater",
					["serverTime"] = 1709984609,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60500.065,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1498]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:43:30]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Nlasb:3065:CHANNEL:3|h|cff0070ddNlasb|r|h|cffd8d8d8]|r: ele sham 6/6 lfg gnomer",
					["serverTime"] = 1709984620,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						12, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60511.065,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1499]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:43:40]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Nlasb-Shadowstrike(AU):3080:CHANNEL:3|h|cff0070ddNlasb|r|h|cffd8d8d8]|r: ele sham 6/6 lfg gnomer consumes/boon etc",
					["serverTime"] = 1709984630,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						12, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60521.765,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1500]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:43:59]|h|r Bashana Runetotem yells: Denizens of Kalimdor, the dread beast Aku'mai has been slain and Ashenvale has been cleansed of the blight of the Old Gods' influence. Feel the boon of Blackfathom, and bask in the warmth of the Earth Mother's gaze!",
					["serverTime"] = 1709984649,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						14, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60540.298,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [1501]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:44:05]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|hBoon of Blackfathom buff has dropped.|h",
					["timestamp"] = 60546.664,
					["serverTime"] = 1709984655,
				}, -- [1502]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:44:22]|h|r Bashana Runetotem yells: Denizens of Kalimdor, the dread beast Aku'mai has been slain and Ashenvale has been cleansed of the blight of the Old Gods' influence. Feel the boon of Blackfathom, and bask in the warmth of the Earth Mother's gaze!",
					["serverTime"] = 1709984672,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						14, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60562.982,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [1503]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:45:07]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Nlasb-Shadowstrike(AU):3202:CHANNEL:3|h|cff0070ddNlasb|r|h|cffd8d8d8]|r: ele sham 6/6 lfg gnomer consumes/boon etc",
					["serverTime"] = 1709984717,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						12, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60608.231,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1504]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:45:15]|h|r You are no longer AFK.",
					["serverTime"] = 1709984725,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60615.849,
					["g"] = 1,
					["b"] = 0,
				}, -- [1505]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:45:24]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Shanty:3229:CHANNEL:3|h|cffaad372Shanty|r|h|cffd8d8d8]|r: Can |cffffffff|Hitem:13875::::::::40:::::::::|h[Ironbound Locked Chest]|h|r be picked at this level? if so pst price",
					["serverTime"] = 1709984734,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						16, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60625.597,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1506]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:45:34]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Mulgore]|h",
					["serverTime"] = 1709984744,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60635.632,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1507]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:45:34]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. Trade - City]|h",
					["serverTime"] = 1709984744,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						18, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60635.632,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1508]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:45:34]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Mulgore]|h",
					["serverTime"] = 1709984744,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60635.632,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1509]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:46:17]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - The Barrens]|h",
					["serverTime"] = 1709984787,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60678.63000000001,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1510]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:46:17]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - The Barrens]|h",
					["serverTime"] = 1709984787,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60678.63000000001,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1511]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:48:24]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. General - Orgrimmar]|h",
					["serverTime"] = 1709984914,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60805.179,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1512]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:48:24]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. Trade - City]|h",
					["serverTime"] = 1709984914,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						18, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60805.179,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1513]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:48:24]|h|r |Hchannel:channel:4|h[4] |h Changed Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Orgrimmar]|h",
					["serverTime"] = 1709984914,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60805.179,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1514]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:48:34]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Ibutcher:3272:CHANNEL:2|h|cff0070ddIbutcher|r|h|cffd8d8d8]|r: LFM fresh BFD xp run  pearl HR pst need range DPS and 1 heal",
					["serverTime"] = 1709984924,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60815.596,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1515]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:48:49]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Nlasb-Shadowstrike(AU):3276:CHANNEL:3|h|cff0070ddNlasb|r|h|cffd8d8d8]|r: ele sham 6/6 lfg gnomer consumes/boon etc",
					["serverTime"] = 1709984939,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						12, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60830.129,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1516]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:49:00]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Maegwin-Shadowstrike(AU):3280:CHANNEL:3|h|cffffffffMaegwin|r|h|cffd8d8d8]|r: Healer LFG SFK",
					["serverTime"] = 1709984950,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60841.513,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1517]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:49:18]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Nvrgofullzug-Shadowstrike(AU):3287:CHANNEL:2|h|cffc69b6dNvrgofullzug|r|h|cffd8d8d8]|r: LF ENCHANTER my mats tipping",
					["serverTime"] = 1709984968,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						24, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60859.463,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1518]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:49:36]|h|r [Y] |cffd8d8d8[|r|Hplayer:Silverash-Shadowstrike(AU):3294:YELL|h|cffc69b6dSilverash|r|h|cffd8d8d8]|r: any rogue toi open lock box",
					["serverTime"] = 1709984986,
					["r"] = 1,
					["extraData"] = {
						7, -- [1]
						26, -- [2]
						27, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60876.86300000001,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [1519]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:49:40]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Ibutcher-Shadowstrike(AU):3296:CHANNEL:2|h|cff0070ddIbutcher|r|h|cffd8d8d8]|r: LFM fresh BFD xp run  pearl HR pst need range DPS and 1 heal",
					["serverTime"] = 1709984990,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60881.646,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1520]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:49:47]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Matori-Shadowstrike(AU):3301:CHANNEL:2|h|cff3fc6eaMatori|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t selling ports to UC |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t max level mage food/water included |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t",
					["serverTime"] = 1709984997,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60888.563,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1521]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:50:00]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Fentányl-Shadowstrike(AU):3309:CHANNEL:3|h|cffaad372Fentányl|r|h|cffd8d8d8]|r: LF Enchanter",
					["serverTime"] = 1709985010,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60901.729,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1522]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:50:11]|h|r [Y] |cffd8d8d8[|r|Hplayer:Offmyhead-Shadowstrike(AU):3316:YELL|h|cffff7c0aOffmyhead|r|h|cffd8d8d8]|r: LF ROGUE TO OPEN |cff1eff00|Hitem:4636::::::::40:::::::::|h[Strong Iron Lockbox]|h|r",
					["serverTime"] = 1709985021,
					["r"] = 1,
					["extraData"] = {
						7, -- [1]
						26, -- [2]
						32, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60911.779,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [1523]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:50:11]|h|r [Y] |cffd8d8d8[|r|Hplayer:Silverash-Shadowstrike(AU):3317:YELL|h|cffc69b6dSilverash|r|h|cffd8d8d8]|r: any rogue open lock box",
					["serverTime"] = 1709985021,
					["r"] = 1,
					["extraData"] = {
						7, -- [1]
						26, -- [2]
						27, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60912.38000000001,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [1524]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:50:18]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Sulit-Shadowstrike(AU):3322:CHANNEL:3|h|cff3fc6eaSulit|r|h|cffd8d8d8]|r: WTS |cff0070dd|Hitem:13025::::::::40:::::::::|h[Deadwood Sledge]|h|r",
					["serverTime"] = 1709985028,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						33, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60919.646,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1525]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:50:21]|h|r You are now AFK: Away from Keyboard",
					["serverTime"] = 1709985031,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60922.646,
					["g"] = 1,
					["b"] = 0,
				}, -- [1526]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:50:28]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Sulit-Shadowstrike(AU):3326:CHANNEL:3|h|cff3fc6eaSulit|r|h|cffd8d8d8]|r: WTS |cff1eff00|Hitem:9932::::::532:118076416:40:::::::::|h[Brigade Circlet of the Wolf]|h|r",
					["serverTime"] = 1709985038,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						33, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60928.896,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1527]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:50:42]|h|r |cffc69b6dSlobbyudder|r looks tipsy.",
					["serverTime"] = 1709985052,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60943.413,
					["g"] = 1,
					["b"] = 0,
				}, -- [1528]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:50:45]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Slyfire-Shadowstrike(AU):3339:CHANNEL:3|h|cffff7c0aSlyfire|r|h|cffd8d8d8]|r: where gnoomers",
					["serverTime"] = 1709985055,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						35, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60945.896,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1529]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:50:53]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Nlasb-Shadowstrike(AU):3345:CHANNEL:3|h|cff0070ddNlasb|r|h|cffd8d8d8]|r: ele sham 6/6 lfg gnomer consumes/boon etc",
					["serverTime"] = 1709985063,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						12, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60953.896,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1530]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:50:54]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Nvrgofullzug-Shadowstrike(AU):3347:CHANNEL:3|h|cffc69b6dNvrgofullzug|r|h|cffd8d8d8]|r: LF Enchanter ORG my mats tipping",
					["serverTime"] = 1709985064,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						37, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60954.946,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1531]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:50:57]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Matori-Shadowstrike(AU):3349:CHANNEL:2|h|cff3fc6eaMatori|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t selling ports to UC |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t max level mage food/water included |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t",
					["serverTime"] = 1709985067,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60958.162,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1532]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:51:38]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Fentányl-Shadowstrike(AU):3377:CHANNEL:3|h|cffaad372Fentányl|r|h|cffd8d8d8]|r: LF Enchanter",
					["serverTime"] = 1709985108,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 60999.046,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1533]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:51:47]|h|r [Y] |cffd8d8d8[|r|Hplayer:Nvrgofullzug-Shadowstrike(AU):3382:YELL|h|cffc69b6dNvrgofullzug|r|h|cffd8d8d8]|r: LF ENCHANTER",
					["serverTime"] = 1709985117,
					["r"] = 1,
					["extraData"] = {
						7, -- [1]
						26, -- [2]
						41, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 61008.528,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [1534]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:51:55]|h|r Nogg yells: Alright everyone listen up. Some stooge... uh, I mean \"brave adventurer\" brought me a whole huge pile of secret gnomish tech and once we finish applying our superior goblin ingenuity to it we are going to use it to BLOW SO MUCH STUFF UP. Gather 'round and let's party!",
					["serverTime"] = 1709985125,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						14, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 61016.462,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [1535]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:52:02]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|hSpark of Inspiration buff has dropped.|h",
					["timestamp"] = 61022.829,
					["serverTime"] = 1709985132,
				}, -- [1536]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:52:02]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Matori-Shadowstrike(AU):3386:CHANNEL:2|h|cff3fc6eaMatori|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t selling ports to UC |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t max level mage food/water included |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t",
					["serverTime"] = 1709985132,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 61023.013,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1537]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:52:19]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Thegigs:3394:CHANNEL:2|h|cff0070ddThegigs|r|h|cffd8d8d8]|r: Where is Nogg (the epic neck quest npc)?",
					["serverTime"] = 1709985149,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						42, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 61039.929,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1538]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:52:29]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fedutil-Shadowstrike(AU):3395:CHANNEL:2|h|cff3fc6eaFedutil|r|h|cffd8d8d8]|r: Engi place",
					["serverTime"] = 1709985159,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						44, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 61049.979,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1539]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:52:29]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. General - Orgrimmar]|h",
					["serverTime"] = 1709985159,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 61050.112,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1540]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:52:29]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. Trade - City]|h",
					["serverTime"] = 1709985159,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						9, -- [2]
						18, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 61050.112,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1541]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:52:29]|h|r |Hchannel:channel:4|h[4] |h Left Channel: |Hchannel:CHANNEL:4|h[4. LocalDefense - Orgrimmar]|h",
					["serverTime"] = 1709985159,
					["r"] = 1,
					["extraData"] = {
						73, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 61050.112,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [1542]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}


Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["scrollback"] = {
		["ChatFrame5"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 4,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["serverTime"] = 1714113579,
					["r"] = 1,
					["b"] = 0,
					["timestamp"] = 7854.664,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [1]
				{
					["message"] = "0 days, 0 hours, 0 minutes, 0 seconds",
					["timestamp"] = 7854.664,
				}, -- [2]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 7854.664,
				}, -- [3]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 7848.317,
					["g"] = 1,
					["b"] = 0,
				}, -- [4]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame7"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame6"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame8"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame10"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame9"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 45,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[16:25:43]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Ärkive:1310:CHANNEL:1|h|cff8787edÄrkive|r|h|cffd8d8d8]|r: anyone looking for the wandering swordsman?",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 7854.664,
					["serverTime"] = 1714112751,
					["extraData"] = {
						69, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:26:58]|h|r |Hchannel:channel:1|h[1] |h Left Channel: |Hchannel:CHANNEL:1|h[1. General - Durotar]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 7854.664,
					["serverTime"] = 1714112826,
					["extraData"] = {
						69, -- [1]
						1, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:26:58]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Durotar]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 7854.664,
					["serverTime"] = 1714112826,
					["extraData"] = {
						71, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
				}, -- [3]
				{
					["message"] = "0 days, 0 hours, 12 minutes, 33 seconds",
					["timestamp"] = 7854.664,
				}, -- [4]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 7854.664,
				}, -- [5]
				{
					["message"] = " |cffff8800<|cffffbb00FarmLog|cffff8800>|r |cffffbb00v1.24|r by |cffb266ffKof|r @ |cffff2222Firemaw|r (era), type |cff00ff00/fl|r for options, right click minimap icon to resume/pause a farm session, |cff00ff00/fl help|r for more commands",
					["timestamp"] = 7848.317,
				}, -- [6]
				{
					["message"] = "|cFFFF1C1C Loaded: LFG Bulletin Board 3.23 by Vyscî-Whitemane",
					["timestamp"] = 7848.317,
				}, -- [7]
				{
					["message"] = "|cFF00FFFFLoaded MageBookTracker v1.1.0 by Haruhara",
					["timestamp"] = 7848.317,
				}, -- [8]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Dominos Detected, please make sure Dominos Elements are disabled in MoveAny!",
					["timestamp"] = 7848.317,
				}, -- [9]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Click the MoveAny Minimap Button to open the settings.",
					["timestamp"] = 7848.317,
				}, -- [10]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Or tap /move or /moveany in chat to open the settings.",
					["timestamp"] = 7848.317,
				}, -- [11]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 To hide these messages deactivate tips in the MoveAny menu.",
					["timestamp"] = 7848.317,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:29]|h|r |cFF00FFB0WeaponSwingTimer: |rThank you for installing WeaponSwingTimer Version 7.2.5 by WatchYourSixx! Use |cFFFFC300/wst|r for more options.",
					["timestamp"] = 7848.317,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:29]|h|r |cff33ff99WowSimsExporter|r: WowSimsExporter v2.9 Initialized. use /wse For Window.",
					["timestamp"] = 7848.317,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:31]|h|r RestedXP Guides: Targeting macro updated with (Kaltunk)",
					["timestamp"] = 7854.664,
					["serverTime"] = 1714113579,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:31]|h|r |cff33ff99Scambuster|r: INFO: Parsing provider list Shadowstrike Discord Blacklist...",
					["timestamp"] = 7854.664,
					["serverTime"] = 1714113579,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:31]|h|r |cff33ff99Scambuster|r: Welcome to version 0.1.6",
					["timestamp"] = 7854.664,
					["serverTime"] = 1714113579,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:31]|h|r |cffffff99<aux> loaded - /aux",
					["timestamp"] = 7854.664,
					["serverTime"] = 1714113579,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:31]|h|r |c00FFAA00ThreatClassic2 v2.50 - Type /tc2 for options.|r",
					["timestamp"] = 7854.664,
					["serverTime"] = 1714113579,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:32]|h|r |cffe6cc80 [Whoa Thick Frames |cFF0070FFClassic|r |cffe6cc80v1.5d ] |cffffffffis now loaded. Use |cffffff00'/whoaf' |cffffffffto view options.",
					["timestamp"] = 7854.664,
					["serverTime"] = 1714113580,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:32]|h|r |cffe6cc80Ranker|r: AddOn version 2024.03.25.01 loaded.",
					["timestamp"] = 7854.664,
					["serverTime"] = 1714113580,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:32]|h|r |cffffff00[Grab GUID]|r loaded. Use |cff00ff00/gg|r or |cff00ff00/grabguid|r to bring up Grab GUID frame.",
					["timestamp"] = 7854.664,
					["serverTime"] = 1714113580,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:33]|h|r |cFFffff00[Questie]|r |cFF6ce314The 'Darkmoon Faire' world event is active!",
					["timestamp"] = 7857.293000000001,
					["serverTime"] = 1714113581,
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:34]|h|r |cff1a9fc0Enemy Cooldown Count|r loaded!",
					["timestamp"] = 7857.664,
					["serverTime"] = 1714113582,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:34]|h|r Type |cff1a9fc0/ecdc|r to open settings.",
					["timestamp"] = 7857.664,
					["serverTime"] = 1714113582,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:35]|h|r RestedXP Guides: TotemTimers has known incompatibilities with the Waypoint Arrow. Disable it if you're experiencing navigation issues.",
					["timestamp"] = 7858.664,
					["serverTime"] = 1714113583,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:41]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|h|HNWBCustomLink:timers|hYou are on a layered realm.|h|h",
					["timestamp"] = 7864.665,
					["serverTime"] = 1714113589,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:39:41]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|h|HNWBCustomLink:timers|hClick here to view current timers.|h|h",
					["timestamp"] = 7864.665,
					["serverTime"] = 1714113589,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:41:47]|h|r Discovered Razor Hill: 45 experience gained",
					["serverTime"] = 1714113715,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 7991.288000000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:44:51]|h|r Discovered Orgrimmar: 55 experience gained",
					["serverTime"] = 1714113899,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 8175.323,
					["g"] = 1,
					["b"] = 0,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:44:52]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Orgrimmar]|h",
					["serverTime"] = 1714113900,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 8175.515,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:44:52]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Orgrimmar]|h",
					["serverTime"] = 1714113900,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 8175.515,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:45:00]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):1387:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: LF5M Sunken Temple Need 1 Tank 2 Healer 2 Melee DPS (8/8) Guild Run at 7pm SATURDAY - Need all (Experience, WBs, Consumes, Discord Mandatory) PST for more Details!",
					["serverTime"] = 1714113908,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						9, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 8183.988,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:45:04]|h|r [Y] |cffd8d8d8[|r|Hplayer:Packapunch:1389:YELL|h|cff3fc6eaPackapunch|r|h|cffd8d8d8]|r: 265 Enchanter LFW & Selling UC/TB Ports",
					["serverTime"] = 1714113912,
					["r"] = 1,
					["extraData"] = {
						7, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 8187.687,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:45:05]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Packapunch-Shadowstrike(AU):1390:CHANNEL:2|h|cff3fc6eaPackapunch|r|h|cffd8d8d8]|r: 265 Enchanter LFW & Selling UC/TB Ports",
					["serverTime"] = 1714113913,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						9, -- [2]
						14, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 8188.332,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:45:31]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Ashockyboi-Shadowstrike(AU):1397:CHANNEL:2|h|cff0070ddAshockyboi|r|h|cffd8d8d8]|r: lf3m AB 5 man premade",
					["serverTime"] = 1714113939,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						9, -- [2]
						16, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 8214.975,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:45:53]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fiwl-Shadowstrike(AU):1410:CHANNEL:2|h|cffff7c0aFiwl|r|h|cffd8d8d8]|r: wtb |cff0070dd|Hitem:221297::::::::50:::::::::|h[Eight of Dunes]|h|r",
					["serverTime"] = 1714113961,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						9, -- [2]
						18, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 8237.021,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:46:33]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Morekth-Shadowstrike(AU):1428:CHANNEL:2|h|cffc69b6dMorekth|r|h|cffd8d8d8]|r: WTS |cffffffff|Hitem:3821::::::::50:::::::::|h[Goldthorn]|h|r bulk 3g50 stacks",
					["serverTime"] = 1714114001,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						9, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 8276.399,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:46:33]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Eirä-Shadowstrike(AU):1429:CHANNEL:2|h|cffffffffEirä|r|h|cffd8d8d8]|r: WTB |cffffffff|Hitem:14047::::::::50:::::::::|h[Runecloth]|h|r 3.5g per stack",
					["serverTime"] = 1714114001,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						9, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 8276.669,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:46:37]|h|r |Hplayer:Packapunch:0:TEXT_EMOTE:|hPackapunch|h thanks Zoomi.",
					["serverTime"] = 1714114005,
					["r"] = 1,
					["extraData"] = {
						12, -- [1]
						24, -- [2]
						25, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 8280.809,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:47:08]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Ichor-Shadowstrike(AU):1440:CHANNEL:2|h|cffc69b6dIchor|r|h|cffd8d8d8]|r: LF MASTER TRANSMUTER TO XMUTE |cff1eff00|Hitem:12363::::::::50:::::::::|h[Arcane Crystal]|h|r INTO |cff1eff00|Hitem:12360::::::::50:::::::::|h[Arcanite Bar]|h|r",
					["serverTime"] = 1714114036,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						9, -- [2]
						26, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 8311.801,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:47:19]|h|r [Y] |cffd8d8d8[|r|Hplayer:Emoshankz-Shadowstrike(AU):1447:YELL|h|cfffff468Emoshankz|r|h|cffd8d8d8]|r: wtb port",
					["serverTime"] = 1714114047,
					["r"] = 1,
					["extraData"] = {
						7, -- [1]
						12, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 8322.579,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:47:21]|h|r [Y] |cffd8d8d8[|r|Hplayer:Emoshankz-Shadowstrike(AU):1449:YELL|h|cfffff468Emoshankz|r|h|cffd8d8d8]|r: uc",
					["serverTime"] = 1714114049,
					["r"] = 1,
					["extraData"] = {
						7, -- [1]
						12, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 8324.446,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:47:21]|h|r Sold junk for 2 Copper.",
					["r"] = 1,
					["serverTime"] = 1714114049,
					["timestamp"] = 8324.537,
					["g"] = 0.85,
					["b"] = 0,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:47:22]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):1451:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: LF5M Sunken Temple Need 1 Tank 2 Healer 2 Melee DPS (8/8) Guild Run at 7pm SATURDAY - Need all (Experience, WBs, Consumes, Discord Mandatory) PST for more Details!",
					["serverTime"] = 1714114050,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						9, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 8325.897,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [45]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}

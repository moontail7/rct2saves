
RXPCData = {
	["completedWaypoints"] = {
		{
		}, -- [1]
	},
	["currentStep"] = 1,
	["questObjectivesCache"] = {
		[788] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Mottled Boar slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[790] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Sarkoth's Mangled Claw: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[792] = {
			{
				["type"] = "monster",
				["numRequired"] = 12,
				["text"] = "Vile Familiar slain: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[6394] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Thazz'ril's Pick: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[4402] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Cactus Apple: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[789] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Scorpid Worker Tail: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[5441] = {
			{
				["type"] = "monster",
				["numRequired"] = 5,
				["text"] = "Peons Awoken: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[0] = 8,
		[794] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Burning Blade Medallion: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
	},
	["currentGuideGroup"] = "RestedXP Survival Guide (H)",
	["flightPaths"] = {
	},
	["questNameCache"] = {
		[788] = "Cutting Teeth",
		[790] = "Sarkoth",
		[792] = "Vile Familiars",
		[6394] = "Thazz'ril's Pick",
		[4641] = "Your Place In The World",
		[4402] = "Galgar's Cactus Apple Surprise",
		[789] = "Sting of the Scorpid",
		[5441] = "Lazy Peons",
		[794] = "Burning Blade Medallion",
	},
	["currentGuideName"] = "01-06 Orc/Troll",
	["stepSkip"] = {
	},
	["currentStepId"] = 3857651152,
}
RXPCTrackingData = {
	["profileKeys"] = {
		["Skeeboo - Shadowstrike (AU)"] = "Skeeboo - Shadowstrike (AU)",
	},
	["profiles"] = {
		["Skeeboo - Shadowstrike (AU)"] = {
			["levels"] = {
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 26,
							["day"] = 0,
							["month"] = 4,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 16,
							["minute"] = 24,
						},
						["started"] = 0,
					},
					["quests"] = {
					},
				}, -- [1]
			},
			["trackedGuid"] = "Player-5818-00ABA237",
		},
	},
}
RXPCComms = {
	["profileKeys"] = {
		["Skeeboo - Shadowstrike (AU)"] = "Skeeboo - Shadowstrike (AU)",
	},
	["profiles"] = {
		["Skeeboo - Shadowstrike (AU)"] = {
		},
	},
}
RXPCSettings = nil

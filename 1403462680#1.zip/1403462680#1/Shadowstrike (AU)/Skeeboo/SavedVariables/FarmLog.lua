
FLogVars = {
	["enabled"] = false,
	["inInstance"] = false,
	["todayKills"] = {
	},
	["itemTooltip"] = true,
	["lockMinimapButton"] = false,
	["currentFarm"] = "default",
	["ver"] = 1.24,
	["hud"] = {
		["show"] = false,
		["locked"] = false,
	},
	["viewTotal"] = true,
	["farms"] = {
		["default"] = {
			["current"] = {
				["ah"] = 0,
				["skill"] = {
				},
				["kills"] = {
				},
				["gold"] = 0,
				["deaths"] = 0,
				["vendor"] = 0,
				["drops"] = {
				},
				["hks"] = 0,
				["resets"] = 0,
				["rep"] = {
				},
				["ranks"] = {
				},
				["dks"] = 0,
				["bgsWin"] = {
				},
				["xp"] = 0,
				["honor"] = 0,
				["seconds"] = 0,
				["consumes"] = {
				},
				["bgsLoss"] = {
				},
				["bgs"] = {
				},
			},
			["goldTotal"] = 0,
			["honorPerHourTotal"] = 0,
			["past"] = {
				["ah"] = 0,
				["skill"] = {
				},
				["kills"] = {
				},
				["gold"] = 0,
				["deaths"] = 0,
				["vendor"] = 0,
				["drops"] = {
				},
				["hks"] = 0,
				["resets"] = 0,
				["rep"] = {
				},
				["ranks"] = {
				},
				["dks"] = 0,
				["bgsWin"] = {
				},
				["xp"] = 0,
				["honor"] = 0,
				["seconds"] = 0,
				["consumes"] = {
				},
				["bgsLoss"] = {
				},
				["bgs"] = {
				},
			},
			["goldPerHourTotal"] = 0,
			["honorTotal"] = 0,
		},
	},
	["minimapButtonPosition"] = {
		["y"] = -127,
		["x"] = -165,
		["point"] = "TOPRIGHT",
	},
	["enableMinimapButton"] = true,
	["frameRect"] = {
		["y"] = 0,
		["x"] = 0,
		["point"] = "CENTER",
		["height"] = 200,
		["visible"] = false,
		["width"] = 250,
	},
	["lockFrames"] = false,
}

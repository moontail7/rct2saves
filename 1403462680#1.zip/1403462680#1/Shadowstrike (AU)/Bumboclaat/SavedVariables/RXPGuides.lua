
RXPCData = {
	["completedWaypoints"] = {
		[131] = {
		},
	},
	["currentStep"] = 131,
	["questObjectivesCache"] = {
		[0] = 74,
		[357] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "The Lich's Spellbook: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[845] = {
			{
				["type"] = "item",
				["numRequired"] = 4,
				["text"] = "Zhevra Hooves: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[365] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Tirisfal Pumpkin: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[369] = {
			{
				["type"] = "item",
				["numRequired"] = 4,
				["text"] = "Vicious Night Web Spider Venom: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[869] = {
			{
				["type"] = "item",
				["numRequired"] = 12,
				["text"] = "Raptor Head: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[877] = {
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Test the Dried Seeds: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[381] = {
			{
				["type"] = "item",
				["numRequired"] = 12,
				["text"] = "Scarlet Armband: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[5651] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["generated"] = true,
				["text"] = "Objective Complete",
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[901] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Console Key: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[409] = {
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Lillith Nefara slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[421] = {
			{
				["type"] = "monster",
				["numRequired"] = 5,
				["text"] = "Moonrage Whitescalp slain: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[425] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Ivar's Head: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[437] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Essence of Nightlash: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Enter the Dead Fields",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[4021] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Piece of Krom'zar's Banner: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[354] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Gregor's Remains: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Nissa's Remains: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Thurman's Remains: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[358] = {
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Rot Hide Graverobber slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 5,
				["text"] = "Rot Hide Mongrel slain: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Embalming Ichor: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[362] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Devlin's Remains: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[855] = {
			{
				["type"] = "item",
				["numRequired"] = 15,
				["text"] = "Centaur Bracers: 0/15",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[77670] = {
			{
				["type"] = "spell",
				["numRequired"] = 1,
				["text"] = "Learn Spell: Engrave Gloves - Penance",
				["finished"] = true,
				["numFulfilled"] = 1,
			}, -- [1]
		},
		[871] = {
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Razormane Water Seeker slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Razormane Thornweaver slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 3,
				["text"] = "Razormane Hunter slain: 0/3",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[887] = {
			{
				["type"] = "monster",
				["numRequired"] = 12,
				["text"] = "Southsea Brigand slain: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 6,
				["text"] = "Southsea Cannoneer slain: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[895] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Baron Longshore's Head: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[903] = {
			{
				["type"] = "item",
				["numRequired"] = 7,
				["text"] = "Prowler Claws: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[398] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Maggot Eye's Paw: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[5481] = {
			{
				["type"] = "item",
				["numRequired"] = 3,
				["text"] = "Gloom Weed: 0/3",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[848] = {
			{
				["type"] = "item",
				["numRequired"] = 4,
				["text"] = "Fungal Spores: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[5482] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Doom Weed: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[872] = {
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Razormane Geomancer slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Razormane Defender slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Kreenig Snarlsnout's Tusk: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[880] = {
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Altered Snapjaw Shell: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[3901] = {
			{
				["type"] = "monster",
				["numRequired"] = 12,
				["text"] = "Rattlecage Skeleton slain: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[896] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Cats Eye Emerald: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[5041] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Crossroads' Supply Crates: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[3902] = {
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Scavenged Goods: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[367] = {
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Darkhound Blood: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[865] = {
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Intact Raptor Horn: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[375] = {
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Duskbat Pelt: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Coarse Thread: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[881] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Echeyakee's Hide: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[4921] = {
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Find Mankrik's Wife: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[905] = {
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Visit Blue Raptor Nest: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Visit Yellow Raptor Nest: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Visit Red Raptor Nest: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[423] = {
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Glutton Shackle: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 3,
				["text"] = "Darksoul Shackle: 0/3",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[850] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Kodobane's Head: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[858] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Ignition Key: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[435] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Erland must reach Rane Yorick",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[447] = {
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Grizzled Bear Heart: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Skittering Blood: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[356] = {
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Bleeding Horror slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Wandering Spirit slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[364] = {
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Mindless Zombie slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Wretched Zombie slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[6395] = {
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Samuel's Remains Buried: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[867] = {
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Witchwing Talon: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[376] = {
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Scavenger Paw: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Duskbat Wing: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[380] = {
			{
				["type"] = "monster",
				["numRequired"] = 6,
				["text"] = "Young Night Web Spider slain: 10/10",
				["finished"] = true,
				["numFulfilled"] = 10,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Night Web Spider slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[899] = {
			{
				["type"] = "item",
				["numRequired"] = 60,
				["text"] = " : 0/60",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[851] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Verog's Head: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[370] = {
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Captain Perrine slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 3,
				["text"] = "Scarlet Zealot slain: 0/3",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 3,
				["text"] = "Scarlet Missionary slain: 0/3",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[875] = {
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Harpy Lieutenant Ring: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[404] = {
			{
				["type"] = "item",
				["numRequired"] = 7,
				["text"] = "Putrid Claw: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[368] = {
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Vile Fin Scale: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[422] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Remedy of Arugal: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[426] = {
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Notched Rib: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 3,
				["text"] = "Blackened Skull: 0/3",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[427] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Scarlet Warrior slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[844] = {
			{
				["type"] = "item",
				["numRequired"] = 7,
				["text"] = "Plainstrider Beak: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[852] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Hezrul's Head: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[3281] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Stolen Silver: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[371] = {
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Captain Vachon slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 5,
				["text"] = "Scarlet Friar slain: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[79080] = {
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Pray over the Supplicant: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[372] = {
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Captain Melrache slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 2,
				["text"] = "Scarlet Bodyguard slain: 0/2",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[870] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Explore the waters of the Forgotten Pools",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[900] = {
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Shut off Main Control Valve: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Shut off Fuel Control Valve: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Shut off Regulator Valve: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[374] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Scarlet Insignia Ring: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[5650] = {
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Heal and fortify Deathguard Kel: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[8873] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["generated"] = true,
				["text"] = "Objective Complete",
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[863] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Escort Wizzlecrank out of the Venture Co. drill site",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[382] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Scarlet Crusade Documents: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[821] = {
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Savannah Lion Tusk: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Plainstrider Kidney: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Thunder Lizard Horn: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[888] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Shipment of Boots: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Telescopic Lens: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
	},
	["currentGuideGroup"] = "RestedXP Speedrun Guide (H)",
	["flightPaths"] = {
		[80] = "Ratchet, The Barrens",
		[77] = "Camp Taurajo, The Barrens",
		[22] = "Thunder Bluff, Mulgore",
		[23] = "Orgrimmar, Durotar",
		[25] = "Crossroads, The Barrens",
	},
	["questNameCache"] = {
		[357] = "The Lich's Identity",
		[3221] = "Speak with Renferrel",
		[492] = "A New Plague",
		[369] = "A New Plague",
		[8] = "A Rogue's Deal",
		[5650] = "Garments of Darkness",
		[381] = "The Scarlet Crusade",
		[5651] = "In Favor of Darkness",
		[901] = "Samophlange",
		[405] = "The Prodigal Lich",
		[409] = "Proving Allegiance",
		[421] = "Prove Your Worth",
		[425] = "Ivar the Foul",
		[429] = "Wild Hearts",
		[437] = "The Dead Fields",
		[5658] = "Touch of Weakness",
		[445] = "Delivery to Silverpine Forest",
		[449] = "The Deathstalkers' Report",
		[902] = "Samophlange",
		[4021] = "Counterattack!",
		[477] = "Border Crossings",
		[354] = "Deaths in the Family",
		[358] = "Graverobbers",
		[362] = "The Haunted Mills",
		[366] = "Return the Book",
		[77670] = "Meditation on Undeath",
		[374] = "Proof of Demise",
		[382] = "The Red Messenger",
		[895] = "WANTED: Baron Longshore",
		[903] = "Prowlers of the Barrens",
		[398] = "Wanted: Maggot Eye",
		[3261] = "Jorn Skyseer",
		[878] = "Tribes at War",
		[361] = "A Letter Undelivered",
		[422] = "Arugal's Folly",
		[430] = "Return to Quinn",
		[5481] = "Gordo's Task",
		[426] = "The Mills Overrun",
		[1069] = "Deepmoss Spider Eggs",
		[894] = "Samophlange",
		[438] = "The Decrepit Ferry",
		[880] = "Altered Beings",
		[3901] = "Rattling the Rattlecages",
		[896] = "Miner's Fortune",
		[1492] = "Wharfmaster Dizzywig",
		[5041] = "Supplies for the Crossroads",
		[3902] = "Scavenging Deathknell",
		[877] = "The Stagnant Oasis",
		[1483] = "Ziz Fizziks",
		[865] = "Raptor Horns",
		[478] = "Maps and Runes",
		[355] = "Speak with Sevren",
		[359] = "Forsaken Duties",
		[363] = "Rude Awakening",
		[367] = "A New Plague",
		[371] = "At War With The Scarlet Crusade",
		[375] = "The Chill of Death",
		[881] = "Echeyakee",
		[383] = "Vital Intelligence",
		[4921] = "Lost in Battle",
		[905] = "The Angry Scytheclaws",
		[481] = "Dalar's Analysis",
		[482] = "Dalaran's Intentions",
		[411] = "The Prodigal Lich Returns",
		[407] = "Fields of Grief",
		[6321] = "Supplying the Sepulcher",
		[6323] = "Ride to the Undercity",
		[6322] = "Michael Garrett",
		[423] = "Arugal's Folly",
		[427] = "At War With The Scarlet Crusade",
		[858] = "Ignition",
		[435] = "Escorting Erland",
		[439] = "Rot Hide Clues",
		[852] = "Hezrul Bloodmark",
		[447] = "A Recipe For Death",
		[872] = "The Disruption Ends",
		[890] = "The Missing Shipment",
		[842] = "Crossroads Conscription",
		[850] = "Kolkar Leaders",
		[851] = "Verog the Dervish",
		[372] = "At War With The Scarlet Crusade",
		[819] = "Chen's Empty Keg",
		[875] = "Harpy Lieutenants",
		[356] = "Rear Guard Patrol",
		[360] = "Return to the Magistrate",
		[364] = "The Mindless Ones",
		[6395] = "Marla's Last Wish",
		[867] = "Harpy Raiders",
		[376] = "The Damned",
		[380] = "Night Web's Hollow",
		[1359] = "Zinge's Delivery",
		[899] = "Consumed by Hatred",
		[869] = "Raptor Thieves",
		[855] = "Centaur Bracers",
		[883] = "Lakota'mani",
		[404] = "A Putrid Task",
		[368] = "A New Plague",
		[848] = "Fungal Spores",
		[887] = "Southsea Freebooters",
		[871] = "Disrupt the Attacks",
		[844] = "Plainstrider Menace",
		[1061] = "The Spirits of Stonetalon",
		[3281] = "Stolen Silver",
		[1358] = "Sample for Helbrim",
		[845] = "The Zhevra",
		[888] = "Stolen Booty",
		[892] = "The Missing Shipment",
		[900] = "Samophlange",
		[365] = "Fields of Grief",
		[863] = "The Escape",
		[5482] = "Doom Weed",
		[840] = "Conscript of the Horde",
		[370] = "At War With The Scarlet Crusade",
		[821] = "Chen's Empty Keg",
		[870] = "The Forgotten Pools",
	},
	["currentGuideName"] = "12-17 The Barrens",
	["stepSkip"] = {
		true, -- [1]
		[122] = true,
		[75] = true,
		[46] = true,
		[54] = true,
		[76] = true,
		[108] = true,
		[124] = true,
		[77] = true,
		[12] = true,
		[55] = true,
		[125] = true,
		[20] = true,
		[110] = true,
		[32] = true,
		[40] = true,
		[64] = true,
		[112] = true,
		[33] = true,
		[97] = true,
		[25] = true,
		[42] = true,
		[115] = true,
		[68] = true,
		[84] = true,
		[116] = true,
		[43] = true,
		[51] = true,
		[129] = true,
		[22] = true,
		[98] = true,
		[85] = true,
		[78] = true,
		[83] = true,
		[47] = true,
		[119] = true,
		[72] = true,
		[126] = true,
		[104] = true,
		[107] = true,
		[73] = true,
		[45] = true,
		[105] = true,
		[121] = true,
		[19] = true,
		[11] = true,
		[109] = true,
	},
	["currentStepId"] = 3993310595,
}
RXPCTrackingData = {
	["profileKeys"] = {
		["Bumboclaat - Shadowstrike (AU)"] = "Bumboclaat - Shadowstrike (AU)",
	},
	["profiles"] = {
		["Bumboclaat - Shadowstrike (AU)"] = {
			["levels"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Tirisfal Glades"] = {
							["xp"] = 286,
							["count"] = 5,
						},
					},
					["timestamp"] = {
						["dateFinished"] = {
							["monthDay"] = 30,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 46,
							["year"] = 2024,
							["hour"] = 22,
							["weekday"] = 3,
						},
						["finished"] = 4714,
						["started"] = 1,
					},
					["quests"] = {
					},
				}, -- [4]
				{
					["groupExperience"] = 0,
					["deaths"] = 2,
					["mobs"] = {
						["Tirisfal Glades"] = {
							["xp"] = 1441,
							["count"] = 24,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 30,
							["day"] = 0,
							["month"] = 1,
							["minute"] = 46,
							["year"] = 2024,
							["hour"] = 22,
							["weekday"] = 3,
						},
						["finished"] = 5524,
						["dateFinished"] = {
							["monthDay"] = 6,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 41,
							["year"] = 2024,
							["hour"] = 21,
							["weekday"] = 3,
						},
						["started"] = 4715,
					},
					["quests"] = {
						["Tirisfal Glades"] = {
							[380] = 360,
							[6395] = 450,
							[3902] = 320,
							[381] = 360,
						},
					},
				}, -- [5]
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Tirisfal Glades"] = {
							["xp"] = 2037,
							["count"] = 29,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 6,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 41,
							["year"] = 2024,
							["hour"] = 21,
							["weekday"] = 3,
						},
						["finished"] = 7637,
						["dateFinished"] = {
							["monthDay"] = 6,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 16,
							["year"] = 2024,
							["hour"] = 22,
							["weekday"] = 3,
						},
						["started"] = 5525,
					},
					["quests"] = {
						["Tirisfal Glades"] = {
							[383] = 340,
							[5651] = 90,
							[382] = 675,
							[8] = 110,
						},
					},
				}, -- [6]
				{
					["groupExperience"] = 0,
					["deaths"] = 2,
					["mobs"] = {
						["Tirisfal Glades"] = {
							["xp"] = 2272,
							["count"] = 32,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 6,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 16,
							["year"] = 2024,
							["hour"] = 22,
							["weekday"] = 3,
						},
						["finished"] = 9355,
						["dateFinished"] = {
							["monthDay"] = 6,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 45,
							["year"] = 2024,
							["hour"] = 22,
							["weekday"] = 3,
						},
						["started"] = 7638,
					},
					["quests"] = {
						["Tirisfal Glades"] = {
							[404] = 410,
							[5650] = 270,
							[427] = 700,
							[365] = 625,
							[5481] = 230,
						},
					},
				}, -- [7]
				{
					["groupExperience"] = 374,
					["deaths"] = 2,
					["mobs"] = {
						["Durotar"] = {
							["xp"] = 407,
							["count"] = 6,
						},
						["Tirisfal Glades"] = {
							["xp"] = 3831,
							["count"] = 39,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 6,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 45,
							["year"] = 2024,
							["hour"] = 22,
							["weekday"] = 3,
						},
						["finished"] = 13471,
						["dateFinished"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 29,
							["year"] = 2024,
							["hour"] = 11,
							["weekday"] = 4,
						},
						["started"] = 9356,
					},
					["quests"] = {
						["Tirisfal Glades"] = {
							[407] = 160,
							[367] = 550,
						},
					},
				}, -- [8]
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Tirisfal Glades"] = {
							["xp"] = 2514,
							["count"] = 23,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 29,
							["year"] = 2024,
							["hour"] = 11,
							["weekday"] = 4,
						},
						["finished"] = 14292,
						["dateFinished"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 43,
							["year"] = 2024,
							["hour"] = 11,
							["weekday"] = 4,
						},
						["started"] = 13472,
					},
					["quests"] = {
						["Tirisfal Glades"] = {
							[368] = 1162,
							[398] = 1275,
							[358] = 1050,
							[5482] = 825,
						},
					},
				}, -- [9]
				{
					["groupExperience"] = 75,
					["deaths"] = 1,
					["mobs"] = {
						["Tirisfal Glades"] = {
							["xp"] = 4435,
							["count"] = 51,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 43,
							["year"] = 2024,
							["hour"] = 11,
							["weekday"] = 4,
						},
						["finished"] = 15907,
						["dateFinished"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 4,
							["year"] = 2024,
							["hour"] = 12,
							["minute"] = 49,
						},
						["started"] = 14293,
					},
					["quests"] = {
						["Tirisfal Glades"] = {
							[362] = 630,
							[354] = 1312,
							[426] = 1312,
						},
					},
				}, -- [10]
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Tirisfal Glades"] = {
							["xp"] = 4373,
							["count"] = 46,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 4,
							["year"] = 2024,
							["hour"] = 12,
							["minute"] = 49,
						},
						["finished"] = 18372,
						["dateFinished"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 4,
							["year"] = 2024,
							["hour"] = 14,
							["minute"] = 20,
						},
						["started"] = 15908,
					},
					["quests"] = {
						["Tirisfal Glades"] = {
							[374] = 937,
							[375] = 1050,
							[355] = 127,
							[370] = 1162,
							[359] = 300,
						},
						["Undercity"] = {
							[405] = 270,
						},
					},
				}, -- [11]
				{
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Tirisfal Glades"] = {
							["xp"] = 5132,
							["count"] = 51,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 4,
							["year"] = 2024,
							["hour"] = 14,
							["minute"] = 20,
						},
						["finished"] = 20042,
						["dateFinished"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 3,
							["year"] = 2024,
							["hour"] = 15,
							["weekday"] = 4,
						},
						["started"] = 18373,
					},
					["quests"] = {
						["Tirisfal Glades"] = {
							[360] = 585,
							[369] = 330,
							[356] = 975,
							[371] = 1275,
							[492] = 1312,
						},
					},
				}, -- [12]
				{
					["groupExperience"] = 6984,
					["deaths"] = 0,
					["mobs"] = {
						["Ragefire Chasm"] = {
							["xp"] = 4322,
							["count"] = 45,
						},
						["Tirisfal Glades"] = {
							["xp"] = 2148,
							["count"] = 25,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 3,
							["year"] = 2024,
							["hour"] = 15,
							["weekday"] = 4,
						},
						["finished"] = 22952,
						["dateFinished"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 4,
							["year"] = 2024,
							["hour"] = 15,
							["minute"] = 50,
						},
						["started"] = 20043,
					},
					["quests"] = {
						["Ragefire Chasm"] = {
							[5722] = 1312,
						},
						["Undercity"] = {
							[357] = 787,
							[79080] = 135,
						},
						["Tirisfal Glades"] = {
							[366] = 525,
							[409] = 1012,
							[372] = 1350,
						},
					},
				}, -- [13]
				{
					["groupExperience"] = 4892,
					["deaths"] = 1,
					["mobs"] = {
						["Ragefire Chasm"] = {
							["xp"] = 4892,
							["count"] = 52,
						},
						["Silverpine Forest"] = {
							["xp"] = 2673,
							["count"] = 22,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 4,
							["year"] = 2024,
							["hour"] = 15,
							["minute"] = 50,
						},
						["finished"] = 25821,
						["dateFinished"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 4,
							["year"] = 2024,
							["hour"] = 22,
							["minute"] = 9,
						},
						["started"] = 22953,
					},
					["quests"] = {
						["Undercity"] = {
							[5725] = 2175,
						},
						["Silverpine Forest"] = {
							[449] = 660,
							[435] = 1312,
							[445] = 937,
						},
					},
				}, -- [14]
				{
					["groupExperience"] = 0,
					["deaths"] = 1,
					["mobs"] = {
						["Silverpine Forest"] = {
							["xp"] = 9891,
							["count"] = 89,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 4,
							["year"] = 2024,
							["hour"] = 22,
							["minute"] = 9,
						},
						["finished"] = 29478,
						["dateFinished"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 4,
							["year"] = 2024,
							["hour"] = 23,
							["minute"] = 10,
						},
						["started"] = 25822,
					},
					["quests"] = {
						["Silverpine Forest"] = {
							[430] = 975,
							[425] = 1012,
							[3221] = 135,
							[421] = 1275,
							[6321] = 315,
							[429] = 660,
						},
					},
				}, -- [15]
				{
					["groupExperience"] = 0,
					["deaths"] = 3,
					["mobs"] = {
						["Silverpine Forest"] = {
							["xp"] = 8044,
							["count"] = 63,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 7,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 4,
							["year"] = 2024,
							["hour"] = 23,
							["minute"] = 10,
						},
						["finished"] = 33347,
						["dateFinished"] = {
							["monthDay"] = 8,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 52,
							["year"] = 2024,
							["hour"] = 12,
							["weekday"] = 5,
						},
						["started"] = 29479,
					},
					["quests"] = {
						["Silverpine Forest"] = {
							[437] = 1462,
							[438] = 1312,
							[477] = 1462,
							[422] = 1312,
							[478] = 1125,
						},
					},
				}, -- [16]
				{
					["groupExperience"] = 0,
					["deaths"] = 2,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 3969,
							["count"] = 29,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 8,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 52,
							["year"] = 2024,
							["hour"] = 12,
							["weekday"] = 5,
						},
						["finished"] = 40417,
						["dateFinished"] = {
							["monthDay"] = 8,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 5,
							["year"] = 2024,
							["hour"] = 22,
							["minute"] = 50,
						},
						["started"] = 33348,
					},
					["quests"] = {
						["Silverpine Forest"] = {
							[482] = 150,
							[423] = 1462,
							[481] = 150,
							[439] = 435,
						},
						["Undercity"] = {
							[1359] = 165,
							[411] = 1350,
							[447] = 1350,
							[6322] = 195,
							[6323] = 375,
						},
						["The Barrens"] = {
							[842] = 1350,
							[850] = 1312,
							[840] = 690,
							[1358] = 1575,
						},
						["Orgrimmar"] = {
							[5761] = 1725,
							[5726] = 1350,
							[5727] = 690,
						},
					},
				}, -- [17]
				{
					["groupExperience"] = 1200,
					["deaths"] = 0,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 7553,
							["count"] = 66,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 8,
							["day"] = 0,
							["month"] = 2,
							["weekday"] = 5,
							["year"] = 2024,
							["hour"] = 22,
							["minute"] = 50,
						},
						["finished"] = 46407,
						["dateFinished"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 37,
							["year"] = 2024,
							["hour"] = 0,
							["weekday"] = 6,
						},
						["started"] = 40418,
					},
					["quests"] = {
						["The Barrens"] = {
							[1492] = 390,
							[870] = 1012,
							[848] = 1575,
							[869] = 1350,
							[855] = 1875,
						},
						["Thunder Bluff"] = {
							[5723] = 1575,
							[5724] = 2175,
							[853] = 1200,
						},
					},
				}, -- [18]
				{
					["groupExperience"] = 326,
					["deaths"] = 0,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 17069,
							["count"] = 124,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 9,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 37,
							["year"] = 2024,
							["hour"] = 0,
							["weekday"] = 6,
						},
						["finished"] = 52925,
						["dateFinished"] = {
							["monthDay"] = 10,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 36,
							["year"] = 2024,
							["hour"] = 15,
							["weekday"] = 7,
						},
						["started"] = 46408,
					},
					["quests"] = {
						["The Barrens"] = {
							[4921] = 1725,
							[877] = 1725,
							[3281] = 2025,
						},
					},
				}, -- [19]
				{
					["groupExperience"] = 1692,
					["deaths"] = 0,
					["mobs"] = {
						["The Barrens"] = {
							["xp"] = 2758,
							["count"] = 11,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 10,
							["day"] = 0,
							["month"] = 2,
							["minute"] = 36,
							["year"] = 2024,
							["hour"] = 15,
							["weekday"] = 7,
						},
						["started"] = 52926,
					},
					["quests"] = {
						["The Barrens"] = {
							[865] = 2025,
							[891] = 2325,
							[880] = 1725,
						},
					},
				}, -- [20]
			},
			["trackedGuid"] = "Player-5818-009F719C",
		},
	},
}
RXPCComms = {
	["profileKeys"] = {
		["Bumboclaat - Shadowstrike (AU)"] = "Bumboclaat - Shadowstrike (AU)",
	},
	["profiles"] = {
		["Bumboclaat - Shadowstrike (AU)"] = {
			["announcements"] = {
				["12-17 The Barrens"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["11-14 Silverpine Forest"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["06-11 Tirisfal Glades"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["01-06 Tirisfal Glades"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
			},
			["players"] = {
				["Belvin"] = {
					["timePlayed"] = 0,
					["class"] = "HUNTER",
					["xp"] = 236,
				},
				["Narberal"] = {
					["timePlayed"] = 0,
					["class"] = "PRIEST",
					["xp"] = 1200,
				},
				["Holydda"] = {
					["timePlayed"] = 260.1549999999115,
					["class"] = "HUNTER",
					["xp"] = 236,
				},
				["Kurtcowbane"] = {
					["timePlayed"] = 40.22100000001956,
					["class"] = "WARRIOR",
					["xp"] = 236,
				},
				["Melvs"] = {
					["class"] = "WARRIOR",
					["lastSeen"] = 187459.955,
					["xpPercentage"] = 59,
					["isRxp"] = true,
					["timePlayed"] = 1451.040999999997,
					["level"] = 13,
				},
				["Deadlyfans"] = {
					["isRxp"] = true,
					["lastSeen"] = 742561.66,
					["xpPercentage"] = 86,
					["level"] = 21,
					["timePlayed"] = 260.1549999999115,
					["class"] = "MAGE",
				},
				["Bergal"] = {
					["timePlayed"] = 0,
					["class"] = "WARRIOR",
					["xp"] = 1200,
				},
				["Bombilini"] = {
					["level"] = 8,
					["lastSeen"] = 173006.103,
					["xpPercentage"] = 38,
					["class"] = "ROGUE",
					["timePlayed"] = 53.93000000002212,
					["isRxp"] = true,
				},
				["Notgenuinely"] = {
					["class"] = "MAGE",
					["lastSeen"] = 189683.662,
					["xpPercentage"] = 50,
					["isRxp"] = true,
					["timePlayed"] = 1451.040999999997,
					["level"] = 15,
				},
				["Beklisau"] = {
					["timePlayed"] = 0,
					["class"] = "WARRIOR",
					["xp"] = 1350,
				},
				["Verakai"] = {
					["timePlayed"] = 1451.040999999997,
					["class"] = "ROGUE",
					["xp"] = 91,
				},
				["Ryuji"] = {
					["timePlayed"] = 34.50599999999395,
					["class"] = "HUNTER",
					["xp"] = 87,
				},
				["Incisions"] = {
					["timePlayed"] = 0,
					["class"] = "ROGUE",
					["xp"] = 1200,
				},
				["Lovemuffin"] = {
					["timePlayed"] = 1451.040999999997,
					["class"] = "MAGE",
					["xp"] = 75,
				},
				["Bigfawti"] = {
					["timePlayed"] = 0,
					["class"] = "WARRIOR",
					["xp"] = 1200,
				},
			},
		},
	},
}
RXPCSettings = nil

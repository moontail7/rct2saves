
Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["scrollback"] = {
		["ChatFrame5"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 1,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:31]|h|r You have been disconnected from Blizzard services.",
					["serverTime"] = 1707836370,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 743719.008,
					["g"] = 1,
					["b"] = 0,
				}, -- [1]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 1,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:31]|h|r You have been disconnected from Blizzard services.",
					["serverTime"] = 1707836370,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 743719.008,
					["g"] = 1,
					["b"] = 0,
				}, -- [1]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 7,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["b"] = 0,
					["r"] = 1,
					["serverTime"] = 1707757572,
					["timestamp"] = 742394.7440000001,
					["g"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [1]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["g"] = 1,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707825941,
					["b"] = 0,
				}, -- [2]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["serverTime"] = 1707835047,
					["r"] = 1,
					["b"] = 0,
					["timestamp"] = 742394.7440000001,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [3]
				{
					["message"] = "0 days, 0 hours, 0 minutes, 0 seconds",
					["timestamp"] = 742394.7440000001,
				}, -- [4]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 742394.7440000001,
				}, -- [5]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 742376.172,
					["g"] = 1,
					["b"] = 0,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:31]|h|r You have been disconnected from Blizzard services.",
					["serverTime"] = 1707836370,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 743719.008,
					["g"] = 1,
					["b"] = 0,
				}, -- [7]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame7"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 1,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:31]|h|r You have been disconnected from Blizzard services.",
					["serverTime"] = 1707836370,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 743719.008,
					["g"] = 1,
					["b"] = 0,
				}, -- [1]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame6"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 1,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:31]|h|r You have been disconnected from Blizzard services.",
					["serverTime"] = 1707836370,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 743719.008,
					["g"] = 1,
					["b"] = 0,
				}, -- [1]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame8"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 1,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:31]|h|r You have been disconnected from Blizzard services.",
					["serverTime"] = 1707836370,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 743719.008,
					["g"] = 1,
					["b"] = 0,
				}, -- [1]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame10"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 1,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:31]|h|r You have been disconnected from Blizzard services.",
					["serverTime"] = 1707836370,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 743719.008,
					["g"] = 1,
					["b"] = 0,
				}, -- [1]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame9"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 1,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:31]|h|r You have been disconnected from Blizzard services.",
					["serverTime"] = 1707836370,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 743719.008,
					["g"] = 1,
					["b"] = 0,
				}, -- [1]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 241,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[19:35:26]|h|r Guild Message of the Day: bryce the guilds new raid leader.....",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["serverTime"] = 1707757572,
					["timestamp"] = 742394.7440000001,
					["g"] = 1,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[19:35:26]|h|r Unknown macro option: assist",
					["b"] = 0,
					["r"] = 1,
					["serverTime"] = 1707757572,
					["timestamp"] = 742394.7440000001,
					["g"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:06:12]|h|r Guild Message of the Day: Gnomer 8pm today, bring lube",
					["g"] = 1,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707825941,
					["b"] = 0.250980406999588,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:06:13]|h|r Unknown macro option: assist",
					["g"] = 1,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707825941,
					["b"] = 0,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:05:43]|h|r Guild Message of the Day: {star} Remember to msg Handsomehank at level 30 for your free welcome packs! {star}",
					["serverTime"] = 1707835047,
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["timestamp"] = 742394.7440000001,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:05:43]|h|r Unknown macro option: assist",
					["serverTime"] = 1707835047,
					["r"] = 1,
					["b"] = 0,
					["timestamp"] = 742394.7440000001,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:06:18]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Parman-Shadowstrike(AU):20325:GUILD|h|cffd84e4e26|r:|cff0070ddParman|r|h|cffd8d8d8]|r: anyone know how to peel a good orange",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707825976,
					["extraData"] = {
						5, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:06:26]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Gnarw-Shadowstrike(AU):20328:CHANNEL:1|h|cffc69b6dGnarw|r|h|cffd8d8d8]|r: LF2M RFD. DPS and Heal",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707825984,
					["extraData"] = {
						70, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:06:42]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Syviax:20338:CHANNEL:1|h|cffffffffSyviax|r|h|cffd8d8d8]|r: priest LFG RFK",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707826000,
					["extraData"] = {
						70, -- [1]
						3, -- [2]
						6, -- [3]
						["n"] = 3,
					},
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:06:49]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Fallenhanzo-Shadowstrike(AU):20341:GUILD|h|cff8b8b8b13|r:|cffaad372Fallenhanzo|r|h|cffd8d8d8]|r: step 1",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707826007,
					["extraData"] = {
						5, -- [1]
						1, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:06:49]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Syviax-Shadowstrike(AU):20342:CHANNEL:1|h|cffffffffSyviax|r|h|cffd8d8d8]|r: or LFM",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707826007,
					["extraData"] = {
						70, -- [1]
						3, -- [2]
						6, -- [3]
						["n"] = 3,
					},
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:06:52]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Fallenhanzo-Shadowstrike(AU):20344:GUILD|h|cff8b8b8b13|r:|cffaad372Fallenhanzo|r|h|cffd8d8d8]|r: find a chainsaw",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707826010,
					["extraData"] = {
						5, -- [1]
						1, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:06:56]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Parman-Shadowstrike(AU):20346:GUILD|h|cffd84e4e26|r:|cff0070ddParman|r|h|cffd8d8d8]|r: JUST PEEL THE DAMN ORANGE",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707826014,
					["extraData"] = {
						5, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:06:59]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq8|k:67:0:BN_WHISPER:|Kq8|k:cbo#11390|h|A:UI-ChatIcon-WoW:0:0:0:0|a|cff3fc6ea|Kq8|k|r|h|cffd8d8d8]|r: i tank stuff for u as rogue",
					["b"] = 0.9647059440612793,
					["r"] = 0,
					["g"] = 1,
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707826017,
					["extraData"] = {
						53, -- [1]
						9, -- [2]
						10, -- [3]
						["n"] = 3,
					},
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:07:01]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq8|k:67:0:BN_WHISPER:|Kq8|k:cbo#11390|h|A:UI-ChatIcon-WoW:0:0:0:0|a|cff3fc6ea|Kq8|k|r|h|cffd8d8d8]|r: if u need",
					["b"] = 0.9647059440612793,
					["r"] = 0,
					["g"] = 1,
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707826019,
					["extraData"] = {
						53, -- [1]
						9, -- [2]
						10, -- [3]
						["n"] = 3,
					},
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:07:12]|h|r |Hchannel:channel:1|h[1] |h Left Channel: |Hchannel:CHANNEL:1|h[1. General - The Barrens]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707826030,
					["extraData"] = {
						70, -- [1]
						3, -- [2]
						11, -- [3]
						["n"] = 3,
					},
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:07:12]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - The Barrens]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707826030,
					["extraData"] = {
						72, -- [1]
						13, -- [2]
						14, -- [3]
						["n"] = 3,
					},
				}, -- [17]
				{
					["message"] = "0 days, 2 hours, 30 minutes, 17 seconds",
					["timestamp"] = 742394.7440000001,
				}, -- [18]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 742394.7440000001,
				}, -- [19]
				{
					["message"] = "|cFFFF1C1C Loaded: LFG Bulletin Board 3.12 by Vyscî-Whitemane",
					["timestamp"] = 742376.172,
				}, -- [20]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Dominos Detected, please make sure Dominos Elements are disabled in MoveAny!",
					["timestamp"] = 742376.172,
				}, -- [21]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Click the MoveAny Minimap Button to open the settings.",
					["timestamp"] = 742376.172,
				}, -- [22]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Or tap /move or /moveany in chat to open the settings.",
					["timestamp"] = 742376.172,
				}, -- [23]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 To hide these messages deactivate tips in the MoveAny menu.",
					["timestamp"] = 742376.172,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:19]|h|r Error parsing guide 12-17 The Barrens: Invalid function call (.isQuestTurnIn)\n.isQuestTurnIn 858",
					["timestamp"] = 742376.172,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:20]|h|r Error parsing guide Twisted Fate - 10 (The Barrens): Invalid coordinates or map name\n.goto The Barrent,50.7,32.8 << Undead",
					["timestamp"] = 742376.172,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:25]|h|r |cFF00FFB0WeaponSwingTimer: |rThank you for installing WeaponSwingTimer Version 7.2.3 by WatchYourSixx! Use |cFFFFC300/wst|r for more options.",
					["timestamp"] = 742376.172,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:27]|h|r Guild Message of the Day: {star} Remember to msg Handsomehank at level 30 for your free welcome packs! {star}",
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 742394.6290000001,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:27]|h|r Unknown macro option: assist",
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 742394.7440000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:27]|h|r |cffffff99<aux> loaded - /aux",
					["timestamp"] = 742394.7440000001,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:27]|h|r RestedXP Guides: Targeting macro updated with (Gazrog)",
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707835047,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:27]|h|r RestedXP Guides: Targeting macro updated with (Sergra Darkthorn)",
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707835047,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:27]|h|r RestedXP Guides: Targeting macro updated with (Tonga Runetotem)",
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707835047,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:27]|h|r RestedXP Guides: Targeting macro updated with (Mankrika)",
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707835047,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:27]|h|r RestedXP Guides: Targeting macro updated with (Omusa Thunderhorn)",
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707835047,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:27]|h|r |c00FFAA00ThreatClassic2 v2.50 - Type /tc2 for options.|r",
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707835047,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:27]|h|r |cffe6cc80 [Whoa Thick Frames |cFF0070FFClassic|r |cffe6cc80v1.5d ] |cffffffffis now loaded. Use |cffffff00'/whoaf' |cffffffffto view options.",
					["timestamp"] = 742394.7440000001,
					["serverTime"] = 1707835047,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:29]|h|r |cFFffff00[Questie]|r |cFF6ce314The 'Lunar Festival' world event is active!",
					["timestamp"] = 742397.181,
					["serverTime"] = 1707835049,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:29]|h|r |cFFffff00[Questie]|r |cFF6ce314The 'Love is in the Air' world event is active!",
					["timestamp"] = 742397.181,
					["serverTime"] = 1707835049,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:29]|h|r |cFFffff00[Questie]|r |cFF6ce314The 'Darkmoon Faire' world event is active!",
					["timestamp"] = 742397.181,
					["serverTime"] = 1707835049,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:31]|h|r RestedXP Guides: TomTom has known incompatibilities with the Waypoint Arrow. Disable it if you're experiencing navigation issues.",
					["timestamp"] = 742398.746,
					["serverTime"] = 1707835051,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:31]|h|r RestedXP Guides: TotemTimers has known incompatibilities with the Waypoint Arrow. Disable it if you're experiencing navigation issues.",
					["timestamp"] = 742398.746,
					["serverTime"] = 1707835051,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:32]|h|r |cffd8d8d8[|r|Hplayer:Belvin:24166|h|cffd8d83f22|r:|cffaad372Belvin|r|h|cffd8d8d8]|r: Level 22 Tauren Hunter - Orgrimmar",
					["serverTime"] = 1707835052,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742399.9720000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:32]|h|r 1 |4player:players; total",
					["serverTime"] = 1707835052,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742399.9720000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:34]|h|r [W To] |cffd8d8d8[|r|Hplayer:Belvin-Shadowstrike(AU):24168:WHISPER:BELVIN-SHADOWSTRIKE(AU)|h|cffd8d83f22|r:|cffaad372Belvin|r|h|cffd8d8d8]|r: inv",
					["serverTime"] = 1707835054,
					["r"] = 1,
					["extraData"] = {
						10, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742402.381,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:37]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|h|HNWBCustomLink:timers|hYou are on a layered realm.|h|h",
					["timestamp"] = 742404.747,
					["serverTime"] = 1707835057,
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:37]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|h|HNWBCustomLink:timers|hClick here to view current timers.|h|h",
					["timestamp"] = 742404.747,
					["serverTime"] = 1707835057,
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:42]|h|r |cffd8d8d8[|r|Hplayer:Belvin:24170|h|cffd8d83f22|r:|cffaad372Belvin|r|h|cffd8d8d8]|r has invited you to join a group.",
					["serverTime"] = 1707835062,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742409.794,
					["g"] = 1,
					["b"] = 0,
				}, -- [48]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:43]|h|r Dungeon difficulty set to Normal",
					["serverTime"] = 1707835063,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742410.765,
					["g"] = 1,
					["b"] = 0,
				}, -- [49]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:47]|h|r You receive item: |cffffffff|Hitem:118::::::::20:::::::::|h[Minor Healing Potion]|h|rx5.",
					["serverTime"] = 1707835067,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742415.3030000001,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [50]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:37:47]|h|r You receive item: |cffffffff|Hitem:118::::::::20:::::::::|h[Minor Healing Potion]|h|r.",
					["serverTime"] = 1707835067,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742415.3910000001,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [51]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:38:21]|h|r false",
					["timestamp"] = 742448.712,
					["serverTime"] = 1707835101,
				}, -- [52]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:39:53]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Bumboclaat-Shadowstrike(AU):24192:PARTY|h|cffd8d83f20|r:|cffffffffBumboclaat|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t RestedXP Guides: Flying to 25 ETA 1 minute 9 seconds",
					["serverTime"] = 1707835193,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742541.103,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [53]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:40:07]|h|r Deadlyfans joins the party.",
					["serverTime"] = 1707835207,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742555.285,
					["g"] = 1,
					["b"] = 0,
				}, -- [54]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:40:24]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Belvin-Shadowstrike(AU):24197:PARTY|h|cffd8d83f22|r:|cffaad372Belvin|r|h|cffd8d8d8]|r: omw :D",
					["serverTime"] = 1707835224,
					["r"] = 0.4627451300621033,
					["extraData"] = {
						50, -- [1]
						7, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742572.037,
					["g"] = 0.7843137979507446,
					["b"] = 1,
				}, -- [55]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:40:44]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holydda-Shadowstrike(AU):24204:PARTY|h|cffd84e4e26|r:|cffaad372Holydda|r|h|cffd8d8d8]|r: gogo bros",
					["serverTime"] = 1707835243,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						7, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742592.61,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [56]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:41:07]|h|r [W To] |cffd8d8d8[|r|Hplayer:Deadlyfans-Shadowstrike(AU):24207:WHISPER:DEADLYFANS-SHADOWSTRIKE(AU)|h|cffd8d83f21|r:|cff3fc6eaDeadlyfans|r|h|cffd8d8d8]|r: r u heals LOL",
					["serverTime"] = 1707835266,
					["r"] = 1,
					["extraData"] = {
						10, -- [1]
						11, -- [2]
						12, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742615.6460000001,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [57]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:41:12]|h|r [W From] |cffd8d8d8[|r|Hplayer:Deadlyfans-Shadowstrike(AU):24209:WHISPER:DEADLYFANS-SHADOWSTRIKE(AU)|h|cffd8d83f21|r:|cff3fc6eaDeadlyfans|r|h|cffd8d8d8]|r: nah haha",
					["serverTime"] = 1707835271,
					["r"] = 1,
					["extraData"] = {
						0, -- [1]
						11, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742620.534,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [58]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:41:48]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Crabman:24215:CHANNEL:1|h|cff8787edCrabman|r|h|cffd8d8d8]|r: so long gay barrens",
					["serverTime"] = 1707835307,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742656.015,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [59]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:41:51]|h|r You have learned a new spell: Mind Flay (Rank 1).",
					["serverTime"] = 1707835310,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742658.969,
					["g"] = 1,
					["b"] = 0,
				}, -- [60]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:42:01]|h|r [W To] |cffd8d8d8[|r|Hplayer:Deadlyfans-Shadowstrike(AU):24221:WHISPER:DEADLYFANS-SHADOWSTRIKE(AU)|h|cffd8d83f21|r:|cff3fc6eaDeadlyfans|r|h|cffd8d8d8]|r: ok ok i heal",
					["serverTime"] = 1707835320,
					["r"] = 1,
					["extraData"] = {
						10, -- [1]
						11, -- [2]
						12, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742669.3200000001,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [61]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:42:07]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Milkmen-Shadowstrike(AU):24223:CHANNEL:1|h|cffff7c0aMilkmen|r|h|cffd8d8d8]|r: im not your friend guy",
					["serverTime"] = 1707835326,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742674.846,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [62]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:42:24]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Madladd-Shadowstrike(AU):24230:CHANNEL:1|h|cfffff468Madladd|r|h|cffd8d8d8]|r: what's so gay about it?",
					["serverTime"] = 1707835343,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						19, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742691.829,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [63]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:42:39]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Ashbringer-Shadowstrike(AU):24239:CHANNEL:1|h|cffc69b6dAshbringer|r|h|cffd8d8d8]|r: LFM FOR RFD NEED TANK/HEALER/DPS",
					["serverTime"] = 1707835358,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						21, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742706.949,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [64]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:42:40]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Ashbringer-Shadowstrike(AU):24240:CHANNEL:3|h|cffc69b6dAshbringer|r|h|cffd8d8d8]|r: LFM FOR RFD NEED TANK/HEALER/DPS",
					["serverTime"] = 1707835359,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						23, -- [2]
						24, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742707.836,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [65]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:42:42]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Cheskii-Shadowstrike(AU):24243:CHANNEL:1|h|cff0070ddCheskii|r|h|cffd8d8d8]|r: in the distance, \"I'm not your guy, friend\"",
					["serverTime"] = 1707835361,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						26, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742709.72,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [66]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:42:51]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Crabman-Shadowstrike(AU):24246:CHANNEL:1|h|cff8787edCrabman|r|h|cffd8d8d8]|r: you're dad",
					["serverTime"] = 1707835370,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742719.484,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [67]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:43:07]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Milkmen-Shadowstrike(AU):24249:CHANNEL:1|h|cffff7c0aMilkmen|r|h|cffd8d8d8]|r: im not your friend buddy",
					["serverTime"] = 1707835386,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742734.946,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [68]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:43:11]|h|r |cffaad372Holydda|r receives loot: |cff9d9d9d|Hitem:5124::::::::20:::::::::|h[Small Raptor Tooth]|h|r.",
					["serverTime"] = 1707835390,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742739.184,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [69]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:43:12]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Ashbringer-Shadowstrike(AU):24252:CHANNEL:3|h|cffc69b6dAshbringer|r|h|cffd8d8d8]|r: LFM FOR RAZORFEN DOWNS TANK/HEALER/DPS",
					["serverTime"] = 1707835391,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						23, -- [2]
						24, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742739.757,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [70]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:43:13]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Ashbringer-Shadowstrike(AU):24253:CHANNEL:1|h|cffc69b6dAshbringer|r|h|cffd8d8d8]|r: LFM FOR RAZORFEN DOWNS TANK/HEALER/DPS",
					["serverTime"] = 1707835392,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						21, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742740.758,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [71]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:43:16]|h|r |cffaad372Holydda|r receives loot: |cffffffff|Hitem:783::::::::20:::::::::|h[Light Hide]|h|r.",
					["serverTime"] = 1707835395,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742743.764,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [72]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:43:33]|h|r |cffaad372Holydda|r receives loot: |cff9d9d9d|Hitem:5124::::::::20:::::::::|h[Small Raptor Tooth]|h|r.",
					["serverTime"] = 1707835412,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742761.149,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [73]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:43:34]|h|r |cffaad372Holydda|r receives loot: |cff1eff00|Hitem:1206::::::::20:::::::::|h[Moss Agate]|h|r.",
					["serverTime"] = 1707835413,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742762.148,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [74]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:43:51]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Ashbringer-Shadowstrike(AU):24262:CHANNEL:1|h|cffc69b6dAshbringer|r|h|cffd8d8d8]|r: LF TANK/HEALER FOR RAZORFEN DOWNS",
					["serverTime"] = 1707835430,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						21, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742778.709,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [75]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:43:53]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Ashbringer-Shadowstrike(AU):24263:CHANNEL:3|h|cffc69b6dAshbringer|r|h|cffd8d8d8]|r: LF TANK/HEALER FOR RAZORFEN DOWNS",
					["serverTime"] = 1707835432,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						23, -- [2]
						24, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742781.278,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [76]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:44:05]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Chargrilled:24269:CHANNEL:1|h|cffc69b6dChargrilled|r|h|cffd8d8d8]|r: is there maintenance tonight",
					["serverTime"] = 1707835444,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742792.735,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [77]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:44:14]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Ashbringer-Shadowstrike(AU):24272:CHANNEL:1|h|cffc69b6dAshbringer|r|h|cffd8d8d8]|r: LF TANK/HEALER FOR RAZORFEN DOWNS",
					["serverTime"] = 1707835453,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						21, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742802.275,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [78]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:44:15]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Ashbringer-Shadowstrike(AU):24273:CHANNEL:3|h|cffc69b6dAshbringer|r|h|cffd8d8d8]|r: LF TANK/HEALER FOR RAZORFEN DOWNS",
					["serverTime"] = 1707835454,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						23, -- [2]
						24, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742802.985,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [79]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:44:20]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Ratjack-Shadowstrike(AU):24275:CHANNEL:1|h|cfffff468Ratjack|r|h|cffd8d8d8]|r: wait 2 minutes and find out ya spaz",
					["serverTime"] = 1707835459,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742807.773,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [80]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:44:21]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Deadlyfans-Shadowstrike(AU):24276:PARTY|h|cffd8d83f21|r:|cff3fc6eaDeadlyfans|r|h|cffd8d8d8]|r: do you have quest that can be share?",
					["serverTime"] = 1707835460,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						7, -- [2]
						32, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742808.97,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [81]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:44:25]|h|r Your skill in Wands has increased to 95.",
					["serverTime"] = 1707835464,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						33, -- [2]
						34, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742812.983,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [82]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:44:31]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Bubbs:24282:CHANNEL:1|h|cffffffffBubbs|r|h|cffd8d8d8]|r: lol",
					["serverTime"] = 1707835470,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						35, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742818.841,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [83]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:44:31]|h|r [SERVER] Shutdown in 15:00",
					["serverTime"] = 1707835470,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742819.582,
					["g"] = 1,
					["b"] = 0,
				}, -- [84]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:44:37]|h|r You loot 14 Copper",
					["serverTime"] = 1707835476,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742824.997,
					["g"] = 1,
					["b"] = 0,
				}, -- [85]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:44:39]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Ratjack-Shadowstrike(AU):24286:CHANNEL:1|h|cfffff468Ratjack|r|h|cffd8d8d8]|r: there ya go",
					["serverTime"] = 1707835478,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742826.84,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [86]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:44:40]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Deadlyfans-Shadowstrike(AU):24287:PARTY|h|cffd8d83f21|r:|cff3fc6eaDeadlyfans|r|h|cffd8d8d8]|r: ay",
					["serverTime"] = 1707835479,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						7, -- [2]
						32, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742828.6020000001,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [87]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:44:42]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Belvin-Shadowstrike(AU):24288:PARTY|h|cffd8d83f22|r:|cffaad372Belvin|r|h|cffd8d8d8]|r: oh shoot",
					["serverTime"] = 1707835481,
					["r"] = 0.4627451300621033,
					["extraData"] = {
						50, -- [1]
						7, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742830.581,
					["g"] = 0.7843137979507446,
					["b"] = 1,
				}, -- [88]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:44:57]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holydda-Shadowstrike(AU):24290:PARTY|h|cffd84e4e26|r:|cffaad372Holydda|r|h|cffd8d8d8]|r: maybe  for 15mins...",
					["serverTime"] = 1707835497,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						7, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742845.422,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [89]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:44:59]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Deadlyfans-Shadowstrike(AU):24291:PARTY|h|cffd8d83f21|r:|cff3fc6eaDeadlyfans|r|h|cffd8d8d8]|r: its so hard to get wc group",
					["serverTime"] = 1707835499,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						7, -- [2]
						32, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742846.845,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [90]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:45:03]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Chargrilled-Shadowstrike(AU):24293:CHANNEL:1|h|cffc69b6dChargrilled|r|h|cffd8d8d8]|r: N",
					["serverTime"] = 1707835503,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742851.424,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [91]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:45:07]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Belvin-Shadowstrike(AU):24294:PARTY|h|cffd8d83f22|r:|cffaad372Belvin|r|h|cffd8d8d8]|r: my bad all",
					["serverTime"] = 1707835507,
					["r"] = 0.4627451300621033,
					["extraData"] = {
						50, -- [1]
						7, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742855.198,
					["g"] = 0.7843137979507446,
					["b"] = 1,
				}, -- [92]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:45:11]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Ratjack-Shadowstrike(AU):24295:CHANNEL:1|h|cfffff468Ratjack|r|h|cffd8d8d8]|r: I",
					["serverTime"] = 1707835511,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742859.042,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [93]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:45:11]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Bumboclaat-Shadowstrike(AU):24296:PARTY|h|cffd8d83f20|r:|cffffffffBumboclaat|r|h|cffd8d8d8]|r: its okay |cffaad372belvin|r",
					["serverTime"] = 1707835511,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742859.042,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [94]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:45:17]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holydda-Shadowstrike(AU):24297:PARTY|h|cffd84e4e26|r:|cffaad372Holydda|r|h|cffd8d8d8]|r: if",
					["serverTime"] = 1707835517,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						7, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742865.218,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [95]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:45:21]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Chargrilled-Shadowstrike(AU):24298:CHANNEL:1|h|cffc69b6dChargrilled|r|h|cffd8d8d8]|r: C",
					["serverTime"] = 1707835521,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742869.442,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [96]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:45:23]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Chargrilled-Shadowstrike(AU):24300:CHANNEL:1|h|cffc69b6dChargrilled|r|h|cffd8d8d8]|r: E",
					["serverTime"] = 1707835523,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742870.79,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [97]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:45:23]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holydda-Shadowstrike(AU):24301:PARTY|h|cffd84e4e26|r:|cffaad372Holydda|r|h|cffd8d8d8]|r: later maybe",
					["serverTime"] = 1707835523,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						7, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742871.2270000001,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [98]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:45:25]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Chargrilled-Shadowstrike(AU):24302:CHANNEL:1|h|cffc69b6dChargrilled|r|h|cffd8d8d8]|r: UPDATE CUNT",
					["serverTime"] = 1707835525,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742873.169,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [99]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:45:31]|h|r [SERVER] Shutdown in 14:00",
					["serverTime"] = 1707835531,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742879.579,
					["g"] = 1,
					["b"] = 0,
				}, -- [100]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:45:33]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holydda-Shadowstrike(AU):24305:PARTY|h|cffd84e4e26|r:|cffaad372Holydda|r|h|cffd8d8d8]|r: |cffaad372belvin|r u can call later",
					["serverTime"] = 1707835533,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						7, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742881.36,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [101]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:45:40]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Belvin-Shadowstrike(AU):24309:PARTY|h|cffd8d83f22|r:|cffaad372Belvin|r|h|cffd8d8d8]|r: ok np",
					["serverTime"] = 1707835540,
					["r"] = 0.4627451300621033,
					["extraData"] = {
						50, -- [1]
						7, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742887.818,
					["g"] = 0.7843137979507446,
					["b"] = 1,
				}, -- [102]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:45:42]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Chargrilled-Shadowstrike(AU):24311:CHANNEL:1|h|cffc69b6dChargrilled|r|h|cffd8d8d8]|r: legit well time",
					["serverTime"] = 1707835542,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742890.1630000001,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [103]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:45:42]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Questionmark-Shadowstrike(AU):24312:CHANNEL:1|h|cff0070ddQuestionmark|r|h|cffd8d8d8]|r: druids still too op",
					["serverTime"] = 1707835542,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						39, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742890.1630000001,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [104]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:45:47]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Questionmark-Shadowstrike(AU):24313:CHANNEL:1|h|cff0070ddQuestionmark|r|h|cffd8d8d8]|r: hunter nerfs inc",
					["serverTime"] = 1707835547,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						39, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742895.603,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [105]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:46:04]|h|r |cffaad372Holydda|r receives loot: |cff1eff00|Hitem:818::::::::20:::::::::|h[Tigerseye]|h|r.",
					["serverTime"] = 1707835564,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742912.658,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [106]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:46:23]|h|r |cffc69b6dKurtcowbane|r receives loot: |cff1eff00|Hitem:208778::::::::20:::::::::|h[Rune of Quick Strike]|h|r.",
					["serverTime"] = 1707835583,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742930.998,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [107]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:46:23]|h|r |cffc69b6dKurtcowbane|r receives loot: |cffffffff|Hitem:6361::::::::20:::::::::|h[Raw Rainbow Fin Albacore]|h|rx2.",
					["serverTime"] = 1707835583,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742931.0040000001,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [108]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:46:31]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Deadlyfans-Shadowstrike(AU):24322:PARTY|h|cffd8d83f21|r:|cff3fc6eaDeadlyfans|r|h|cffd8d8d8]|r: are you guys keen for wc after reset?",
					["serverTime"] = 1707835590,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						7, -- [2]
						32, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742939.341,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [109]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:46:31]|h|r [SERVER] Shutdown in 13:00",
					["serverTime"] = 1707835590,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742939.617,
					["g"] = 1,
					["b"] = 0,
				}, -- [110]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:46:40]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Belvin-Shadowstrike(AU):24324:PARTY|h|cffd8d83f22|r:|cffaad372Belvin|r|h|cffd8d8d8]|r: ye",
					["serverTime"] = 1707835599,
					["r"] = 0.4627451300621033,
					["extraData"] = {
						50, -- [1]
						7, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742948.59,
					["g"] = 0.7843137979507446,
					["b"] = 1,
				}, -- [111]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:46:44]|h|r |cff3fc6eaDeadlyfans|r receives loot: |cffffffff|Hitem:10940::::::::20:::::::::|h[Strange Dust]|h|rx3.",
					["serverTime"] = 1707835603,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742952.368,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [112]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:46:59]|h|r |cff3fc6eaDeadlyfans|r receives loot: |cffffffff|Hitem:22239::::::::20:::::::::|h[Sweet Surprise]|h|r.",
					["serverTime"] = 1707835618,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742967.409,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [113]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:46:59]|h|r |cff3fc6eaDeadlyfans|r receives loot: |cffffffff|Hitem:22238::::::::20:::::::::|h[Very Berry Cream]|h|rx2.",
					["serverTime"] = 1707835618,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742967.509,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [114]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:47:00]|h|r |cff3fc6eaDeadlyfans|r receives loot: |cffffffff|Hitem:21830::::::::20:::::::::|h[Empty Wrapper]|h|r.",
					["serverTime"] = 1707835619,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742967.729,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [115]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:47:00]|h|r |cff3fc6eaDeadlyfans|r receives loot: |cffffffff|Hitem:22237::::::::20:::::::::|h[Dark Desire]|h|rx2.",
					["serverTime"] = 1707835619,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742967.729,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [116]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:47:06]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holydda-Shadowstrike(AU):24334:PARTY|h|cffd84e4e26|r:|cffaad372Holydda|r|h|cffd8d8d8]|r: i will go on",
					["serverTime"] = 1707835625,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						7, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742973.939,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [117]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:47:11]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Belvin-Shadowstrike(AU):24335:PARTY|h|cffd8d83f22|r:|cffaad372Belvin|r|h|cffd8d8d8]|r: im gunna start walking to thousand needles and run after reset",
					["serverTime"] = 1707835630,
					["r"] = 0.4627451300621033,
					["extraData"] = {
						50, -- [1]
						7, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742978.846,
					["g"] = 0.7843137979507446,
					["b"] = 1,
				}, -- [118]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:47:18]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Baltod-Shadowstrike(AU):24338:CHANNEL:1|h|cffaad372Baltod|r|h|cffd8d8d8]|r: illcherish this melee hunter moment",
					["serverTime"] = 1707835637,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						41, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742986.147,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [119]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:47:23]|h|r |cffc69b6dKurtcowbane|r is now the group leader.",
					["serverTime"] = 1707835642,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742991.444,
					["g"] = 1,
					["b"] = 0,
				}, -- [120]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:47:32]|h|r [SERVER] Shutdown in 12:00",
					["serverTime"] = 1707835651,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 742999.738,
					["g"] = 1,
					["b"] = 0,
				}, -- [121]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:47:46]|h|r |cffaad372Holydda|r receives loot: |cffffffff|Hitem:6470::::::::20:::::::::|h[Deviate Scale]|h|r.",
					["serverTime"] = 1707835665,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743014.057,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [122]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:47:47]|h|r |cffaad372Holydda|r receives loot: |cff1eff00|Hitem:3305::::::::20:::::::::|h[Brackwater Leggings]|h|r.",
					["serverTime"] = 1707835666,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743014.993,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [123]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:47:52]|h|r |cffaad372Holydda|r receives loot: |cffffffff|Hitem:2318::::::::20:::::::::|h[Light Leather]|h|rx2.",
					["serverTime"] = 1707835671,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743020.001,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [124]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:47:58]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Shroom:24347:CHANNEL:1|h|cffc69b6dShroom|r|h|cffd8d8d8]|r: apparently they are making shaman runes abit harder to get because they were too easy and quick",
					["serverTime"] = 1707835677,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						43, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743026.025,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [125]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:01]|h|r You receive loot: |cffffffff|Hitem:5098::::::::20:::::::::|h[Altered Snapjaw Shell]|h|r.",
					["serverTime"] = 1707835680,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743029.296,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [126]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:05]|h|r You receive loot: |cffffffff|Hitem:2318::::::::20:::::::::|h[Light Leather]|h|rx2.",
					["serverTime"] = 1707835684,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743033.017,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [127]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:12]|h|r |cffaad372Belvin|r leaves the party.",
					["serverTime"] = 1707835691,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743040.204,
					["g"] = 1,
					["b"] = 0,
				}, -- [128]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:12]|h|r Interface action failed because of an AddOn",
					["serverTime"] = 1707835691,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 743040.204,
					["g"] = 1,
					["b"] = 0,
				}, -- [129]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:13]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holydda-Shadowstrike(AU):24355:PARTY|h|cffd84e4e26|r:|cffaad372Holydda|r|h|cffd8d8d8]|r: so hard foe wc",
					["serverTime"] = 1707835692,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						7, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743041.322,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [130]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:15]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Rainofarroz:24356:CHANNEL:1|h|cffaad372Rainofarroz|r|h|cffd8d8d8]|r: guess i should do my shaman runes asap",
					["serverTime"] = 1707835694,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						45, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743043.274,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [131]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:17]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Questionmark-Shadowstrike(AU):24357:CHANNEL:1|h|cff0070ddQuestionmark|r|h|cffd8d8d8]|r: better nerf hunters",
					["serverTime"] = 1707835696,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						39, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743045.253,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [132]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:18]|h|r Your skill in Defense has increased to 93.",
					["serverTime"] = 1707835697,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						33, -- [2]
						34, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743046.21,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [133]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:23]|h|r You receive loot: |cffffffff|Hitem:5523::::::::20:::::::::|h[Small Barnacled Clam]|h|r.",
					["serverTime"] = 1707835702,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743050.797,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [134]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:23]|h|r You receive loot: |cffffffff|Hitem:5098::::::::20:::::::::|h[Altered Snapjaw Shell]|h|r.",
					["serverTime"] = 1707835702,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743050.797,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [135]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:23]|h|r You receive loot: |cffffffff|Hitem:6361::::::::20:::::::::|h[Raw Rainbow Fin Albacore]|h|r.",
					["serverTime"] = 1707835702,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743050.9,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [136]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:25]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Holydda-Shadowstrike(AU):24365:PARTY|h|cffd84e4e26|r:|cffaad372Holydda|r|h|cffd8d8d8]|r: for wc *",
					["serverTime"] = 1707835704,
					["r"] = 0.6666666865348816,
					["extraData"] = {
						3, -- [1]
						7, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743052.807,
					["g"] = 0.6666666865348816,
					["b"] = 1,
				}, -- [137]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:25]|h|r You receive loot: |cffffffff|Hitem:2318::::::::20:::::::::|h[Light Leather]|h|r.",
					["serverTime"] = 1707835704,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743053.647,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [138]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:32]|h|r [SERVER] Shutdown in 11:00",
					["serverTime"] = 1707835711,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743059.805,
					["g"] = 1,
					["b"] = 0,
				}, -- [139]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:40]|h|r Your skill in Wands has increased to 96.",
					["serverTime"] = 1707835719,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						33, -- [2]
						34, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743068.407,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [140]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:41]|h|r You receive loot: |cffffffff|Hitem:5098::::::::20:::::::::|h[Altered Snapjaw Shell]|h|r.",
					["serverTime"] = 1707835720,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743069.112,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [141]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:43]|h|r |TInterface\\FriendsFrame\\UI-Toast-ToastIcons.tga:16:16:0:0:128:64:2:29:34:61|t|HBNplayer:|Kq56|k:110:24373:BN_INLINE_TOAST_ALERT:0|h[|Kq56|k]|h has gone offline.",
					["serverTime"] = 1707835722,
					["r"] = 0.5098039507865906,
					["extraData"] = {
						54, -- [1]
						47, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743071.351,
					["g"] = 0.7725490927696228,
					["b"] = 1,
				}, -- [142]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:46]|h|r You receive loot: |cffffffff|Hitem:2934::::::::20:::::::::|h[Ruined Leather Scraps]|h|r.",
					["serverTime"] = 1707835725,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743074.314,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [143]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:51]|h|r |cffaad372Holydda|r receives loot: |cff9d9d9d|Hitem:3180::::::::20:::::::::|h[Flecked Raptor Scale]|h|r.",
					["serverTime"] = 1707835730,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743078.708,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [144]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:52]|h|r |cffaad372Holydda|r receives loot: |cff1eff00|Hitem:15306::::::18:1171336832:20:::::::::|h[Feral Bindings of Agility]|h|r.",
					["serverTime"] = 1707835731,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743080.339,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [145]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:57]|h|r |cffaad372Holydda|r receives loot: |cffffffff|Hitem:2318::::::::20:::::::::|h[Light Leather]|h|rx2.",
					["serverTime"] = 1707835736,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743084.893,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [146]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:58]|h|r |HlootHistory:30|h[Loot]|h: |cff1eff00|Hitem:211332::::::::20:::::::::|h[Waylaid Supplies: Heavy Linen Bandages]|h|r",
					["serverTime"] = 1707835737,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743086.343,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [147]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:59]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Rainofarroz-Shadowstrike(AU):24381:CHANNEL:1|h|cffaad372Rainofarroz|r|h|cffd8d8d8]|r: one of the shaman runes bugged and i cratered twice",
					["serverTime"] = 1707835738,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						45, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743087.365,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [148]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:48:59]|h|r You loot 20 Copper",
					["serverTime"] = 1707835738,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743087.459,
					["g"] = 1,
					["b"] = 0,
				}, -- [149]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:49:00]|h|r |cffc69b6dKurtcowbane|r leaves the party.",
					["serverTime"] = 1707835739,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743087.809,
					["g"] = 1,
					["b"] = 0,
				}, -- [150]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:49:00]|h|r |cffaad372Holydda|r is now the group leader.",
					["serverTime"] = 1707835739,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743087.878,
					["g"] = 1,
					["b"] = 0,
				}, -- [151]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:49:11]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Rainofarroz-Shadowstrike(AU):24385:CHANNEL:1|h|cffaad372Rainofarroz|r|h|cffd8d8d8]|r: so maybe they should fix that",
					["serverTime"] = 1707835750,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						14, -- [2]
						45, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743098.677,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [152]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:49:19]|h|r |HlootHistory:30|h[Loot]|h: You have selected Greed for: |cff1eff00|Hitem:211332::::::::20:::::::::|h[Waylaid Supplies: Heavy Linen Bandages]|h|r",
					["serverTime"] = 1707835758,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743107.402,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [153]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:49:19]|h|r |HlootHistory:30|h[Loot]|h: Greed Roll - 80 for |cff1eff00|Hitem:211332::::::::20:::::::::|h[Waylaid Supplies: Heavy Linen Bandages]|h|r by |cff00ff00Bumboclaat|r",
					["serverTime"] = 1707835758,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743107.402,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [154]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:49:19]|h|r |HlootHistory:30|h[Loot]|h: You won: |cff1eff00|Hitem:211332::::::::20:::::::::|h[Waylaid Supplies: Heavy Linen Bandages]|h|r",
					["serverTime"] = 1707835758,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743107.402,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [155]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:49:19]|h|r You receive loot: |cff1eff00|Hitem:211332::::::::20:::::::::|h[Waylaid Supplies: Heavy Linen Bandages]|h|r.",
					["serverTime"] = 1707835758,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743107.484,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [156]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:49:38]|h|r [SERVER] Shutdown in 10:00",
					["serverTime"] = 1707835767,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743126.184,
					["g"] = 1,
					["b"] = 0,
				}, -- [157]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:49:58]|h|r |cffaad372Holydda|r receives loot: |cff9d9d9d|Hitem:5124::::::::20:::::::::|h[Small Raptor Tooth]|h|r.",
					["serverTime"] = 1707835787,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743145.831,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [158]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:50:08]|h|r You loot 22 Copper",
					["serverTime"] = 1707835797,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743155.964,
					["g"] = 1,
					["b"] = 0,
				}, -- [159]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:50:18]|h|r You receive loot: |cffffffff|Hitem:5098::::::::20:::::::::|h[Altered Snapjaw Shell]|h|r.",
					["serverTime"] = 1707835807,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743166.2540000001,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [160]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:50:21]|h|r You receive loot: |cffffffff|Hitem:2318::::::::20:::::::::|h[Light Leather]|h|r.",
					["serverTime"] = 1707835810,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743169.438,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [161]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:50:23]|h|r |cffaad372Holydda|r receives loot: |cff9d9d9d|Hitem:3669::::::::20:::::::::|h[Gelatinous Goo]|h|r.",
					["serverTime"] = 1707835812,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743171.522,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [162]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:50:32]|h|r [SERVER] Shutdown in 9:00",
					["serverTime"] = 1707835821,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743179.799,
					["g"] = 1,
					["b"] = 0,
				}, -- [163]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:51:09]|h|r You receive loot: |cffffffff|Hitem:5523::::::::20:::::::::|h[Small Barnacled Clam]|h|r.",
					["serverTime"] = 1707835868,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743217.482,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [164]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:51:09]|h|r You receive loot: |cffffffff|Hitem:5098::::::::20:::::::::|h[Altered Snapjaw Shell]|h|r.",
					["serverTime"] = 1707835868,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743217.482,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [165]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:51:12]|h|r You receive loot: |cffffffff|Hitem:2318::::::::20:::::::::|h[Light Leather]|h|rx2.",
					["serverTime"] = 1707835871,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743220.5920000001,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [166]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:51:18]|h|r |Hchannel:channel:5|h[5] |h |cffffff00Swamp of Sorrows is under attack!|r",
					["serverTime"] = 1707835877,
					["r"] = 1,
					["extraData"] = {
						74, -- [1]
						49, -- [2]
						50, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743226.459,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [167]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:51:34]|h|r |cffaad372Holydda|r receives loot: |cff9d9d9d|Hitem:6444::::::::20:::::::::|h[Forked Tongue]|h|r.",
					["serverTime"] = 1707835893,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743242.16,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [168]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:51:34]|h|r |cffaad372Holydda|r receives loot: |cff9d9d9d|Hitem:5124::::::::20:::::::::|h[Small Raptor Tooth]|h|r.",
					["serverTime"] = 1707835893,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743242.16,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [169]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:51:34]|h|r |cffaad372Holydda|r receives loot: |cffffffff|Hitem:2318::::::::20:::::::::|h[Light Leather]|h|r.",
					["serverTime"] = 1707835893,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743242.16,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [170]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:51:34]|h|r [SERVER] Shutdown in 8:00",
					["serverTime"] = 1707835893,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743242.16,
					["g"] = 1,
					["b"] = 0,
				}, -- [171]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:51:36]|h|r |cffaad372Holydda|r receives loot: |cffffffff|Hitem:2319::::::::20:::::::::|h[Medium Leather]|h|r.",
					["serverTime"] = 1707835895,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743244.078,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [172]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:51:49]|h|r RestedXP Guides: Rare Found! Gesharahan is nearby.",
					["timestamp"] = 743256.719,
					["serverTime"] = 1707835908,
				}, -- [173]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:51:50]|h|r You loot 4 Copper",
					["serverTime"] = 1707835909,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743257.738,
					["g"] = 1,
					["b"] = 0,
				}, -- [174]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:52:05]|h|r You receive loot: |cffffffff|Hitem:5098::::::::20:::::::::|h[Altered Snapjaw Shell]|h|r.",
					["serverTime"] = 1707835924,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743272.921,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [175]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:52:05]|h|r You receive loot: |cff9d9d9d|Hitem:4555::::::::20:::::::::|h[Thick Scaly Tail]|h|r.",
					["serverTime"] = 1707835924,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743273.353,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [176]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:52:21]|h|r You receive loot: |cffffffff|Hitem:5523::::::::20:::::::::|h[Small Barnacled Clam]|h|r.",
					["serverTime"] = 1707835940,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743289.5,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [177]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:52:21]|h|r You receive loot: |cff9d9d9d|Hitem:4555::::::::20:::::::::|h[Thick Scaly Tail]|h|r.",
					["serverTime"] = 1707835940,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743289.5,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [178]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:52:21]|h|r You receive loot: |cffffffff|Hitem:5098::::::::20:::::::::|h[Altered Snapjaw Shell]|h|r.",
					["serverTime"] = 1707835940,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743289.5,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [179]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:52:25]|h|r Your skill in Skinning has increased to 146.",
					["serverTime"] = 1707835944,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						33, -- [2]
						34, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743292.7710000001,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [180]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:52:25]|h|r You receive loot: |cffffffff|Hitem:2318::::::::20:::::::::|h[Light Leather]|h|r.",
					["serverTime"] = 1707835944,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743292.832,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [181]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:52:26]|h|r |cffaad372Holydda|r has died.",
					["serverTime"] = 1707835945,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743293.706,
					["g"] = 1,
					["b"] = 0,
				}, -- [182]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:52:32]|h|r [SERVER] Shutdown in 7:00",
					["serverTime"] = 1707835951,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743299.911,
					["g"] = 1,
					["b"] = 0,
				}, -- [183]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:52:38]|h|r You leave the group.",
					["serverTime"] = 1707835957,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743306.234,
					["g"] = 1,
					["b"] = 0,
				}, -- [184]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:52:39]|h|r You receive loot: |cffffffff|Hitem:5098::::::::20:::::::::|h[Altered Snapjaw Shell]|h|r.",
					["serverTime"] = 1707835958,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743307.635,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [185]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:52:44]|h|r You receive loot: |cffffffff|Hitem:2318::::::::20:::::::::|h[Light Leather]|h|r.",
					["serverTime"] = 1707835963,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743311.742,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [186]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:53:22]|h|r 12:53:22 Hezrul Bloodmark attempts to run away in fear!",
					["serverTime"] = 1707836001,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						52, -- [2]
						53, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743350.377,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [187]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:53:25]|h|r You receive loot: |cffffffff|Hitem:2592::::::::20:::::::::|h[Wool Cloth]|h|rx2.",
					["serverTime"] = 1707836004,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743352.755,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [188]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:53:26]|h|r You loot 9 Copper",
					["serverTime"] = 1707836005,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743353.762,
					["g"] = 1,
					["b"] = 0,
				}, -- [189]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:53:27]|h|r RestedXP Guides: Rare Found! Gesharahan is nearby.",
					["timestamp"] = 743354.781,
					["serverTime"] = 1707836006,
				}, -- [190]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:53:27]|h|r You receive loot: |cffffffff|Hitem:2287::::::::20:::::::::|h[Haunch of Meat]|h|r.",
					["serverTime"] = 1707836006,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743355.024,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [191]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:53:28]|h|r You loot 25 Copper",
					["serverTime"] = 1707836007,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743356.079,
					["g"] = 1,
					["b"] = 0,
				}, -- [192]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:53:32]|h|r [SERVER] Shutdown in 6:00",
					["serverTime"] = 1707836011,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743359.943,
					["g"] = 1,
					["b"] = 0,
				}, -- [193]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:53:34]|h|r You receive loot: |cffffffff|Hitem:2589::::::::20:::::::::|h[Linen Cloth]|h|rx2.",
					["serverTime"] = 1707836013,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743362.018,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [194]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:53:35]|h|r You loot 12 Copper",
					["serverTime"] = 1707836014,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743363.122,
					["g"] = 1,
					["b"] = 0,
				}, -- [195]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:53:36]|h|r You loot 27 Copper",
					["serverTime"] = 1707836015,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743364.251,
					["g"] = 1,
					["b"] = 0,
				}, -- [196]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:53:46]|h|r Your skill in Wands has increased to 97.",
					["serverTime"] = 1707836025,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						33, -- [2]
						34, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743374.174,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [197]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:53:50]|h|r You loot 5 Copper",
					["serverTime"] = 1707836029,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						37, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743378.633,
					["g"] = 1,
					["b"] = 0,
				}, -- [198]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:54:32]|h|r [SERVER] Shutdown in 5:00",
					["serverTime"] = 1707836071,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743419.98,
					["g"] = 1,
					["b"] = 0,
				}, -- [199]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:54:46]|h|r [SERVER] Shutdown in 4:45",
					["serverTime"] = 1707836085,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743434.007,
					["g"] = 1,
					["b"] = 0,
				}, -- [200]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:55:01]|h|r [SERVER] Shutdown in 4:30",
					["serverTime"] = 1707836100,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743449.0210000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [201]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:55:16]|h|r [SERVER] Shutdown in 4:15",
					["serverTime"] = 1707836115,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743463.998,
					["g"] = 1,
					["b"] = 0,
				}, -- [202]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:55:22]|h|r Your Thunder Bluff reputation has increased by 100.",
					["serverTime"] = 1707836121,
					["r"] = 0.501960813999176,
					["extraData"] = {
						36, -- [1]
						54, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743470.204,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [203]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:55:22]|h|r Altered Beings completed.",
					["serverTime"] = 1707836121,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743470.204,
					["g"] = 1,
					["b"] = 0,
				}, -- [204]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:55:22]|h|r Experience gained: 1725.",
					["serverTime"] = 1707836121,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743470.204,
					["g"] = 1,
					["b"] = 0,
				}, -- [205]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:55:22]|h|r Received 8 Silver.",
					["serverTime"] = 1707836121,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743470.204,
					["g"] = 1,
					["b"] = 0,
				}, -- [206]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:55:22]|h|r 12:55:22 Tonga Runetotem inspects the snapjaw shells...",
					["serverTime"] = 1707836121,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						52, -- [2]
						53, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743470.54,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [207]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:55:23]|h|r Quest accepted: Hamuul Runetotem",
					["serverTime"] = 1707836122,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743470.929,
					["g"] = 1,
					["b"] = 0,
				}, -- [208]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:55:23]|h|r You receive item: |cffffffff|Hitem:10414::::::::20:::::::::|h[Sample Snapjaw Shell]|h|r.",
					["serverTime"] = 1707836122,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743471.188,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [209]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:55:23]|h|r Quest accepted: Mura Runetotem",
					["serverTime"] = 1707836122,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743471.31,
					["g"] = 1,
					["b"] = 0,
				}, -- [210]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:55:27]|h|r 12:55:27 Tonga Runetotem says: Hm...",
					["serverTime"] = 1707836126,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						56, -- [2]
						57, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743474.677,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [211]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:55:31]|h|r [SERVER] Shutdown in 4:00",
					["serverTime"] = 1707836130,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743479.037,
					["g"] = 1,
					["b"] = 0,
				}, -- [212]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:55:46]|h|r [SERVER] Shutdown in 3:45",
					["serverTime"] = 1707836145,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743494.014,
					["g"] = 1,
					["b"] = 0,
				}, -- [213]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:55:47]|h|r Sold junk for 3 Silver, 10 Copper.",
					["r"] = 1,
					["serverTime"] = 1707836146,
					["timestamp"] = 743494.8030000001,
					["g"] = 0.85,
					["b"] = 0,
				}, -- [214]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:56:01]|h|r [SERVER] Shutdown in 3:30",
					["serverTime"] = 1707836160,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743509.0210000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [215]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:56:02]|h|r You create: |cffffffff|Hitem:2581::::::::20:::::::::|h[Heavy Linen Bandage]|h|r.",
					["serverTime"] = 1707836161,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743510.611,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [216]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:56:03]|h|r Your skill in First Aid has increased to 82.",
					["serverTime"] = 1707836162,
					["r"] = 0.3333333432674408,
					["extraData"] = {
						27, -- [1]
						33, -- [2]
						34, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743510.677,
					["g"] = 0.3333333432674408,
					["b"] = 1,
				}, -- [217]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:56:14]|h|r You receive loot: |cffffffff|Hitem:5503::::::::20:::::::::|h[Clam Meat]|h|r.",
					["serverTime"] = 1707836173,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743521.772,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [218]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:56:14]|h|r You receive loot: |cff1eff00|Hitem:5498::::::::20:::::::::|h[Small Lustrous Pearl]|h|r.",
					["serverTime"] = 1707836173,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743522.415,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [219]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:56:14]|h|r You receive loot: |cffffffff|Hitem:5503::::::::20:::::::::|h[Clam Meat]|h|r.",
					["serverTime"] = 1707836173,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743522.415,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [220]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:56:15]|h|r You receive loot: |cffffffff|Hitem:5503::::::::20:::::::::|h[Clam Meat]|h|r.",
					["serverTime"] = 1707836174,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743522.858,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [221]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:56:16]|h|r [SERVER] Shutdown in 3:15",
					["serverTime"] = 1707836175,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743524.035,
					["g"] = 1,
					["b"] = 0,
				}, -- [222]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:56:31]|h|r [SERVER] Shutdown in 3:00",
					["serverTime"] = 1707836190,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743539.034,
					["g"] = 1,
					["b"] = 0,
				}, -- [223]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:56:46]|h|r [SERVER] Shutdown in 2:45",
					["serverTime"] = 1707836205,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743553.878,
					["g"] = 1,
					["b"] = 0,
				}, -- [224]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:57:01]|h|r [SERVER] Shutdown in 2:30",
					["serverTime"] = 1707836220,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743569.047,
					["g"] = 1,
					["b"] = 0,
				}, -- [225]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:57:16]|h|r [SERVER] Shutdown in 2:15",
					["serverTime"] = 1707836235,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743583.908,
					["g"] = 1,
					["b"] = 0,
				}, -- [226]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:57:17]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq68|k:69:24546:BN_WHISPER:|Kq68|k:cameron#1349|h|A:UI-ChatIcon-WoW:0:0:0:0|a|cffaad372|Kq68|k|r|h|cffd8d8d8]|r: is classic a reset or do the servers go down?",
					["serverTime"] = 1707836236,
					["r"] = 0,
					["extraData"] = {
						52, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743585.14,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [227]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:57:31]|h|r [SERVER] Shutdown in 2:00",
					["serverTime"] = 1707836250,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743599.055,
					["g"] = 1,
					["b"] = 0,
				}, -- [228]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:57:42]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq68|k:69:24553:BN_WHISPER:|Kq68|k:cameron#1349|h|A:UI-ChatIcon-WoW:0:0:0:0|a|cffaad372|Kq68|k|r|h|cffd8d8d8]|r: not sure mang",
					["serverTime"] = 1707836261,
					["r"] = 0,
					["extraData"] = {
						53, -- [1]
						58, -- [2]
						60, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743610.194,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [229]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:57:46]|h|r [SERVER] Shutdown in 1:45",
					["serverTime"] = 1707836265,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743613.955,
					["g"] = 1,
					["b"] = 0,
				}, -- [230]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:57:58]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq68|k:69:24556:BN_WHISPER:|Kq68|k:cameron#1349|h|A:UI-ChatIcon-WoW:0:0:0:0|a|cffaad372|Kq68|k|r|h|cffd8d8d8]|r: true should probbaly sleep anyway",
					["serverTime"] = 1707836277,
					["r"] = 0,
					["extraData"] = {
						52, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743626.194,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [231]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:58:01]|h|r [SERVER] Shutdown in 1:30",
					["serverTime"] = 1707836280,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743628.985,
					["g"] = 1,
					["b"] = 0,
				}, -- [232]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:58:16]|h|r [SERVER] Shutdown in 1:15",
					["serverTime"] = 1707836295,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743643.959,
					["g"] = 1,
					["b"] = 0,
				}, -- [233]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:58:31]|h|r [SERVER] Shutdown in 1:00",
					["serverTime"] = 1707836310,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743658.997,
					["g"] = 1,
					["b"] = 0,
				}, -- [234]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:58:46]|h|r [SERVER] Shutdown in 0:45",
					["serverTime"] = 1707836325,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743674.022,
					["g"] = 1,
					["b"] = 0,
				}, -- [235]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:58:52]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq68|k:69:24578:BN_WHISPER:|Kq68|k:cameron#1349|h|A:UI-ChatIcon-App:0:0:0:0|a|cffa0a0a0|Kq68|k|r|h|cffd8d8d8]|r: fk i missed what lvl u were upto",
					["serverTime"] = 1707836331,
					["r"] = 0,
					["extraData"] = {
						53, -- [1]
						58, -- [2]
						60, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743680.052,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [236]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:01]|h|r [SERVER] Shutdown in 0:30",
					["serverTime"] = 1707836340,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743689.0480000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [237]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:16]|h|r [SERVER] Shutdown in 0:15",
					["serverTime"] = 1707836355,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743704.0430000001,
					["g"] = 1,
					["b"] = 0,
				}, -- [238]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:21]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq68|k:69:24591:BN_WHISPER:|Kq68|k:cameron#1349|h|A:UI-ChatIcon-App:0:0:0:0|a|cffa0a0a0|Kq68|k|r|h|cffd8d8d8]|r: 26, no more 50% buff",
					["serverTime"] = 1707836360,
					["r"] = 0,
					["extraData"] = {
						52, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743709.405,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [239]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:24]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq68|k:69:24594:BN_WHISPER:|Kq68|k:cameron#1349|h|A:UI-ChatIcon-App:0:0:0:0|a|cffa0a0a0|Kq68|k|r|h|cffd8d8d8]|r: sucks now",
					["serverTime"] = 1707836363,
					["r"] = 0,
					["extraData"] = {
						52, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 743712.615,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [240]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:31]|h|r You have been disconnected from Blizzard services.",
					["serverTime"] = 1707836370,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 743719.008,
					["g"] = 1,
					["b"] = 0,
				}, -- [241]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}


_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
		},
	},
	["ocd_tracker"] = {
		["enabled"] = false,
		["current_cooldowns"] = {
		},
		["group_frames"] = true,
		["lines_per_column"] = 12,
		["width"] = 120,
		["frames"] = {
			["defensive-raid"] = {
			},
			["main"] = {
			},
			["ofensive"] = {
			},
			["defensive-target"] = {
			},
			["utility"] = {
			},
			["defensive-personal"] = {
			},
		},
		["show_options"] = false,
		["own_frame"] = {
			["defensive-raid"] = false,
			["ofensive"] = false,
			["defensive-target"] = false,
			["utility"] = false,
			["defensive-personal"] = false,
		},
		["show_title"] = true,
		["framme_locked"] = false,
		["height"] = 18,
		["cooldowns"] = {
		},
		["show_conditions"] = {
			["only_inside_instance"] = true,
			["only_in_group"] = true,
		},
		["ignored_cooldowns"] = {
		},
		["filters"] = {
			["itemutil"] = false,
			["itempower"] = false,
			["defensive-target"] = false,
			["itemheal"] = false,
			["defensive-personal"] = false,
			["defensive-raid"] = false,
			["ofensive"] = true,
			["crowdcontrol"] = false,
			["utility"] = false,
		},
	},
	["last_version"] = "1.15.1 12294",
	["player_stats"] = {
	},
	["force_font_outline"] = "",
	["tabela_instancias"] = {
	},
	["coach"] = {
		["enabled"] = false,
		["welcome_panel_pos"] = {
		},
		["last_coach_name"] = false,
	},
	["local_instances_config"] = {
		{
			["modo"] = 2,
			["sub_attribute"] = 1,
			["horizontalSnap"] = true,
			["verticalSnap"] = false,
			["isLocked"] = false,
			["is_open"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
				[3] = 2,
			},
			["segment"] = 0,
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -358.898567199707,
					["x"] = 615.3046875,
					["w"] = 165.3906097412109,
					["h"] = 126.8984603881836,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
		{
			["modo"] = 2,
			["sub_attribute"] = 1,
			["horizontalSnap"] = true,
			["verticalSnap"] = false,
			["isLocked"] = false,
			["is_open"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
				1, -- [1]
			},
			["segment"] = 0,
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -358.898567199707,
					["x"] = 775.6668701171875,
					["w"] = 155.3333282470703,
					["h"] = 126.8984603881836,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [2]
	},
	["cached_talents"] = {
	},
	["last_instance_id"] = 0,
	["data_harvest_for_charsts"] = {
		["players"] = {
			{
				["playerKey"] = "total",
				["combatObjectContainer"] = 1,
				["name"] = "Damage of Each Individual Player",
				["playerOnly"] = true,
			}, -- [1]
		},
		["totals"] = {
			{
				["combatObjectSubTableKey"] = 1,
				["name"] = "Damage of All Player Combined",
				["combatObjectSubTableName"] = "totals",
			}, -- [1]
		},
	},
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["announce_prepots"] = {
		["enabled"] = false,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["active_profile"] = "Rightclicker-Skull Rock",
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["combat_log"] = {
		["inverse_deathlog_overalldata"] = false,
		["evoker_calc_damage"] = false,
		["track_hunter_frenzy"] = false,
		["merge_critical_heals"] = false,
		["inverse_deathlog_raid"] = false,
		["merge_gemstones_1007"] = false,
		["evoker_show_realtimedps"] = false,
		["inverse_deathlog_mplus"] = false,
	},
	["ignore_nicktag"] = false,
	["mythic_plus_log"] = {
	},
	["combat_counter"] = 76,
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["data_harvested_for_charts"] = {
	},
	["on_death_menu"] = false,
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["last_realversion"] = 155,
	["last_instance_time"] = 0,
	["combat_id"] = 0,
	["savedStyles"] = {
	},
	["last_day"] = "13",
	["character_data"] = {
		["logons"] = 38,
	},
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["raid_roster_indexed"] = {
		},
		["tempo_start"] = 731861.399,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["bossTimers"] = {
		},
		["trinketProcs"] = {
		},
		["totals"] = {
			0, -- [1]
			0, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["debuff_uptime"] = 0,
				["cooldowns_defensive"] = 0,
				["interrupt"] = 0,
				["dispell"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
			["frags_total"] = 0,
			["voidzone_damage"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage_section"] = {
			},
			["damage"] = {
			},
		},
		["amountCasts"] = {
		},
		["totals_grupo"] = {
			0, -- [1]
			0, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["debuff_uptime"] = 0,
				["cooldowns_defensive"] = 0,
				["interrupt"] = 0,
				["dispell"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
		},
		["data_inicio"] = 0,
		["frags"] = {
		},
		["data_fim"] = 0,
		["cleu_events"] = {
			["n"] = 1,
		},
		["cleu_timeline"] = {
		},
		["spells_cast_timeline"] = {
		},
		["start_time"] = 0,
		["TimeData"] = {
		},
		["combat_counter"] = 75,
	},
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["enabled"] = true,
			["animate"] = false,
			["hide_pull_bar"] = false,
			["author"] = "Terciob",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["usefocus"] = false,
			["updatespeed"] = 1,
			["useclasscolors"] = false,
			["showamount"] = false,
			["useplayercolor"] = false,
			["absolute_mode"] = false,
			["playSound"] = false,
			["playSoundFile"] = "Details Threat Warning Volume 3",
			["disable_gouge"] = false,
		},
		["DETAILS_PLUGIN_COMPARETWO_WINDOW"] = {
			["enabled"] = true,
			["author"] = "Terciob",
		},
		["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
			["use_square_mode"] = false,
			["is_first_run"] = false,
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["main_frame_size"] = {
				300.0000610351563, -- [1]
				499.9999389648438, -- [2]
			},
			["arrow_anchor_y"] = 0,
			["minimap"] = {
				["minimapPos"] = 304.022555701998,
				["radius"] = 160,
				["hide"] = true,
			},
			["main_frame_locked"] = false,
			["arrow_anchor_x"] = 0,
			["author"] = "Terciob",
			["row_texture"] = "Details Serenity",
			["square_grow_direction"] = "right",
			["y"] = -1.52587890625e-05,
			["row_color"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.1, -- [3]
				0.4, -- [4]
			},
			["square_amount"] = 5,
			["enabled"] = false,
			["arrow_size"] = 10,
			["per_second"] = {
				["enabled"] = false,
				["point"] = "CENTER",
				["scale"] = 1,
				["font_shadow"] = true,
				["y"] = -3.0517578125e-05,
				["x"] = 0.0001220703125,
				["attribute_type"] = 1,
				["update_speed"] = 0.05,
				["size"] = 32,
			},
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.2, -- [4]
			},
			["main_frame_strata"] = "LOW",
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["use_spark"] = true,
			["font_size"] = 10,
			["x"] = 3.0517578125e-05,
			["font_face"] = "Friz Quadrata TT",
			["square_size"] = 32,
			["point"] = "CENTER",
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["row_height"] = 20,
			["scale"] = 1,
		},
	},
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["nick_tag_cache"] = {
		["nextreset"] = 1708242223,
		["last_version"] = 16,
	},
	["announce_cooldowns"] = {
		["ignored_cooldowns"] = {
		},
		["enabled"] = false,
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["cached_roles"] = {
	},
	["cached_specs"] = {
	},
}

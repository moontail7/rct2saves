
SpyPerCharDB = {
	["KOSData"] = {
	},
	["IgnoreData"] = {
	},
	["PlayerData"] = {
	},
	["version"] = "1.1",
}

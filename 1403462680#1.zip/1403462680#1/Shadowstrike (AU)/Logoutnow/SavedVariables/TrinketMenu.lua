
TrinketMenuPerOptions = {
	["Visible"] = "ON",
	["MainScale"] = 1,
	["XPos"] = 400,
	["Alpha"] = 1,
	["MainOrient"] = "HORIZONTAL",
	["FirstUse"] = true,
	["ItemsUsed"] = {
	},
	["Hidden"] = {
	},
	["MenuDock"] = "BOTTOMLEFT",
	["MainDock"] = "BOTTOMRIGHT",
	["YPos"] = 400,
	["MenuScale"] = 1,
	["MenuOrient"] = "VERTICAL",
}
TrinketMenuQueue = {
	["Enabled"] = {
	},
	["Stats"] = {
	},
	["Sort"] = {
		{
			0, -- [1]
		}, -- [1]
		[0] = {
			0, -- [1]
		},
	},
	["Profiles"] = {
	},
}

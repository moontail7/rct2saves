
Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["scrollback"] = {
		["ChatFrame5"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 11,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707747209,
					["r"] = 1,
				}, -- [1]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["b"] = 0,
					["r"] = 1,
					["serverTime"] = 1707747326,
					["timestamp"] = 731881.8,
					["g"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [2]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["g"] = 1,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 731881.8,
					["serverTime"] = 1707747412,
					["b"] = 0,
				}, -- [3]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["b"] = 0,
					["serverTime"] = 1707747579,
					["timestamp"] = 731881.8,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [4]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707757224,
					["r"] = 1,
				}, -- [5]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["b"] = 0,
					["r"] = 1,
					["serverTime"] = 1707789519,
					["timestamp"] = 731881.8,
					["g"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [6]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["g"] = 1,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822131,
					["b"] = 0,
				}, -- [7]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["serverTime"] = 1707824533,
					["r"] = 1,
					["b"] = 0,
					["timestamp"] = 731881.8,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [8]
				{
					["message"] = "0 days, 0 hours, 0 minutes, 0 seconds",
					["timestamp"] = 731881.8,
				}, -- [9]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 731881.8,
				}, -- [10]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 731861.399,
					["g"] = 1,
					["b"] = 0,
				}, -- [11]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame7"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame6"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame8"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame10"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame9"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 117,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[00:13:40]|h|r You receive item: |cffffffff|Hitem:210138::::::::1:::::::::|h[Dark Iron Ordinance]|h|rx8.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707747219,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:13:40]|h|r You receive item: |cffffffff|Hitem:213545::::::::1:::::::::|h[Scroll: PEATCHY ATTAX]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707747219,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:13:40]|h|r You receive item: |cff1eff00|Hitem:6613::::::848:184167040:1:::::::::|h[Sage's Bracers of the Eagle]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707747219,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:13:40]|h|r You receive item: |cff0070dd|Hitem:13105::::::::1:::::::::|h[Sutarn's Ring]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707747219,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:13:41]|h|r You receive item: |cff1eff00|Hitem:7356::::::1842:1953324672:1:::::::::|h[Elder's Cloak of Shadow Wrath]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707747220,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:13:41]|h|r You receive item: |cffffffff|Hitem:4402::::::::1:::::::::|h[Small Flame Sac]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707747220,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:13:41]|h|r You receive item: |cffffffff|Hitem:12205::::::::1:::::::::|h[White Spider Meat]|h|rx2.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707747220,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:13:41]|h|r You receive item: |cffffffff|Hitem:8146::::::::1:::::::::|h[Wicked Claw]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707747220,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:14:10]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Goeasyiamnew-Shadowstrike(AU):8231:CHANNEL:2|h|cff3fc6eaGoeasyiamnew|r|h|cffd8d8d8]|r: Portals 1g UC + ORC |||| Free max rank food/water (in TB)",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707747249,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:14:28]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Chungafury-Shadowstrike(AU):8247:CHANNEL:2|h|cffc69b6dChungafury|r|h|cffd8d8d8]|r: LF ENCH WITH ADVANCED MINING ENCH",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707747267,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:15:28]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Juckfason-Shadowstrike(AU):8290:CHANNEL:2|h|cffffffffJuckfason|r|h|cffd8d8d8]|r: WTS|cffa335ee|Hitem:870::::::::40:::::::::|h[Fiery War Axe]|h|r",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1707747327,
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:15:38]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Goeasyiamnew-Shadowstrike(AU):8300:CHANNEL:2|h|cff3fc6eaGoeasyiamnew|r|h|cffd8d8d8]|r: Portals 1g UC + ORC |||| Free max rank food/water (in TB)",
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1707747337,
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:16:02]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Offtheirhead-Shadowstrike(AU):8318:CHANNEL:1|h|cffc69b6dOfftheirhead|r|h|cffd8d8d8]|r: |cffffffff<|r|cff00ff00乃卂丂乇Ｄ|r|cffffffff>|r Recruiting Tanks, Healers & DPS for our gnomer teams. Raid time 9pm server onwards. STV PVP every 3 hrs. |cffffffff|Hurl:https://discord.gg/VPmRvdbAbN|h[https://discord.gg/VPmRvdbAbN]|h|r",
					["extraData"] = {
						70, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1707747361,
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:17:04]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Goeasyiamnew:2:CHANNEL:2|h|cff3fc6eaGoeasyiamnew|r|h|cffd8d8d8]|r: Portals 1g UC + ORC |||| Free max rank food/water (in TB)",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707747423,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:18:45]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Goeasyiamnew-Shadowstrike(AU):46:CHANNEL:2|h|cff3fc6eaGoeasyiamnew|r|h|cffd8d8d8]|r: Portals 1g UC + ORC |||| Free max rank food/water (in TB)",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707747524,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:19:00]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Thee:56:CHANNEL:2|h|cff8787edThee|r|h|cffd8d8d8]|r: is there any use for",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707747539,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:19:16]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Thee-Shadowstrike(AU):63:CHANNEL:2|h|cff8787edThee|r|h|cffd8d8d8]|r: is there any use for |cffffffff|Hitem:22260::::::::21:::::::::|h[Friendship Bracelet]|h|r?",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707747555,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:19:35]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Elleaka-Shadowstrike(AU):74:CHANNEL:2|h|cffaad372Elleaka|r|h|cffd8d8d8]|r: Yep, you can use it on people with the heart broken buff",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707747574,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						6, -- [3]
						["n"] = 3,
					},
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:19:42]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Mageymcswag:78:CHANNEL:2|h|cff3fc6eaMageymcswag|r|h|cffd8d8d8]|r: WTB |cffffffff|Hitem:8153::::::::40:::::::::|h[Wildvine]|h|r",
					["serverTime"] = 1707747581,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:19:53]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Pacifist:87:CHANNEL:2|h|cffc69b6dPacifist|r|h|cffd8d8d8]|r: if someone fucks up the perfume/cologne they get heart broken",
					["serverTime"] = 1707747592,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:19:57]|h|r [Y] |cffd8d8d8[|r|Hplayer:Elleaka-Shadowstrike(AU):91:YELL|h|cffaad372Elleaka|r|h|cffd8d8d8]|r: Can anyone mend my broken heart? |cffffffff|Hitem:22259::::::::35:::::::::|h[Unbestowed Friendship Bracelet]|h|r",
					["serverTime"] = 1707747596,
					["r"] = 1,
					["extraData"] = {
						7, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731881.8,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:20:07]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Thee-Shadowstrike(AU):100:CHANNEL:2|h|cff8787edThee|r|h|cffd8d8d8]|r: that is |cffffffff|Hitem:22259::::::::21:::::::::|h[Unbestowed Friendship Bracelet]|h|r",
					["serverTime"] = 1707747606,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:20:08]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Frozencoke:102:CHANNEL:2|h|cffff7c0aFrozencoke|r|h|cffd8d8d8]|r: you also get 200hp for the buff",
					["serverTime"] = 1707747607,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:20:08]|h|r |Hchannel:channel:1|h[1] |h Left Channel: |Hchannel:CHANNEL:1|h[1. General - Orgrimmar]|h",
					["serverTime"] = 1707747607,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:20:08]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["serverTime"] = 1707747607,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:20:08]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Orgrimmar]|h",
					["serverTime"] = 1707747607,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:01:04]|h|r [Y] |cffd8d8d8[|r|Hplayer:Saul-Shadowstrike(AU):3336:YELL|h|cff3fc6eaSaul|r|h|cffd8d8d8]|r: S> Portals to Org/UC - 1g.",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 731881.8,
					["extraData"] = {
						7, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707757263,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:01:33]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Goeasyiamnew-Shadowstrike(AU):3339:CHANNEL:2|h|cff3fc6eaGoeasyiamnew|r|h|cffd8d8d8]|r: Portals 1g UC + ORG |||| Free max rank food/water (in TB)",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707757292,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:02:57]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Goeasyiamnew-Shadowstrike(AU):3349:CHANNEL:2|h|cff3fc6eaGoeasyiamnew|r|h|cffd8d8d8]|r: Portals 1g UC + ORG |||| Free max rank food/water (in TB)",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707757376,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:03:04]|h|r You receive item: |cffffffff|Hitem:9302::::::::1:::::::::|h[Recipe: Ghost Dye]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707757383,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:03:04]|h|r You receive item: |cff1eff00|Hitem:217278::::::::1:::::::::|h[Plans: Golden Scale Cuirass]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707757383,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:03:05]|h|r You receive item: |cffffffff|Hitem:4424::::::::1:::::::::|h[Scroll of Spirit III]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707757384,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:03:14]|h|r You receive item: |cffffffff|Hitem:2452::::::::1:::::::::|h[Swiftthistle]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707757393,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:03:19]|h|r You receive item: |cff0070dd|Hitem:936::::::::1:::::::::|h[Midnight Mace]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707757398,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:03:20]|h|r You receive item: |cffffffff|Hitem:4419::::::::1:::::::::|h[Scroll of Intellect III]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707757399,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:03:20]|h|r You receive item: |cffffffff|Hitem:4402::::::::1:::::::::|h[Small Flame Sac]|h|rx2.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707757399,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:03:21]|h|r You receive item: |cffffffff|Hitem:12205::::::::1:::::::::|h[White Spider Meat]|h|rx5.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707757400,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:04:07]|h|r [Y] |cffd8d8d8[|r|Hplayer:Saul-Shadowstrike(AU):3381:YELL|h|cff3fc6eaSaul|r|h|cffd8d8d8]|r: S> Portals to Org/UC - 1g.",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 731881.8,
					["extraData"] = {
						7, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707757446,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:05:30]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Goeasyiamnew-Shadowstrike(AU):3406:CHANNEL:2|h|cff3fc6eaGoeasyiamnew|r|h|cffd8d8d8]|r: Portals 1g UC + ORG |||| Free max rank food/water (in TB)",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707757529,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[03:05:51]|h|r |Hchannel:channel:1|h[1] |h Left Channel: |Hchannel:CHANNEL:1|h[1. General - Orgrimmar]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["extraData"] = {
						70, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1707757550,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:58:42]|h|r [S] |cffd8d8d8[|r|Hplayer:Imded-Shadowstrike(AU):741:SAY|h|cffaad372Imded|r|h|cffd8d8d8]|r: can someone use rings on me plz :) ?",
					["extraData"] = {
						2, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 1,
					["serverTime"] = 1707789520,
					["timestamp"] = 731881.8,
					["g"] = 1,
					["r"] = 1,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:58:49]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Nanginator-Shadowstrike(AU):748:CHANNEL:2|h|cff8787edNanginator|r|h|cffd8d8d8]|r: Free 225 Enchants - Org Bank - Your Mats - Tips Appreciated",
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1707789527,
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:58:50]|h|r You receive item: |cffffffff|Hitem:9302::::::::1:::::::::|h[Recipe: Ghost Dye]|h|r.",
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1707789528,
					["timestamp"] = 731881.8,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:58:50]|h|r You receive item: |cffffffff|Hitem:4419::::::::1:::::::::|h[Scroll of Intellect III]|h|r.",
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1707789528,
					["timestamp"] = 731881.8,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:58:51]|h|r You receive item: |cffffffff|Hitem:4424::::::::1:::::::::|h[Scroll of Spirit III]|h|r.",
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1707789529,
					["timestamp"] = 731881.8,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:58:51]|h|r You receive item: |cffffffff|Hitem:8146::::::::1:::::::::|h[Wicked Claw]|h|r.",
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1707789529,
					["timestamp"] = 731881.8,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:58:51]|h|r You receive item: |cff1eff00|Hitem:6613::::::848:184167040:1:::::::::|h[Sage's Bracers of the Eagle]|h|r.",
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1707789529,
					["timestamp"] = 731881.8,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:58:51]|h|r You receive item: |cffffffff|Hitem:213545::::::::1:::::::::|h[Scroll: PEATCHY ATTAX]|h|r.",
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1707789529,
					["timestamp"] = 731881.8,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [48]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:58:51]|h|r You receive item: |cffffffff|Hitem:211785::::::::1:::::::::|h[Scroll: CWAL]|h|r.",
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1707789529,
					["timestamp"] = 731881.8,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [49]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:58:51]|h|r You receive item: |cffffffff|Hitem:3012::::::::1:::::::::|h[Scroll of Agility]|h|r.",
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1707789529,
					["timestamp"] = 731881.8,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [50]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:58:52]|h|r You receive item: |cffffffff|Hitem:3576::::::::1:::::::::|h[Tin Bar]|h|rx20.",
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1707789530,
					["timestamp"] = 731881.8,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [51]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:58:52]|h|r You receive item: |cffffffff|Hitem:2841::::::::1:::::::::|h[Bronze Bar]|h|rx12.",
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1707789530,
					["timestamp"] = 731881.8,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [52]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:58:52]|h|r You receive item: |cffffffff|Hitem:4404::::::::1:::::::::|h[Silver Contact]|h|rx15.",
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1707789530,
					["timestamp"] = 731881.8,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [53]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:58:53]|h|r You receive item: |cffffffff|Hitem:3576::::::::1:::::::::|h[Tin Bar]|h|rx7.",
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1707789531,
					["timestamp"] = 731881.8,
					["g"] = 0.6666666865348816,
					["r"] = 0,
				}, -- [54]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:06]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Questionmark:774:CHANNEL:2|h|cff0070ddQuestionmark|r|h|cffd8d8d8]|r: wts |cff1eff00|Hitem:12010::::::683:2107669888:38:::::::::|h[Fen Ring of the Tiger]|h|r",
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1707789544,
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [55]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:20]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Jimmey-Shadowstrike(AU):789:CHANNEL:2|h|cffaad372Jimmey|r|h|cffd8d8d8]|r: jimmey is a lower class white guy who wants a lower class white woman. and theres none left in the north island",
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1707789558,
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [56]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:39]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Karl-Shadowstrike(AU):808:CHANNEL:2|h|cff0070ddKarl|r|h|cffd8d8d8]|r: theres heaps of sheep what you talking about",
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						12, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1707789577,
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [57]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:43]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Jimmey-Shadowstrike(AU):811:CHANNEL:2|h|cffaad372Jimmey|r|h|cffd8d8d8]|r: looooooooooooool",
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1707789581,
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [58]
				{
					["message"] = "|cff979797|Hpratcopy|h[11:59:52]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Papaterb:818:CHANNEL:2|h|cffff7c0aPapaterb|r|h|cffd8d8d8]|r: WTB UC port @ tb",
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						14, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1707789590,
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [59]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:04]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Julianne:828:CHANNEL:2|h|cff3fc6eaJulianne|r|h|cffd8d8d8]|r: WTS |cff1eff00|Hitem:12040::::::682:401680768:40:::::::::|h[Forest Pendant of the Tiger]|h|r8g",
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						16, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1707789602,
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [60]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:11]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Caata-Shadowstrike(AU):838:CHANNEL:2|h|cffffffffCaata|r|h|cffd8d8d8]|r: Sharing Priest quest [[35] The Troll Scroll (79731)] for Dispersion Rune- save time and money. I'm at TB near the mail box - tips appreciated",
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						18, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1707789609,
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [61]
				{
					["message"] = "|cff979797|Hpratcopy|h[12:00:19]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Lavablurst-Shadowstrike(AU):843:CHANNEL:2|h|cff0070ddLavablurst|r|h|cffd8d8d8]|r: WTS |cff0070dd|Hitem:10019::::::::38::::1:3524:::::|h[Dreamweave Gloves]|h|r 60g - bis caster gloves",
					["extraData"] = {
						71, -- [1]
						3, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1707789617,
					["timestamp"] = 731881.8,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [62]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:17]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Juckfason-Shadowstrike(AU):18469:CHANNEL:2|h|cffffffffJuckfason|r|h|cffd8d8d8]|r: WTS|cffa335ee|Hitem:870::::::::40:::::::::|h[Fiery War Axe]|h|r",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822135,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [63]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:19]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Stiryx-Shadowstrike(AU):18470:CHANNEL:2|h|cffff7c0aStiryx|r|h|cffd8d8d8]|r: LF1M Gnomer fresh - need healer.",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822137,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [64]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:21]|h|r You receive item: |cffffffff|Hitem:2840::::::::1:::::::::|h[Copper Bar]|h|rx20.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822139,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
				}, -- [65]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:27]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Pharaoh-Shadowstrike(AU):18476:CHANNEL:2|h|cffffffffPharaoh|r|h|cffd8d8d8]|r: lf2m dps rfk boar run",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822145,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [66]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:32]|h|r You receive item: |cffffffff|Hitem:2841::::::::1:::::::::|h[Bronze Bar]|h|rx17.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822150,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
				}, -- [67]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:35]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Moogician-Shadowstrike(AU):18487:CHANNEL:1|h|cffff7c0aMoogician|r|h|cffd8d8d8]|r: NEED ALL SPELL CLEAVE SM ARM SPAM!!",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822153,
					["extraData"] = {
						70, -- [1]
						12, -- [2]
						13, -- [3]
						["n"] = 3,
					},
				}, -- [68]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:36]|h|r You receive item: |cff1eff00|Hitem:2776::::::::1:::::::::|h[Gold Ore]|h|rx3.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822154,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
				}, -- [69]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:36]|h|r You receive item: |cffffffff|Hitem:2770::::::::1:::::::::|h[Copper Ore]|h|rx10.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822154,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
				}, -- [70]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:36]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Moogician-Shadowstrike(AU):18490:CHANNEL:2|h|cffff7c0aMoogician|r|h|cffd8d8d8]|r: NEED ALL SPELL CLEAVE SM ARM SPAM!!",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822154,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						15, -- [3]
						["n"] = 3,
					},
				}, -- [71]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:36]|h|r You receive item: |cffffffff|Hitem:2770::::::::1:::::::::|h[Copper Ore]|h|rx4.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822154,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
				}, -- [72]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:37]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Atsumi-Shadowstrike(AU):18492:CHANNEL:2|h|cff8787edAtsumi|r|h|cffd8d8d8]|r: LF3M BFD 2 dps 1 healer.  Feral/warrior/Priest Pref",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822155,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						17, -- [3]
						["n"] = 3,
					},
				}, -- [73]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:41]|h|r You receive item: |cff1eff00|Hitem:1210::::::::1:::::::::|h[Shadowgem]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822159,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
				}, -- [74]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:43]|h|r You receive item: |cffffffff|Hitem:2840::::::::1:::::::::|h[Copper Bar]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822161,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
				}, -- [75]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:46]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Pharaoh-Shadowstrike(AU):18504:CHANNEL:2|h|cffffffffPharaoh|r|h|cffd8d8d8]|r: lf2m dps rfk boar run",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822164,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [76]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:47]|h|r You receive item: |cffffffff|Hitem:2589::::::::1:::::::::|h[Linen Cloth]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822165,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
				}, -- [77]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:49]|h|r You receive item: |cffffffff|Hitem:2835::::::::1:::::::::|h[Rough Stone]|h|rx13.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822167,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
				}, -- [78]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:51]|h|r You receive item: |cffffffff|Hitem:2836::::::::1:::::::::|h[Coarse Stone]|h|rx3.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822169,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
				}, -- [79]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:52]|h|r You receive item: |cffffffff|Hitem:2838::::::::1:::::::::|h[Heavy Stone]|h|rx3.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822170,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
				}, -- [80]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:53]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Bkdoorbandit-Shadowstrike(AU):18515:CHANNEL:2|h|cffc69b6dBkdoorbandit|r|h|cffd8d8d8]|r: WTB Shredder Operating Manual - Page 9",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822171,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						19, -- [3]
						["n"] = 3,
					},
				}, -- [81]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:54]|h|r You receive item: |cffffffff|Hitem:2771::::::::1:::::::::|h[Tin Ore]|h|rx7.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822172,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
				}, -- [82]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:02:56]|h|r You receive item: |cff1eff00|Hitem:774::::::::1:::::::::|h[Malachite]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822174,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
				}, -- [83]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:03:04]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Moogician-Shadowstrike(AU):18526:CHANNEL:2|h|cffff7c0aMoogician|r|h|cffd8d8d8]|r: NEED ALL SPELL CLEAVE SM ARM SPAM!!",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822182,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						15, -- [3]
						["n"] = 3,
					},
				}, -- [84]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:03:07]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Pharaoh-Shadowstrike(AU):18531:CHANNEL:2|h|cffffffffPharaoh|r|h|cffd8d8d8]|r: lf1m dps rfk boar farm",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822185,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						8, -- [3]
						["n"] = 3,
					},
				}, -- [85]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:03:17]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Jaz-Shadowstrike(AU):18536:CHANNEL:2|h|cff0070ddJaz|r|h|cffd8d8d8]|r: Offering maxed Tailoring/Enchanting services! All Bags,  Patterns and Enchants with your mats or mine! Also buying all greens, COD them to me your pice!",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822195,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						21, -- [3]
						["n"] = 3,
					},
				}, -- [86]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:03:18]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Atsumi-Shadowstrike(AU):18537:CHANNEL:2|h|cff8787edAtsumi|r|h|cffd8d8d8]|r: LF1M BFD need healer Priest pref",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822196,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						17, -- [3]
						["n"] = 3,
					},
				}, -- [87]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:03:26]|h|r |Hchannel:channel:1|h[1] |h Left Channel: |Hchannel:CHANNEL:1|h[1. General - Orgrimmar]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822204,
					["extraData"] = {
						70, -- [1]
						12, -- [2]
						23, -- [3]
						["n"] = 3,
					},
				}, -- [88]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:03:26]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 731881.8,
					["serverTime"] = 1707822204,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						25, -- [3]
						["n"] = 3,
					},
				}, -- [89]
				{
					["message"] = "0 days, 0 hours, 38 minutes, 49 seconds",
					["timestamp"] = 731881.8,
				}, -- [90]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 731881.8,
				}, -- [91]
				{
					["message"] = "|cFFFF1C1C Loaded: LFG Bulletin Board 3.12 by Vyscî-Whitemane",
					["timestamp"] = 731861.399,
				}, -- [92]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Dominos Detected, please make sure Dominos Elements are disabled in MoveAny!",
					["timestamp"] = 731861.399,
				}, -- [93]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Click the MoveAny Minimap Button to open the settings.",
					["timestamp"] = 731861.399,
				}, -- [94]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Or tap /move or /moveany in chat to open the settings.",
					["timestamp"] = 731861.399,
				}, -- [95]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 To hide these messages deactivate tips in the MoveAny menu.",
					["timestamp"] = 731861.399,
				}, -- [96]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:06]|h|r Error parsing guide 12-17 The Barrens: Invalid function call (.isQuestTurnIn)\n.isQuestTurnIn 858",
					["timestamp"] = 731861.399,
				}, -- [97]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:13]|h|r |cFF00FFB0WeaponSwingTimer: |rThank you for installing WeaponSwingTimer Version 7.2.3 by WatchYourSixx! Use |cFFFFC300/wst|r for more options.",
					["timestamp"] = 731861.399,
				}, -- [98]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:15]|h|r |cffffff99<aux> loaded - /aux",
					["timestamp"] = 731881.8,
				}, -- [99]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:15]|h|r RestedXP Guides: Targeting macro updated with (Kaltunk)",
					["timestamp"] = 731881.8,
					["serverTime"] = 1707824533,
				}, -- [100]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:15]|h|r |c00FFAA00ThreatClassic2 v2.50 - Type /tc2 for options.|r",
					["timestamp"] = 731881.8,
					["serverTime"] = 1707824533,
				}, -- [101]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:15]|h|r |cffe6cc80 [Whoa Thick Frames |cFF0070FFClassic|r |cffe6cc80v1.5d ] |cffffffffis now loaded. Use |cffffff00'/whoaf' |cffffffffto view options.",
					["timestamp"] = 731881.8,
					["serverTime"] = 1707824533,
				}, -- [102]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:17]|h|r |cFFffff00[Questie]|r |cFF6ce314The 'Lunar Festival' world event is active!",
					["timestamp"] = 731884.319,
					["serverTime"] = 1707824535,
				}, -- [103]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:17]|h|r |cFFffff00[Questie]|r |cFF6ce314The 'Love is in the Air' world event is active!",
					["timestamp"] = 731884.319,
					["serverTime"] = 1707824535,
				}, -- [104]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:17]|h|r |cFFffff00[Questie]|r |cFF6ce314The 'Darkmoon Faire' world event is active!",
					["timestamp"] = 731884.319,
					["serverTime"] = 1707824535,
				}, -- [105]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:18]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Rry-Shadowstrike(AU):20243:CHANNEL:2|h|cff8787edRry|r|h|cffd8d8d8]|r: LF1M Gnomer - Need heals.",
					["serverTime"] = 1707824536,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731885.09,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [106]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:19]|h|r RestedXP Guides: TomTom has known incompatibilities with the Waypoint Arrow. Disable it if you're experiencing navigation issues.",
					["timestamp"] = 731885.804,
					["serverTime"] = 1707824537,
				}, -- [107]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:19]|h|r RestedXP Guides: TotemTimers has known incompatibilities with the Waypoint Arrow. Disable it if you're experiencing navigation issues.",
					["timestamp"] = 731885.804,
					["serverTime"] = 1707824537,
				}, -- [108]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:25]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|h|HNWBCustomLink:timers|hYou are on a layered realm.|h|h",
					["timestamp"] = 731891.8030000001,
					["serverTime"] = 1707824543,
				}, -- [109]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:42:25]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|h|HNWBCustomLink:timers|hClick here to view current timers.|h|h",
					["timestamp"] = 731891.8030000001,
					["serverTime"] = 1707824543,
				}, -- [110]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:43:04]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Goeasyiamnew-Shadowstrike(AU):20263:CHANNEL:2|h|cff3fc6eaGoeasyiamnew|r|h|cffd8d8d8]|r: Portals 1g UC + ORG |||| Free max rank food/water (in TB)",
					["serverTime"] = 1707824582,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731930.927,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [111]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:43:08]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Sayid:20264:CHANNEL:2|h|cffffffffSayid|r|h|cffd8d8d8]|r: 31 priest lfg",
					["serverTime"] = 1707824586,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731934.514,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [112]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:43:21]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Batsheal-Shadowstrike(AU):20274:CHANNEL:2|h|cffffffffBatsheal|r|h|cffd8d8d8]|r: Max Enchanting & Tailoring || LFW",
					["serverTime"] = 1707824599,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731948.226,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [113]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:43:21]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Batsheal-Shadowstrike(AU):20275:CHANNEL:2|h|cffffffffBatsheal|r|h|cffd8d8d8]|r: All Recipes in Org!",
					["serverTime"] = 1707824599,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731948.226,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [114]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:43:37]|h|r |Hchannel:channel:1|h[1] |h Left Channel: |Hchannel:CHANNEL:1|h[1. General - Orgrimmar]|h",
					["serverTime"] = 1707824615,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731964.144,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [115]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:43:37]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["serverTime"] = 1707824615,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						1, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731964.144,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [116]
				{
					["message"] = "|cff979797|Hpratcopy|h[21:43:37]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Orgrimmar]|h",
					["serverTime"] = 1707824615,
					["r"] = 1,
					["extraData"] = {
						72, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 731964.144,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [117]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}


POISONER_CONFIG = {
	["TooltipType"] = "full",
	["Buttons"] = {
		["FreeButton"] = {
			["Active"] = 1,
			["Scale"] = 1,
			["Lock"] = 0,
			["Alpha"] = 1,
			["Position"] = {
				["RelativeTo"] = "UIParent",
				["XPos"] = 0,
				["RelativePoint"] = "CENTER",
				["Anchor"] = "CENTER",
				["YPos"] = 0,
			},
		},
		["QuickButton"] = {
			["Scale"] = 1,
			["Lock"] = 1,
			["Alpha"] = 1,
			["Position"] = {
				["RelativeTo"] = "UIParent",
				["XPos"] = 0,
				["RelativePoint"] = "CENTER",
				["Anchor"] = "CENTER",
				["YPos"] = 0,
			},
		},
		["LDBIcon"] = {
			["hide"] = "true",
		},
	},
	["Preset"] = {
		["Normal"] = {
			["Mainhand"] = 1,
			["Offhand"] = 1,
		},
		["CTRL"] = {
			["Mainhand"] = 1,
			["Offhand"] = 1,
		},
		["Overwrite"] = 0,
		["ALT"] = {
			["Mainhand"] = 1,
			["Offhand"] = 1,
		},
		["SHIFT"] = {
			["Mainhand"] = 1,
			["Offhand"] = 1,
		},
	},
	["Enabled"] = 0,
	["Menu"] = {
		["Position"] = "bottomleft",
		["Parent"] = "Poisoner_FreeButton",
		["Spacing"] = 0,
		["Scale"] = 1,
		["AutoHide"] = {
			["Active"] = 0,
			["Time"] = 10,
			["inCombat"] = 0,
		},
		["ShowOnMouseover"] = 0,
		["Sorting"] = {
			"IP", -- [1]
			"DP", -- [2]
			"WP", -- [3]
			"MP", -- [4]
			"CP", -- [5]
			"SS", -- [6]
			"WS", -- [7]
		},
	},
	["PrintClickedPoison"] = 1,
	["Timer"] = {
		["Active"] = 1,
		["Scale"] = 1,
		["WarningThreshold"] = 2,
		["Alpha"] = 1,
		["Output"] = {
			["Chat"] = 1,
			["ErrorFrame"] = 1,
			["Audio"] = 1,
			["Aura"] = 1,
		},
		["IgnoreWhileFishing"] = 0,
		["Position"] = {
			["RelativeTo"] = "UIParent",
			["XPos"] = 0,
			["RelativePoint"] = "CENTER",
			["Anchor"] = "CENTER",
			["YPos"] = 100,
			["OnlyInstanced"] = 0,
		},
		["OnlyInstanced"] = 0,
		["Lock"] = 1,
		["Weapon"] = {
			["MainHand"] = 1,
			["OffHand"] = 1,
		},
	},
	["Poisons"] = {
		[2863] = {
			["Name"] = "Coarse Sharpening Stone",
			["Texture"] = 135249,
		},
		[6947] = {
			["Name"] = "Instant Poison",
			["Texture"] = 132273,
		},
		[3239] = {
			["Name"] = "Rough Weightstone",
			["Texture"] = 135255,
		},
		[3241] = {
			["Name"] = "Heavy Weightstone",
			["Texture"] = 135257,
		},
		[8926] = {
			["Name"] = "Instant Poison IV",
			["Texture"] = 132273,
		},
		[6951] = {
			["Name"] = "Mind-numbing Poison II",
			["Texture"] = 136066,
		},
		[211845] = {
			["Name"] = "Blackfathom Sharpening Stone",
			["Texture"] = 134417,
		},
		[3776] = {
			["Name"] = "Crippling Poison II",
			["Texture"] = 134799,
		},
		[8927] = {
			["Name"] = "Instant Poison V",
			["Texture"] = 132273,
		},
		[2871] = {
			["Name"] = "Heavy Sharpening Stone",
			["Texture"] = 135250,
		},
		[7964] = {
			["Name"] = "Solid Sharpening Stone",
			["Texture"] = 135251,
		},
		[6950] = {
			["Name"] = "Instant Poison III",
			["Texture"] = 132273,
		},
		[8928] = {
			["Name"] = "Instant Poison VI",
			["Texture"] = 132273,
		},
		[10920] = {
			["Name"] = "Wound Poison II",
			["Texture"] = 132274,
		},
		[8984] = {
			["Name"] = "Deadly Poison III",
			["Texture"] = 132290,
		},
		[2862] = {
			["Name"] = "Rough Sharpening Stone",
			["Texture"] = 135248,
		},
		[7965] = {
			["Name"] = "Solid Weightstone",
			["Texture"] = 135258,
		},
		[10921] = {
			["Name"] = "Wound Poison III",
			["Texture"] = 132274,
		},
		[3240] = {
			["Name"] = "Coarse Weightstone",
			["Texture"] = 135256,
		},
		[18262] = {
			["Name"] = "Elemental Sharpening Stone",
			["Texture"] = 135228,
		},
		[6949] = {
			["Name"] = "Instant Poison II",
			["Texture"] = 132273,
		},
		[9186] = {
			["Name"] = "Mind-numbing Poison III",
			["Texture"] = 136066,
		},
		[3775] = {
			["Name"] = "Crippling Poison",
			["Texture"] = 132274,
		},
		[12643] = {
			["Name"] = "Dense Weightstone",
			["Texture"] = 135259,
		},
		[8985] = {
			["Name"] = "Deadly Poison IV",
			["Texture"] = 132290,
		},
		[10918] = {
			["Name"] = "Wound Poison",
			["Texture"] = 132274,
		},
		[5237] = {
			["Name"] = "Mind-numbing Poison",
			["Texture"] = 136066,
		},
		[10922] = {
			["Name"] = "Wound Poison IV",
			["Texture"] = 132274,
		},
		[12404] = {
			["Name"] = "Dense Sharpening Stone",
			["Texture"] = 135252,
		},
		[2893] = {
			["Name"] = "Deadly Poison II",
			["Texture"] = 132290,
		},
		[2892] = {
			["Name"] = "Deadly Poison",
			["Texture"] = 132290,
		},
		[20844] = {
			["Name"] = "Deadly Poison V",
			["Texture"] = 132290,
		},
	},
	["StartedOnce"] = 1,
	["Buy"] = {
		["Active"] = 1,
		["WP"] = 0,
		["DP"] = 0,
		["MP"] = 0,
		["Check"] = 1,
		["Prompt"] = 0,
		["CP"] = 0,
		["IP"] = 0,
	},
}

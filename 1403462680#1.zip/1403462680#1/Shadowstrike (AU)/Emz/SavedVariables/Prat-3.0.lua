
Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["scrollback"] = {
		["ChatFrame5"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame10"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 11,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714108501,
					["r"] = 1,
				}, -- [1]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["b"] = 0,
					["r"] = 1,
					["serverTime"] = 1714108523,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [2]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["g"] = 1,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 27625.47,
					["serverTime"] = 1714108880,
					["b"] = 0,
				}, -- [3]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["b"] = 0,
					["serverTime"] = 1714109019,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [4]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714109827,
					["r"] = 1,
				}, -- [5]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["b"] = 0,
					["r"] = 1,
					["serverTime"] = 1714114083,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [6]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["g"] = 1,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114200,
					["b"] = 0,
				}, -- [7]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["serverTime"] = 1714133350,
					["r"] = 1,
					["b"] = 0,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [8]
				{
					["message"] = "0 days, 0 hours, 0 minutes, 0 seconds",
					["timestamp"] = 27625.47,
				}, -- [9]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 27625.47,
				}, -- [10]
				{
					["message"] = "Speech to text allows you to add closed captioning in a voice channel.",
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 27605.592,
					["g"] = 1,
					["b"] = 0,
				}, -- [11]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame7"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame6"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame8"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 110,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[22:08:01]|h|r Guild Message of the Day: The Deli is open to everyone -Check Discord for raid signups- https://discord.gg/VNUAdDqZYj msg Punkx/Feralpunk/Ðëmøñ for info",
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714108501,
					["r"] = 0.250980406999588,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:14:53]|h|r Guild Message of the Day: RAID WED AND SUN - 7.30ST PULL! - msg Punkx/Feralpunk for info! Discord -> https://discord.gg/5sFkRfXV4p",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["serverTime"] = 1714108523,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:15:15]|h|r Guild Message of the Day: RAID WED AND SUN - 7.30ST PULL! - msg Punkx/Feralpunk for info! Discord -> https://discord.gg/5sFkRfXV4p",
					["g"] = 1,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 27625.47,
					["serverTime"] = 1714108880,
					["b"] = 0.250980406999588,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:21:11]|h|r Guild Message of the Day: RAID WED AND SUN - 7.30ST PULL! - msg Punkx/Feralpunk for info! Discord -> https://discord.gg/5sFkRfXV4p",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["serverTime"] = 1714109019,
					["timestamp"] = 27625.47,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:23:30]|h|r Guild Message of the Day: RAID WED AND SUN - 7.30ST PULL! - msg Punkx/Feralpunk for info! Discord -> https://discord.gg/5sFkRfXV4p",
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714109827,
					["r"] = 0.250980406999588,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:36:58]|h|r Guild Message of the Day: RAID WED AND SUN - 7.30ST PULL! - msg Punkx/Feralpunk for info! Discord -> https://discord.gg/5sFkRfXV4p",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["serverTime"] = 1714114083,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:44:53]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Ajayani-Shadowstrike(AU):427:GUILD|h|cffd88b6550|r:|cffaad372Ajayani|r|h|cffd8d8d8]|r: [NWB] Ashenvale event starts in 15 minutes.",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						5, -- [1]
						35, -- [2]
						36, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110301,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:09:50]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Ðëmøñ-Shadowstrike(AU):1049:GUILD|h|cff65b26542|r:|cff8787edÐëmøñ|r|h|cffd8d8d8]|r: anyone wanna do gnomer?",
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						5, -- [1]
						35, -- [2]
						86, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111798,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:47:54]|h|r Guild Message of the Day: RAID WED AND SUN - 7.30ST PULL! - msg Punkx/Feralpunk for info! Discord -> https://discord.gg/5sFkRfXV4p",
					["g"] = 1,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114200,
					["b"] = 0.250980406999588,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:49:52]|h|r Guild Message of the Day: RAID WED AND SUN - 7.30ST PULL! - msg Punkx/Feralpunk for info! Discord -> https://discord.gg/5sFkRfXV4p",
					["serverTime"] = 1714133350,
					["r"] = 0.250980406999588,
					["b"] = 0.250980406999588,
					["timestamp"] = 27625.47,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["g"] = 1,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:59:47]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Deathawaìts-Shadowstrike(AU):1635:GUILD|h|cff8b8b8b35|r:|cffaad372Deathawaìts|r|h|cffd8d8d8]|r: anyone want to tank SM",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114795,
					["extraData"] = {
						5, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:59:52]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Deathawaìts-Shadowstrike(AU):1640:GUILD|h|cff8b8b8b35|r:|cffaad372Deathawaìts|r|h|cffd8d8d8]|r: starting lib",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114800,
					["extraData"] = {
						5, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:16:18]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Ðëmøñ-Shadowstrike(AU):1853:GUILD|h|cff65b26542|r:|cff8787edÐëmøñ|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|tCritMatic: New highest crit hit for Cleave: 207",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115786,
					["extraData"] = {
						5, -- [1]
						19, -- [2]
						31, -- [3]
						["n"] = 3,
					},
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:29:53]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Ajayani-Shadowstrike(AU):2036:GUILD|h|cffd88b6550|r:|cffaad372Ajayani|r|h|cffd8d8d8]|r: [NWB] Stranglethorn event starts in 30 minutes.",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116601,
					["extraData"] = {
						5, -- [1]
						19, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:35:30]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Ðëmøñ-Shadowstrike(AU):2103:GUILD|h|cff65b26542|r:|cff8787edÐëmøñ|r|h|cffd8d8d8]|r: anyone wanna do gnomer?",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116938,
					["extraData"] = {
						5, -- [1]
						19, -- [2]
						31, -- [3]
						["n"] = 3,
					},
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:38:56]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Ðëmøñ-Shadowstrike(AU):2156:GUILD|h|cff65b26542|r:|cff8787edÐëmøñ|r|h|cffd8d8d8]|r: LF3M GNOMER TANK + HEALS",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117144,
					["extraData"] = {
						5, -- [1]
						19, -- [2]
						31, -- [3]
						["n"] = 3,
					},
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:40:27]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Ghuldamn-Shadowstrike(AU):2183:GUILD|h|cff8b8b8b38|r:|cff8787edGhuldamn|r|h|cffd8d8d8]|r: LF3M HEALS,DPS SM ARM",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117235,
					["extraData"] = {
						5, -- [1]
						19, -- [2]
						42, -- [3]
						["n"] = 3,
					},
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:42:39]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Ðëmøñ-Shadowstrike(AU):2231:GUILD|h|cff65b26542|r:|cff8787edÐëmøñ|r|h|cffd8d8d8]|r: LF3M GNOMER TANK + HEALS",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117367,
					["extraData"] = {
						5, -- [1]
						19, -- [2]
						31, -- [3]
						["n"] = 3,
					},
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:43:59]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Btlheals-Shadowstrike(AU):2252:GUILD|h|cffd8d83f50|r:|cffffffffBtlheals|r|h|cffd8d8d8]|r: has the bg dmg reduction happened yet?",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117447,
					["extraData"] = {
						5, -- [1]
						19, -- [2]
						45, -- [3]
						["n"] = 3,
					},
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:44:17]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Btlheals-Shadowstrike(AU):2260:GUILD|h|cffd8d83f50|r:|cffffffffBtlheals|r|h|cffd8d8d8]|r: slam and chop alwasys do shit dps so i cant tell",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117465,
					["extraData"] = {
						5, -- [1]
						19, -- [2]
						45, -- [3]
						["n"] = 3,
					},
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:44:53]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Ajayani-Shadowstrike(AU):2272:GUILD|h|cffd8d83f50|r:|cffaad372Ajayani|r|h|cffd8d8d8]|r: [NWB] Stranglethorn event starts in 15 minutes.",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117501,
					["extraData"] = {
						5, -- [1]
						19, -- [2]
						35, -- [3]
						["n"] = 3,
					},
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:47:45]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Ðëmøñ-Shadowstrike(AU):2313:GUILD|h|cff65b26542|r:|cff8787edÐëmøñ|r|h|cffd8d8d8]|r: |cffa335ee|Hitem:220590::::::::42:::::::::|h[Spire of Hakkari Worship]|h|r",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117673,
					["extraData"] = {
						5, -- [1]
						19, -- [2]
						31, -- [3]
						["n"] = 3,
					},
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:49:20]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Prepvanish-Shadowstrike(AU):2338:GUILD|h|cffd8d83f50|r:|cfffff468Prepvanish|r|h|cffd8d8d8]|r: @btl starts late tonight/early morning",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117768,
					["extraData"] = {
						5, -- [1]
						19, -- [2]
						52, -- [3]
						["n"] = 3,
					},
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:49:28]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Btlheals-Shadowstrike(AU):2342:GUILD|h|cffd8d83f50|r:|cffffffffBtlheals|r|h|cffd8d8d8]|r: cheers bro",
					["b"] = 0.250980406999588,
					["r"] = 0.250980406999588,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117776,
					["extraData"] = {
						5, -- [1]
						19, -- [2]
						45, -- [3]
						["n"] = 3,
					},
				}, -- [24]
				{
					["message"] = "0 days, 4 hours, 19 minutes, 34 seconds",
					["timestamp"] = 27625.47,
				}, -- [25]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 27625.47,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:01]|h|r Guild Message of the Day: RAID WED AND SUN - 7.30ST PULL! - msg Punkx/Feralpunk for info! Discord -> https://discord.gg/5sFkRfXV4p",
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 27625.174,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:14:54]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Feralpunk-Shadowstrike(AU):98:GUILD|h|cffd8d83f50|r:|cffff7c0aFeralpunk|r|h|cffd8d8d8]|r: someone msg |cff0070ddsontre|r on disc, a botter got his account",
					["serverTime"] = 1714133702,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						39, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27978.308,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:14:56]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Feralpunk-Shadowstrike(AU):99:GUILD|h|cffd8d83f50|r:|cffff7c0aFeralpunk|r|h|cffd8d8d8]|r: hes online",
					["serverTime"] = 1714133704,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						39, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27980.323,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:14:59]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Yttam-Shadowstrike(AU):102:GUILD|h|cffd8d83f50|r:|cff3fc6eaYttam|r|h|cffd8d8d8]|r: sontreeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
					["serverTime"] = 1714133707,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						40, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27982.765,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:02]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Sontre-Shadowstrike(AU):103:GUILD|h|cffd8d83f50|r:|cff0070ddSontre|r|h|cffd8d8d8]|r: lol",
					["serverTime"] = 1714133710,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						41, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27985.589,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:05]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Sontre-Shadowstrike(AU):105:GUILD|h|cffd8d83f50|r:|cff0070ddSontre|r|h|cffd8d8d8]|r: fuck up",
					["serverTime"] = 1714133713,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						41, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27989.113,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:09]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Feralpunk-Shadowstrike(AU):107:GUILD|h|cffd8d83f50|r:|cffff7c0aFeralpunk|r|h|cffd8d8d8]|r: woah",
					["serverTime"] = 1714133717,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						39, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27993.114,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:14]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Yttam-Shadowstrike(AU):109:GUILD|h|cffd8d83f50|r:|cff3fc6eaYttam|r|h|cffd8d8d8]|r: and hes fiesty",
					["serverTime"] = 1714133722,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						40, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27997.911,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:16]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Yttam-Shadowstrike(AU):111:GUILD|h|cffd8d83f50|r:|cff3fc6eaYttam|r|h|cffd8d8d8]|r: reow",
					["serverTime"] = 1714133724,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						40, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27999.35,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:19]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Sontre-Shadowstrike(AU):113:GUILD|h|cffd8d83f50|r:|cff0070ddSontre|r|h|cffd8d8d8]|r: sending ur stuff",
					["serverTime"] = 1714133727,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						41, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28002.611,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:31]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Sontre-Shadowstrike(AU):120:GUILD|h|cffd8d83f50|r:|cff0070ddSontre|r|h|cffd8d8d8]|r: im not even making gold",
					["serverTime"] = 1714133739,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						41, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28015.149,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:32]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Assistance-Shadowstrike(AU):121:GUILD|h|cffd8d83f50|r:|cffff7c0aAssistance|r|h|cffd8d8d8]|r: hi |cff0070ddsontre|r :)",
					["serverTime"] = 1714133740,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						43, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28015.64,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:35]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Sontre-Shadowstrike(AU):124:GUILD|h|cffd8d83f50|r:|cff0070ddSontre|r|h|cffd8d8d8]|r: bneing afk from wow sadge",
					["serverTime"] = 1714133743,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						41, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28018.637,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:45]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Yttam-Shadowstrike(AU):129:GUILD|h|cffd8d83f50|r:|cff3fc6eaYttam|r|h|cffd8d8d8]|r: what a loser",
					["serverTime"] = 1714133753,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						40, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28028.646,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:48]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Assistance-Shadowstrike(AU):131:GUILD|h|cffd8d83f50|r:|cffff7c0aAssistance|r|h|cffd8d8d8]|r: have u quit",
					["serverTime"] = 1714133756,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						43, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28031.895,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:53]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Sontre-Shadowstrike(AU):135:GUILD|h|cffd8d83f50|r:|cff0070ddSontre|r|h|cffd8d8d8]|r: i know",
					["serverTime"] = 1714133761,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						41, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28036.789,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:16:06]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Feralpunk-Shadowstrike(AU):140:GUILD|h|cffd8d83f50|r:|cffff7c0aFeralpunk|r|h|cffd8d8d8]|r: are you chopping trees too?",
					["serverTime"] = 1714133774,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						39, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28049.868,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:16:10]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Feralpunk-Shadowstrike(AU):143:GUILD|h|cffd8d83f50|r:|cffff7c0aFeralpunk|r|h|cffd8d8d8]|r: a bit tired?",
					["serverTime"] = 1714133778,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						39, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28053.868,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:16:19]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Yttam-Shadowstrike(AU):153:GUILD|h|cffd8d83f50|r:|cff3fc6eaYttam|r|h|cffd8d8d8]|r: @ghardd",
					["serverTime"] = 1714133787,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						40, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28063.246,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:16:35]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):158:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: suck my willy I chopped trees for 10hrs today",
					["serverTime"] = 1714133803,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28079.075,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:16:44]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Mindnumbing-Shadowstrike(AU):165:GUILD|h|cffd8d83f50|r:|cfffff468Mindnumbing|r|h|cffd8d8d8]|r: chainsaw or hand",
					["serverTime"] = 1714133812,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						51, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28087.815,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:16:55]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Yttam-Shadowstrike(AU):170:GUILD|h|cffd8d83f50|r:|cff3fc6eaYttam|r|h|cffd8d8d8]|r: ur a big lumberjack now its kinda hot",
					["serverTime"] = 1714133823,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						40, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28098.396,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [48]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:04]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Yttam-Shadowstrike(AU):172:GUILD|h|cffd8d83f50|r:|cff3fc6eaYttam|r|h|cffd8d8d8]|r: did u pick a flanno colour yet",
					["serverTime"] = 1714133832,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						40, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28107.931,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [49]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:12]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Btlheals-Shadowstrike(AU):176:GUILD|h|cffd8d83f50|r:|cffffffffBtlheals|r|h|cffd8d8d8]|r: what trees we talkin here ghaard",
					["serverTime"] = 1714133840,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						52, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28115.41,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [50]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:22]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):181:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: shirtless",
					["serverTime"] = 1714133850,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28125.37,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [51]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:25]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Feralpunk-Shadowstrike(AU):183:GUILD|h|cffd8d83f50|r:|cffff7c0aFeralpunk|r|h|cffd8d8d8]|r: house plants",
					["serverTime"] = 1714133853,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						39, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28128.45,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [52]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:26]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Assistance-Shadowstrike(AU):185:GUILD|h|cffd8d83f50|r:|cffff7c0aAssistance|r|h|cffd8d8d8]|r: yew trees",
					["serverTime"] = 1714133854,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						43, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28129.517,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [53]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:26]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):186:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: shows of my 1 pack",
					["serverTime"] = 1714133854,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28130.25,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [54]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:29]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Yttam-Shadowstrike(AU):189:GUILD|h|cffd8d83f50|r:|cff3fc6eaYttam|r|h|cffd8d8d8]|r: lets go",
					["serverTime"] = 1714133857,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						40, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28132.663,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [55]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:35]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Btlheals-Shadowstrike(AU):194:GUILD|h|cffd8d83f50|r:|cffffffffBtlheals|r|h|cffd8d8d8]|r: lame",
					["serverTime"] = 1714133863,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						52, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28139.253,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [56]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:42]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Assistance-Shadowstrike(AU):207:GUILD|h|cffd8d83f50|r:|cffff7c0aAssistance|r|h|cffd8d8d8]|r: some magic",
					["serverTime"] = 1714133870,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						43, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28145.92,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [57]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:54]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Mindnumbing-Shadowstrike(AU):214:GUILD|h|cffd8d83f50|r:|cfffff468Mindnumbing|r|h|cffd8d8d8]|r: he'd be lucky to cut an oak down bruv",
					["serverTime"] = 1714133882,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						51, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28157.691,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [58]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:56]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Btlheals-Shadowstrike(AU):216:GUILD|h|cffd8d83f50|r:|cffffffffBtlheals|r|h|cffd8d8d8]|r: thats whAT I WAS AFTER",
					["serverTime"] = 1714133884,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						52, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28159.352,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [59]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:18:16]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Btlheals-Shadowstrike(AU):221:GUILD|h|cffd8d83f50|r:|cffffffffBtlheals|r|h|cffd8d8d8]|r: i thought he was cool for a sex",
					["serverTime"] = 1714133904,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						52, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28180.181,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [60]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:18:19]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Btlheals-Shadowstrike(AU):222:GUILD|h|cffd8d83f50|r:|cffffffffBtlheals|r|h|cffd8d8d8]|r: sec*",
					["serverTime"] = 1714133907,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						52, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28182.404,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [61]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:18:21]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Btlheals-Shadowstrike(AU):224:GUILD|h|cffd8d83f50|r:|cffffffffBtlheals|r|h|cffd8d8d8]|r: nvm",
					["serverTime"] = 1714133909,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						52, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28184.423,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [62]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:18:22]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Vivekk-Shadowstrike(AU):226:GUILD|h|cff8b8b8b31|r:|cffff7c0aVivekk|r|h|cffd8d8d8]|r: anyone wanna do an RFK?",
					["serverTime"] = 1714133910,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28186.194,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [63]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:18:40]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):242:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: what are you cunts even saying",
					["serverTime"] = 1714133928,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28204.143,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [64]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:18:57]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):249:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: must be tired, from all my wood cutting",
					["serverTime"] = 1714133945,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28221.18,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [65]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:19:00]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):252:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: cant read",
					["serverTime"] = 1714133948,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28223.593,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [66]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:19:18]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Assistance-Shadowstrike(AU):260:GUILD|h|cffd8d83f50|r:|cffff7c0aAssistance|r|h|cffd8d8d8]|r: are you allowed to use a saw",
					["serverTime"] = 1714133966,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						43, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28241.558,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [67]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:19:27]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Assistance-Shadowstrike(AU):265:GUILD|h|cffd8d83f50|r:|cffff7c0aAssistance|r|h|cffd8d8d8]|r: or you brooming up the bark",
					["serverTime"] = 1714133975,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						43, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28251.004,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [68]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:19:34]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):267:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: yeah I sit there with an ol school wood saw",
					["serverTime"] = 1714133982,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28257.574,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [69]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:19:41]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):269:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: takes me 1 whole day to cut a tree",
					["serverTime"] = 1714133989,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28265.173,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [70]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:20:24]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Slamnshamn-Shadowstrike(AU):282:GUILD|h|cffd8d83f50|r:|cff0070ddSlamnshamn|r|h|cffd8d8d8]|r: you should probably work on your efficiency",
					["serverTime"] = 1714134032,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						67, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28308.023,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [71]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:20:48]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Btlheals-Shadowstrike(AU):289:GUILD|h|cffd8d83f50|r:|cffffffffBtlheals|r|h|cffd8d8d8]|r: thats allways a thing",
					["serverTime"] = 1714134056,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						52, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28332.188,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [72]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:20:51]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):290:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: not all of us can fel 10 trees with a single explosive arrow",
					["serverTime"] = 1714134059,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28334.434,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [73]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:20:56]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):292:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: they dont call him |cffc69b6dchopin|r for nothing",
					["serverTime"] = 1714134064,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28340.198,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [74]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:20:57]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Slamnshamn-Shadowstrike(AU):293:GUILD|h|cffd8d83f50|r:|cff0070ddSlamnshamn|r|h|cffd8d8d8]|r: pussy",
					["serverTime"] = 1714134065,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						67, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28340.903,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [75]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:20:59]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Btlheals-Shadowstrike(AU):296:GUILD|h|cffd8d83f50|r:|cffffffffBtlheals|r|h|cffd8d8d8]|r: punk told me for years now they have been tring",
					["serverTime"] = 1714134067,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						52, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28343.117,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [76]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:21:29]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Dorathy-Shadowstrike(AU):303:GUILD|h|cffd8d83f50|r:|cffaad372Dorathy|r|h|cffd8d8d8]|r: what",
					["serverTime"] = 1714134097,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						74, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28373.012,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [77]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:21:32]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Dorathy-Shadowstrike(AU):304:GUILD|h|cffd8d83f50|r:|cffaad372Dorathy|r|h|cffd8d8d8]|r: fuck yuou",
					["serverTime"] = 1714134100,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						74, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28375.916,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [78]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:21:35]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):305:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: lmao",
					["serverTime"] = 1714134103,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28379.28,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [79]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:21:38]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Slamnshamn-Shadowstrike(AU):306:GUILD|h|cffd8d83f50|r:|cff0070ddSlamnshamn|r|h|cffd8d8d8]|r: owned ghard",
					["serverTime"] = 1714134106,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						67, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28381.726,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [80]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:21:41]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Mindnumbing-Shadowstrike(AU):309:GUILD|h|cffd8d83f50|r:|cfffff468Mindnumbing|r|h|cffd8d8d8]|r: efc ramp",
					["serverTime"] = 1714134109,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						51, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28384.887,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [81]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:22:15]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Slamnshamn-Shadowstrike(AU):312:GUILD|h|cffd8d83f50|r:|cff0070ddSlamnshamn|r|h|cffd8d8d8]|r: ghard come a bg you puss",
					["serverTime"] = 1714134143,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						67, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28418.597,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [82]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:22:18]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Macaunewpj-Shadowstrike(AU):314:GUILD|h|cff8b8b8b21|r:|cffffffffMacaunewpj|r|h|cffd8d8d8]|r: LFM WC, need 1 TANK",
					["serverTime"] = 1714134146,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						77, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28421.469,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [83]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:22:27]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Dorathy-Shadowstrike(AU):316:GUILD|h|cffd8d83f50|r:|cffaad372Dorathy|r|h|cffd8d8d8]|r: can you pvp?",
					["serverTime"] = 1714134155,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						74, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28430.62,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [84]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:22:40]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):317:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: farming gloves",
					["serverTime"] = 1714134168,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28443.43,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [85]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:22:52]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Dorathy-Shadowstrike(AU):323:GUILD|h|cffd8d83f50|r:|cffaad372Dorathy|r|h|cffd8d8d8]|r: |cff0070dd|Hitem:220830:1887:::::::50:::::::::|h[First Sergeant's Chain Gauntlets]|h|r?",
					["serverTime"] = 1714134180,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						74, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28455.683,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [86]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:05]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Slamnshamn-Shadowstrike(AU):327:GUILD|h|cffd8d83f50|r:|cff0070ddSlamnshamn|r|h|cffd8d8d8]|r: yeah we get those in wsg",
					["serverTime"] = 1714134193,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						67, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28468.428,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [87]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:06]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Slamnshamn-Shadowstrike(AU):328:GUILD|h|cffd8d83f50|r:|cff0070ddSlamnshamn|r|h|cffd8d8d8]|r: lets go",
					["serverTime"] = 1714134194,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						67, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28469.503,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [88]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:08]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):329:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: what rank are you?",
					["serverTime"] = 1714134196,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28471.428,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [89]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:17]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Dorathy-Shadowstrike(AU):334:GUILD|h|cffd8d83f50|r:|cffaad372Dorathy|r|h|cffd8d8d8]|r: 8",
					["serverTime"] = 1714134205,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						74, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28480.801,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [90]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:21]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):336:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: oh yeah?",
					["serverTime"] = 1714134209,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28485.075,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [91]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:22]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Slamnshamn-Shadowstrike(AU):337:GUILD|h|cffd8d83f50|r:|cff0070ddSlamnshamn|r|h|cffd8d8d8]|r: hwl",
					["serverTime"] = 1714134210,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						67, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28486.241,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [92]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:27]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):338:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: whats your pvp rep @?",
					["serverTime"] = 1714134215,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28491.098,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [93]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:37]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Dorathy-Shadowstrike(AU):342:GUILD|h|cffd8d83f50|r:|cffaad372Dorathy|r|h|cffd8d8d8]|r: yeah pretty sure",
					["serverTime"] = 1714134225,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						74, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28500.472,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [94]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:46]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Slamnshamn-Shadowstrike(AU):344:GUILD|h|cffd8d83f50|r:|cff0070ddSlamnshamn|r|h|cffd8d8d8]|r: exalted",
					["serverTime"] = 1714134234,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						67, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28509.573,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [95]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:54]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Dorathy-Shadowstrike(AU):349:GUILD|h|cffd8d83f50|r:|cffaad372Dorathy|r|h|cffd8d8d8]|r: the one after exalted",
					["serverTime"] = 1714134242,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						74, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28518.178,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [96]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:56]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):350:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: natrually",
					["serverTime"] = 1714134244,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28519.99,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [97]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:24:06]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Slamnshamn-Shadowstrike(AU):354:GUILD|h|cffd8d83f50|r:|cff0070ddSlamnshamn|r|h|cffd8d8d8]|r: yeah im trying to catch up to chop",
					["serverTime"] = 1714134254,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						67, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28529.597,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [98]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:24:07]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):355:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: exalted 999?",
					["serverTime"] = 1714134255,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28531.133,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [99]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:24:25]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Dorathy-Shadowstrike(AU):358:GUILD|h|cffd8d83f50|r:|cffaad372Dorathy|r|h|cffd8d8d8]|r: i got 1000",
					["serverTime"] = 1714134273,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						74, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28549.073,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [100]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:24:37]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):360:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: secret tech?",
					["serverTime"] = 1714134285,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28561.234,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [101]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:24:42]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Slamnshamn-Shadowstrike(AU):362:GUILD|h|cffd8d83f50|r:|cff0070ddSlamnshamn|r|h|cffd8d8d8]|r: server first",
					["serverTime"] = 1714134290,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						67, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28565.434,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [102]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:24:43]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Btlheals-Shadowstrike(AU):363:GUILD|h|cffd8d83f50|r:|cffffffffBtlheals|r|h|cffd8d8d8]|r: he got an email",
					["serverTime"] = 1714134291,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						52, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28566.855,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [103]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:24:46]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Notgharrd-Shadowstrike(AU):366:GUILD|h|cffd8d83f50|r:|cffc69b6dNotgharrd|r|h|cffd8d8d8]|r: does softlocking hakkar unlock that?",
					["serverTime"] = 1714134294,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						48, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28570.258,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [104]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:24:48]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Btlheals-Shadowstrike(AU):367:GUILD|h|cffd8d83f50|r:|cffffffffBtlheals|r|h|cffd8d8d8]|r: deserved it apparently",
					["serverTime"] = 1714134296,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						52, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28572.065,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [105]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:24:51]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Dorathy-Shadowstrike(AU):368:GUILD|h|cffd8d83f50|r:|cffaad372Dorathy|r|h|cffd8d8d8]|r: did it no deaths",
					["serverTime"] = 1714134299,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						74, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28574.525,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [106]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:24:52]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Slamnshamn-Shadowstrike(AU):369:GUILD|h|cffd8d83f50|r:|cff0070ddSlamnshamn|r|h|cffd8d8d8]|r: join his discord. like and subscribe to his youtube",
					["serverTime"] = 1714134300,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						67, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28576.324,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [107]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:24:55]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Slamnshamn-Shadowstrike(AU):371:GUILD|h|cffd8d83f50|r:|cff0070ddSlamnshamn|r|h|cffd8d8d8]|r: and you can find out",
					["serverTime"] = 1714134303,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						67, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28578.979,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [108]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:35:49]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Vivekk-Shadowstrike(AU):498:GUILD|h|cff8b8b8b31|r:|cffff7c0aVivekk|r|h|cffd8d8d8]|r: LF heals + DPS for RFK",
					["serverTime"] = 1714134957,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 29232.864,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [109]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:36:08]|h|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Tutudots-Shadowstrike(AU):500:GUILD|h|cff65b26542|r:|cff0070ddTutudots|r|h|cffd8d8d8]|r: i can heal",
					["serverTime"] = 1714134976,
					["r"] = 0.250980406999588,
					["extraData"] = {
						5, -- [1]
						38, -- [2]
						97, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 29251.343,
					["g"] = 1,
					["b"] = 0.250980406999588,
				}, -- [110]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame9"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 672,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["ReverseEnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[15:15:46]|h|r |cff0070ddGrimtog|r has gone offline.",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1714108554,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["r"] = 1,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:16:36]|h|r |cffc69b6dBuffdaddyxd|r has gone offline.",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1714108604,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["r"] = 1,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:17:53]|h|r |cffaad372Ikari|r has gone offline.",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1714108681,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["r"] = 1,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:18:44]|h|r |cffd8d8d8[|r|Hplayer:Tankmt:27|h|cff65b26543|r:|cffff7c0aTankmt|r|h|cffd8d8d8]|r has come online.",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1714108732,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["r"] = 1,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:18:49]|h|r |cffaad372Fiftypercent|r has gone offline.",
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1714108737,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["r"] = 1,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:21:23]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Chase:46:CHANNEL:1|h|cff0070ddChase|r|h|cffd8d8d8]|r: lf inc group",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714108891,
					["extraData"] = {
						69, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:22:47]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Xenojin:54:CHANNEL:1|h|cfffff468Xenojin|r|h|cffd8d8d8]|r: whos got jamniss",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714108975,
					["extraData"] = {
						69, -- [1]
						1, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:23:03]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Ragecage:55:CHANNEL:1|h|cff0070ddRagecage|r|h|cffd8d8d8]|r: lfg inc",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714108991,
					["extraData"] = {
						69, -- [1]
						1, -- [2]
						6, -- [3]
						["n"] = 3,
					},
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:23:07]|h|r |cff8787edRflegend|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714108995,
					["extraData"] = {
						1, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:23:10]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Milkmyhorns-Shadowstrike(AU):57:CHANNEL:1|h|cffff7c0aMilkmyhorns|r|h|cffd8d8d8]|r: same",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714108998,
					["extraData"] = {
						69, -- [1]
						1, -- [2]
						10, -- [3]
						["n"] = 3,
					},
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:23:32]|h|r |cffaad372Kradle|r has gone offline.",
					["serverTime"] = 1714109020,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27625.47,
					["g"] = 1,
					["b"] = 0,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:23:52]|h|r |cffd8d8d8[|r|Hplayer:Ajayani:68|h|cffd88b6550|r:|cffaad372Ajayani|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714109040,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27625.47,
					["g"] = 1,
					["b"] = 0,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:23:53]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Chase-Shadowstrike(AU):69:CHANNEL:1|h|cff0070ddChase|r|h|cffd8d8d8]|r: lfm feralas inc",
					["serverTime"] = 1714109041,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27625.47,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:24:14]|h|r |cffc69b6dSdxcs|r has gone offline.",
					["serverTime"] = 1714109062,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27625.47,
					["g"] = 1,
					["b"] = 0,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:24:40]|h|r You create: |cffffffff|Hitem:8075::::::::47:::::::::|h[Conjured Sourdough]|h|rx12.",
					["serverTime"] = 1714109088,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27625.47,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:24:43]|h|r You create: |cffffffff|Hitem:8077::::::::47:::::::::|h[Conjured Mineral Water]|h|rx20.",
					["serverTime"] = 1714109091,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						6, -- [2]
						7, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27625.47,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:10]|h|r Type '/help' for a listing of a few commands.",
					["serverTime"] = 1714109118,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 27625.47,
					["g"] = 1,
					["b"] = 0,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:32]|h|r |Hchannel:channel:1|h[1] |h Left Channel: |Hchannel:CHANNEL:1|h[1. General - Feralas]|h",
					["serverTime"] = 1714109140,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						3, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27625.47,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:25:32]|h|r |Hchannel:channel:3|h[3] |h Left Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Feralas]|h",
					["serverTime"] = 1714109140,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27625.47,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:37:45]|h|r Longtooth Howler calls for help!",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.501960813999176,
					["timestamp"] = 27625.47,
					["extraData"] = {
						17, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714109873,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:37:47]|h|r |cffc69b6dBeezos|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714109875,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:37:48]|h|r You receive loot: |cffffffff|Hitem:12203::::::::47:::::::::|h[Red Wolf Meat]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714109876,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:37:48]|h|r You receive loot: |cffffffff|Hitem:8146::::::::47:::::::::|h[Wicked Claw]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714109876,
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:38:03]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Orgrimmar]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714109891,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:38:03]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Orgrimmar]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714109891,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:38:40]|h|r |cff0070ddPeely|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714109928,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:38:44]|h|r |cffd8d8d8[|r|Hplayer:Quer:98|h|cff8b8b8b24|r:|cfffff468Quer|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714109932,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:38:47]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Morthanas:99:CHANNEL:3|h|cffff7c0aMorthanas|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|tENCHANTER LFW @ ORG. Most p3 enchants such as Gloves:- Riding Skill, +7 Agi. Boots:- Speed, +7 Agi. Weapon:- Fiery, +15 str and agi, +20 spirit. 2H:- +25 Agi. Your mats. If you wish, whisper '|cffffff00|Hinvplr:Morthanas|h[inv]|h|r' for instant |cffffff00|Hinvplr:Morthanas|h[invite]|h|r|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714109935,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:38:47]|h|r [Y] |cffd8d8d8[|r|Hplayer:Morthanas-Shadowstrike(AU):100:YELL|h|cffff7c0aMorthanas|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|tENCHANTER LFW @ ORG. Most p3 enchants such as Gloves:- Riding Skill, +7 Agi. Boots:- Speed, +7 Agi. Weapon:- Fiery, +15 str and agi, +20 spirit. 2H:- +25 Agi. Your mats. If you wish, whisper '|cffffff00|Hinvplr:Morthanas-Shadowstrike(AU)|h[inv]|h|r' for instant |cffffff00|Hinvplr:Morthanas-Shadowstrike(AU)|h[invite]|h|r|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 27625.47,
					["extraData"] = {
						7, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714109935,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:39:02]|h|r |cffd8d8d8[|r|Hplayer:Peely:102|h|cffd88b6550|r:|cff0070ddPeely|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714109950,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:39:44]|h|r |cffaad372Snipegodx|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714109992,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:39:50]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):127:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: LF6M Sunken Temple Need 1 Tank 2 Healer 3 Melee DPS (8/8) Guild Run at 7pm SATURDAY - Need all (Experience, WBs, Consumes, Discord Mandatory) PST for more Details!",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714109998,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:40:14]|h|r |cffd8d8d8[|r|Hplayer:Enjoglove:145|h|cff8b8b8b24|r:|cfffff468Enjoglove|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110022,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:40:26]|h|r |cfffff468Enjoglove|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110034,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:40:30]|h|r |cffd8d8d8[|r|Hplayer:Cannonballer:162|h|cffd88b6550|r:|cffc69b6dCannonballer|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110038,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:40:44]|h|r |cffd8d8d8[|r|Hplayer:Rickgrime:177|h|cffd88b6550|r:|cffaad372Rickgrime|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110052,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:40:52]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Basilboy-Shadowstrike(AU):187:CHANNEL:2|h|cffffffffBasilboy|r|h|cffd8d8d8]|r: WTS |cffffffff|Hitem:14046::::::::50:::::::::|h[Runecloth Bag]|h|r 7g ea",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110060,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:40:54]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Qashgirl-Shadowstrike(AU):192:CHANNEL:2|h|cffffffffQashgirl|r|h|cffd8d8d8]|r: Any STs LF healer?",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						24, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110062,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:41:06]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Morthanas-Shadowstrike(AU):207:CHANNEL:3|h|cffff7c0aMorthanas|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|tENCHANTER LFW @ ORG. Most p3 enchants such as Gloves:- Riding Skill, +7 Agi. Boots:- Speed, +7 Agi. Weapon:- Fiery, +15 str and agi, +20 spirit. 2H:- +25 Agi. Your mats. If you wish, whisper '|cffffff00|Hinvplr:Morthanas-Shadowstrike(AU)|h[inv]|h|r' for instant |cffffff00|Hinvplr:Morthanas-Shadowstrike(AU)|h[invite]|h|r|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110074,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:41:06]|h|r [Y] |cffd8d8d8[|r|Hplayer:Morthanas-Shadowstrike(AU):208:YELL|h|cffff7c0aMorthanas|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|tENCHANTER LFW @ ORG. Most p3 enchants such as Gloves:- Riding Skill, +7 Agi. Boots:- Speed, +7 Agi. Weapon:- Fiery, +15 str and agi, +20 spirit. 2H:- +25 Agi. Your mats. If you wish, whisper '|cffffff00|Hinvplr:Morthanas-Shadowstrike(AU)|h[inv]|h|r' for instant |cffffff00|Hinvplr:Morthanas-Shadowstrike(AU)|h[invite]|h|r|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 27625.47,
					["extraData"] = {
						7, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110074,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:41:47]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):236:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: LF7M Sunken Temple Need 1 Tank 2 Healer 4 Melee DPS (8/8) Guild Run at 7pm SATURDAY - Need all (Experience, WBs, Consumes, Discord Mandatory) PST for more Details!",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110115,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:41:49]|h|r |cffffffffRiemensue|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110117,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:42:12]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Analgesic:256:CHANNEL:2|h|cffffffffAnalgesic|r|h|cffd8d8d8]|r: WTB |cff0070dd|Hitem:221279::::::::50:::::::::|h[Eight of Wilds]|h|r",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						26, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110140,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:42:31]|h|r |cff0070ddPeely|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110159,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:42:33]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Canadianeh-Shadowstrike(AU):279:CHANNEL:1|h|cff0070ddCanadianeh|r|h|cffd8d8d8]|r: WTB port to UC",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110161,
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:42:34]|h|r |cffd8d8d8[|r|Hplayer:Punkx:281|h|cffd88b6550|r:|cff0070ddPunkx|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110162,
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:42:40]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fugitive-Shadowstrike(AU):287:CHANNEL:2|h|cfffff468Fugitive|r|h|cffd8d8d8]|r: wtb of nightmares 5,6,8",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110168,
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:42:41]|h|r |cffd8d8d8[|r|Hplayer:Peely:288|h|cffd88b6550|r:|cff0070ddPeely|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110169,
				}, -- [48]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:43:03]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Canadianeh-Shadowstrike(AU):306:CHANNEL:2|h|cff0070ddCanadianeh|r|h|cffd8d8d8]|r: WTB port to UC from OG",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						32, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110191,
				}, -- [49]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:43:44]|h|r [Y] |cffd8d8d8[|r|Hplayer:Wewlol-Shadowstrike(AU):344:YELL|h|cffffffffWewlol|r|h|cffd8d8d8]|r: LF Enchanter",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 27625.47,
					["extraData"] = {
						7, -- [1]
						15, -- [2]
						34, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110232,
				}, -- [50]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:43:44]|h|r |cffd8d8d8[|r|Hplayer:Uuge:345|h|cff8b8b8b17|r:|cff0070ddUuge|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110232,
				}, -- [51]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:44:02]|h|r |cff0070ddUuge|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110250,
				}, -- [52]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:44:30]|h|r |cff0070ddPunkx|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110278,
				}, -- [53]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:44:37]|h|r |cffd8d8d8[|r|Hplayer:Punks:410|h|cff8b8b8b1|r:|cffc69b6dPunks|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110285,
				}, -- [54]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:44:52]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Canadianeh-Shadowstrike(AU):424:CHANNEL:1|h|cff0070ddCanadianeh|r|h|cffd8d8d8]|r: WTB port to UC",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110300,
				}, -- [55]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:45:00]|h|r |cffc69b6dCannonballer|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110308,
				}, -- [56]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:45:05]|h|r |cffd8d8d8[|r|Hplayer:Enjoglove:438|h|cff8b8b8b24|r:|cfffff468Enjoglove|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110313,
				}, -- [57]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:45:18]|h|r [Y] |cffd8d8d8[|r|Hplayer:Wewlol-Shadowstrike(AU):445:YELL|h|cffffffffWewlol|r|h|cffd8d8d8]|r: LF ENCHANTER",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 27625.47,
					["extraData"] = {
						7, -- [1]
						15, -- [2]
						34, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110326,
				}, -- [58]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:45:37]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):465:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: LF7M Sunken Temple Need 1 Tank 2 Healer 4 Melee DPS (8/8) Guild Run at 7pm SATURDAY - Need all (Experience, WBs, Consumes, Discord Mandatory) PST for more Details!",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110345,
				}, -- [59]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:46:06]|h|r [Y] |cffd8d8d8[|r|Hplayer:Qashgirl-Shadowstrike(AU):498:YELL|h|cffffffffQashgirl|r|h|cffd8d8d8]|r: LF lockpick",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 27625.47,
					["extraData"] = {
						7, -- [1]
						15, -- [2]
						37, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110374,
				}, -- [60]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:46:11]|h|r [Y] |cffd8d8d8[|r|Hplayer:Wewlol-Shadowstrike(AU):501:YELL|h|cffffffffWewlol|r|h|cffd8d8d8]|r: LF Enchanter",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 27625.47,
					["extraData"] = {
						7, -- [1]
						15, -- [2]
						34, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110379,
				}, -- [61]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:46:41]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Furyfeet-Shadowstrike(AU):533:CHANNEL:2|h|cffc69b6dFuryfeet|r|h|cffd8d8d8]|r: WTB |cff1eff00|Hitem:11737::::::::1:::::::::|h[Libram of Voracity]|h|r",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110409,
				}, -- [62]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:46:43]|h|r [S] |cffd8d8d8[|r|Hplayer:Matazma-Shadowstrike(AU):537:SAY|h|cfffff468Matazma|r|h|cffd8d8d8]|r: fml",
					["r"] = 1,
					["b"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						2, -- [1]
						40, -- [2]
						41, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110411,
				}, -- [63]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:46:44]|h|r |cffaad372Kql|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110412,
				}, -- [64]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:46:45]|h|r [S] |cffd8d8d8[|r|Hplayer:Matazma-Shadowstrike(AU):540:SAY|h|cfffff468Matazma|r|h|cffd8d8d8]|r: cant do that",
					["r"] = 1,
					["b"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						2, -- [1]
						40, -- [2]
						41, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110413,
				}, -- [65]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:46:54]|h|r [S] |cffd8d8d8[|r|Hplayer:Qashgirl-Shadowstrike(AU):550:SAY|h|cffffffffQashgirl|r|h|cffd8d8d8]|r: oh steel too high",
					["r"] = 1,
					["b"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						2, -- [1]
						40, -- [2]
						42, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110422,
				}, -- [66]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:46:55]|h|r You receive item: |cff0070dd|Hitem:13042::::::::47:::::::::|h[Sword of the Magistrate]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110423,
				}, -- [67]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:46:56]|h|r [S] |cffd8d8d8[|r|Hplayer:Matazma-Shadowstrike(AU):556:SAY|h|cfffff468Matazma|r|h|cffd8d8d8]|r: cant doi steel sorry",
					["r"] = 1,
					["b"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						2, -- [1]
						40, -- [2]
						41, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110424,
				}, -- [68]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:46:58]|h|r [S] |cffd8d8d8[|r|Hplayer:Matazma-Shadowstrike(AU):557:SAY|h|cfffff468Matazma|r|h|cffd8d8d8]|r: :(",
					["r"] = 1,
					["b"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						2, -- [1]
						40, -- [2]
						41, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110426,
				}, -- [69]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:47:02]|h|r |Hchannel:channel:3|h[3] |h|cffd8d8d8[|r|Hplayer:Morthanas-Shadowstrike(AU):563:CHANNEL:3|h|cffff7c0aMorthanas|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|tENCHANTER LFW @ ORG. Most p3 enchants such as Gloves:- Riding Skill, +7 Agi. Boots:- Speed, +7 Agi. Weapon:- Fiery, +15 str and agi, +20 spirit. 2H:- +25 Agi. Your mats. If you wish, whisper '|cffffff00|Hinvplr:Morthanas-Shadowstrike(AU)|h[inv]|h|r' for instant |cffffff00|Hinvplr:Morthanas-Shadowstrike(AU)|h[invite]|h|r|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						13, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110430,
				}, -- [70]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:47:02]|h|r [Y] |cffd8d8d8[|r|Hplayer:Morthanas-Shadowstrike(AU):564:YELL|h|cffff7c0aMorthanas|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|tENCHANTER LFW @ ORG. Most p3 enchants such as Gloves:- Riding Skill, +7 Agi. Boots:- Speed, +7 Agi. Weapon:- Fiery, +15 str and agi, +20 spirit. 2H:- +25 Agi. Your mats. If you wish, whisper '|cffffff00|Hinvplr:Morthanas-Shadowstrike(AU)|h[inv]|h|r' for instant |cffffff00|Hinvplr:Morthanas-Shadowstrike(AU)|h[invite]|h|r|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_3:0|t",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 27625.47,
					["extraData"] = {
						7, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110430,
				}, -- [71]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:47:04]|h|r [S] |cffd8d8d8[|r|Hplayer:Qashgirl-Shadowstrike(AU):566:SAY|h|cffffffffQashgirl|r|h|cffd8d8d8]|r: /shame",
					["r"] = 1,
					["b"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						2, -- [1]
						40, -- [2]
						42, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110432,
				}, -- [72]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:47:05]|h|r [S] |cffd8d8d8[|r|Hplayer:Qashgirl-Shadowstrike(AU):570:SAY|h|cffffffffQashgirl|r|h|cffd8d8d8]|r: /shame",
					["r"] = 1,
					["b"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						2, -- [1]
						40, -- [2]
						42, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110433,
				}, -- [73]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:47:07]|h|r [S] |cffd8d8d8[|r|Hplayer:Qashgirl-Shadowstrike(AU):572:SAY|h|cffffffffQashgirl|r|h|cffd8d8d8]|r: /shame",
					["r"] = 1,
					["b"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						2, -- [1]
						40, -- [2]
						42, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110435,
				}, -- [74]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:47:07]|h|r [S] |cffd8d8d8[|r|Hplayer:Matazma-Shadowstrike(AU):573:SAY|h|cfffff468Matazma|r|h|cffd8d8d8]|r: haha",
					["r"] = 1,
					["b"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						2, -- [1]
						40, -- [2]
						41, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110435,
				}, -- [75]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:47:10]|h|r [S] |cffd8d8d8[|r|Hplayer:Qashgirl-Shadowstrike(AU):578:SAY|h|cffffffffQashgirl|r|h|cffd8d8d8]|r: *Rings bell*",
					["r"] = 1,
					["b"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						2, -- [1]
						40, -- [2]
						42, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110438,
				}, -- [76]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:47:36]|h|r [Y] |cffd8d8d8[|r|Hplayer:Qashgirl-Shadowstrike(AU):599:YELL|h|cffffffffQashgirl|r|h|cffd8d8d8]|r: LF lockpick",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 27625.47,
					["extraData"] = {
						7, -- [1]
						15, -- [2]
						37, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110464,
				}, -- [77]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:47:36]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Furyfeet-Shadowstrike(AU):600:CHANNEL:2|h|cffc69b6dFuryfeet|r|h|cffd8d8d8]|r: WTB |cffffffff|Hitem:14047::::::::1:::::::::|h[Runecloth]|h|r 20s ea",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						38, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110464,
				}, -- [78]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:47:45]|h|r [Y] |cffd8d8d8[|r|Hplayer:Shootinflaps-Shadowstrike(AU):606:YELL|h|cffaad372Shootinflaps|r|h|cffd8d8d8]|r: wtb port to UC",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 27625.47,
					["extraData"] = {
						7, -- [1]
						15, -- [2]
						43, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110473,
				}, -- [79]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:48:07]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Basilboy-Shadowstrike(AU):620:CHANNEL:2|h|cffffffffBasilboy|r|h|cffd8d8d8]|r: WTS |cffffffff|Hitem:14046::::::::50:::::::::|h[Runecloth Bag]|h|r 7g ea",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110495,
				}, -- [80]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:48:33]|h|r [Y] |cffd8d8d8[|r|Hplayer:Nuggalugga-Shadowstrike(AU):639:YELL|h|cfffff468Nuggalugga|r|h|cffd8d8d8]|r: |cff0070dd|Hitem:13043::::::::50:::::::::|h[Blade of the Titans]|h|rx2 20g ea or both for 35.",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 27625.47,
					["extraData"] = {
						7, -- [1]
						15, -- [2]
						44, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110521,
				}, -- [81]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:48:51]|h|r |cffc69b6dPunks|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110539,
				}, -- [82]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:49:00]|h|r |cffd8d8d8[|r|Hplayer:Punkx:656|h|cffd88b6550|r:|cff0070ddPunkx|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110548,
				}, -- [83]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:49:08]|h|r |cfffff468Enjoglove|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110556,
				}, -- [84]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:49:12]|h|r |cffd8d8d8[|r|Hplayer:Cannonballer:665|h|cffd88b6550|r:|cffc69b6dCannonballer|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110560,
				}, -- [85]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:49:19]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Grentirus:670:CHANNEL:1|h|cffffffffGrentirus|r|h|cffd8d8d8]|r: |cffffff00|Hinvplr:splint|h[inv splint]|h|r",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						45, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110567,
				}, -- [86]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:49:39]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):684:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: LF7M Sunken Temple Need 1 Tank 2 Healer 4 Melee DPS (8/8) Guild Run at 7pm SATURDAY - Need all (Experience, WBs, Consumes, Discord Mandatory) PST for more Details!",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110587,
				}, -- [87]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:49:46]|h|r |cffd8d8d8[|r|Hplayer:Deathawaìts:689|h|cff8b8b8b34|r:|cffaad372Deathawaìts|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110594,
				}, -- [88]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:49:53]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Corvux:691:CHANNEL:2|h|cfffff468Corvux|r|h|cffd8d8d8]|r: LFG SM",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						47, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110601,
				}, -- [89]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:50:01]|h|r |cffff7c0aAurinnon|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110609,
				}, -- [90]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:50:35]|h|r |cffd8d8d8[|r|Hplayer:Snipegodx:701|h|cff8b8b8b18|r:|cffaad372Snipegodx|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110643,
				}, -- [91]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:51:06]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110674,
				}, -- [92]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:51:06]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110674,
				}, -- [93]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:51:08]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):714:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: LF7M Sunken Temple Need 1 Tank 2 Healer 4 Melee DPS (8/8) Guild Run at 7pm SATURDAY - Need all (Experience, WBs, Consumes, Discord Mandatory) PST for more Details!",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110676,
				}, -- [94]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:51:12]|h|r |cff0070ddPeely|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110680,
				}, -- [95]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:51:20]|h|r |cffd8d8d8[|r|Hplayer:Peely:721|h|cffd88b6550|r:|cff0070ddPeely|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110688,
				}, -- [96]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:51:54]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Escaped-Shadowstrike(AU):726:CHANNEL:2|h|cffff7c0aEscaped|r|h|cffd8d8d8]|r: WTS |cff0070dd|Hitem:221313::::::::50::::1:3524:::::|h[Flask of Nightmarish Mojo]|h|r 85g",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						49, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110722,
				}, -- [97]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:52:20]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):737:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: LF7M Sunken Temple Need 1 Tank 2 Healer 4 Melee DPS (8/8) Guild Run at 7pm SATURDAY - Need all (Experience, WBs, Consumes, Discord Mandatory) PST for more Details!",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110748,
				}, -- [98]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:04]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):749:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: LF7M Sunken Temple Need 1 Tank 2 Healer 4 Melee DPS (8/8) Guild Run at 7pm SATURDAY - Need all (Experience, WBs, Consumes, Discord Mandatory) PST for more Details!",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110792,
				}, -- [99]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:06]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Escaped-Shadowstrike(AU):751:CHANNEL:2|h|cffff7c0aEscaped|r|h|cffd8d8d8]|r: WTS |cff0070dd|Hitem:221313::::::::50::::1:3524:::::|h[Flask of Nightmarish Mojo]|h|r 85g",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						49, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110794,
				}, -- [100]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:14]|h|r You receive item: |cffffffff|Hitem:212160::::::::47:::::::::|h[Chronoboon Displacer]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110802,
				}, -- [101]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:17]|h|r You receive item: |cffffffff|Hitem:212160::::::::47:::::::::|h[Chronoboon Displacer]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110805,
				}, -- [102]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:18]|h|r You receive item: |cffffffff|Hitem:212160::::::::47:::::::::|h[Chronoboon Displacer]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110806,
				}, -- [103]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:19]|h|r You receive item: |cffffffff|Hitem:212160::::::::47:::::::::|h[Chronoboon Displacer]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110807,
				}, -- [104]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:21]|h|r You receive item: |cffffffff|Hitem:212160::::::::47:::::::::|h[Chronoboon Displacer]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110809,
				}, -- [105]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:21]|h|r |cffd8d8d8[|r|Hplayer:Beezos:760|h|cff8b8b8b13|r:|cffc69b6dBeezos|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110809,
				}, -- [106]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:21]|h|r You receive item: |cffffffff|Hitem:212160::::::::47:::::::::|h[Chronoboon Displacer]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110809,
				}, -- [107]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:27]|h|r |cffd8d8d8[|r|Hplayer:Sdxcs:762|h|cff8b8b8b1|r:|cffc69b6dSdxcs|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110815,
				}, -- [108]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:32]|h|r |cffffffffBtlheals|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110820,
				}, -- [109]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:34]|h|r You receive item: |cffffffff|Hitem:17031::::::::47:::::::::|h[Rune of Teleportation]|h|rx10.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110822,
				}, -- [110]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:39]|h|r You receive item: |cffffffff|Hitem:211779::::::::47:::::::::|h[Comprehension Charm]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110827,
				}, -- [111]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:40]|h|r You receive item: |cffffffff|Hitem:211779::::::::47:::::::::|h[Comprehension Charm]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110828,
				}, -- [112]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:40]|h|r You receive item: |cffffffff|Hitem:211779::::::::47:::::::::|h[Comprehension Charm]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110828,
				}, -- [113]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:48]|h|r |cffd8d8d8[|r|Hplayer:Bearwithme:780|h|cffd88b6550|r:|cffff7c0aBearwithme|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110836,
				}, -- [114]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:53:49]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fiwl-Shadowstrike(AU):782:CHANNEL:2|h|cffff7c0aFiwl|r|h|cffd8d8d8]|r: wtb eight of dunes",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						51, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110837,
				}, -- [115]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:54:26]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Weaved-Shadowstrike(AU):793:CHANNEL:2|h|cffaad372Weaved|r|h|cffd8d8d8]|r: |cff0070dd|Hitem:221305::::::::50:::::::::|h[Seven of Nightmares]|h|r|cff0070dd|Hitem:221278::::::::50:::::::::|h[Seven of Wilds]|h|r for sale",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						53, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110874,
				}, -- [116]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:54:33]|h|r |cffff7c0aJayquillin|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110881,
				}, -- [117]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:54:37]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110885,
				}, -- [118]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:54:37]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110885,
				}, -- [119]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:54:37]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110885,
				}, -- [120]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:55:04]|h|r |cff0070ddTutudots|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110912,
				}, -- [121]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:55:11]|h|r |cff0070ddPunkx|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110919,
				}, -- [122]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:55:16]|h|r |cffd8d8d8[|r|Hplayer:Kradle:810|h|cff8b8b8b31|r:|cffaad372Kradle|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110924,
				}, -- [123]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:55:20]|h|r |cffd8d8d8[|r|Hplayer:Ðëmøñ:812|h|cff65b26542|r:|cff8787edÐëmøñ|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110928,
				}, -- [124]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:55:26]|h|r [Y] |cffd8d8d8[|r|Hplayer:Elama-Shadowstrike(AU):813:YELL|h|cffffffffElama|r|h|cffd8d8d8]|r: care therre is  a rogue",
					["r"] = 1,
					["b"] = 0.250980406999588,
					["g"] = 0.250980406999588,
					["timestamp"] = 27625.47,
					["extraData"] = {
						7, -- [1]
						15, -- [2]
						57, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110934,
				}, -- [125]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:55:27]|h|r Silas Darkmoon says: Welcome one and all to the Darkmoon Faire, the greatest event in all the world!  We have it all... delicious food, strong drink, exotic artifacts, fortunes read, amazing prizes and excitement without end!  Don't forget to turn in your Darkmoon Faire Prize Tickets to Gelvas Grimegate!  All it takes is five or more and you're on your way to the most wondrous prizes on all of Azeroth.  Everybody is a winner!",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						13, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110935,
				}, -- [126]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:55:45]|h|r You receive item: |cffffffff|Hitem:19422::::::::47:::::::::|h[Darkmoon Faire Fortune]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110953,
				}, -- [127]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:55:50]|h|r |cffd8d8d8[|r|Hplayer:Hundredhits:819|h|cff65b26542|r:|cffaad372Hundredhits|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110958,
				}, -- [128]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:55:51]|h|r Silas Darkmoon says: Come one, come all!  Welcome to the Darkmoon Faire!  Do you crave adventure?  Do you seek exotic and mysterious treasures?  Then look no further!  You, my friend, have come to the right place!  Dive right in and take part in all that the Faire has to offer!  We'll be at this location all week, so be sure to tell your friends and loved ones!",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						13, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110959,
				}, -- [129]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:55:52]|h|r Sayge says: Come to me true believers, and see what the future holds for you!",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						13, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110960,
				}, -- [130]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:55:56]|h|r You receive item: |cff1eff00|Hitem:184938::::::::47:::::::::|h[Supercharged Chronoboon Displacer]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110964,
				}, -- [131]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:56:27]|h|r Professor Thaddeus Paleo says: I have a fine selection of exotic potions and scrolls.  But they're not for the faint of heart!",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						13, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714110995,
				}, -- [132]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:57:01]|h|r Lhara says: Darkmoon Faire Cards?  See the Professor here for those.  Come see me if you are a dealer in hard to come by antiquities and artifacts.",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						13, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111029,
				}, -- [133]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:57:09]|h|r |cffd8d8d8[|r|Hplayer:Vict:837|h|cffd88b6550|r:|cff3fc6eaVict|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111037,
				}, -- [134]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:57:09]|h|r Darkmoon Faire Carnie says: Don't forget to buy refreshments and souvenirs!",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						13, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111037,
				}, -- [135]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:57:21]|h|r |cffd8d8d8[|r|Hplayer:Creditfraud:839|h|cffd88b6550|r:|cfffff468Creditfraud|r|h|cffd8d8d8]|r has invited you to join a group.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111049,
				}, -- [136]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:57:23]|h|r Dungeon difficulty set to Normal",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111051,
				}, -- [137]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:57:31]|h|r Professor Thaddeus Paleo says: Have you any Darkmoon Faire Cards?  Come speak with me to learn more about them if you dare!",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						13, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111059,
				}, -- [138]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:57:35]|h|r Sylannia says: You there!  Yes you!  You look thirsty.  Get over here, I have just what you need!",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						13, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111063,
				}, -- [139]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:57:55]|h|r |cff8787edÐëmøñ|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111083,
				}, -- [140]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:58:05]|h|r |cffd8d8d8[|r|Hplayer:Unluckyy:853|h|cff8b8b8b2|r:|cffffffffUnluckyy|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111093,
				}, -- [141]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:58:42]|h|r |cffc69b6dZmashy|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111130,
				}, -- [142]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:58:43]|h|r |cffffffffUnluckyy|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111131,
				}, -- [143]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:58:44]|h|r |cfffff468Prepvanish|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111132,
				}, -- [144]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:58:50]|h|r |cffd8d8d8[|r|Hplayer:Steeuu:865|h|cffd88b6550|r:|cffff7c0aSteeuu|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111138,
				}, -- [145]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:58:51]|h|r |cffd8d8d8[|r|Hplayer:Ðëmøñ:866|h|cff65b26542|r:|cff8787edÐëmøñ|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111139,
				}, -- [146]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:58:54]|h|r |cffd8d8d8[|r|Hplayer:Yttam:867|h|cffd88b6550|r:|cff3fc6eaYttam|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111142,
				}, -- [147]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:59:07]|h|r |cfffff468Quer|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111155,
				}, -- [148]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:59:29]|h|r Professor Thaddeus Paleo says: I have a fine selection of exotic potions and scrolls.  But they're not for the faint of heart!",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						13, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111177,
				}, -- [149]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:59:43]|h|r Silas Darkmoon says: Come one, come all!  Welcome to the Darkmoon Faire!  Do you crave adventure?  Do you seek exotic and mysterious treasures?  Then look no further!  You, my friend, have come to the right place!  Dive right in and take part in all that the Faire has to offer!  We'll be at this location all week, so be sure to tell your friends and loved ones!",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						13, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111191,
				}, -- [150]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:59:52]|h|r You receive loot: |cffffffff|Hitem:19443::::::::47:::::::::|h[Sayge's Fortune #25]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111200,
				}, -- [151]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:59:52]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Emz-Shadowstrike(AU):881:PARTY|h|cffd8d83f47|r:|cff3fc6eaEmz|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: Picked up |cffffffff|Hitem:19443::::::::47:::::::::|h[Sayge's Fortune #25]|h|r which starts |Hquestie:7944:Player-5818-00A9F32E|h|cFF6ce314[|r|cFF6ce314[60] Your Fortune Awaits You...|r|cFF6ce314]|r|h!",
					["r"] = 0.6666666865348816,
					["b"] = 1,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						3, -- [1]
						60, -- [2]
						61, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111200,
				}, -- [152]
				{
					["message"] = "|cff979797|Hpratcopy|h[15:59:54]|h|r Silas Darkmoon says: Welcome one and all to the Darkmoon Faire, the greatest event in all the world!  We have it all... delicious food, strong drink, exotic artifacts, fortunes read, amazing prizes and excitement without end!  Don't forget to turn in your Darkmoon Faire Prize Tickets to Gelvas Grimegate!  All it takes is five or more and you're on your way to the most wondrous prizes on all of Azeroth.  Everybody is a winner!",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						13, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111202,
				}, -- [153]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:00:01]|h|r Quest accepted: Your Fortune Awaits You...",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111209,
				}, -- [154]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:00:09]|h|r |cffd8d8d8[|r|Hplayer:Sevensins:886|h|cff8b8b8b25|r:|cffc69b6dSevensins|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111217,
				}, -- [155]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:00:10]|h|r |cffd8d8d8[|r|Hplayer:Quer:887|h|cff8b8b8b24|r:|cfffff468Quer|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111218,
				}, -- [156]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:00:21]|h|r Sayge says: The longer you wait, the less future you have for me to foretell.",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						13, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111229,
				}, -- [157]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:00:43]|h|r Sylannia says: Cheap Beer!  Get your Cheap Beer right here!",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						13, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111251,
				}, -- [158]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:01:18]|h|r |cffff7c0aBearwithme|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111286,
				}, -- [159]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:01:22]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111290,
				}, -- [160]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:01:22]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111290,
				}, -- [161]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:01:22]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111290,
				}, -- [162]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:01:25]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fatlip:901:CHANNEL:2|h|cff0070ddFatlip|r|h|cffd8d8d8]|r: WTS |cff0070dd|Hitem:221281::::::::50:::::::::|h[Ace of Plagues]|h|r",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						62, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111293,
				}, -- [163]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:01:30]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fiwl-Shadowstrike(AU):902:CHANNEL:2|h|cffff7c0aFiwl|r|h|cffd8d8d8]|r: wtb eight of dunes",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						51, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111298,
				}, -- [164]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:01:39]|h|r |cffff7c0aSteeuu|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111307,
				}, -- [165]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:01:46]|h|r |cffd8d8d8[|r|Hplayer:Jayquillin:905|h|cff8b8b8b19|r:|cffff7c0aJayquillin|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111314,
				}, -- [166]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:01:47]|h|r |cffd8d8d8[|r|Hplayer:Zmashy:906|h|cff65b26542|r:|cffc69b6dZmashy|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111315,
				}, -- [167]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:02:09]|h|r |cffaad372Billies|r has left the guild.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111337,
				}, -- [168]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:02:21]|h|r |cff3fc6eaJaydz|r has left the guild.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111349,
				}, -- [169]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:02:26]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Peely-Shadowstrike(AU):917:CHANNEL:2|h|cffd88b6550|r:|cff0070ddPeely|r|h|cffd8d8d8]|r: LF TRIBAL LEATHERWORKER",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						64, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111354,
				}, -- [170]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:02:39]|h|r |cfffff468Wigga|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111367,
				}, -- [171]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:02:46]|h|r |cffd8d8d8[|r|Hplayer:Wigga:927|h|cff8b8b8b32|r:|cfffff468Wigga|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111374,
				}, -- [172]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:02:49]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):928:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: LF7M Sunken Temple Need 1 Tank 2 Healer 4 Melee DPS (8/8) Guild Run at 7pm SATURDAY - Need all (Experience, WBs, Consumes, Discord Mandatory) PST for more Details!",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111377,
				}, -- [173]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:03:46]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Morladim-Shadowstrike(AU):934:CHANNEL:2|h|cfffff468Morladim|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|tENCHANTING|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t +22 Healing Bracer || +9str Bracer || Crusader || +5 All Res Cape || Fiery || Icy Chill || +Riding || +7stam Bracer/Boots/Shield || +7agi Boots/Gloves || +4dmg 1H || +7dmg 2H || +15 agi/str 1H || +20 spirit 1H || +25 agi 2H",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						66, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111434,
				}, -- [174]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:03:47]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Compunction-Shadowstrike(AU):936:CHANNEL:2|h|cfffff468Compunction|r|h|cffd8d8d8]|r: LF Enchanter 3 agi on cloak, 3 stats on chest, 5 agility on gloves, minor speed on boots, 7 stam on bracers, my mats + tip",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						68, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111435,
				}, -- [175]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:03:49]|h|r Your Thunder Bluff reputation has increased by 100.",
					["r"] = 0.501960813999176,
					["b"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 27625.47,
					["extraData"] = {
						36, -- [1]
						70, -- [2]
						71, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111437,
				}, -- [176]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:03:49]|h|r Deadmire completed.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111437,
				}, -- [177]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:03:49]|h|r Experience gained: 6825.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111437,
				}, -- [178]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:03:49]|h|r You receive item: |cffffffff|Hitem:5838::::::::47:::::::::|h[Kodo Skin Scroll]|h|r.",
					["r"] = 0,
					["b"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["extraData"] = {
						28, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111437,
				}, -- [179]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:03:49]|h|r Quest accepted: Frostmaw",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111437,
				}, -- [180]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:04:29]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Ichor-Shadowstrike(AU):947:CHANNEL:2|h|cffc69b6dIchor|r|h|cffd8d8d8]|r: LF MASTER TRANSMUTER TO XMUTE |cff1eff00|Hitem:12363::::::::50:::::::::|h[Arcane Crystal]|h|r INTO |cff1eff00|Hitem:12360::::::::50:::::::::|h[Arcanite Bar]|h|r",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						72, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111477,
				}, -- [181]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:04:42]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Ooxo-Shadowstrike(AU):948:CHANNEL:2|h|cff0070ddOoxo|r|h|cffd8d8d8]|r: WTB FIVE OF DUNES PST",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						74, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111490,
				}, -- [182]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:04:42]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Ooxo-Shadowstrike(AU):949:CHANNEL:2|h|cff0070ddOoxo|r|h|cffd8d8d8]|r: WTB FIVE OF DUNES PST",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						74, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111490,
				}, -- [183]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:05:20]|h|r Your auction of |cffffffff|Hitem:4306::::::::47:::::::::|h[Silk Cloth]|h|r has sold for |cffffffff43|r|cffc7c7cfs|r |cffffffff19|r|cffeda55fc|r!",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111528,
				}, -- [184]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:05:22]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Ooxo-Shadowstrike(AU):960:CHANNEL:2|h|cff0070ddOoxo|r|h|cffd8d8d8]|r: WTB FIVE OF DUNES PST",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						74, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111530,
				}, -- [185]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:05:32]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):964:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: |cffffffff|Hurl:https://www.youtube.com/watch?v=4dhJGwJFJb4|h[https://www.youtube.com/watch?v=4dhJGwJFJb4]|h|r",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111540,
				}, -- [186]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:05:35]|h|r |cff8787edÐëmøñ|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111543,
				}, -- [187]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:05:38]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):966:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: LF7M Sunken Temple Need 1 Tank 2 Healer 4 Melee DPS (8/8) Guild Run at 7pm SATURDAY - Need all (Experience, WBs, Consumes, Discord Mandatory) PST for more Details!",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111546,
				}, -- [188]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:05:41]|h|r |cffd8d8d8[|r|Hplayer:Unluckyy:970|h|cff8b8b8b2|r:|cffffffffUnluckyy|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111549,
				}, -- [189]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:05:42]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Ichor-Shadowstrike(AU):971:CHANNEL:2|h|cffc69b6dIchor|r|h|cffd8d8d8]|r: LF MASTER TRANSMUTER TO XMUTE |cff1eff00|Hitem:12363::::::::50:::::::::|h[Arcane Crystal]|h|r INTO |cff1eff00|Hitem:12360::::::::50:::::::::|h[Arcanite Bar]|h|r",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						72, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111550,
				}, -- [190]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:06:02]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Millionaire:972:CHANNEL:2|h|cffffffffMillionaire|r|h|cffd8d8d8]|r: Tailor/Ench LFW",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						76, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111570,
				}, -- [191]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:06:06]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111574,
				}, -- [192]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:06:06]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111574,
				}, -- [193]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:06:06]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111574,
				}, -- [194]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:06:37]|h|r |cffaad372Ajayani|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111605,
				}, -- [195]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:06:52]|h|r Darkmoon Faire Carnie says: The Darkmoon Faire is the greatest event on all of Azeroth!",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						13, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111620,
				}, -- [196]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:07:36]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111664,
				}, -- [197]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:07:36]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111664,
				}, -- [198]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:07:36]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111664,
				}, -- [199]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:07:59]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Spellbreaker-Shadowstrike(AU):1000:CHANNEL:2|h|cff0070ddSpellbreaker|r|h|cffd8d8d8]|r: WTB BULK |cff1eff00|Hitem:12363::::::::50:::::::::|h[Arcane Crystal]|h|r",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						78, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111687,
				}, -- [200]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:08:19]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Unownable:1007:CHANNEL:2|h|cff0070ddUnownable|r|h|cffd8d8d8]|r: WTB Arcanite Transmute",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						80, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111707,
				}, -- [201]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:08:35]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):1011:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: LF7M Sunken Temple Need 1 Tank 2 Healer 4 Melee DPS (8/8) Guild Run at 7pm SATURDAY - Need all (Experience, WBs, Consumes, Discord Mandatory) PST for more Details!",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111723,
				}, -- [202]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:08:40]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Millionaire-Shadowstrike(AU):1013:CHANNEL:2|h|cffffffffMillionaire|r|h|cffd8d8d8]|r: Tailor/Ench LFW",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						76, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111728,
				}, -- [203]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:09:00]|h|r |cffaad372Kradle|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111748,
				}, -- [204]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:09:04]|h|r |cffd8d8d8[|r|Hplayer:Ajayani:1019|h|cffd88b6550|r:|cffaad372Ajayani|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111752,
				}, -- [205]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:09:21]|h|r |cff3fc6eaVict|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111769,
				}, -- [206]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:09:23]|h|r |cffffffffUnluckyy|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111771,
				}, -- [207]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:09:25]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Ouibaguette-Shadowstrike(AU):1027:CHANNEL:2|h|cffaad372Ouibaguette|r|h|cffd8d8d8]|r: LFM BFD Need all!",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						82, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111773,
				}, -- [208]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:09:32]|h|r |cffd8d8d8[|r|Hplayer:Ðëmøñ:1032|h|cff65b26542|r:|cff8787edÐëmøñ|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111780,
				}, -- [209]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:09:40]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Millionaire-Shadowstrike(AU):1038:CHANNEL:2|h|cffffffffMillionaire|r|h|cffd8d8d8]|r: Tailor/Ench LFW",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						76, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111788,
				}, -- [210]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:09:42]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Baltod:1041:CHANNEL:2|h|cffaad372Baltod|r|h|cffd8d8d8]|r: WTB|cff1eff00|Hitem:11737::::::::50:::::::::|h[Libram of Voracity]|h|r300g",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						84, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111790,
				}, -- [211]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:09:48]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):1047:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: LF7M Sunken Temple Need 1 Tank 2 Healer 4 Melee DPS (8/8) Guild Run at 7pm SATURDAY - Need all (Experience, WBs, Consumes, Discord Mandatory) PST for more Details!",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111796,
				}, -- [212]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:09:53]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Onlybums:1052:CHANNEL:2|h|cff3fc6eaOnlybums|r|h|cffd8d8d8]|r: WTB |cff1eff00|Hitem:11737::::::::50:::::::::|h[Libram of Voracity]|h|r 350g",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						87, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111801,
				}, -- [213]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:09:57]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Bangkalt-Shadowstrike(AU):1055:CHANNEL:2|h|cffc69b6dBangkalt|r|h|cffd8d8d8]|r: WTS |cff0070dd|Hitem:221271::::::::1:::::::::|h[Ace of Wilds]|h|r",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						89, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111805,
				}, -- [214]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:10:04]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Millionaire-Shadowstrike(AU):1063:CHANNEL:2|h|cffffffffMillionaire|r|h|cffd8d8d8]|r: Tailor/Ench LFW",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						76, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111812,
				}, -- [215]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:10:20]|h|r |cffd8d8d8[|r|Hplayer:Grampserson:1075|h|cff8b8b8b30|r:|cff8787edGrampserson|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111828,
				}, -- [216]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:10:39]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Skoolbully:1091:CHANNEL:2|h|cffff7c0aSkoolbully|r|h|cffd8d8d8]|r: heals/dps LFG BRD",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						91, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111847,
				}, -- [217]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:10:48]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Millionaire-Shadowstrike(AU):1097:CHANNEL:2|h|cffffffffMillionaire|r|h|cffd8d8d8]|r: Tailor/Ench LFW",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						76, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111856,
				}, -- [218]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:12:45]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):1165:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: LF7M Sunken Temple Need 1 Tank 2 Healer 4 Melee DPS (8/8) Guild Run at 7pm SATURDAY - Need all (Experience, WBs, Consumes, Discord Mandatory) PST for more Details!",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714111973,
				}, -- [219]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:13:24]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Millionaire-Shadowstrike(AU):1180:CHANNEL:2|h|cffffffffMillionaire|r|h|cffd8d8d8]|r: Tailor/Ench LFW",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						76, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112012,
				}, -- [220]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:13:24]|h|r |cffaad372Ajayani|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112012,
				}, -- [221]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:13:35]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112023,
				}, -- [222]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:13:35]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112023,
				}, -- [223]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:13:35]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112023,
				}, -- [224]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:13:38]|h|r |cffd8d8d8[|r|Hplayer:Amdarais:1187|h|cff8b8b8b31|r:|cff8787edAmdarais|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112026,
				}, -- [225]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:13:47]|h|r [S] |cffd8d8d8[|r|Hplayer:Vasoline-Shadowstrike(AU):1189:SAY|h|cfffff468Vasoline|r|h|cffd8d8d8]|r: then snipe",
					["r"] = 1,
					["b"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						2, -- [1]
						40, -- [2]
						93, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112035,
				}, -- [226]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:13:54]|h|r |cff0070ddTinyterry|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112042,
				}, -- [227]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:14:02]|h|r |cff8787edAmdarais|r has left the guild.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112050,
				}, -- [228]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:14:23]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112071,
				}, -- [229]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:14:23]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112071,
				}, -- [230]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:14:23]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112071,
				}, -- [231]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:14:39]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Fayne-Shadowstrike(AU):1207:CHANNEL:2|h|cffc69b6dFayne|r|h|cffd8d8d8]|r: LF7M Sunken Temple Need 1 Tank 2 Healer 4 Melee DPS (8/8) Guild Run at 7pm SATURDAY - Need all (Experience, WBs, Consumes, Discord Mandatory) PST for more Details!",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112087,
				}, -- [232]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:14:50]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Unownable-Shadowstrike(AU):1210:CHANNEL:2|h|cff0070ddUnownable|r|h|cffd8d8d8]|r: LF Arcanite Bar Transmute $",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						80, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112098,
				}, -- [233]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:13]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Millionaire-Shadowstrike(AU):1213:CHANNEL:2|h|cffffffffMillionaire|r|h|cffd8d8d8]|r: Tailor/Ench LFW",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						76, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112121,
				}, -- [234]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:32]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112140,
				}, -- [235]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:32]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112140,
				}, -- [236]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:32]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112140,
				}, -- [237]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:37]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112145,
				}, -- [238]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:37]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112145,
				}, -- [239]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:37]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112145,
				}, -- [240]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:43]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112151,
				}, -- [241]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:43]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112151,
				}, -- [242]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:43]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112151,
				}, -- [243]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:45]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112153,
				}, -- [244]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:45]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112153,
				}, -- [245]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:45]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112153,
				}, -- [246]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:52]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112160,
				}, -- [247]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:52]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112160,
				}, -- [248]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:15:52]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112160,
				}, -- [249]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:16:35]|h|r Silas Darkmoon says: Come one, come all.  Welcome to the Darkmoon Faire!  Don't be shy.  Step right up to Lhara and buy yourself an exotic artifact from far off lands.  If you're one of the lucky few who have found Darkmoon Cards, have a word with Professor Paleo.  Hungry?  Thirsty?  You're in luck!  Refreshments are available right here from Sylannia and Stamp.  I recommend the Darkmoon Special Reserve to wash down some Red Hot Wings.  And if the future is what you seek, then run, don't walk, to speak with Sayge.",
					["r"] = 1,
					["b"] = 0.6235294342041016,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						13, -- [1]
						58, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112203,
				}, -- [250]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:17:12]|h|r |cffd8d8d8[|r|Hplayer:Ajayani:1249|h|cffd88b6550|r:|cffaad372Ajayani|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112240,
				}, -- [251]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:17:24]|h|r Luhf dies, honorable kill Rank: Sergeant (Estimated Honor Points: 58)",
					["r"] = 0.8784314393997192,
					["b"] = 0.03921568766236305,
					["g"] = 0.7921569347381592,
					["timestamp"] = 27625.47,
					["extraData"] = {
						35, -- [1]
						94, -- [2]
						95, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112252,
				}, -- [252]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:17:29]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112257,
				}, -- [253]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:17:29]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112257,
				}, -- [254]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:17:29]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112257,
				}, -- [255]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:18:00]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Rakcaze-Shadowstrike(AU):1261:CHANNEL:2|h|cff0070ddRakcaze|r|h|cffd8d8d8]|r: wts |cff0070dd|Hitem:13120::::::::50:::::::::|h[Deepfury Bracers]|h|r WTB |cff0070dd|Hitem:221285::::::::50:::::::::|h[Five of Plagues]|h|r pst",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						96, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112288,
				}, -- [256]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:18:24]|h|r |cfffff468Quer|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112312,
				}, -- [257]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:18:28]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112316,
				}, -- [258]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:18:28]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112316,
				}, -- [259]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:18:28]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112316,
				}, -- [260]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:18:30]|h|r |cffc69b6dBaldymort|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112318,
				}, -- [261]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:18:44]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112332,
				}, -- [262]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:18:44]|h|r |Hchannel:channel:2|h[2] |h Changed Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112332,
				}, -- [263]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:18:44]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Thunder Bluff]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112332,
				}, -- [264]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:18:50]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						69, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112338,
				}, -- [265]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:18:50]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						70, -- [1]
						19, -- [2]
						55, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112338,
				}, -- [266]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:18:50]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Mulgore]|h",
					["r"] = 1,
					["b"] = 0.7529412508010864,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["extraData"] = {
						71, -- [1]
						10, -- [2]
						11, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112338,
				}, -- [267]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:19:06]|h|r |cffaad372Suss|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112354,
				}, -- [268]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:19:23]|h|r |cffd8d8d8[|r|Hplayer:Thedirtybird:1283|h|cff8b8b8b32|r:|cff0070ddThedirtybird|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112371,
				}, -- [269]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:19:51]|h|r |cffd8d8d8[|r|Hplayer:Quer:1287|h|cff8b8b8b24|r:|cfffff468Quer|r|h|cffd8d8d8]|r has come online.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112399,
				}, -- [270]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:20:02]|h|r [S] |cffd8d8d8[|r|Hplayer:Creditfraud-Shadowstrike(AU):1289:SAY|h|cfffff468Creditfraud|r|h|cffd8d8d8]|r: were all cringe",
					["r"] = 1,
					["b"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						2, -- [1]
						40, -- [2]
						98, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112410,
				}, -- [271]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:20:13]|h|r |cffff7c0aJayquillin|r has gone offline.",
					["r"] = 1,
					["b"] = 0,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["serverTime"] = 1714112421,
				}, -- [272]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:48:01]|h|r Darkmoon Faire Carnie says: Having a good time?",
					["extraData"] = {
						13, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0.6235294342041016,
					["serverTime"] = 1714114089,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["r"] = 1,
				}, -- [273]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:48:01]|h|r Lhara says: Darkmoon Faire Cards?  See the Professor here for those.  Come see me if you are a dealer in hard to come by antiquities and artifacts.",
					["extraData"] = {
						13, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0.6235294342041016,
					["serverTime"] = 1714114089,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["r"] = 1,
				}, -- [274]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:48:15]|h|r |cffffffffBtlheals|r has gone offline.",
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1714114103,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["r"] = 1,
				}, -- [275]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:48:17]|h|r Stamp Thunderhorn says: You've got money and we've got food.  What are you waiting for?!",
					["extraData"] = {
						13, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["b"] = 0.6235294342041016,
					["serverTime"] = 1714114105,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["r"] = 1,
				}, -- [276]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:48:24]|h|r |cffd8d8d8[|r|Hplayer:Berglar:1470|h|cff65b26540|r:|cff3fc6eaBerglar|r|h|cffd8d8d8]|r has come online.",
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1714114112,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["r"] = 1,
				}, -- [277]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:48:59]|h|r |cffff7c0aTsalang|r has gone offline.",
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1714114147,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["r"] = 1,
				}, -- [278]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:49:06]|h|r |cfffff468Prepvanish|r has gone offline.",
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1714114154,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["r"] = 1,
				}, -- [279]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:49:13]|h|r |cffd8d8d8[|r|Hplayer:Grasstoucher:1479|h|cffd88b6550|r:|cffaad372Grasstoucher|r|h|cffd8d8d8]|r has come online.",
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1714114161,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["r"] = 1,
				}, -- [280]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:49:41]|h|r |Hchannel:channel:3|h[3] |h |cffffff00Mulgore is under attack!|r",
					["extraData"] = {
						71, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
					["b"] = 0.7529412508010864,
					["serverTime"] = 1714114189,
					["timestamp"] = 27625.47,
					["g"] = 0.7529412508010864,
					["r"] = 1,
				}, -- [281]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:49:42]|h|r |cffaad372Grasstoucher|r has gone offline.",
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
					["b"] = 0,
					["serverTime"] = 1714114190,
					["timestamp"] = 27625.47,
					["g"] = 1,
					["r"] = 1,
				}, -- [282]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:49:54]|h|r Silas Darkmoon says: Come one, come all.  Welcome to the Darkmoon Faire!  Don't be shy.  Step right up to Lhara and buy yourself an exotic artifact from far off lands.  If you're one of the lucky few who have found Darkmoon Cards, have a word with Professor Paleo.  Hungry?  Thirsty?  You're in luck!  Refreshments are available right here from Sylannia and Stamp.  I recommend the Darkmoon Special Reserve to wash down some Red Hot Wings.  And if the future is what you seek, then run, don't walk, to speak with Sayge.",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114202,
					["extraData"] = {
						13, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [283]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:50:20]|h|r |cffd8d8d8[|r|Hplayer:Zmashy:1497|h|cff65b26542|r:|cffc69b6dZmashy|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114228,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [284]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:50:32]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Feralas]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114240,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
				}, -- [285]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:50:32]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Feralas]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114240,
					["extraData"] = {
						71, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
				}, -- [286]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:50:50]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Getotrix-Shadowstrike(AU):1507:CHANNEL:1|h|cffffffffGetotrix|r|h|cffd8d8d8]|r: LFM FERALAS INC",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114258,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						11, -- [3]
						["n"] = 3,
					},
				}, -- [287]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:51:01]|h|r |cffd8d8d8[|r|Hplayer:Dorathy:1508|h|cffd88b6550|r:|cffaad372Dorathy|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114269,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [288]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:51:07]|h|r |cffc69b6dZmashy|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114275,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [289]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:51:37]|h|r |cffd8d8d8[|r|Hplayer:Diqiurena:1515|h|cffd88b6550|r:|cffaad372Diqiurena|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114305,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [290]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:52:02]|h|r |cffd8d8d8[|r|Hplayer:Vivekk:1522|h|cff8b8b8b28|r:|cffff7c0aVivekk|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114330,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [291]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:52:14]|h|r |cff3fc6eaBerglar|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114342,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [292]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:52:54]|h|r |cffd8d8d8[|r|Hplayer:Frombehînd:1530|h|cff8b8b8b20|r:|cfffff468Frombehînd|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114382,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [293]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:53:19]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Mattdamonn-Shadowstrike(AU):1535:CHANNEL:1|h|cffffffffMattdamonn|r|h|cffd8d8d8]|r: LF1M Feral inc dps",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114407,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						13, -- [3]
						["n"] = 3,
					},
				}, -- [294]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:53:28]|h|r |cffaad372Shadè|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114416,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [295]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:53:29]|h|r |cffaad372Shadê|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114417,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [296]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:53:51]|h|r |cfffff468Frombehînd|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114439,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [297]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:54:15]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Getotrix-Shadowstrike(AU):1551:CHANNEL:1|h|cffffffffGetotrix|r|h|cffd8d8d8]|r: LF1M FERALAS INC",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114463,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						11, -- [3]
						["n"] = 3,
					},
				}, -- [298]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:55:06]|h|r |cffd8d8d8[|r|Hplayer:Prepvanish:1558|h|cffd88b6550|r:|cfffff468Prepvanish|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114514,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [299]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:55:34]|h|r |cffc69b6dThelvadam|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114542,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [300]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:55:50]|h|r You create: |cffffffff|Hitem:8077::::::::47:::::::::|h[Conjured Mineral Water]|h|rx20.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114558,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [301]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:55:55]|h|r You create: |cffffffff|Hitem:8075::::::::47:::::::::|h[Conjured Sourdough]|h|rx12.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114563,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [302]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:56:31]|h|r |cffaad372Kayleea|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114599,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [303]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:56:33]|h|r |cffd8d8d8[|r|Hplayer:Zmashy:1578|h|cff65b26542|r:|cffc69b6dZmashy|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114601,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [304]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:56:35]|h|r |cffff7c0aVivekk|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114603,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [305]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:56:38]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Getotrix-Shadowstrike(AU):1583:CHANNEL:1|h|cffffffffGetotrix|r|h|cffd8d8d8]|r: LF1M FERALAS INC",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114606,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						11, -- [3]
						["n"] = 3,
					},
				}, -- [306]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:57:11]|h|r You loot 1 Silver, 59 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114639,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [307]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:57:15]|h|r |cffd8d8d8[|r|Hplayer:Kayleea:1595|h|cffd88b6550|r:|cffaad372Kayleea|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114643,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [308]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:57:28]|h|r You loot 1 Silver, 86 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114656,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [309]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:57:55]|h|r You receive loot: |cffffffff|Hitem:8973::::::::47:::::::::|h[Thick Yeti Hide]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114683,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [310]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:57:56]|h|r You loot 2 Silver, 41 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114684,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [311]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:58:10]|h|r You loot 2 Silver, 53 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114698,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [312]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:58:44]|h|r You receive loot: |cff9d9d9d|Hitem:4017::::::::47:::::::::|h[Sharp Shortsword]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114732,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [313]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:58:44]|h|r You receive loot: |cffffffff|Hitem:4599::::::::47:::::::::|h[Cured Ham Steak]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114732,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [314]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:58:44]|h|r You receive loot: |cffffffff|Hitem:8973::::::::47:::::::::|h[Thick Yeti Hide]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114732,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [315]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:58:45]|h|r You loot 1 Silver, 59 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114733,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [316]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:59:18]|h|r |cffd8d8d8[|r|Hplayer:Vivekk:1625|h|cff8b8b8b28|r:|cffff7c0aVivekk|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114766,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [317]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:59:18]|h|r |cffd8d8d8[|r|Hplayer:Btlheals:1626|h|cffd88b6550|r:|cffffffffBtlheals|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114766,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [318]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:59:31]|h|r You loot 3 Silver, 17 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114779,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [319]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:59:50]|h|r You receive loot: |cffffffff|Hitem:8973::::::::47:::::::::|h[Thick Yeti Hide]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114798,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [320]
				{
					["message"] = "|cff979797|Hpratcopy|h[16:59:51]|h|r You loot 3 Silver, 81 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114799,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [321]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:00:26]|h|r You loot 3 Silver, 20 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114834,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [322]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:00:54]|h|r Enraged Feral Scar becomes enraged!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114862,
					["extraData"] = {
						17, -- [1]
						21, -- [2]
						22, -- [3]
						["n"] = 3,
					},
				}, -- [323]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:00:58]|h|r You loot 4 Silver, 36 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114866,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [324]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:00:59]|h|r |cffd8d8d8[|r|Hplayer:Slamnshamn:1655|h|cffd88b6550|r:|cff0070ddSlamnshamn|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114867,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [325]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:01:38]|h|r You loot 1 Silver, 20 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114906,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [326]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:01:39]|h|r |cffaad372Ajayani|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114907,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [327]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:02:01]|h|r Enraged Feral Scar becomes enraged!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114929,
					["extraData"] = {
						17, -- [1]
						21, -- [2]
						22, -- [3]
						["n"] = 3,
					},
				}, -- [328]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:02:01]|h|r Your skill in Defense has increased to 220.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114929,
					["extraData"] = {
						27, -- [1]
						23, -- [2]
						24, -- [3]
						["n"] = 3,
					},
				}, -- [329]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:02:07]|h|r You loot 1 Silver, 63 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114935,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [330]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:02:37]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Bwhae:1672:CHANNEL:1|h|cff3fc6eaBwhae|r|h|cffd8d8d8]|r: lfg feralas inc",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714114965,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						25, -- [3]
						["n"] = 3,
					},
				}, -- [331]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:03:58]|h|r |cffd8d8d8[|r|Hplayer:Ajayani:1687|h|cffd88b6550|r:|cffaad372Ajayani|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115046,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [332]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:04:09]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Bwhae-Shadowstrike(AU):1689:CHANNEL:1|h|cff3fc6eaBwhae|r|h|cffd8d8d8]|r: lfg feralas inc",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115057,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						25, -- [3]
						["n"] = 3,
					},
				}, -- [333]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:04:27]|h|r |cff8787edMalcer|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115075,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [334]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:05:16]|h|r You feel normal.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115124,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [335]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:05:18]|h|r You loot 4 Silver, 27 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115126,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [336]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:05:43]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Babypud:1713:CHANNEL:1|h|cff0070ddBabypud|r|h|cffd8d8d8]|r: LFG Inc",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115151,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						27, -- [3]
						["n"] = 3,
					},
				}, -- [337]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:05:56]|h|r Enraged Feral Scar becomes enraged!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115164,
					["extraData"] = {
						17, -- [1]
						21, -- [2]
						22, -- [3]
						["n"] = 3,
					},
				}, -- [338]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:05:58]|h|r You receive loot: |cffffffff|Hitem:3928::::::::47:::::::::|h[Superior Healing Potion]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115166,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [339]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:05:59]|h|r You loot 4 Silver, 27 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115167,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [340]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:06:13]|h|r |cffc69b6dCannonballer|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115181,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [341]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:06:18]|h|r |cffd8d8d8[|r|Hplayer:Enjoglove:1725|h|cff8b8b8b24|r:|cfffff468Enjoglove|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115186,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [342]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:06:20]|h|r Quest accepted: Rescue OOX-22/FE!",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115188,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [343]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:06:20]|h|r Homing Robot OOX-22/FE says: Emergency power activated!  Initializing ambulatory motor!  CLUCK!",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115188,
					["extraData"] = {
						13, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [344]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:06:23]|h|r Homing Robot OOX-22/FE says: Threat analyzed!  Activating combat plan beta!  CLUCK!",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115191,
					["extraData"] = {
						13, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [345]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:06:23]|h|r [S] |cffd8d8d8[|r|Hplayer:Sepocana-Shadowstrike(AU):1729:SAY|h|cff3fc6eaSepocana|r|h|cffd8d8d8]|r: oh",
					["b"] = 1,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115191,
					["extraData"] = {
						2, -- [1]
						29, -- [2]
						30, -- [3]
						["n"] = 3,
					},
				}, -- [346]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:06:33]|h|r Enraged Feral Scar becomes enraged!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115201,
					["extraData"] = {
						17, -- [1]
						21, -- [2]
						22, -- [3]
						["n"] = 3,
					},
				}, -- [347]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:06:40]|h|r You loot 4 Silver, 10 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115208,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [348]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:06:54]|h|r |cfffff468Enjoglove|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115222,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [349]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:06:57]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Babypud-Shadowstrike(AU):1739:CHANNEL:1|h|cff0070ddBabypud|r|h|cffd8d8d8]|r: LFG Incursions have heaps to share",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115225,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						27, -- [3]
						["n"] = 3,
					},
				}, -- [350]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:07:18]|h|r Your skill in Wands has increased to 224.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115246,
					["extraData"] = {
						27, -- [1]
						23, -- [2]
						24, -- [3]
						["n"] = 3,
					},
				}, -- [351]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:08:18]|h|r You loot 2 Silver, 90 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115306,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [352]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:08:50]|h|r You loot 99 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115338,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [353]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:09:22]|h|r You loot 3 Silver, 19 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115370,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [354]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:09:45]|h|r You loot 2 Silver, 76 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115393,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [355]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:09:48]|h|r Homing Robot OOX-22/FE says: CLUCK!  Sensors detect spatial anomaly -- danger imminent!  CLUCK!",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115396,
					["extraData"] = {
						13, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [356]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:09:56]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Babypud-Shadowstrike(AU):1779:CHANNEL:1|h|cff0070ddBabypud|r|h|cffd8d8d8]|r: Call out bosses when u killin",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115404,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						27, -- [3]
						["n"] = 3,
					},
				}, -- [357]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:09:58]|h|r Homing Robot OOX-22/FE says: Physical threat detected!  Evasive action!  CLUCK!",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115406,
					["extraData"] = {
						13, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [358]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:10:31]|h|r |cffd8d8d8[|r|Hplayer:Enjoglove:1786|h|cff8b8b8b24|r:|cfffff468Enjoglove|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115439,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [359]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:10:43]|h|r |cffff7c0aKizza|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115451,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [360]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:11:25]|h|r |cfffff468Prepvanish|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115493,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [361]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:11:35]|h|r |cffd8d8d8[|r|Hplayer:Grasstoucher:1795|h|cffd88b6550|r:|cffaad372Grasstoucher|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115503,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [362]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:11:46]|h|r Rescue OOX-22/FE! failed.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115514,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [363]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:11:54]|h|r Your skill in Daggers has increased to 26.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115522,
					["extraData"] = {
						27, -- [1]
						23, -- [2]
						24, -- [3]
						["n"] = 3,
					},
				}, -- [364]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:12:00]|h|r You loot 4 Silver, 59 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115528,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [365]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:12:03]|h|r You loot 1 Silver, 69 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115531,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [366]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:12:51]|h|r |cffd8d8d8[|r|Hplayer:Zajave:1808|h|cff8b8b8b28|r:|cff0070ddZajave|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115579,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [367]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:13:07]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Babypud-Shadowstrike(AU):1814:CHANNEL:1|h|cff0070ddBabypud|r|h|cffd8d8d8]|r: LFG",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115595,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						27, -- [3]
						["n"] = 3,
					},
				}, -- [368]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:13:09]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Babypud-Shadowstrike(AU):1815:CHANNEL:1|h|cff0070ddBabypud|r|h|cffd8d8d8]|r: inc",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115597,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						27, -- [3]
						["n"] = 3,
					},
				}, -- [369]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:13:39]|h|r You receive loot: |cffffffff|Hitem:8146::::::::47:::::::::|h[Wicked Claw]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115627,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [370]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:13:40]|h|r You loot 3 Silver, 73 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115628,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [371]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:14:02]|h|r You loot 2 Silver, 88 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115650,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [372]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:14:39]|h|r |cff0070ddZajave|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115687,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [373]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:14:42]|h|r |cffd8d8d8[|r|Hplayer:Basilis:1832|h|cff8b8b8b18|r:|cffff7c0aBasilis|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115690,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [374]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:14:42]|h|r You loot 3 Silver, 62 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115690,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [375]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:14:43]|h|r You receive loot: |cff1eff00|Hitem:220932::::::::47:::::::::|h[Waylaid Supplies: Thorium Grenades]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115691,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [376]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:15:12]|h|r Quest accepted: Rescue OOX-22/FE!",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115720,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [377]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:15:12]|h|r Homing Robot OOX-22/FE says: Emergency power activated!  Initializing ambulatory motor!  CLUCK!",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115720,
					["extraData"] = {
						13, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [378]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:15:17]|h|r |cffd8d8d8[|r|Hplayer:Undiddly:1843|h|cffd8d83f47|r:|cffffffffUndiddly|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115725,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [379]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:15:57]|h|r |cffd8d8d8[|r|Hplayer:Teddywolf:1848|h|cff8b8b8b25|r:|cffffffffTeddywolf|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115765,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [380]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:16:04]|h|r Homing Robot OOX-22/FE says: CLUCK!  Sensors detect spatial anomaly -- danger imminent!  CLUCK!",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115772,
					["extraData"] = {
						13, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [381]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:17:11]|h|r Rescue OOX-22/FE! failed.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115839,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [382]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:17:31]|h|r |cffd8d8d8[|r|Hplayer:Petophile:1862|h|cffd88b6550|r:|cffaad372Petophile|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115859,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [383]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:18:57]|h|r You loot 70 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115945,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [384]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:19:08]|h|r |cff8787edGrampserson|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115956,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [385]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:19:11]|h|r You receive loot: |cffffffff|Hitem:1645::::::::47:::::::::|h[Moonberry Juice]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115959,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [386]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:19:12]|h|r You loot 2 Silver, 42 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115960,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [387]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:19:32]|h|r You loot 2 Silver, 57 Copper",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115980,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [388]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:19:38]|h|r |cffd8d8d8[|r|Hplayer:Lavenderlock:1883|h|cff8b8b8b25|r:|cff3fc6eaLavenderlock|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115986,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [389]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:19:43]|h|r Enraged Feral Scar becomes enraged!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714115991,
					["extraData"] = {
						17, -- [1]
						21, -- [2]
						22, -- [3]
						["n"] = 3,
					},
				}, -- [390]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:20:02]|h|r You have invited |cfffff468Quenda|r to join your group.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116010,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [391]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:20:02]|h|r Dungeon difficulty set to Normal",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116010,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [392]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:20:04]|h|r |cfffff468Quenda|r joins the party.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116012,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [393]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:20:13]|h|r Enraged Feral Scar becomes enraged!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116021,
					["extraData"] = {
						17, -- [1]
						21, -- [2]
						22, -- [3]
						["n"] = 3,
					},
				}, -- [394]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:20:16]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Quenda-Shadowstrike(AU):1892:PARTY|h|cfffff468Quenda|r|h|cffd8d8d8]|r: hey",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116024,
					["extraData"] = {
						3, -- [1]
						32, -- [2]
						33, -- [3]
						["n"] = 3,
					},
				}, -- [395]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:20:19]|h|r Your share of the loot is 1 Silver, 96 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116027,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [396]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:20:23]|h|r |cfffff468Quenda|r receives loot: |cffffffff|Hitem:8973::::::::47:::::::::|h[Thick Yeti Hide]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116031,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [397]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:20:23]|h|r |cfffff468Quenda|r receives loot: |cffffffff|Hitem:4234::::::::47:::::::::|h[Heavy Leather]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116031,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [398]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:20:32]|h|r |cfffff468Quenda|r receives loot: |cffffffff|Hitem:4234::::::::47:::::::::|h[Heavy Leather]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116040,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [399]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:20:33]|h|r You create: |cffffffff|Hitem:8075::::::::47:::::::::|h[Conjured Sourdough]|h|rx12.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116041,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [400]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:20:44]|h|r You have requested to trade with |cfffff468Quenda|r.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116052,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [401]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:20:55]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Quenda-Shadowstrike(AU):1908:PARTY|h|cfffff468Quenda|r|h|cffd8d8d8]|r: escort?",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116063,
					["extraData"] = {
						3, -- [1]
						32, -- [2]
						33, -- [3]
						["n"] = 3,
					},
				}, -- [402]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:20:58]|h|r Homing Robot OOX-22/FE says: Emergency power activated!  Initializing ambulatory motor!  CLUCK!",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116066,
					["extraData"] = {
						13, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [403]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:20:58]|h|r Quest accepted: Rescue OOX-22/FE!",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116066,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [404]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:21:16]|h|r |cfffff468Quenda|r receives loot: |cffffffff|Hitem:8973::::::::47:::::::::|h[Thick Yeti Hide]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116084,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [405]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:21:16]|h|r |cfffff468Quenda|r receives loot: |cffffffff|Hitem:4304::::::::47:::::::::|h[Thick Leather]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116084,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [406]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:21:26]|h|r |cffd8d8d8[|r|Hplayer:Grampserson:1915|h|cff8b8b8b31|r:|cff8787edGrampserson|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116094,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [407]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:21:35]|h|r Your share of the loot is 83 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116103,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [408]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:21:42]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Mattdamonn-Shadowstrike(AU):1919:CHANNEL:1|h|cffffffffMattdamonn|r|h|cffd8d8d8]|r: LF1M Feral inc dps",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116110,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						13, -- [3]
						["n"] = 3,
					},
				}, -- [409]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:21:51]|h|r |cfffff468Quenda|r receives loot: |cffffffff|Hitem:8973::::::::47:::::::::|h[Thick Yeti Hide]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116119,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [410]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:21:51]|h|r |cfffff468Quenda|r receives loot: |cff9d9d9d|Hitem:4026::::::::47:::::::::|h[Sentinel Musket]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116119,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [411]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:21:52]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Quenda-Shadowstrike(AU):1923:PARTY|h|cfffff468Quenda|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 10/10 Thick Yeti Hide for |Hquestie:2822:Player-5818-00A54E9B|h|cFFFFFF00[|r|cFFFFFF00[46] The Mark of Quality |cFF00ff00(Complete)|r|r|cFFFFFF00]|r|h!",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116120,
					["extraData"] = {
						3, -- [1]
						32, -- [2]
						33, -- [3]
						["n"] = 3,
					},
				}, -- [412]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:21:52]|h|r Your share of the loot is 72 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116120,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [413]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:21:56]|h|r Homing Robot OOX-22/FE says: Physical threat detected!  Evasive action!  CLUCK!",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116124,
					["extraData"] = {
						13, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [414]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:21:56]|h|r |cffd8d8d8[|r|Hplayer:Kizza:1926|h|cff8b8b8b18|r:|cffff7c0aKizza|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116124,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [415]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:22:06]|h|r |cffd8d8d8[|r|Hplayer:Suss:1929|h|cffd88b6550|r:|cffaad372Suss|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116134,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [416]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:22:10]|h|r |cffaad372Grasstoucher|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116138,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [417]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:22:13]|h|r Your share of the loot is 1 Silver, 49 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116141,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [418]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:22:32]|h|r Your share of the loot is 1 Silver, 15 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116160,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [419]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:22:33]|h|r Homing Robot OOX-22/FE says: CLUCK!  Sensors detect spatial anomaly -- danger imminent!  CLUCK!",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116161,
					["extraData"] = {
						13, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [420]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:22:51]|h|r |cffd8d8d8[|r|Hplayer:Prepvanish:1940|h|cffd88b6550|r:|cfffff468Prepvanish|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116179,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [421]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:23:15]|h|r |cfffff468Quenda|r receives loot: |cff9d9d9d|Hitem:11408::::::::47:::::::::|h[Bear Jaw]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116203,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [422]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:24:22]|h|r |cff8787edSlappylock|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116270,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [423]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:24:30]|h|r |cffc69b6dBuffdaddyxd|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116278,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [424]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:24:48]|h|r Homing Robot OOX-22/FE says: CLUCK!  Sensors detect spatial anomaly -- danger imminent!  CLUCK!",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116296,
					["extraData"] = {
						13, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [425]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:24:48]|h|r Discovered The Forgotten Coast: 455 experience gained",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116296,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [426]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:24:55]|h|r |cffffffffUndiddly|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116303,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [427]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:25:11]|h|r |cfffff468Quenda|r receives loot: |cffffffff|Hitem:2799::::::::47:::::::::|h[Gorilla Fang]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116319,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [428]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:25:15]|h|r You receive loot: |cffffffff|Hitem:2799::::::::47:::::::::|h[Gorilla Fang]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116323,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [429]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:25:15]|h|r You receive loot: |cffffffff|Hitem:5637::::::::47:::::::::|h[Large Fang]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116323,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [430]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:25:16]|h|r |cfffff468Quenda|r receives loot: |cff9d9d9d|Hitem:4099::::::::47:::::::::|h[Tuft of Gorilla Hair]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116324,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [431]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:25:22]|h|r |cfffff468Quenda|r receives loot: |cffffffff|Hitem:4304::::::::47:::::::::|h[Thick Leather]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116330,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [432]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:25:26]|h|r |cfffff468Quenda|r receives loot: |cffffffff|Hitem:4304::::::::47:::::::::|h[Thick Leather]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116334,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [433]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:25:27]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Getotrix-Shadowstrike(AU):1982:CHANNEL:1|h|cffffffffGetotrix|r|h|cffd8d8d8]|r: handing in nerene",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116335,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						11, -- [3]
						["n"] = 3,
					},
				}, -- [434]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:25:29]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Getotrix-Shadowstrike(AU):1984:CHANNEL:1|h|cffffffffGetotrix|r|h|cffd8d8d8]|r: 1 min",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116337,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						11, -- [3]
						["n"] = 3,
					},
				}, -- [435]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:25:59]|h|r |cffd8d8d8[|r|Hplayer:Undiddly:1988|h|cffd8d83f47|r:|cffffffffUndiddly|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116367,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [436]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:26:02]|h|r Homing Robot OOX-22/FE says: CLUCK!  Sensors detect spatial anomaly -- danger imminent!  CLUCK!",
					["b"] = 0.6235294342041016,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116370,
					["extraData"] = {
						13, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
				}, -- [437]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:26:08]|h|r |cffd8d8d8[|r|Hplayer:Dangerdann:1991|h|cff8b8b8b34|r:|cffffffffDangerdann|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116376,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [438]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:26:32]|h|r |cffaad372Suss|r has left the guild.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116400,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [439]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:26:47]|h|r Woodpaw Reaver attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116415,
					["extraData"] = {
						17, -- [1]
						21, -- [2]
						22, -- [3]
						["n"] = 3,
					},
				}, -- [440]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:26:48]|h|r Your skill in Defense has increased to 221.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116416,
					["extraData"] = {
						27, -- [1]
						23, -- [2]
						24, -- [3]
						["n"] = 3,
					},
				}, -- [441]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:26:48]|h|r Woodpaw Brute attempts to run away in fear!",
					["b"] = 0.250980406999588,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116416,
					["extraData"] = {
						17, -- [1]
						21, -- [2]
						22, -- [3]
						["n"] = 3,
					},
				}, -- [442]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:26:54]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Emz-Shadowstrike(AU):2003:PARTY|h|cffd8d83f47|r:|cff3fc6eaEmz|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Escort OOX-22/FE to the dock along the Forgotten Coast for |Hquestie:2767:Player-5818-00A9F32E|h|cFFFFFF00[|r|cFFFFFF00[45] Rescue OOX-22/FE! |cFF00ff00(Complete)|r|r|cFFFFFF00]|r|h!",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116422,
					["extraData"] = {
						50, -- [1]
						32, -- [2]
						34, -- [3]
						["n"] = 3,
					},
				}, -- [443]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:26:54]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Quenda-Shadowstrike(AU):2004:PARTY|h|cfffff468Quenda|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t Questie: 1/1 Escort OOX-22/FE to the dock along the Forgotten Coast for |Hquestie:2767:Player-5818-00A54E9B|h|cFFFFFF00[|r|cFFFFFF00[45] Rescue OOX-22/FE! |cFF00ff00(Complete)|r|r|cFFFFFF00]|r|h!",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116422,
					["extraData"] = {
						3, -- [1]
						32, -- [2]
						33, -- [3]
						["n"] = 3,
					},
				}, -- [444]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:27:03]|h|r Your share of the loot is 1 Silver, 70 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116431,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [445]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:27:06]|h|r |Hchannel:PARTY|h[P] |h|cffd8d8d8[|r|Hplayer:Quenda-Shadowstrike(AU):2009:PARTY|h|cfffff468Quenda|r|h|cffd8d8d8]|r: cheers",
					["b"] = 1,
					["r"] = 0.6666666865348816,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116434,
					["extraData"] = {
						3, -- [1]
						32, -- [2]
						33, -- [3]
						["n"] = 3,
					},
				}, -- [446]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:27:13]|h|r |Hchannel:PARTY|h[PL] |h|cffd8d8d8[|r|Hplayer:Emz-Shadowstrike(AU):2011:PARTY|h|cffd8d83f47|r:|cff3fc6eaEmz|r|h|cffd8d8d8]|r: ty",
					["b"] = 1,
					["r"] = 0.4627451300621033,
					["g"] = 0.7843137979507446,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116441,
					["extraData"] = {
						50, -- [1]
						32, -- [2]
						34, -- [3]
						["n"] = 3,
					},
				}, -- [447]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:27:21]|h|r Your group has been disbanded.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116449,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [448]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:27:38]|h|r |cffff7c0aTankmt|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116466,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [449]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:28:07]|h|r You receive loot: |cffffffff|Hitem:4306::::::::47:::::::::|h[Silk Cloth]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116495,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [450]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:28:08]|h|r Your share of the loot is 1 Silver, 78 Copper.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116496,
					["extraData"] = {
						29, -- [1]
						17, -- [2]
						18, -- [3]
						["n"] = 3,
					},
				}, -- [451]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:28:51]|h|r |cffd8d8d8[|r|Hplayer:Grimtog:2025|h|cff8b8b8b25|r:|cff0070ddGrimtog|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116539,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [452]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:29:26]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Getotrix-Shadowstrike(AU):2031:CHANNEL:1|h|cffffffffGetotrix|r|h|cffd8d8d8]|r: LF1M FERALAS INC",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116574,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						11, -- [3]
						["n"] = 3,
					},
				}, -- [453]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:31:08]|h|r |cffd8d8d8[|r|Hplayer:Rflegend:2045|h|cff65b26540|r:|cff8787edRflegend|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116676,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [454]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:31:40]|h|r |cffff7c0aBasilis|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116708,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [455]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:31:41]|h|r |cffd8d8d8[|r|Hplayer:Ghyn:2052|h|cff8b8b8b36|r:|cff0070ddGhyn|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116709,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [456]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:31:50]|h|r You feel rested.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116718,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [457]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:32:16]|h|r You receive item: |cffffffff|Hitem:9629::::::::47:::::::::|h[A Shrunken Head]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116744,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [458]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:32:16]|h|r Quest accepted: A Strange Request",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116744,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [459]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:32:37]|h|r Congratulations, you have reached level 48!",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116765,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [460]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:32:37]|h|r You have gained 40 hit points and 66 mana.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116765,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [461]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:32:37]|h|r You have gained 1 talent point.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116765,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [462]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:32:37]|h|r Your Intellect increases by 3.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116765,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [463]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:32:37]|h|r Your Spirit increases by 2.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116765,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
				}, -- [464]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:32:37]|h|r Your Thunder Bluff reputation has increased by 100.",
					["b"] = 1,
					["r"] = 0.501960813999176,
					["g"] = 0.501960813999176,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116765,
					["extraData"] = {
						36, -- [1]
						36, -- [2]
						37, -- [3]
						["n"] = 3,
					},
				}, -- [465]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:32:37]|h|r Your skill in Fire has increased to 240.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116765,
					["extraData"] = {
						27, -- [1]
						23, -- [2]
						24, -- [3]
						["n"] = 3,
					},
				}, -- [466]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:32:37]|h|r Your skill in Arcane has increased to 240.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116765,
					["extraData"] = {
						27, -- [1]
						23, -- [2]
						24, -- [3]
						["n"] = 3,
					},
				}, -- [467]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:32:37]|h|r Your skill in Frost has increased to 240.",
					["b"] = 1,
					["r"] = 0.3333333432674408,
					["g"] = 0.3333333432674408,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116765,
					["extraData"] = {
						27, -- [1]
						23, -- [2]
						24, -- [3]
						["n"] = 3,
					},
				}, -- [468]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:32:38]|h|r The Mark of Quality completed.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116766,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [469]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:32:38]|h|r Experience gained: 7087.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116766,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [470]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:32:38]|h|r You receive item: |cff1eff00|Hitem:9633::::::::48:::::::::|h[Jangdor's Handcrafted Boots]|h|r.",
					["b"] = 0,
					["r"] = 0,
					["g"] = 0.6666666865348816,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116766,
					["extraData"] = {
						28, -- [1]
						15, -- [2]
						16, -- [3]
						["n"] = 3,
					},
				}, -- [471]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:32:38]|h|r Quest accepted: Improved Quality",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116766,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [472]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:33:25]|h|r |cffaad372Snipegodx|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116813,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [473]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:33:35]|h|r |cffd8d8d8[|r|Hplayer:Storagewar:2086|h|cff8b8b8b1|r:|cffc69b6dStoragewar|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116823,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [474]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:33:45]|h|r |cff8787edRflegend|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116833,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [475]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:33:46]|h|r |cffffffffDangerdann|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116834,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [476]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:33:56]|h|r |cffc69b6dStoragewar|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116844,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [477]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:33:58]|h|r |cffd8d8d8[|r|Hplayer:Ghuldamn:2092|h|cff8b8b8b38|r:|cff8787edGhuldamn|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116846,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [478]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:34:55]|h|r |cff0070ddThedirtybird|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116903,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [479]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:36:01]|h|r |cffff7c0aBulljuice|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714116969,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [480]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:36:34]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Babypud-Shadowstrike(AU):2115:CHANNEL:1|h|cff0070ddBabypud|r|h|cffd8d8d8]|r: LFG Incur",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117002,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						27, -- [3]
						["n"] = 3,
					},
				}, -- [481]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:36:48]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Alibabba:2118:CHANNEL:1|h|cff0070ddAlibabba|r|h|cffd8d8d8]|r: lfg for fel inc",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117016,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						38, -- [3]
						["n"] = 3,
					},
				}, -- [482]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:37:03]|h|r |cffd8d8d8[|r|Hplayer:Ikari:2122|h|cff8b8b8b13|r:|cffaad372Ikari|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117031,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [483]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:37:46]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Whiteravenn-Shadowstrike(AU):2134:CHANNEL:1|h|cffaad372Whiteravenn|r|h|cffd8d8d8]|r: LFG feralas INC",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117074,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						40, -- [3]
						["n"] = 3,
					},
				}, -- [484]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:38:41]|h|r You are now AFK: Away from Keyboard",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117129,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [485]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:40:22]|h|r |cffd8d8d8[|r|Hplayer:Zajave:2181|h|cff8b8b8b28|r:|cff0070ddZajave|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117230,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [486]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:40:54]|h|r |cff0070ddZajave|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117262,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [487]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:42:34]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Vz-Shadowstrike(AU):2226:CHANNEL:1|h|cfffff468Vz|r|h|cffd8d8d8]|r: dps lfg Feralas incs",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117362,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						43, -- [3]
						["n"] = 3,
					},
				}, -- [488]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:42:36]|h|r |cffff7c0aKizza|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117364,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [489]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:42:38]|h|r |cff0070ddGhyn|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117366,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [490]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:43:06]|h|r |cffd8d8d8[|r|Hplayer:Ghyn:2240|h|cff8b8b8b36|r:|cff0070ddGhyn|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117394,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [491]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:43:59]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Bonds-Shadowstrike(AU):2253:CHANNEL:1|h|cff8787edBonds|r|h|cffd8d8d8]|r: anyone looking for scars?",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117447,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						46, -- [3]
						["n"] = 3,
					},
				}, -- [492]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:44:38]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Vz-Shadowstrike(AU):2266:CHANNEL:1|h|cfffff468Vz|r|h|cffd8d8d8]|r: LF2M Feralas incs",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117486,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						43, -- [3]
						["n"] = 3,
					},
				}, -- [493]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:46:55]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Dondee:2296:CHANNEL:1|h|cff0070ddDondee|r|h|cffd8d8d8]|r: LFG INC",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117623,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						48, -- [3]
						["n"] = 3,
					},
				}, -- [494]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:47:24]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Daguvnar:2305:CHANNEL:1|h|cffaad372Daguvnar|r|h|cffd8d8d8]|r: lfg inc",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117652,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						50, -- [3]
						["n"] = 3,
					},
				}, -- [495]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:47:26]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Babypud-Shadowstrike(AU):2307:CHANNEL:1|h|cff0070ddBabypud|r|h|cffd8d8d8]|r: LFG Feral inc ele sham can heal if need",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117654,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						27, -- [3]
						["n"] = 3,
					},
				}, -- [496]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:47:32]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Whiteravenn-Shadowstrike(AU):2310:CHANNEL:1|h|cffaad372Whiteravenn|r|h|cffd8d8d8]|r: LFG feralas INC",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117660,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						40, -- [3]
						["n"] = 3,
					},
				}, -- [497]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:48:15]|h|r |cffaad372Diqiurena|r has gone offline.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117703,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [498]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:49:37]|h|r |cffd8d8d8[|r|Hplayer:Diqiurena:2346|h|cffd8d83f50|r:|cffaad372Diqiurena|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117785,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [499]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:49:42]|h|r |cffd8d8d8[|r|Hplayer:Mcshoulders:2350|h|cff8b8b8b13|r:|cff0070ddMcshoulders|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117790,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [500]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:50:04]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Daguvnar-Shadowstrike(AU):2363:CHANNEL:1|h|cffaad372Daguvnar|r|h|cffd8d8d8]|r: lfg inc",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117812,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						50, -- [3]
						["n"] = 3,
					},
				}, -- [501]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:50:42]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Dondee-Shadowstrike(AU):2381:CHANNEL:1|h|cff0070ddDondee|r|h|cffd8d8d8]|r: also LFG inc",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117850,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						48, -- [3]
						["n"] = 3,
					},
				}, -- [502]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:50:56]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Anoteros:2389:CHANNEL:1|h|cff0070ddAnoteros|r|h|cffd8d8d8]|r: dps/heals lfg incursions",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117864,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						53, -- [3]
						["n"] = 3,
					},
				}, -- [503]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:51:42]|h|r |cffd8d8d8[|r|Hplayer:Unicorns:2410|h|cff8b8b8b33|r:|cffaad372Unicorns|r|h|cffd8d8d8]|r has come online.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117910,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [504]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:51:57]|h|r |cff3fc6eaRoserolis|r has left the guild.",
					["b"] = 0,
					["r"] = 1,
					["g"] = 1,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117925,
					["extraData"] = {
						1, -- [1]
						3, -- [2]
						4, -- [3]
						["n"] = 3,
					},
				}, -- [505]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:52:19]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Thunder Bluff]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117947,
					["extraData"] = {
						69, -- [1]
						5, -- [2]
						6, -- [3]
						["n"] = 3,
					},
				}, -- [506]
				{
					["message"] = "|cff979797|Hpratcopy|h[17:52:19]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Thunder Bluff]|h",
					["b"] = 0.7529412508010864,
					["r"] = 1,
					["g"] = 0.7529412508010864,
					["timestamp"] = 27625.47,
					["serverTime"] = 1714117947,
					["extraData"] = {
						71, -- [1]
						8, -- [2]
						9, -- [3]
						["n"] = 3,
					},
				}, -- [507]
				{
					["message"] = "0 days, 4 hours, 16 minutes, 43 seconds",
					["timestamp"] = 27625.47,
				}, -- [508]
				{
					["message"] = "========== End of Scrollback ==========",
					["timestamp"] = 27625.47,
				}, -- [509]
				{
					["message"] = " |cffff8800<|cffffbb00FarmLog|cffff8800>|r |cffffbb00v1.24|r by |cffb266ffKof|r @ |cffff2222Firemaw|r (era), type |cff00ff00/fl|r for options, right click minimap icon to resume/pause a farm session, |cff00ff00/fl help|r for more commands",
					["timestamp"] = 27605.592,
				}, -- [510]
				{
					["message"] = "|cFFFF1C1C Loaded: LFG Bulletin Board 3.23 by Vyscî-Whitemane",
					["timestamp"] = 27605.592,
				}, -- [511]
				{
					["message"] = "|cFF00FFFFLoaded MageBookTracker v1.1.0 by Haruhara",
					["timestamp"] = 27605.592,
				}, -- [512]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Dominos Detected, please make sure Dominos Elements are disabled in MoveAny!",
					["timestamp"] = 27605.592,
				}, -- [513]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Click the MoveAny Minimap Button to open the settings.",
					["timestamp"] = 27605.592,
				}, -- [514]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 Or tap /move or /moveany in chat to open the settings.",
					["timestamp"] = 27605.592,
				}, -- [515]
				{
					["message"] = "|cff3FC7EB[MoveAny |T135994:16:16:0:0|t]|r |cFFFFFF00 To hide these messages deactivate tips in the MoveAny menu.",
					["timestamp"] = 27605.592,
				}, -- [516]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:00]|h|r |cFF00FFB0WeaponSwingTimer: |rThank you for installing WeaponSwingTimer Version 7.2.5 by WatchYourSixx! Use |cFFFFC300/wst|r for more options.",
					["timestamp"] = 27605.592,
				}, -- [517]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:00]|h|r |cff33ff99WowSimsExporter|r: WowSimsExporter v2.9 Initialized. use /wse For Window.",
					["timestamp"] = 27605.592,
				}, -- [518]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:02]|h|r |cff33ff99Scambuster|r: INFO: Parsing provider list Shadowstrike Discord Blacklist...",
					["timestamp"] = 27625.47,
					["serverTime"] = 1714133350,
				}, -- [519]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:02]|h|r |cff33ff99Scambuster|r: Welcome to version 0.1.6",
					["timestamp"] = 27625.47,
					["serverTime"] = 1714133350,
				}, -- [520]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:02]|h|r |cffffff99<aux> loaded - /aux",
					["timestamp"] = 27625.47,
					["serverTime"] = 1714133350,
				}, -- [521]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:02]|h|r |c00FFAA00ThreatClassic2 v2.50 - Type /tc2 for options.|r",
					["timestamp"] = 27625.47,
					["serverTime"] = 1714133350,
				}, -- [522]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:03]|h|r |cffe6cc80 [Whoa Thick Frames |cFF0070FFClassic|r |cffe6cc80v1.5d ] |cffffffffis now loaded. Use |cffffff00'/whoaf' |cffffffffto view options.",
					["timestamp"] = 27625.47,
					["serverTime"] = 1714133351,
				}, -- [523]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:03]|h|r |cffe6cc80Ranker|r: AddOn version 2024.03.25.01 loaded.",
					["timestamp"] = 27625.47,
					["serverTime"] = 1714133351,
				}, -- [524]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:04]|h|r |cffffff00[Grab GUID]|r loaded. Use |cff00ff00/gg|r or |cff00ff00/grabguid|r to bring up Grab GUID frame.",
					["timestamp"] = 27625.47,
					["serverTime"] = 1714133352,
				}, -- [525]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:05]|h|r |cff1a9fc0Enemy Cooldown Count|r loaded!",
					["timestamp"] = 27628.472,
					["serverTime"] = 1714133353,
				}, -- [526]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:05]|h|r Type |cff1a9fc0/ecdc|r to open settings.",
					["timestamp"] = 27628.472,
					["serverTime"] = 1714133353,
				}, -- [527]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:05]|h|r |cFFffff00[Questie]|r |cFF6ce314The 'Darkmoon Faire' world event is active!",
					["timestamp"] = 27629.066,
					["serverTime"] = 1714133353,
				}, -- [528]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:06]|h|r RestedXP Guides: TotemTimers has known incompatibilities with the Waypoint Arrow. Disable it if you're experiencing navigation issues.",
					["timestamp"] = 27629.471,
					["serverTime"] = 1714133354,
				}, -- [529]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:08]|h|r Error parsing guide Icy Veins/Spell Power/Deep Freeze - 40 (Azeroth): Invalid text/map name\n.zone Hinterlands >>Travel to |cFFfa9602Hinterlands|r",
					["timestamp"] = 27632.11,
					["serverTime"] = 1714133356,
				}, -- [530]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:08]|h|r Error parsing guide Icy Veins/Spell Power/Deep Freeze - 40 (Azeroth): Invalid coordinates or map name\n.goto Hinterlands,36,72.7",
					["timestamp"] = 27632.11,
					["serverTime"] = 1714133356,
				}, -- [531]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:09]|h|r |cffff7d0a<|r|cffffd200DBM|r|cffff7d0a>|r Your version of Deadly Boss Mods is out-of-date.",
					["r"] = 0.41,
					["serverTime"] = 1714133357,
					["timestamp"] = 27632.769,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [532]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:09]|h|r |cffff7d0a<|r|cffffd200DBM|r|cffff7d0a>|r  Version 10.2.36 (2024/04/23 00:00:00) is available for download through Curse, Wago, WoWI, or from GitHub Releases page",
					["r"] = 0.41,
					["serverTime"] = 1714133357,
					["timestamp"] = 27632.769,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [533]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:09]|h|r |cffff7d0a<|r|cffffd200DBM|r|cffff7d0a>|r  Version DBM-Raids-Vanilla is available for download through Curse, Wago, WoWI, or from GitHub Releases page",
					["r"] = 0.41,
					["serverTime"] = 1714133357,
					["timestamp"] = 27632.769,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [534]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:12]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|h|HNWBCustomLink:timers|hYou are on a layered realm.|h|h",
					["timestamp"] = 27635.471,
					["serverTime"] = 1714133360,
				}, -- [535]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:12]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|h|HNWBCustomLink:timers|hClick here to view current timers.|h|h",
					["timestamp"] = 27635.471,
					["serverTime"] = 1714133360,
				}, -- [536]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:12]|h|r |cffff6900|HNWBCustomLink:buffs|h[DMF]|h|r |cffffff00|HNWBCustomLink:timers|h|HNWBCustomLink:timers|hYour DMF buff cooldown has 2 hours 30 minutes left.|h|h",
					["timestamp"] = 27635.471,
					["serverTime"] = 1714133360,
				}, -- [537]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:15]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Shocknawe:1:CHANNEL:2|h|cff0070ddShocknawe|r|h|cffd8d8d8]|r: LF BS |cffffffff|Hitem:16206::::::::50:::::::::|h[Arcanite Rod]|h|r have mats",
					["serverTime"] = 1714133363,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						2, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27638.416,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [538]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:27]|h|r RestedXP Guides: Targeting macro updated with (Uthel'nay)",
					["timestamp"] = 27650.557,
					["serverTime"] = 1714133375,
				}, -- [539]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:29]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Orgrimmar]|h",
					["serverTime"] = 1714133377,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27652.638,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [540]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:29]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Orgrimmar]|h",
					["serverTime"] = 1714133377,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27652.638,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [541]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:09:47]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Richiemon:8:CHANNEL:1|h|cffaad372Richiemon|r|h|cffd8d8d8]|r: anyone elses trinket menu always erroring?",
					["serverTime"] = 1714133395,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						4, -- [2]
						10, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27670.384,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [542]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:10:29]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Explicits:14:CHANNEL:1|h|cffaad372Explicits|r|h|cffd8d8d8]|r: anyone for premade wsg",
					["serverTime"] = 1714133437,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						4, -- [2]
						12, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27713.285,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [543]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:10:39]|h|r Your Darkspear Trolls reputation has increased by 50.",
					["serverTime"] = 1714133447,
					["r"] = 0.501960813999176,
					["extraData"] = {
						36, -- [1]
						14, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27723.326,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [544]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:10:40]|h|r The Gordunni Orb completed.",
					["serverTime"] = 1714133448,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27723.334,
					["g"] = 1,
					["b"] = 0,
				}, -- [545]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:10:40]|h|r Experience gained: 3675.",
					["serverTime"] = 1714133448,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27723.334,
					["g"] = 1,
					["b"] = 0,
				}, -- [546]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:10:40]|h|r RestedXP Guides: Targeting macro updated with (Pephredo)",
					["timestamp"] = 27723.385,
					["serverTime"] = 1714133448,
				}, -- [547]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:10:40]|h|r RestedXP Guides: Targeting macro updated with (Zor Lonetree)",
					["timestamp"] = 27723.46,
					["serverTime"] = 1714133448,
				}, -- [548]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:10:40]|h|r RestedXP Guides: Targeting macro updated with (Zilzibin Drumlore)",
					["timestamp"] = 27723.523,
					["serverTime"] = 1714133448,
				}, -- [549]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:10:40]|h|r Quest accepted: Speak with Un'thuwa",
					["serverTime"] = 1714133448,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27724.006,
					["g"] = 1,
					["b"] = 0,
				}, -- [550]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:10:41]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Abdel:20:CHANNEL:1|h|cff8787edAbdel|r|h|cffd8d8d8]|r: wtb port uc",
					["serverTime"] = 1714133449,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						4, -- [2]
						18, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27725.154,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [551]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:10:51]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Tokenx:23:CHANNEL:2|h|cffaad372Tokenx|r|h|cffd8d8d8]|r: WTS |cff0070dd|Hitem:2564::::::::50:::::::::|h[Elven Spirit Claws]|h|r 3g",
					["serverTime"] = 1714133459,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						20, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27734.527,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [552]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:11:04]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Ichor:25:CHANNEL:2|h|cffc69b6dIchor|r|h|cffd8d8d8]|r: LF MASTER TRANSMUTER TO XMUTE |cff1eff00|Hitem:12363::::::::50:::::::::|h[Arcane Crystal]|h|r INTO |cff1eff00|Hitem:12360::::::::50:::::::::|h[Arcanite Bar]|h|r",
					["serverTime"] = 1714133472,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27747.599,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [553]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:11:10]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Vaysham:27:CHANNEL:2|h|cff0070ddVaysham|r|h|cffd8d8d8]|r: WTB |cff1eff00|Hitem:221021::::::::50:::::::::|h[Nightmare Seed]|h|r pst",
					["serverTime"] = 1714133478,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						24, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27754.13,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [554]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:11:13]|h|r You receive item: |cffffffff|Hitem:7269::::::::48:::::::::|h[Deino's Flask]|h|r.",
					["serverTime"] = 1714133481,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						26, -- [2]
						27, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27756.369,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [555]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:11:13]|h|r Quest accepted: Waters of Xavian",
					["serverTime"] = 1714133481,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27756.416,
					["g"] = 1,
					["b"] = 0,
				}, -- [556]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:11:36]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Xian:38:CHANNEL:2|h|cffffffffXian|r|h|cffd8d8d8]|r: WTS quest share for priest dispersion rune |Hquestie:79731:Player-5818-00AB2307|h|cFFC0C0C0[|r|cFFC0C0C0[35] The Troll Scroll|r|cFFC0C0C0]|r|h 1g",
					["serverTime"] = 1714133504,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27779.867,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [557]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:11:40]|h|r |cffd8d8d8[|r|Hplayer:Cuirass:40|h|cffd8d83f50|r:|cffc69b6dCuirass|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714133508,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27784.082,
					["g"] = 1,
					["b"] = 0,
				}, -- [558]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:11:44]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Lavablurst:42:CHANNEL:2|h|cff0070ddLavablurst|r|h|cffd8d8d8]|r: LFW ENCHANTER - 25agi/15agi 2h/1h - 15STR 1h -20 spirit 1h- 7agi gloves/7agi boots - 5spirit boots/9 spirit bracers - 9str bracers - +3 all chest - 100hp chest - FIERY weapon / +4/+7 striking weapon +7 stam shield - 7 INT Bracers - 7stam boots/bracers",
					["serverTime"] = 1714133512,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						30, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27788.015,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [559]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:11:57]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Twopact:48:CHANNEL:2|h|cff8787edTwopact|r|h|cffd8d8d8]|r: WTS |cffffffff|Hitem:5634::::::::1:::::::::|h[Free Action Potion]|h|r Cheaper than AH",
					["serverTime"] = 1714133525,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						32, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27800.832,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [560]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:12:35]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Vaysham-Shadowstrike(AU):56:CHANNEL:2|h|cff0070ddVaysham|r|h|cffd8d8d8]|r: wtb |cff1eff00|Hitem:221021::::::::50:::::::::|h[Nightmare Seed]|h|rx14 pst",
					["serverTime"] = 1714133563,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						24, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27839.163,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [561]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:12:36]|h|r You have learned a new spell: Conjure Mana Citrine.",
					["serverTime"] = 1714133564,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27840.11,
					["g"] = 1,
					["b"] = 0,
				}, -- [562]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:12:58]|h|r [Y] |cffd8d8d8[|r|Hplayer:Feralpunk-Shadowstrike(AU):62:YELL|h|cffd8d83f50|r:|cffff7c0aFeralpunk|r|h|cffd8d8d8]|r: LF Blacksmith",
					["serverTime"] = 1714133586,
					["r"] = 1,
					["extraData"] = {
						7, -- [1]
						34, -- [2]
						35, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27861.691,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [563]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:13:03]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Xian-Shadowstrike(AU):63:CHANNEL:2|h|cffffffffXian|r|h|cffd8d8d8]|r: WTS quest share for priest dispersion rune |Hquestie:79731:Player-5818-00AB2307|h|cFFC0C0C0[|r|cFFC0C0C0[35] The Troll Scroll|r|cFFC0C0C0]|r|h 1g",
					["serverTime"] = 1714133591,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27866.92,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [564]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:13:13]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Explicits-Shadowstrike(AU):66:CHANNEL:2|h|cffaad372Explicits|r|h|cffd8d8d8]|r: anyone for premade wsg",
					["serverTime"] = 1714133601,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						36, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27877.049,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [565]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:14:02]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Explicits-Shadowstrike(AU):75:CHANNEL:2|h|cffaad372Explicits|r|h|cffd8d8d8]|r: LF2M wsg premade",
					["serverTime"] = 1714133650,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						36, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27925.438,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [566]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:14:31]|h|r |cffd8d8d8[|r|Hplayer:Sontre:88|h|cffd8d83f50|r:|cff0070ddSontre|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714133679,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27954.682,
					["g"] = 1,
					["b"] = 0,
				}, -- [567]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:14:36]|h|r |cffd8d8d8[|r|Hplayer:Lokuyzaw:91|h|cff8b8b8b1|r:|cffc69b6dLokuyzaw|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714133684,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27959.379,
					["g"] = 1,
					["b"] = 0,
				}, -- [568]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:14:53]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Explicits-Shadowstrike(AU):97:CHANNEL:2|h|cffaad372Explicits|r|h|cffd8d8d8]|r: LF1M wsg premade prefer heals",
					["serverTime"] = 1714133701,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						36, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27976.536,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [569]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:14:58]|h|r |cffd8d8d8[|r|Hplayer:Smitemeddy:101|h|cffd8d83f50|r:|cffffffffSmitemeddy|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714133706,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27982.09,
					["g"] = 1,
					["b"] = 0,
				}, -- [570]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:14]|h|r |cffc69b6dLokuyzaw|r has gone offline.",
					["serverTime"] = 1714133722,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 27998.118,
					["g"] = 1,
					["b"] = 0,
				}, -- [571]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:24]|h|r [Y] |cffd8d8d8[|r|Hplayer:Toma-Shadowstrike(AU):117:YELL|h|cffaad372Toma|r|h|cffd8d8d8]|r: WTB RFC boost runs  6g a run have 3 alts",
					["serverTime"] = 1714133732,
					["r"] = 1,
					["extraData"] = {
						7, -- [1]
						34, -- [2]
						42, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28008.094,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [572]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:34]|h|r |cffd8d8d8[|r|Hplayer:Ikorr:123|h|cffd8d83f50|r:|cffaad372Ikorr|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714133742,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28017.845,
					["g"] = 1,
					["b"] = 0,
				}, -- [573]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:38]|h|r Nogg yells: Alright everyone listen up. Some stooge... uh, I mean \"brave adventurer\" brought me a whole huge pile of secret gnomish tech and once we finish applying our superior goblin ingenuity to it we are going to use it to BLOW SO MUCH STUFF UP. Gather 'round and let's party!",
					["serverTime"] = 1714133746,
					["r"] = 1,
					["extraData"] = {
						15, -- [1]
						44, -- [2]
						45, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28021.556,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [574]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:15:44]|h|r |cffff6900|HNWBCustomLink:buffs|h[WorldBuffs]|h|r |cffffff00|HNWBCustomLink:timers|hSpark of Inspiration buff has dropped.|h",
					["timestamp"] = 28027.954,
					["serverTime"] = 1714133752,
				}, -- [575]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:16:00]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Flayed:138:CHANNEL:2|h|cffffffffFlayed|r|h|cffd8d8d8]|r: WTS |cff0070dd|Hitem:221287::::::::50:::::::::|h[Seven of Plagues]|h|r",
					["serverTime"] = 1714133768,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						46, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28043.85,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [576]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:16:11]|h|r Zukk'ash Report completed.",
					["serverTime"] = 1714133779,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28054.797,
					["g"] = 1,
					["b"] = 0,
				}, -- [577]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:16:11]|h|r Experience gained: 7700.",
					["serverTime"] = 1714133779,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28054.797,
					["g"] = 1,
					["b"] = 0,
				}, -- [578]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:16:11]|h|r Your Horde reputation has increased by 50.",
					["serverTime"] = 1714133779,
					["r"] = 0.501960813999176,
					["extraData"] = {
						36, -- [1]
						14, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28054.81,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [579]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:16:11]|h|r RestedXP Guides: Targeting macro updated with (Belgrom Rockmaul)",
					["timestamp"] = 28054.85,
					["serverTime"] = 1714133779,
				}, -- [580]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:16:11]|h|r You receive item: |cff1eff00|Hitem:19038::::::::48:::::::::|h[Ring of Subtlety]|h|r.",
					["serverTime"] = 1714133779,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						26, -- [2]
						27, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28054.892,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [581]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:16:24]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Xian-Shadowstrike(AU):155:CHANNEL:2|h|cffffffffXian|r|h|cffd8d8d8]|r: WTS quest share for priest dispersion rune |Hquestie:79731:Player-5818-00AB2307|h|cFFC0C0C0[|r|cFFC0C0C0[35] The Troll Scroll|r|cFFC0C0C0]|r|h 1g",
					["serverTime"] = 1714133792,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28067.656,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [582]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:16:42]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Slicen:163:CHANNEL:1|h|cfffff468Slicen|r|h|cffd8d8d8]|r: lf3m healer/dps wc",
					["serverTime"] = 1714133810,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						4, -- [2]
						49, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28085.508,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [583]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:26]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Flayed-Shadowstrike(AU):187:CHANNEL:2|h|cffffffffFlayed|r|h|cffd8d8d8]|r: WTS |cff0070dd|Hitem:221287::::::::50:::::::::|h[Seven of Plagues]|h|r",
					["serverTime"] = 1714133854,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						46, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28130.25,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [584]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:36]|h|r Your Orgrimmar reputation has increased by 150.",
					["serverTime"] = 1714133864,
					["r"] = 0.501960813999176,
					["extraData"] = {
						36, -- [1]
						14, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28139.581,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [585]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:36]|h|r A Grim Discovery completed.",
					["serverTime"] = 1714133864,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28139.581,
					["g"] = 1,
					["b"] = 0,
				}, -- [586]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:36]|h|r Experience gained: 8487.",
					["serverTime"] = 1714133864,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28139.581,
					["g"] = 1,
					["b"] = 0,
				}, -- [587]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:36]|h|r Received 1 Gold, 95 Silver.",
					["serverTime"] = 1714133864,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28139.581,
					["g"] = 1,
					["b"] = 0,
				}, -- [588]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:36]|h|r You receive item: |cff1eff00|Hitem:11859::::::::48:::::::::|h[Jademoon Orb]|h|r.",
					["serverTime"] = 1714133864,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						26, -- [2]
						27, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28139.597,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [589]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:36]|h|r RestedXP Guides: Targeting macro updated with (Neeru Fireblade)",
					["timestamp"] = 28139.644,
					["serverTime"] = 1714133864,
				}, -- [590]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:36]|h|r You receive item: |cffffffff|Hitem:10643::::::::48:::::::::|h[Sealed Letter to Ag'tor]|h|r.",
					["serverTime"] = 1714133864,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						26, -- [2]
						27, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28139.85,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [591]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:17:36]|h|r Quest accepted: Betrayed",
					["serverTime"] = 1714133864,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28140.115,
					["g"] = 1,
					["b"] = 0,
				}, -- [592]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:18:07]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Buta-Shadowstrike(AU):220:CHANNEL:2|h|cffff7c0aButa|r|h|cffd8d8d8]|r: WTB |cffa335ee|Hitem:943::::::::41:::::::::|h[Warden Staff]|h|r",
					["serverTime"] = 1714133895,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						53, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28170.546,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [593]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:18:23]|h|r Your Orgrimmar reputation has increased by 50.",
					["serverTime"] = 1714133911,
					["r"] = 0.501960813999176,
					["extraData"] = {
						36, -- [1]
						14, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28186.521,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [594]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:18:23]|h|r A Strange Request completed.",
					["serverTime"] = 1714133911,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28186.555,
					["g"] = 1,
					["b"] = 0,
				}, -- [595]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:18:23]|h|r Experience gained: 3412.",
					["serverTime"] = 1714133911,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28186.555,
					["g"] = 1,
					["b"] = 0,
				}, -- [596]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:18:23]|h|r You receive item: |cffffffff|Hitem:9628::::::::48:::::::::|h[Neeru's Herb Pouch]|h|r.",
					["serverTime"] = 1714133911,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						26, -- [2]
						27, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28186.759,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [597]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:18:23]|h|r Quest accepted: Return to Witch Doctor Uzer'i",
					["serverTime"] = 1714133911,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28186.863,
					["g"] = 1,
					["b"] = 0,
				}, -- [598]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:18:23]|h|r RestedXP Guides: Targeting macro updated with (Auctioneer Thathung)",
					["timestamp"] = 28186.887,
					["serverTime"] = 1714133911,
				}, -- [599]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:18:23]|h|r Quest accepted: Ak'Zeloth",
					["serverTime"] = 1714133911,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28186.98,
					["g"] = 1,
					["b"] = 0,
				}, -- [600]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:18:24]|h|r Quest accepted: Slaying the Beast",
					["serverTime"] = 1714133912,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28187.74,
					["g"] = 1,
					["b"] = 0,
				}, -- [601]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:19:04]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Xian-Shadowstrike(AU):254:CHANNEL:2|h|cffffffffXian|r|h|cffd8d8d8]|r: WTS quest share for priest dispersion rune |Hquestie:79731:Player-5818-00AB2307|h|cFFC0C0C0[|r|cFFC0C0C0[35] The Troll Scroll|r|cFFC0C0C0]|r|h 1g",
					["serverTime"] = 1714133952,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						28, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28227.526,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [602]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:19:19]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Morladim-Shadowstrike(AU):261:CHANNEL:2|h|cfffff468Morladim|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t ENCHANTING |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t +22 Healing Bracer || +9str Bracer || Crusader || +5 All Res Cape || Fiery || Icy Chill || +Riding || +7stam Bracer/Boots/Shield || +7agi Boots/Gloves || +4dmg 1H || +7dmg 2H || +15 agi/str 1H || +20 spirit 1H || +25 agi 2H",
					["serverTime"] = 1714133967,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						56, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28242.482,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [603]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:19:21]|h|r [Y] |cffd8d8d8[|r|Hplayer:Morladim-Shadowstrike(AU):262:YELL|h|cfffff468Morladim|r|h|cffd8d8d8]|r: |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t ENCHANTING |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t +22 Healing Bracer || +9str Bracer || Crusader || +5 All Res Cape || Fiery || Icy Chill || +Riding || +7stam Bracer/Boots/Shield || +7agi Boots/Gloves || +4dmg 1H || +7dmg 2H || +15 agi/str 1H || +20 spirit 1H || +25 agi 2H",
					["serverTime"] = 1714133969,
					["r"] = 1,
					["extraData"] = {
						7, -- [1]
						34, -- [2]
						58, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28245.143,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [604]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:19:22]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Ozonosphere:263:CHANNEL:2|h|cffaad372Ozonosphere|r|h|cffd8d8d8]|r: any mara WO groups?",
					["serverTime"] = 1714133970,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						59, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28245.565,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [605]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:19:50]|h|r |cffaad372Rickgrime|r has gone offline.",
					["serverTime"] = 1714133998,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28273.441,
					["g"] = 1,
					["b"] = 0,
				}, -- [606]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:19:50]|h|r |cff0070ddSontre|r has gone offline.",
					["serverTime"] = 1714133998,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28274.119,
					["g"] = 1,
					["b"] = 0,
				}, -- [607]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:20:02]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Lirielbaenre:276:CHANNEL:2|h|cff3fc6eaLirielbaenre|r|h|cffd8d8d8]|r: wts|cffa335ee|Hitem:869::::::::50:::::::::|h[Dazzling Longsword]|h|r",
					["serverTime"] = 1714134010,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						61, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28286.208,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [608]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:20:06]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Mown-Shadowstrike(AU):277:CHANNEL:2|h|cfffff468Mown|r|h|cffd8d8d8]|r: |cff1eff00|Hitem:10726::::::::50::::1:3524:::::|h[Gnomish Mind Control Cap]|h|r 30g cheaper than AH",
					["serverTime"] = 1714134014,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						63, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28289.948,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [609]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:20:16]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Knowone-Shadowstrike(AU):280:CHANNEL:2|h|cff3fc6eaKnowone|r|h|cffd8d8d8]|r: LF ENCHANTER +3 STATS TO CHEST",
					["serverTime"] = 1714134024,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						65, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28299.447,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [610]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:20:35]|h|r [Y] |cffd8d8d8[|r|Hplayer:Niceguy:286:YELL|h|cffaad372Niceguy|r|h|cffd8d8d8]|r: LF  ENCHANTER 7agi boots",
					["serverTime"] = 1714134043,
					["r"] = 1,
					["extraData"] = {
						7, -- [1]
						34, -- [2]
						68, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28318.625,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [611]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:20:55]|h|r [Y] |cffd8d8d8[|r|Hplayer:Liberalvoter-Shadowstrike(AU):291:YELL|h|cffaad372Liberalvoter|r|h|cffd8d8d8]|r: WTB PORT UC",
					["serverTime"] = 1714134063,
					["r"] = 1,
					["extraData"] = {
						7, -- [1]
						34, -- [2]
						69, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28338.445,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [612]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:21:00]|h|r |cff0070ddTinyterry|r has gone offline.",
					["serverTime"] = 1714134068,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28343.985,
					["g"] = 1,
					["b"] = 0,
				}, -- [613]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:21:07]|h|r |cffd8d8d8[|r|Hplayer:Rickgrime:298|h|cffd8d83f50|r:|cffaad372Rickgrime|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714134075,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28350.925,
					["g"] = 1,
					["b"] = 0,
				}, -- [614]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:21:17]|h|r |cffd8d8d8[|r|Hplayer:Tinyterry:299|h|cffd8d83f50|r:|cff0070ddTinyterry|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714134085,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28360.868,
					["g"] = 1,
					["b"] = 0,
				}, -- [615]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:21:19]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Vatsa-Shadowstrike(AU):300:CHANNEL:2|h|cfffff468Vatsa|r|h|cffd8d8d8]|r: lfg mara wo runs",
					["serverTime"] = 1714134087,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						70, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28362.66,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [616]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:21:22]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Deleted-Shadowstrike(AU):302:CHANNEL:1|h|cff0070ddDeleted|r|h|cffd8d8d8]|r: Anyone for duels outside Org?",
					["serverTime"] = 1714134090,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						4, -- [2]
						72, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28366.261,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [617]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:22:05]|h|r |cffd8d8d8[|r|Hplayer:Ajayani:311|h|cffd8d83f50|r:|cffaad372Ajayani|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714134133,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28408.374,
					["g"] = 1,
					["b"] = 0,
				}, -- [618]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:22:17]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Skoolbully:313:CHANNEL:2|h|cffff7c0aSkoolbully|r|h|cffd8d8d8]|r: heals LFG Mara runs",
					["serverTime"] = 1714134145,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						75, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28421.037,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [619]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:22:25]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Flayed-Shadowstrike(AU):315:CHANNEL:2|h|cffffffffFlayed|r|h|cffd8d8d8]|r: WTS |cff0070dd|Hitem:221287::::::::50:::::::::|h[Seven of Plagues]|h|r",
					["serverTime"] = 1714134153,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						46, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28429.181,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [620]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:22:43]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Ichor-Shadowstrike(AU):320:CHANNEL:2|h|cffc69b6dIchor|r|h|cffd8d8d8]|r: LF MASTER TRANSMUTER TO XMUTE |cff1eff00|Hitem:12363::::::::50:::::::::|h[Arcane Crystal]|h|r INTO |cff1eff00|Hitem:12360::::::::50:::::::::|h[Arcanite Bar]|h|r",
					["serverTime"] = 1714134171,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						22, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28447.129,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [621]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:10]|h|r |cffd8d8d8[|r|Hplayer:Snipegodx:331|h|cff8b8b8b20|r:|cffaad372Snipegodx|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714134198,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28473.905,
					["g"] = 1,
					["b"] = 0,
				}, -- [622]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:28]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Inxhaustible-Shadowstrike(AU):339:CHANNEL:2|h|cffc69b6dInxhaustible|r|h|cffd8d8d8]|r: LFG MARA or BFD runs",
					["serverTime"] = 1714134216,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						78, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28491.759,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [623]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:28]|h|r |cffd8d8d8[|r|Hplayer:Prijesmrti:340|h|cffd8d83f47|r:|cffffffffPrijesmrti|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714134216,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28492.233,
					["g"] = 1,
					["b"] = 0,
				}, -- [624]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:38]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Aleutian-Shadowstrike(AU):343:CHANNEL:2|h|cff0070ddAleutian|r|h|cffd8d8d8]|r: LF2M BRD! Need tank and heals!",
					["serverTime"] = 1714134226,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						80, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28502.238,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [625]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:52]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Mangojoos-Shadowstrike(AU):347:CHANNEL:1|h|cff8787edMangojoos|r|h|cffd8d8d8]|r: LF TAILOR FOR SHADOWEAVE GEAR. PANTS/ROBE/GLOVES/SHOULDERS/BOOTS/MASK MY MATS",
					["serverTime"] = 1714134240,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						4, -- [2]
						82, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28515.687,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [626]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:23:54]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Deleted-Shadowstrike(AU):348:CHANNEL:1|h|cff0070ddDeleted|r|h|cffd8d8d8]|r: LF duel practice outside org - come duel a geared ele shammy",
					["serverTime"] = 1714134242,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						4, -- [2]
						72, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28517.545,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [627]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:24:14]|h|r |Hchannel:channel:2|h[2] |h|cffd8d8d8[|r|Hplayer:Moistas-Shadowstrike(AU):356:CHANNEL:2|h|cffaad372Moistas|r|h|cffd8d8d8]|r: Salty> 8/8 is recruiting 2 DPS with OS Heals & 4 RDPS for our core Raid Team for P3 and future Phases. Raid days Fri and Sat 7 PM ST Social and Casuals welcome!",
					["serverTime"] = 1714134262,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						84, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28537.871,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [628]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:24:58]|h|r [Y] |cffd8d8d8[|r|Hplayer:Shocknawe-Shadowstrike(AU):373:YELL|h|cff0070ddShocknawe|r|h|cffd8d8d8]|r: Enchanter LFW - Org  [2h +25Agi, +7Dmg],[1H +15Agi, +4dmg],[Fiery Weapon],[Chest - Stats+3],[Bracer  +7Str][[Cloak +3Agi], [Gloves +7agi,+5Str],[Boots +5Agi]",
					["serverTime"] = 1714134306,
					["r"] = 1,
					["extraData"] = {
						7, -- [1]
						34, -- [2]
						86, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28582.249,
					["g"] = 0.250980406999588,
					["b"] = 0.250980406999588,
				}, -- [629]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:25:17]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Azshara]|h",
					["serverTime"] = 1714134325,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28600.85,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [630]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:25:17]|h|r |Hchannel:channel:2|h[2] |h Left Channel: |Hchannel:CHANNEL:2|h[2. Trade - City]|h",
					["serverTime"] = 1714134325,
					["r"] = 1,
					["extraData"] = {
						70, -- [1]
						1, -- [2]
						87, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28600.85,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [631]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:25:17]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Azshara]|h",
					["serverTime"] = 1714134325,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28600.85,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [632]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:25:19]|h|r |cffff7d0a<|r|cffffd200DBM|r|cffff7d0a>|r Loaded 'PvP' mods. For more options such as custom alert sounds and personalized warning notes, type /dbm.",
					["r"] = 0.41,
					["serverTime"] = 1714134327,
					["timestamp"] = 28603.205,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [633]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:25:19]|h|r |cffff7d0a<|r|cffffd200DBM|r|cffff7d0a>|r Your version of Deadly Boss Mods is out-of-date.\n Version 10.2.36 (2024/04/23 00:00:00) is available for download through Curse, Wago, WoWI, or from GitHub Releases page",
					["r"] = 0.41,
					["serverTime"] = 1714134327,
					["timestamp"] = 28603.205,
					["g"] = 0.8,
					["b"] = 0.94,
				}, -- [634]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:25:24]|h|r |cffd8d8d8[|r|Hplayer:Purê:380|h|cff8b8b8b19|r:|cffff7c0aPurê|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714134332,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28608.146,
					["g"] = 1,
					["b"] = 0,
				}, -- [635]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:25:38]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Ashenvale]|h",
					["serverTime"] = 1714134346,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28621.926,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [636]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:25:38]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Ashenvale]|h",
					["serverTime"] = 1714134346,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28621.926,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [637]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:26:13]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Sanka-Shadowstrike(AU):391:CHANNEL:1|h|cffffffffSanka|r|h|cffd8d8d8]|r: LF1M ash inc - have WA/Addon/ring plz",
					["serverTime"] = 1714134381,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						4, -- [2]
						89, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28656.336,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [638]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:27:03]|h|r |cff33ff99Postal|r: Collected 97|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t 73|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t",
					["timestamp"] = 28706.883,
					["serverTime"] = 1714134431,
				}, -- [639]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:27:05]|h|r |cffff7c0aPurê|r has gone offline.",
					["serverTime"] = 1714134433,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28708.715,
					["g"] = 1,
					["b"] = 0,
				}, -- [640]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:27:39]|h|r |cffd8d8d8[|r|Hplayer:Purê:403|h|cff8b8b8b19|r:|cffff7c0aPurê|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714134467,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28742.79,
					["g"] = 1,
					["b"] = 0,
				}, -- [641]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:27:56]|h|r |cffd8d8d8[|r|Hplayer:Soginazz:406|h|cff8b8b8b28|r:|cffc69b6dSoginazz|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714134484,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28760.096,
					["g"] = 1,
					["b"] = 0,
				}, -- [642]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:28:33]|h|r |TInterface\\FriendsFrame\\UI-Toast-ToastIcons.tga:16:16:0:0:128:64:2:29:34:61|t|HBNplayer:|Kq3|k:1:411:BN_INLINE_TOAST_ALERT:0|h[|Kq3|k] (|T-2:10:10:0:0:32:32:0:32:0:32|t Shahin)|h has gone offline.",
					["serverTime"] = 1714134521,
					["r"] = 0.5098039507865906,
					["extraData"] = {
						54, -- [1]
						91, -- [2]
						92, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28796.628,
					["g"] = 0.7725490927696228,
					["b"] = 1,
				}, -- [643]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:29:13]|h|r |cffd8d8d8[|r|Hplayer:Fracturos:416|h|cff8b8b8b35|r:|cff0070ddFracturos|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714134561,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28836.933,
					["g"] = 1,
					["b"] = 0,
				}, -- [644]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:29:28]|h|r |cff0070ddTutudots|r has gone offline.",
					["serverTime"] = 1714134576,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28851.635,
					["g"] = 1,
					["b"] = 0,
				}, -- [645]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:29:48]|h|r |Hchannel:channel:1|h[1] |h|cffd8d8d8[|r|Hplayer:Notdysc:420:CHANNEL:1|h|cffc69b6dNotdysc|r|h|cffd8d8d8]|r: lfg ash inc",
					["serverTime"] = 1714134596,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						4, -- [2]
						93, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28871.691,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [646]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:29:52]|h|r |cffff7c0aVarthaka|r has gone offline.",
					["serverTime"] = 1714134600,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28875.473,
					["g"] = 1,
					["b"] = 0,
				}, -- [647]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:29:56]|h|r |Hchannel:channel:1|h[1] |h Changed Channel: |Hchannel:CHANNEL:1|h[1. General - Azshara]|h",
					["serverTime"] = 1714134604,
					["r"] = 1,
					["extraData"] = {
						69, -- [1]
						4, -- [2]
						5, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28880.173,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [648]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:29:56]|h|r |Hchannel:channel:3|h[3] |h Changed Channel: |Hchannel:CHANNEL:3|h[3. LocalDefense - Azshara]|h",
					["serverTime"] = 1714134604,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						7, -- [2]
						8, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28880.173,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [649]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:30:18]|h|r Discovered Shadowsong Shrine: 405 experience gained",
					["serverTime"] = 1714134626,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28901.978,
					["g"] = 1,
					["b"] = 0,
				}, -- [650]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:30:25]|h|r |cffd8d8d8[|r|Hplayer:Tutudots:426|h|cff65b26542|r:|cff0070ddTutudots|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714134633,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28908.652,
					["g"] = 1,
					["b"] = 0,
				}, -- [651]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:30:37]|h|r RestedXP Guides: Rare Found! Varo'then's Ghost is nearby.",
					["timestamp"] = 28921.049,
					["serverTime"] = 1714134645,
				}, -- [652]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:30:56]|h|r RestedXP Guides: Rare Found! Varo'then's Ghost is nearby.",
					["timestamp"] = 28940.312,
					["serverTime"] = 1714134664,
				}, -- [653]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:31:35]|h|r |cffaad372Pemmarah|r has gone offline.",
					["serverTime"] = 1714134703,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28978.408,
					["g"] = 1,
					["b"] = 0,
				}, -- [654]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:31:44]|h|r You receive loot: |cff1eff00|Hitem:7532::::::779:1881819520:48:::::::::|h[Cabalist Spaulders of the Owl]|h|r.",
					["serverTime"] = 1714134712,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						26, -- [2]
						27, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28987.631,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [655]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:31:45]|h|r You loot 4 Silver, 67 Copper",
					["serverTime"] = 1714134713,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						95, -- [2]
						96, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28988.639,
					["g"] = 1,
					["b"] = 0,
				}, -- [656]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:31:55]|h|r You receive loot: |cffffffff|Hitem:4338::::::::48:::::::::|h[Mageweave Cloth]|h|rx3.",
					["serverTime"] = 1714134723,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						26, -- [2]
						27, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28998.848,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [657]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:31:56]|h|r You loot 1 Silver, 42 Copper",
					["serverTime"] = 1714134724,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						95, -- [2]
						96, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 28999.897,
					["g"] = 1,
					["b"] = 0,
				}, -- [658]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:33:06]|h|r |cffd8d8d8[|r|Hplayer:Deathawaìts:459|h|cff8b8b8b36|r:|cffaad372Deathawaìts|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714134794,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 29070.118,
					["g"] = 1,
					["b"] = 0,
				}, -- [659]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:33:07]|h|r Discovered Haldarr Encampment: 390 experience gained",
					["serverTime"] = 1714134795,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 29070.435,
					["g"] = 1,
					["b"] = 0,
				}, -- [660]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:33:30]|h|r |cffaad372Deathawaìts|r has gone offline.",
					["serverTime"] = 1714134818,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 29093.37,
					["g"] = 1,
					["b"] = 0,
				}, -- [661]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:33:48]|h|r Discovered Valormok: 455 experience gained",
					["serverTime"] = 1714134836,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 29112.124,
					["g"] = 1,
					["b"] = 0,
				}, -- [662]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:34:03]|h|r Betrayed completed.",
					["serverTime"] = 1714134851,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 29127.195,
					["g"] = 1,
					["b"] = 0,
				}, -- [663]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:34:03]|h|r Experience gained: 4637.",
					["serverTime"] = 1714134851,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 29127.195,
					["g"] = 1,
					["b"] = 0,
				}, -- [664]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:34:03]|h|r Your Orgrimmar reputation has increased by 50.",
					["serverTime"] = 1714134851,
					["r"] = 0.501960813999176,
					["extraData"] = {
						36, -- [1]
						14, -- [2]
						15, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 29127.202,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [665]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:34:04]|h|r Quest accepted: Betrayed",
					["serverTime"] = 1714134852,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 29127.543,
					["g"] = 1,
					["b"] = 0,
				}, -- [666]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:34:58]|h|r |cff3fc6eaRorzi|r has gone offline.",
					["serverTime"] = 1714134906,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 29181.434,
					["g"] = 1,
					["b"] = 0,
				}, -- [667]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:35:05]|h|r |cffd8d8d8[|r|Hplayer:Rorzzi:492|h|cff8b8b8b18|r:|cffffffffRorzzi|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714134913,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 29188.804,
					["g"] = 1,
					["b"] = 0,
				}, -- [668]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:35:27]|h|r |cffd8d8d8[|r|Hplayer:Healdelivery:494|h|cff8b8b8b17|r:|cff3fc6eaHealdelivery|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714134935,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 29210.826,
					["g"] = 1,
					["b"] = 0,
				}, -- [669]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:37:12]|h|r RestedXP Guides: Targeting macro updated with (Kravel Koalbeard)",
					["timestamp"] = 29315.853,
					["serverTime"] = 1714135040,
				}, -- [670]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:37:29]|h|r |cffaad372Unicorns|r has gone offline.",
					["serverTime"] = 1714135057,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 29332.364,
					["g"] = 1,
					["b"] = 0,
				}, -- [671]
				{
					["message"] = "|cff979797|Hpratcopy|h[22:38:09]|h|r |cffd8d8d8[|r|Hplayer:Woshide:518|h|cff8b8b8b20|r:|cffff7c0aWoshide|r|h|cffd8d8d8]|r has come online.",
					["serverTime"] = 1714135097,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						16, -- [2]
						17, -- [3]
						["n"] = 3,
					},
					["timestamp"] = 29372.994,
					["g"] = 1,
					["b"] = 0,
				}, -- [672]
			},
			["maxElements"] = 4096,
			["TransformIf"] = nil --[[ skipped inline function ]],
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}

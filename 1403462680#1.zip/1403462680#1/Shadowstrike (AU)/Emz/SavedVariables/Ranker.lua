
rankerObjective = 7
rankerLimit = 110000

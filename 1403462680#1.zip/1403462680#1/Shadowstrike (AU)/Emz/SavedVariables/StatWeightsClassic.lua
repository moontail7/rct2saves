
__sw__persistent_data_per_char = {
	["stat_comparison_spells"] = {
		[133] = {
			["name"] = "Fireball",
		},
	},
	["loadouts"] = {
		["active_loadout"] = 1,
		["num_loadouts"] = 2,
		["loadouts_list"] = {
			{
				["loadout"] = {
					["stats"] = {
						28, -- [1]
						33, -- [2]
						101, -- [3]
						163, -- [4]
						137, -- [5]
					},
					["crit_rating"] = 0,
					["healing_power"] = 137,
					["target_hp_perc_default"] = 1,
					["melee_crit"] = 0,
					["target_buffs"] = {
					},
					["dynamic_buffs"] = {
						["target"] = {
						},
						["player"] = {
							["Spark of Inspiration"] = {
								["id"] = 438536,
								["count"] = 0,
								["dur"] = 5833.694999999996,
							},
							["Discoverer's Delight"] = {
								["id"] = 436412,
								["src"] = "player",
								["count"] = 0,
								["dur"] = -29394.259,
							},
							["Supercharged Chronoboon Displacer"] = {
								["id"] = 349981,
								["src"] = "player",
								["count"] = 0,
								["dur"] = -29394.259,
							},
							["Zandalari Ward"] = {
								["id"] = 436351,
								["src"] = "player",
								["count"] = 0,
								["dur"] = -29394.259,
							},
						},
						["mouseover"] = {
						},
					},
					["target_lvl"] = 51,
					["default_target_lvl_diff"] = 3,
					["spell_dmg"] = 137,
					["num_set_pieces"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						nil, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
					},
					["target_creature_type"] = "Humanoid",
					["flags"] = 146,
					["target_name"] = "Ag'tor Bloodfist",
					["hit"] = 0,
					["buffs"] = {
					},
					["custom_talents_code"] = "",
					["max_mana"] = 3186,
					["haste_rating"] = 0,
					["enemy_hp_perc"] = 1,
					["target_res"] = 0,
					["mana"] = 3186,
					["attack_power"] = 18,
					["extra_mana"] = 0,
					["spell_crit_by_school"] = {
						0.2278600120544434, -- [1]
						0.2278600120544434, -- [2]
						0.2278600120544434, -- [3]
						0.2278600120544434, -- [4]
						0.2278600120544434, -- [5]
						0.2278600120544434, -- [6]
						0.2278600120544434, -- [7]
					},
					["spell_dmg_by_school"] = {
						137, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						13, -- [5]
						0, -- [6]
						0, -- [7]
					},
					["player_name"] = "Emz",
					["unbounded_aoe_targets"] = 1,
					["friendly_towards"] = "target",
					["talents_table"] = {
						{
						}, -- [1]
						{
							0, -- [1]
							5, -- [2]
							5, -- [3]
							0, -- [4]
							0, -- [5]
							2, -- [6]
							0, -- [7]
							1, -- [8]
							2, -- [9]
							3, -- [10]
							0, -- [11]
							3, -- [12]
							3, -- [13]
							1, -- [14]
							5, -- [15]
							1, -- [16]
						}, -- [2]
						{
							2, -- [1]
							0, -- [2]
							3, -- [3]
							1, -- [4]
							0, -- [5]
							2, -- [6]
						}, -- [3]
						["pts"] = nil --[[ skipped inline function ]],
					},
					["runes"] = {
						[6729] = {
							["wowhead_id"] = "56j9",
							["apply"] = nil --[[ skipped inline function ]],
						},
						[7097] = {
							["wowhead_id"] = "96xs",
						},
						[6737] = {
							["wowhead_id"] = "76jh",
						},
						[6732] = {
							["wowhead_id"] = "66jc",
						},
						[6923] = {
							["wowhead_id"] = "a6rb",
						},
					},
					["hostile_towards"] = "target",
					["player_hp_perc"] = 1,
					["name"] = "Default",
					["spell_dmg_hit_by_school"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
					},
					["lvl"] = 48,
					["spell_power"] = 0,
					["hit_rating"] = 0,
					["friendly_hp_perc"] = 1,
					["talents_code"] = "-0550020123033151-203102_166jc76jha6rb96xs56j9",
				},
				["equipped"] = {
					["raw"] = {
						["haste_rating"] = 0,
						["spell_heal_mod"] = 0,
						["healing_power"] = 0,
						["mana"] = 0,
						["mana_mod"] = 0,
						["added_physical_spell_crit"] = 0,
						["regen_while_casting"] = 0,
						["haste_mod"] = 0,
						["special_crit_heal_mod"] = 0,
						["cost_mod_base"] = 0,
						["special_crit_mod"] = 0,
						["target_healing_taken"] = 0,
						["spell_dmg"] = 0,
						["resource_refund"] = 0,
						["perc_max_mana_as_mp5"] = 0,
						["hit_rating"] = 0,
						["spell_heal_mod_base"] = 0,
						["spell_heal_mod_mul"] = 0,
						["crit_rating"] = 0,
						["cost_flat"] = 0,
						["cost_mod"] = 0,
						["non_stackable_effect_flags"] = 0,
						["spell_dmg_mod_mul"] = 0,
						["ot_mod"] = 0,
						["mp5_from_int_mod"] = 0,
						["spell_power"] = 0,
						["mp5"] = 0,
						["spell_dmg_mod"] = 0,
					},
					["by_attribute"] = {
						["sp_from_stat_mod"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
						},
						["stat_mod"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
						},
						["crit_from_stat_mod"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
						},
						["hp_from_stat_mod"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
						},
						["stats"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
						},
					},
					["ability"] = {
						["effect_mod"] = {
						},
						["cast_mod_mul"] = {
						},
						["cost_mod"] = {
						},
						["crit_mod"] = {
						},
						["vuln_mod"] = {
						},
						["sp"] = {
						},
						["vuln_ot_mod"] = {
						},
						["flat_add_ot"] = {
						},
						["effect_mod_base"] = {
						},
						["coef_ot_mod"] = {
						},
						["effect_mod_only_heal"] = {
						},
						["effect_ot_mod"] = {
						},
						["coef_mod"] = {
						},
						["crit_ot"] = {
						},
						["refund"] = {
						},
						["cast_mod_reduce"] = {
						},
						["extra_ticks"] = {
						},
						["cost_mod_base"] = {
						},
						["flat_add"] = {
						},
						["hit"] = {
						},
						["cast_mod"] = {
						},
						["cost_flat"] = {
						},
						["crit"] = {
						},
						["sp_ot"] = {
						},
					},
					["by_school"] = {
						["target_spell_dmg_taken_ot"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["spell_dmg_mod_add"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["cost_mod"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["target_res"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["spell_crit_mod"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["spell_crit"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["target_spell_dmg_taken"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["target_mod_res"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["spell_dmg_hit"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["spell_dmg_mod"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
					},
				},
			}, -- [1]
			{
				["loadout"] = {
					["max_mana"] = 0,
					["unbounded_aoe_targets"] = 1,
					["crit_rating"] = 0,
					["healing_power"] = 0,
					["target_res"] = 0,
					["mana"] = 0,
					["talents_code"] = "",
					["talents_table"] = {
					},
					["extra_mana"] = 0,
					["spell_dmg_hit_by_school"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
					},
					["dynamic_buffs"] = {
					},
					["target_lvl"] = 0,
					["spell_crit_by_school"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
					},
					["default_target_lvl_diff"] = 0,
					["spell_dmg_by_school"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
					},
					["spell_power"] = 0,
					["spell_dmg"] = 0,
					["hit"] = 0,
					["num_set_pieces"] = {
					},
					["hit_rating"] = 0,
					["haste_rating"] = 0,
					["target_creature_type"] = "",
					["flags"] = 2,
					["stats"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
					},
					["name"] = "PVP",
					["lvl"] = 1,
					["target_buffs"] = {
					},
					["buffs"] = {
					},
					["custom_talents_code"] = "",
					["target_hp_perc_default"] = 1,
				},
				["equipped"] = {
					["raw"] = {
						["haste_rating"] = 0,
						["spell_heal_mod"] = 0,
						["healing_power"] = 0,
						["mana"] = 0,
						["mana_mod"] = 0,
						["added_physical_spell_crit"] = 0,
						["regen_while_casting"] = 0,
						["haste_mod"] = 0,
						["special_crit_heal_mod"] = 0,
						["cost_mod_base"] = 0,
						["special_crit_mod"] = 0,
						["target_healing_taken"] = 0,
						["spell_dmg"] = 0,
						["resource_refund"] = 0,
						["perc_max_mana_as_mp5"] = 0,
						["hit_rating"] = 0,
						["spell_heal_mod_base"] = 0,
						["spell_heal_mod_mul"] = 0,
						["crit_rating"] = 0,
						["cost_flat"] = 0,
						["cost_mod"] = 0,
						["non_stackable_effect_flags"] = 0,
						["spell_dmg_mod_mul"] = 0,
						["ot_mod"] = 0,
						["mp5_from_int_mod"] = 0,
						["spell_power"] = 0,
						["mp5"] = 0,
						["spell_dmg_mod"] = 0,
					},
					["by_attribute"] = {
						["sp_from_stat_mod"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
						},
						["stat_mod"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
						},
						["crit_from_stat_mod"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
						},
						["hp_from_stat_mod"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
						},
						["stats"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
						},
					},
					["ability"] = {
						["effect_mod"] = {
						},
						["cast_mod_mul"] = {
						},
						["cost_mod"] = {
						},
						["crit_mod"] = {
						},
						["vuln_mod"] = {
						},
						["sp"] = {
						},
						["vuln_ot_mod"] = {
						},
						["flat_add_ot"] = {
						},
						["effect_mod_base"] = {
						},
						["coef_ot_mod"] = {
						},
						["effect_mod_only_heal"] = {
						},
						["effect_ot_mod"] = {
						},
						["coef_mod"] = {
						},
						["crit_ot"] = {
						},
						["refund"] = {
						},
						["cast_mod_reduce"] = {
						},
						["extra_ticks"] = {
						},
						["cost_mod_base"] = {
						},
						["flat_add"] = {
						},
						["hit"] = {
						},
						["cast_mod"] = {
						},
						["cost_flat"] = {
						},
						["crit"] = {
						},
						["sp_ot"] = {
						},
					},
					["by_school"] = {
						["target_spell_dmg_taken_ot"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["spell_dmg_mod_add"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["cost_mod"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["target_res"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["spell_crit_mod"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["spell_crit"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["target_spell_dmg_taken"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["target_mod_res"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["spell_dmg_hit"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
						["spell_dmg_mod"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
							0, -- [5]
							0, -- [6]
							0, -- [7]
						},
					},
				},
			}, -- [2]
		},
	},
	["sim_type"] = 1,
	["settings"] = {
		["icon_overlay_old_rank"] = false,
		["ability_tooltip"] = 15358,
		["icon_overlay_update_freq"] = 3,
		["icon_overlay_disable"] = false,
		["icon_overlay_mana_abilities"] = true,
		["show_tooltip_only_when_shift"] = false,
		["icon_overlay_font_size"] = 8,
		["icon_macro_name_clearance"] = false,
		["clear_original_tooltip"] = false,
		["libstub_minimap_icon"] = {
			["hide"] = false,
		},
		["icon_show_single_target_only"] = false,
		["ability_icon_overlay"] = 1048592,
		["version_saved"] = "30224",
	},
}


RXPCData = {
	["completedWaypoints"] = {
		{
		}, -- [1]
		{
		}, -- [2]
	},
	["currentStep"] = 2,
	["questObjectivesCache"] = {
		[0] = 67,
		[845] = {
			{
				["type"] = "item",
				["numRequired"] = 4,
				["text"] = "Zhevra Hooves: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[869] = {
			{
				["type"] = "item",
				["numRequired"] = 12,
				["text"] = "Raptor Head: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[877] = {
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Test the Dried Seeds: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[2873] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Stoley's Shipment: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[901] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Console Key: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[2875] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Firebeard's Head: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[3161] = {
			{
				["type"] = "item",
				["numRequired"] = 30,
				["text"] = "Gahz'ridian Ornament: 0/30",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[421] = {
			{
				["type"] = "monster",
				["numRequired"] = 5,
				["text"] = "Moonrage Whitescalp slain: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[425] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Ivar's Head: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[870] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Explore the waters of the Forgotten Pools",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[648] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Escort OOX-17/TN to Steamwheedle Port",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[2973] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Iridescent Sprite Darter Wing: 1/10",
				["finished"] = false,
				["numFulfilled"] = 1,
			}, -- [1]
		},
		[4021] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Piece of Krom'zar's Banner: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[2974] = {
			{
				["type"] = "item",
				["numRequired"] = 20,
				["text"] = "Grimtotem Horn: 0/20",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[2975] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Gordunni Ogre slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Gordunni Ogre Mage slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 5,
				["text"] = "Gordunni Brute slain: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[855] = {
			{
				["type"] = "item",
				["numRequired"] = 15,
				["text"] = "Centaur Bracers: 0/15",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[863] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Escort Wizzlecrank out of the Venture Co. drill site",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[871] = {
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Razormane Water Seeker slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Razormane Thornweaver slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 3,
				["text"] = "Razormane Hunter slain: 0/3",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[887] = {
			{
				["type"] = "monster",
				["numRequired"] = 12,
				["text"] = "Southsea Brigand slain: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 6,
				["text"] = "Southsea Cannoneer slain: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[895] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Baron Longshore's Head: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[903] = {
			{
				["type"] = "item",
				["numRequired"] = 7,
				["text"] = "Prowler Claws: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[1560] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Lead Tooga to Torta",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[422] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Remedy of Arugal: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[2979] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Gordunni Orb: 1/1",
				["finished"] = true,
				["numFulfilled"] = 1,
			}, -- [1]
		},
		[5863] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Dunemaul Brute slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Dunemaul Enforcer slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Gor'marok the Ravager slain: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[872] = {
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Razormane Geomancer slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Razormane Defender slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Kreenig Snarlsnout's Tusk: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[2980] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Gordunni Shaman slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Gordunni Warlock slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 5,
				["text"] = "Gordunni Mauler slain: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[3520] = {
			{
				["type"] = "monster",
				["numRequired"] = 3,
				["text"] = "Screecher Spirits Collected: 3/3",
				["finished"] = true,
				["numFulfilled"] = 3,
			}, -- [1]
		},
		[896] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Cats Eye Emerald: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[2822] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Thick Yeti Hide: 7/10",
				["finished"] = false,
				["numFulfilled"] = 7,
			}, -- [1]
		},
		[5041] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Crossroads' Supply Crates: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[1944] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Xavian Water Sample: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[865] = {
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Intact Raptor Horn: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[881] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Echeyakee's Hide: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[4921] = {
			{
				["type"] = "monster",
				["numRequired"] = 1,
				["text"] = "Find Mankrik's Wife: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[905] = {
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Visit Blue Raptor Nest: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Visit Yellow Raptor Nest: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Visit Red Raptor Nest: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[2605] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Laden Dew Gland: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[423] = {
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Glutton Shackle: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 3,
				["text"] = "Darksoul Shackle: 0/3",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[2987] = {
			{
				["type"] = "item",
				["numRequired"] = 12,
				["text"] = "Gordunni Cobalt: 0/12",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[858] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Ignition Key: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[435] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Erland must reach Rane Yorick",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[447] = {
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Grizzled Bear Heart: 6/6",
				["finished"] = true,
				["numFulfilled"] = 6,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Skittering Blood: 6/6",
				["finished"] = true,
				["numFulfilled"] = 6,
			}, -- [2]
		},
		[82] = {
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Centipaar Insect Parts: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[2862] = {
			{
				["type"] = "item",
				["numRequired"] = 10,
				["text"] = "Woodpaw Gnoll Mane: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[2767] = {
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Escort OOX-22/FE to the dock along the Forgotten Coast",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[2863] = {
			{
				["type"] = "monster",
				["numRequired"] = 5,
				["text"] = "Woodpaw Alpha slain: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[851] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Verog's Head: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[867] = {
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Witchwing Talon: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[875] = {
			{
				["type"] = "item",
				["numRequired"] = 6,
				["text"] = "Harpy Lieutenant Ring: 0/6",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[7730] = {
			{
				["type"] = "item",
				["numRequired"] = 20,
				["text"] = "Zukk'ash Carapace: 0/20",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[7731] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Stinglasher's Glands: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[10] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Scrimshank's Surveying Gear: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[1172] = {
			{
				["type"] = "object",
				["numRequired"] = 5,
				["text"] = "Egg of Onyxia destroyed: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[852] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Hezrul's Head: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[3281] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Stolen Silver: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[3362] = {
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Gnarled Thistleshrub slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 8,
				["text"] = "Thistleshrub Rootshaper slain: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[844] = {
			{
				["type"] = "item",
				["numRequired"] = 7,
				["text"] = "Plainstrider Beak: 0/7",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[848] = {
			{
				["type"] = "item",
				["numRequired"] = 4,
				["text"] = "Fungal Spores: 0/4",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[850] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Kodobane's Head: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[900] = {
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Shut off Main Control Valve: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Shut off Fuel Control Valve: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Shut off Regulator Valve: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[8365] = {
			{
				["type"] = "item",
				["numRequired"] = 20,
				["text"] = "Southsea Pirate Hat: 0/20",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[437] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Essence of Nightlash: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "event",
				["numRequired"] = 1,
				["text"] = "Enter the Dead Fields",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
		[924] = {
			{
				["type"] = "object",
				["numRequired"] = 1,
				["text"] = "Destroy the Demon Seed: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[8366] = {
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Southsea Pirate slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Southsea Freebooter slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Southsea Dock Worker slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
			{
				["type"] = "monster",
				["numRequired"] = 10,
				["text"] = "Southsea Swashbuckler slain: 0/10",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [4]
		},
		[880] = {
			{
				["type"] = "item",
				["numRequired"] = 8,
				["text"] = "Altered Snapjaw Shell: 0/8",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
		},
		[821] = {
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Savannah Lion Tusk: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 5,
				["text"] = "Plainstrider Kidney: 0/5",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Thunder Lizard Horn: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [3]
		},
		[888] = {
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Shipment of Boots: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [1]
			{
				["type"] = "item",
				["numRequired"] = 1,
				["text"] = "Telescopic Lens: 0/1",
				["finished"] = false,
				["numFulfilled"] = 0,
			}, -- [2]
		},
	},
	["currentGuideGroup"] = "RestedXP Speedrun Guide (H)",
	["flightPaths"] = {
		[61] = "Splintertree Post, Ashenvale",
		[77] = "Camp Taurajo, The Barrens",
		[55] = "Brackenwall Village, Dustwallow Marsh",
		[42] = "Camp Mojache, Feralas",
		[40] = "Gadgetzan, Tanaris",
		[29] = "Sun Rock Retreat, Stonetalon Mountains",
		[58] = "Zoram'gar Outpost, Ashenvale",
		[80] = "Ratchet, The Barrens",
		[30] = "Freewind Post, Thousand Needles",
		[13] = "Tarren Mill, Hillsbrad",
		[10] = "The Sepulcher, Silverpine Forest",
		[38] = "Shadowprey Village, Desolace",
		[11] = "Undercity, Tirisfal",
		[22] = "Thunder Bluff, Mulgore",
		[23] = "Orgrimmar, Durotar",
		[25] = "Crossroads, The Barrens",
	},
	["questNameCache"] = {
		[845] = "The Zhevra",
		[869] = "Raptor Thieves",
		[877] = "The Stagnant Oasis",
		[2873] = "Stoley's Shipment",
		[901] = "Samophlange",
		[3002] = "The Gordunni Orb",
		[3161] = "Gahz'ridian",
		[421] = "Prove Your Worth",
		[425] = "Ivar the Foul",
		[429] = "Wild Hearts",
		[870] = "The Forgotten Pools",
		[449] = "The Deathstalkers' Report",
		[648] = "Rescue OOX-17/TN!",
		[2973] = "A New Cloak's Sheen",
		[4021] = "Counterattack!",
		[2974] = "A Grim Discovery",
		[477] = "Border Crossings",
		[481] = "Dalar's Analysis",
		[2975] = "The Ogres of Feralas",
		[855] = "Centaur Bracers",
		[863] = "The Escape",
		[871] = "Disrupt the Attacks",
		[2976] = "A Grim Discovery",
		[887] = "Southsea Freebooters",
		[895] = "WANTED: Baron Longshore",
		[903] = "Prowlers of the Barrens",
		[1560] = "Tooga's Quest",
		[422] = "Arugal's Folly",
		[848] = "Fungal Spores",
		[5863] = "The Dunemaul Compound",
		[872] = "The Disruption Ends",
		[880] = "Altered Beings",
		[3520] = "Screecher Spirits",
		[896] = "Miner's Fortune",
		[2822] = "The Mark of Quality",
		[5041] = "Supplies for the Crossroads",
		[482] = "Dalaran's Intentions",
		[865] = "Raptor Horns",
		[881] = "Echeyakee",
		[4921] = "Lost in Battle",
		[905] = "The Angry Scytheclaws",
		[2605] = "The Thirsty Goblin",
		[423] = "Arugal's Folly",
		[2987] = "Gordunni Cobalt",
		[858] = "Ignition",
		[435] = "Escorting Erland",
		[1359] = "Zinge's Delivery",
		[2766] = "Find OOX-22/FE!",
		[82] = "Noxious Lair Investigation",
		[2862] = "War on the Woodpaw",
		[2767] = "Rescue OOX-22/FE!",
		[2863] = "Alpha Strike",
		[851] = "Verog the Dervish",
		[10] = "The Scrimshank Redemption",
		[867] = "Harpy Raiders",
		[875] = "Harpy Lieutenants",
		[7730] = "Zukk'ash Infestation",
		[1172] = "The Brood of Onyxia",
		[7731] = "Stinglasher",
		[3362] = "Thistleshrub Valley",
		[7732] = "Zukk'ash Report",
		[1119] = "Zanzil's Mixture and a Fool's Stout",
		[2875] = "WANTED: Andre Firebeard",
		[8365] = "Pirate Hats Ahoy!",
		[3121] = "A Strange Request",
		[8366] = "Southsea Shakedown",
		[3122] = "Return to Witch Doctor Uzer'i",
		[844] = "Plainstrider Menace",
		[852] = "Hezrul Bloodmark",
		[3281] = "Stolen Silver",
		[439] = "Rot Hide Clues",
		[850] = "Kolkar Leaders",
		[888] = "Stolen Booty",
		[2979] = "Dark Ceremony",
		[900] = "Samophlange",
		[924] = "The Demon Seed",
		[447] = "A Recipe For Death",
		[1205] = "Deadmire",
		[438] = "The Decrepit Ferry",
		[437] = "The Dead Fields",
		[821] = "Chen's Empty Keg",
		[2980] = "The Ogres of Feralas",
	},
	["currentGuideName"] = "46-48 Tanaris",
	["stepSkip"] = {
	},
	["currentStepId"] = 3415149360,
	["guideDisabled"] = {
		nil, -- [1]
		nil, -- [2]
		nil, -- [3]
		nil, -- [4]
		nil, -- [5]
		nil, -- [6]
		nil, -- [7]
		nil, -- [8]
		nil, -- [9]
		nil, -- [10]
		nil, -- [11]
		nil, -- [12]
		nil, -- [13]
		nil, -- [14]
		nil, -- [15]
		nil, -- [16]
		nil, -- [17]
		nil, -- [18]
		nil, -- [19]
		nil, -- [20]
		nil, -- [21]
		19335, -- [22]
		43003, -- [23]
		39220, -- [24]
		11179, -- [25]
		32189, -- [26]
		13072, -- [27]
		22709, -- [28]
		13205, -- [29]
		16215, -- [30]
		100156, -- [31]
		18617, -- [32]
		9075, -- [33]
		38751, -- [34]
		45772, -- [35]
		22856, -- [36]
		70631, -- [37]
		14113, -- [38]
		37801, -- [39]
		30023, -- [40]
		35973, -- [41]
		34973, -- [42]
		10456, -- [43]
		35476, -- [44]
		25425, -- [45]
		25566, -- [46]
		29133, -- [47]
		24806, -- [48]
		27339, -- [49]
		65092, -- [50]
		16156, -- [51]
		10587, -- [52]
		19311, -- [53]
		23334, -- [54]
		39939, -- [55]
		21013, -- [56]
		20381, -- [57]
		28609, -- [58]
		18693, -- [59]
		16896, -- [60]
		38446, -- [61]
		14435, -- [62]
		33012, -- [63]
		14544, -- [64]
		20740, -- [65]
		36462, -- [66]
		11102, -- [67]
		18231, -- [68]
		31221, -- [69]
		30162, -- [70]
		21555, -- [71]
		70807, -- [72]
		17093, -- [73]
		28970, -- [74]
		32608, -- [75]
		14062, -- [76]
		40451, -- [77]
		46797, -- [78]
		44251, -- [79]
		32404, -- [80]
		nil, -- [81]
		nil, -- [82]
		28580, -- [83]
		nil, -- [84]
		nil, -- [85]
		nil, -- [86]
		nil, -- [87]
		nil, -- [88]
		nil, -- [89]
		nil, -- [90]
		nil, -- [91]
		nil, -- [92]
		nil, -- [93]
		nil, -- [94]
		nil, -- [95]
		nil, -- [96]
		nil, -- [97]
		nil, -- [98]
		nil, -- [99]
		nil, -- [100]
		nil, -- [101]
		nil, -- [102]
		nil, -- [103]
		nil, -- [104]
		nil, -- [105]
		nil, -- [106]
		nil, -- [107]
		nil, -- [108]
		nil, -- [109]
		nil, -- [110]
		nil, -- [111]
		nil, -- [112]
		nil, -- [113]
		nil, -- [114]
		21122, -- [115]
		29921, -- [116]
		17872, -- [117]
		9932, -- [118]
		57000, -- [119]
		17199, -- [120]
		37092, -- [121]
		17812, -- [122]
		58238, -- [123]
		13549, -- [124]
		19819, -- [125]
		24386, -- [126]
		12393, -- [127]
		27111, -- [128]
		16182, -- [129]
		21994, -- [130]
		10539, -- [131]
		28523, -- [132]
		40782, -- [133]
		14558, -- [134]
		31519, -- [135]
		9492, -- [136]
		9212, -- [137]
		24202, -- [138]
		38050, -- [139]
		17797, -- [140]
		34000, -- [141]
		20450, -- [142]
		37349, -- [143]
		10431, -- [144]
		23843, -- [145]
		18077, -- [146]
		21466, -- [147]
		29384, -- [148]
		24089, -- [149]
		20139, -- [150]
		60869, -- [151]
		27442, -- [152]
		22751, -- [153]
		31219, -- [154]
		nil, -- [155]
		nil, -- [156]
		nil, -- [157]
		nil, -- [158]
		nil, -- [159]
		nil, -- [160]
		nil, -- [161]
		nil, -- [162]
		nil, -- [163]
		nil, -- [164]
		nil, -- [165]
		nil, -- [166]
		nil, -- [167]
		nil, -- [168]
		nil, -- [169]
		nil, -- [170]
		nil, -- [171]
		nil, -- [172]
		nil, -- [173]
		nil, -- [174]
		nil, -- [175]
		nil, -- [176]
		nil, -- [177]
		nil, -- [178]
		nil, -- [179]
		nil, -- [180]
		nil, -- [181]
		nil, -- [182]
		16345, -- [183]
		60123, -- [184]
		nil, -- [185]
		nil, -- [186]
		nil, -- [187]
		nil, -- [188]
		nil, -- [189]
		nil, -- [190]
		nil, -- [191]
		nil, -- [192]
		nil, -- [193]
		nil, -- [194]
		1519, -- [195]
		1178, -- [196]
		1154, -- [197]
		1402, -- [198]
		1220, -- [199]
		nil, -- [200]
		nil, -- [201]
		3460, -- [202]
		nil, -- [203]
		3259, -- [204]
		2738, -- [205]
		2410, -- [206]
		2577, -- [207]
		1414, -- [208]
		2875, -- [209]
		nil, -- [210]
		nil, -- [211]
		nil, -- [212]
		4051, -- [213]
		nil, -- [214]
		nil, -- [215]
		nil, -- [216]
		nil, -- [217]
		621, -- [218]
		967, -- [219]
		1045, -- [220]
		3598, -- [221]
		2969, -- [222]
		3500, -- [223]
		785, -- [224]
		816, -- [225]
		1047, -- [226]
		727, -- [227]
		983, -- [228]
		1407, -- [229]
		1078, -- [230]
		1092, -- [231]
		1001, -- [232]
		896, -- [233]
		808, -- [234]
		1068, -- [235]
		746, -- [236]
		1262, -- [237]
		1325, -- [238]
		4814, -- [239]
		3314, -- [240]
		3630, -- [241]
		857, -- [242]
		1265, -- [243]
		1349, -- [244]
		1242, -- [245]
		1280, -- [246]
		652, -- [247]
		970, -- [248]
		881, -- [249]
		770, -- [250]
		5656, -- [251]
		893, -- [252]
		2972, -- [253]
		2202, -- [254]
		988, -- [255]
		1396, -- [256]
		970, -- [257]
		5443, -- [258]
		1003, -- [259]
		742, -- [260]
		591, -- [261]
		1296, -- [262]
		804, -- [263]
		1053, -- [264]
		767, -- [265]
		1971, -- [266]
		1084, -- [267]
		934, -- [268]
		928, -- [269]
		1634, -- [270]
		934, -- [271]
		3507, -- [272]
		1526, -- [273]
		1453, -- [274]
		1174, -- [275]
		1010, -- [276]
		984, -- [277]
		553, -- [278]
		607, -- [279]
		1001, -- [280]
		1050, -- [281]
		1012, -- [282]
		2477, -- [283]
		2251, -- [284]
		2779, -- [285]
		1079, -- [286]
		1007, -- [287]
		686, -- [288]
		1245, -- [289]
		1117, -- [290]
		967, -- [291]
		1307, -- [292]
		5361, -- [293]
		2095, -- [294]
		2616, -- [295]
		1517, -- [296]
		673, -- [297]
		1297, -- [298]
		3047, -- [299]
		799, -- [300]
		2470, -- [301]
		1773, -- [302]
		1826, -- [303]
		995, -- [304]
		1281, -- [305]
		1408, -- [306]
		833, -- [307]
		1064, -- [308]
		1567, -- [309]
		1117, -- [310]
		683, -- [311]
		821, -- [312]
		1655, -- [313]
		1025, -- [314]
		1959, -- [315]
		2290, -- [316]
		890, -- [317]
		7120, -- [318]
		4991, -- [319]
		632, -- [320]
		1886, -- [321]
		1348, -- [322]
		1308, -- [323]
		1420, -- [324]
		2181, -- [325]
		547, -- [326]
		1677, -- [327]
		1244, -- [328]
		678, -- [329]
		682, -- [330]
		684, -- [331]
		682, -- [332]
		1137, -- [333]
		988, -- [334]
		1595, -- [335]
		1553, -- [336]
		1613, -- [337]
		1656, -- [338]
		1041, -- [339]
		962, -- [340]
		1429, -- [341]
		775, -- [342]
		807, -- [343]
		1158, -- [344]
		1090, -- [345]
		3454, -- [346]
		849, -- [347]
		1545, -- [348]
		967, -- [349]
		1168, -- [350]
		1799, -- [351]
		2837, -- [352]
		3319, -- [353]
		2207, -- [354]
		nil, -- [355]
		2051, -- [356]
		2326, -- [357]
		1785, -- [358]
		nil, -- [359]
		nil, -- [360]
		1858, -- [361]
		2963, -- [362]
		nil, -- [363]
		nil, -- [364]
		1187, -- [365]
		1202, -- [366]
		nil, -- [367]
		nil, -- [368]
		2982, -- [369]
		nil, -- [370]
		21611, -- [371]
		nil, -- [372]
		1635, -- [373]
		1746, -- [374]
		nil, -- [375]
		nil, -- [376]
		nil, -- [377]
		1947, -- [378]
		2259, -- [379]
		nil, -- [380]
		nil, -- [381]
		nil, -- [382]
		nil, -- [383]
		nil, -- [384]
		nil, -- [385]
		nil, -- [386]
		nil, -- [387]
		nil, -- [388]
		nil, -- [389]
		nil, -- [390]
		nil, -- [391]
		nil, -- [392]
		nil, -- [393]
		nil, -- [394]
		nil, -- [395]
		nil, -- [396]
		2854, -- [397]
		2562, -- [398]
		6364, -- [399]
		4836, -- [400]
		3123, -- [401]
		5771, -- [402]
		2582, -- [403]
		1986, -- [404]
		3508, -- [405]
		9493, -- [406]
		1750, -- [407]
		2092, -- [408]
		3057, -- [409]
		3137, -- [410]
		3186, -- [411]
		1957, -- [412]
		5830, -- [413]
		4982, -- [414]
		1942, -- [415]
		1999, -- [416]
		2449, -- [417]
		2075, -- [418]
		4984, -- [419]
		911, -- [420]
		1028, -- [421]
		1566, -- [422]
		954, -- [423]
		937, -- [424]
		1758, -- [425]
		2093, -- [426]
		1048, -- [427]
		1448, -- [428]
		935, -- [429]
		1166, -- [430]
		807, -- [431]
		821, -- [432]
		1339, -- [433]
		1176, -- [434]
		1354, -- [435]
		892, -- [436]
		864, -- [437]
		899, -- [438]
		879, -- [439]
		1138, -- [440]
		1031, -- [441]
		1023, -- [442]
		1023, -- [443]
		1187, -- [444]
		1545, -- [445]
		2520, -- [446]
		2494, -- [447]
		1268, -- [448]
		1527, -- [449]
		731, -- [450]
		779, -- [451]
		1069, -- [452]
		916, -- [453]
		2298, -- [454]
		2818, -- [455]
		2755, -- [456]
		2149, -- [457]
		640, -- [458]
		619, -- [459]
		1048, -- [460]
		969, -- [461]
		1104, -- [462]
		1052, -- [463]
		1464, -- [464]
		1819, -- [465]
		2097, -- [466]
		1599, -- [467]
		1236, -- [468]
		758, -- [469]
		797, -- [470]
		748, -- [471]
		944, -- [472]
		1122, -- [473]
		5006, -- [474]
		6282, -- [475]
		1950, -- [476]
		757, -- [477]
		1512, -- [478]
		1925, -- [479]
		2158, -- [480]
		2662, -- [481]
		1697, -- [482]
		653, -- [483]
		876, -- [484]
		884, -- [485]
		2041, -- [486]
		1039, -- [487]
		1068, -- [488]
		1514, -- [489]
		1213, -- [490]
		7412, -- [491]
		1808, -- [492]
		1816, -- [493]
		3979, -- [494]
		2120, -- [495]
		1692, -- [496]
		6674, -- [497]
		8040, -- [498]
		8737, -- [499]
		7675, -- [500]
		7099, -- [501]
		2163, -- [502]
		3364, -- [503]
		2549, -- [504]
		6783, -- [505]
		8112, -- [506]
		2158, -- [507]
		2761, -- [508]
		2814, -- [509]
		2549, -- [510]
		1806, -- [511]
		12950, -- [512]
		2949, -- [513]
		6655, -- [514]
		1644, -- [515]
		3124, -- [516]
		909, -- [517]
		1054, -- [518]
		1315, -- [519]
		934, -- [520]
		8530, -- [521]
		1471, -- [522]
		2007, -- [523]
		[0] = 523,
	},
}
RXPCTrackingData = {
	["profileKeys"] = {
		["Emz - Shadowstrike (AU)"] = "Emz - Shadowstrike (AU)",
	},
	["profiles"] = {
		["Emz - Shadowstrike (AU)"] = {
			["levels"] = {
				[28] = {
					["groupExperience"] = 2208,
					["deaths"] = 1,
					["mobs"] = {
						["Blackfathom Deeps"] = {
							["xp"] = 1860,
							["count"] = 91,
						},
						["Ashenvale"] = {
							["xp"] = 348,
							["count"] = 3,
						},
					},
					["timestamp"] = {
						["dateFinished"] = {
							["monthDay"] = 22,
							["day"] = 0,
							["month"] = 3,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 23,
							["minute"] = 41,
						},
						["finished"] = 123678,
						["started"] = 1,
					},
					["quests"] = {
					},
				},
				[15] = {
					["groupExperience"] = 0,
					["deaths"] = 2,
					["mobs"] = {
						["Silverpine Forest"] = {
							["xp"] = 3868,
							["count"] = 15,
						},
					},
					["timestamp"] = {
						["dateFinished"] = {
							["monthDay"] = 10,
							["day"] = 0,
							["month"] = 3,
							["minute"] = 26,
							["year"] = 2024,
							["hour"] = 11,
							["weekday"] = 1,
						},
						["finished"] = 38849,
					},
					["quests"] = {
					},
				},
				[25] = {
					["groupExperience"] = 11644,
					["deaths"] = 4,
					["mobs"] = {
						["Hillsbrad Foothills"] = {
							["xp"] = 449,
							["count"] = 1,
						},
						["Shadowfang Keep"] = {
							["xp"] = 11644,
							["count"] = 88,
						},
					},
					["timestamp"] = {
					},
					["quests"] = {
					},
				},
				[47] = {
					["groupExperience"] = 9467,
					["deaths"] = 5,
					["mobs"] = {
						["Feralas"] = {
							["xp"] = 17997,
							["count"] = 44,
						},
					},
					["timestamp"] = {
						["dateFinished"] = {
							["monthDay"] = 26,
							["day"] = 0,
							["month"] = 4,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 17,
							["minute"] = 32,
						},
						["finished"] = 348280,
						["started"] = 1,
					},
					["quests"] = {
						["Thunder Bluff"] = {
							[1205] = 6825,
						},
					},
				},
				[48] = {
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Azshara"] = {
							["xp"] = 1926,
							["count"] = 2,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 26,
							["day"] = 0,
							["month"] = 4,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 17,
							["minute"] = 32,
						},
						["started"] = 348281,
					},
					["quests"] = {
						["Azshara"] = {
							[3504] = 4637,
						},
						["Feralas"] = {
							[2822] = 7087,
						},
						["Orgrimmar"] = {
							[7732] = 7700,
							[2976] = 8487,
							[3002] = 3675,
							[3121] = 3412,
						},
					},
				},
				[16] = {
					["groupExperience"] = 0,
					["deaths"] = 0,
					["mobs"] = {
						["Silverpine Forest"] = {
							["xp"] = 942,
							["count"] = 6,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 10,
							["day"] = 0,
							["month"] = 3,
							["minute"] = 26,
							["year"] = 2024,
							["hour"] = 11,
							["weekday"] = 1,
						},
						["started"] = 38850,
					},
					["quests"] = {
					},
				},
				[29] = {
					["groupExperience"] = 816,
					["deaths"] = 0,
					["mobs"] = {
						["Blackfathom Deeps"] = {
							["xp"] = 816,
							["count"] = 58,
						},
					},
					["timestamp"] = {
						["dateStarted"] = {
							["monthDay"] = 22,
							["day"] = 0,
							["month"] = 3,
							["weekday"] = 6,
							["year"] = 2024,
							["hour"] = 23,
							["minute"] = 41,
						},
						["started"] = 123679,
					},
					["quests"] = {
					},
				},
			},
			["trackedGuid"] = "Player-5818-00A9F32E",
		},
	},
}
RXPCComms = {
	["profileKeys"] = {
		["Emz - Shadowstrike (AU)"] = "Emz - Shadowstrike (AU)",
	},
	["profiles"] = {
		["Emz - Shadowstrike (AU)"] = {
			["players"] = {
				["Creditfraud"] = {
					["class"] = "ROGUE",
					["lastSeen"] = 5333.564,
					["xpPercentage"] = 0,
					["isRxp"] = true,
					["timePlayed"] = 1808.725000000093,
					["level"] = 50,
				},
				["Balslappias"] = {
					["timePlayed"] = 1817.857000000076,
					["class"] = "WARLOCK",
					["xp"] = 116,
				},
				["Tpainwarpigs"] = {
					["level"] = 28,
					["lastSeen"] = 52552.784,
					["xpPercentage"] = 50,
					["class"] = "SHAMAN",
					["timePlayed"] = 0,
					["isRxp"] = true,
				},
				["Falseclaimin"] = {
					["class"] = "MAGE",
					["lastSeen"] = 580400.915,
					["xpPercentage"] = 0,
					["isRxp"] = true,
					["timePlayed"] = 1808.725000000093,
					["level"] = 40,
				},
				["Quenda"] = {
					["timePlayed"] = 405.7300000000014,
					["class"] = "ROGUE",
					["xp"] = 196,
				},
				["Bumboclaat"] = {
					["class"] = "PRIEST",
					["lastSeen"] = 576727.232,
					["xpPercentage"] = 11,
					["isRxp"] = true,
					["timePlayed"] = 1808.725000000093,
					["level"] = 39,
				},
				["Billardo"] = {
					["timePlayed"] = 1817.857000000076,
					["class"] = "WARLOCK",
					["xp"] = 116,
				},
				["Manaru"] = {
					["timePlayed"] = 1817.857000000076,
					["class"] = "DRUID",
					["xp"] = 116,
				},
				["Quich"] = {
					["timePlayed"] = 1817.857000000076,
					["class"] = "DRUID",
					["xp"] = 116,
				},
			},
			["announcements"] = {
				["43-44 Feralas"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
				["11-14 Silverpine Forest"] = {
					["collect"] = {
					},
					["complete"] = {
					},
				},
			},
		},
	},
}
RXPCSettings = nil


ItemRackUser = {
	["ButtonSpacing"] = 4,
	["QueuesEnabled"] = {
	},
	["Locked"] = "OFF",
	["MainScale"] = 1,
	["SetMenuWrapValue"] = 3,
	["SetMenuWrap"] = "OFF",
	["Sets"] = {
		["~CombatQueue"] = {
			["equip"] = {
			},
		},
		["~Unequip"] = {
			["equip"] = {
			},
		},
	},
	["EnableQueues"] = "ON",
	["EnablePerSetQueues"] = "OFF",
	["Buttons"] = {
	},
	["ItemsUsed"] = {
	},
	["Events"] = {
		["Enabled"] = {
		},
		["Set"] = {
		},
	},
	["Alpha"] = 1,
	["Hidden"] = {
	},
	["EnableEvents"] = "ON",
	["MenuScale"] = 0.85,
	["Queues"] = {
	},
}

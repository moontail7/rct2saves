
EncounterDetailsDB = nil

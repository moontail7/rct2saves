
rankerObjective = 14
rankerLimit = 500000


WT_LearnedPetAbilities = {
}
WT_NeedsToOpenBeastTraining = false
WT_IgnoredSpells = {
}

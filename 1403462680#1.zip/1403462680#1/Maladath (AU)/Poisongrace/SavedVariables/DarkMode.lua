
DMTABPC = nil

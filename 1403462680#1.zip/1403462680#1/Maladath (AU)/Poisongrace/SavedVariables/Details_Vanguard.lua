
_detalhes_databaseVanguard = nil


ClassicCastbarsCharDB = nil

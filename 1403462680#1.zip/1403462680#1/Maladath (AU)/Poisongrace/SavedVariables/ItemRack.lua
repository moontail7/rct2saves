
ItemRackUser = {
["ButtonSpacing"] = 4,
["QueuesEnabled"] = {
},
["Locked"] = "OFF",
["MainScale"] = 1,
["SetMenuWrapValue"] = 3,
["SetMenuWrap"] = "OFF",
["Sets"] = {
["~CombatQueue"] = {
["equip"] = {
},
},
["~Unequip"] = {
["equip"] = {
},
},
},
["EnableQueues"] = "ON",
["Queues"] = {
},
["Buttons"] = {
},
["ItemsUsed"] = {
},
["Events"] = {
["Enabled"] = {
},
["Set"] = {
},
},
["EnableEvents"] = "ON",
["Hidden"] = {
},
["Alpha"] = 1,
["MenuScale"] = 0.85,
["EnablePerSetQueues"] = "OFF",
}


POISONER_CONFIG = {
["TooltipType"] = "full",
["Buttons"] = {
["FreeButton"] = {
["Active"] = 1,
["Scale"] = 1,
["Position"] = {
["RelativeTo"] = "UIParent",
["XPos"] = 0,
["RelativePoint"] = "CENTER",
["Anchor"] = "CENTER",
["YPos"] = 0,
},
["Alpha"] = 1,
["Lock"] = 0,
},
["QuickButton"] = {
["Scale"] = 1,
["Position"] = {
["RelativeTo"] = "UIParent",
["XPos"] = 0,
["RelativePoint"] = "CENTER",
["Anchor"] = "CENTER",
["YPos"] = 0,
},
["Alpha"] = 1,
["Lock"] = 1,
},
["LDBIcon"] = {
["hide"] = "true",
},
},
["Preset"] = {
["Normal"] = {
["Mainhand"] = 1,
["Offhand"] = 1,
},
["CTRL"] = {
["Mainhand"] = 1,
["Offhand"] = 1,
},
["Overwrite"] = 0,
["ALT"] = {
["Mainhand"] = 1,
["Offhand"] = 1,
},
["SHIFT"] = {
["Mainhand"] = 1,
["Offhand"] = 1,
},
},
["StartedOnce"] = 1,
["Menu"] = {
["Spacing"] = 0,
["Scale"] = 1,
["Position"] = "bottomleft",
["Parent"] = "Poisoner_FreeButton",
["AutoHide"] = {
["inCombat"] = 0,
["Time"] = 10,
["Active"] = 0,
},
["ShowOnMouseover"] = 0,
["Sorting"] = {
"IP",
"DP",
"WP",
"MP",
"CP",
"SS",
"WS",
"OP",
"NP",
"AP",
"SP",
},
},
["PrintClickedPoison"] = 1,
["Timer"] = {
["Active"] = 1,
["Scale"] = 1,
["WarningThreshold"] = 2,
["Alpha"] = 1,
["Output"] = {
["Aura"] = 1,
["ErrorFrame"] = 1,
["Audio"] = 1,
["Chat"] = 1,
},
["IgnoreWhileFishing"] = 0,
["Position"] = {
["RelativeTo"] = "UIParent",
["XPos"] = 0,
["RelativePoint"] = "CENTER",
["Anchor"] = "CENTER",
["YPos"] = 100,
["OnlyInstanced"] = 0,
},
["OnlyInstanced"] = 0,
["Lock"] = 1,
["Weapon"] = {
["MainHand"] = 1,
["OffHand"] = 1,
},
},
["Poisons"] = {
[3240] = {
["Name"] = "Coarse Weightstone",
["Texture"] = 135256,
},
[12643] = {
["Name"] = "Dense Weightstone",
["Texture"] = 135259,
},
[8927] = {
["Name"] = "Instant Poison V",
["Texture"] = 132273,
},
[8928] = {
["Name"] = "Instant Poison VI",
["Texture"] = 132273,
},
[5237] = {
["Name"] = "Mind-numbing Poison",
["Texture"] = 136066,
},
[7964] = {
["Name"] = "Solid Sharpening Stone",
["Texture"] = 135251,
},
[10918] = {
["Name"] = "Wound Poison",
["Texture"] = 132274,
},
[9186] = {
["Name"] = "Mind-numbing Poison III",
["Texture"] = 136066,
},
[7965] = {
["Name"] = "Solid Weightstone",
["Texture"] = 135258,
},
[10920] = {
["Name"] = "Wound Poison II",
["Texture"] = 132274,
},
[10921] = {
["Name"] = "Wound Poison III",
["Texture"] = 132274,
},
[10922] = {
["Name"] = "Wound Poison IV",
["Texture"] = 132274,
},
[217346] = {
["Name"] = "Numbing Poison",
["Texture"] = 132098,
},
[12404] = {
["Name"] = "Dense Sharpening Stone",
["Texture"] = 135252,
},
[217347] = {
["Name"] = "Atrophic Poison",
["Texture"] = 132100,
},
[20844] = {
["Name"] = "Deadly Poison V",
["Texture"] = 132290,
},
[18262] = {
["Name"] = "Elemental Sharpening Stone",
["Texture"] = 135228,
},
[3775] = {
["Name"] = "Crippling Poison",
["Texture"] = 132274,
},
[6947] = {
["Name"] = "Instant Poison",
["Texture"] = 132273,
},
[217345] = {
["Name"] = "Sebacious Poison",
["Texture"] = 132108,
},
[2863] = {
["Name"] = "Coarse Sharpening Stone",
["Texture"] = 135249,
},
[211845] = {
["Name"] = "Blackfathom Sharpening Stone",
["Texture"] = 134417,
},
[3776] = {
["Name"] = "Crippling Poison II",
["Texture"] = 134799,
},
[3241] = {
["Name"] = "Heavy Weightstone",
["Texture"] = 135257,
},
[2892] = {
["Name"] = "Deadly Poison",
["Texture"] = 132290,
},
[8926] = {
["Name"] = "Instant Poison IV",
["Texture"] = 132273,
},
[6949] = {
["Name"] = "Instant Poison II",
["Texture"] = 132273,
},
[226374] = {
["Name"] = "Occult Poison I",
["Texture"] = 135935,
},
[3239] = {
["Name"] = "Rough Weightstone",
["Texture"] = 135255,
},
[2862] = {
["Name"] = "Rough Sharpening Stone",
["Texture"] = 135248,
},
[6950] = {
["Name"] = "Instant Poison III",
["Texture"] = 132273,
},
[2871] = {
["Name"] = "Heavy Sharpening Stone",
["Texture"] = 135250,
},
[8985] = {
["Name"] = "Deadly Poison IV",
["Texture"] = 132290,
},
[2893] = {
["Name"] = "Deadly Poison II",
["Texture"] = 132290,
},
[6951] = {
["Name"] = "Mind-numbing Poison II",
["Texture"] = 136066,
},
[8984] = {
["Name"] = "Deadly Poison III",
["Texture"] = 132290,
},
},
["Enabled"] = 1,
["Buy"] = {
["MP"] = 0,
["WP"] = 0,
["DP"] = 0,
["Active"] = 1,
["Check"] = 1,
["Prompt"] = 0,
["CP"] = 0,
["IP"] = 0,
},
}

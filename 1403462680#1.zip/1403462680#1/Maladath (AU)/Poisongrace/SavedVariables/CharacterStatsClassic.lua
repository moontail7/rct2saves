
CharacterStatsClassicCharacterDB = {
["showStatsFromArgentDawnItems"] = true,
["selectedRightStatsCategory"] = 2,
["selectedLeftStatsCategory"] = 1,
}

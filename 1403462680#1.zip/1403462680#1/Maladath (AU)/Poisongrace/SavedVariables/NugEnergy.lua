
NugEnergyDB_Character = nil

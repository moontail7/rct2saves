
FormatFix_UsePercent = false
FormatFix_FontSize = 12
FormatFix_FormatPet = false

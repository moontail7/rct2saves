
SpyPerCharDB = {
["version"] = "1.1",
["IgnoreData"] = {
},
["KOSData"] = {
},
["PlayerData"] = {
},
}

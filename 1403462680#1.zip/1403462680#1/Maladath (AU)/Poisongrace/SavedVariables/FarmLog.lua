
FLogVars = {
["enabled"] = false,
["ver"] = 1.24,
["todayKills"] = {
},
["hud"] = {
["show"] = false,
["locked"] = false,
},
["lockMinimapButton"] = false,
["enableMinimapButton"] = true,
["inInstance"] = false,
["itemTooltip"] = true,
["viewTotal"] = true,
["farms"] = {
["default"] = {
["current"] = {
["ah"] = 0,
["skill"] = {
},
["kills"] = {
},
["gold"] = 0,
["deaths"] = 0,
["vendor"] = 0,
["drops"] = {
},
["hks"] = 0,
["resets"] = 0,
["rep"] = {
},
["ranks"] = {
},
["dks"] = 0,
["bgsWin"] = {
},
["consumes"] = {
},
["seconds"] = 0,
["honor"] = 0,
["xp"] = 0,
["bgsLoss"] = {
},
["bgs"] = {
},
},
["goldTotal"] = 0,
["honorPerHourTotal"] = 0,
["past"] = {
["ah"] = 0,
["skill"] = {
},
["kills"] = {
},
["gold"] = 0,
["deaths"] = 0,
["vendor"] = 0,
["drops"] = {
},
["hks"] = 0,
["resets"] = 0,
["rep"] = {
},
["ranks"] = {
},
["dks"] = 0,
["bgsWin"] = {
},
["consumes"] = {
},
["seconds"] = 0,
["honor"] = 0,
["xp"] = 0,
["bgsLoss"] = {
},
["bgs"] = {
},
},
["goldPerHourTotal"] = 0,
["honorTotal"] = 0,
},
},
["minimapButtonPosition"] = {
["y"] = -127,
["x"] = -165,
["point"] = "TOPRIGHT",
},
["currentFarm"] = "default",
["frameRect"] = {
["y"] = 0,
["x"] = 0,
["point"] = "CENTER",
["height"] = 200,
["visible"] = false,
["width"] = 250,
},
["lockFrames"] = false,
}

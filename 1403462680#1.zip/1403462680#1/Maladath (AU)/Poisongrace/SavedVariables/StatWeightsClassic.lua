
__sw__persistent_data_per_char = nil

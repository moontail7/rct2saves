
TrinketMenuPerOptions = {
["Visible"] = "ON",
["MainScale"] = 1,
["XPos"] = 400,
["Alpha"] = 1,
["MainOrient"] = "HORIZONTAL",
["FirstUse"] = true,
["ItemsUsed"] = {
},
["Hidden"] = {
},
["MenuScale"] = 1,
["MainDock"] = "BOTTOMRIGHT",
["YPos"] = 400,
["MenuDock"] = "BOTTOMLEFT",
["MenuOrient"] = "VERTICAL",
}
TrinketMenuQueue = {
["Enabled"] = {
},
["Stats"] = {
},
["Sort"] = {
{
0,
},
[0] = {
0,
},
},
["Profiles"] = {
},
}

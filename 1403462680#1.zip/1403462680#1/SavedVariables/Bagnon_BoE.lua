
BagnonBoE_DB = {
["enableRarityColoring"] = true,
}

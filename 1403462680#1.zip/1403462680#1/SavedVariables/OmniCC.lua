
OmniCCDB = {
["global"] = {
["dbVersion"] = 6,
["addonVersion"] = "11.0.6",
},
["profileKeys"] = {
["Skeeboo - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Whitemane"] = "Default",
["Poisongrace - Shadowstrike (AU)"] = "Default",
["Boof - Arugal"] = "Default",
["Fuccwit - Whitemane"] = "Default",
["Logoutnow - Shadowstrike (AU)"] = "Default",
["Bumboclaat - Shadowstrike (AU)"] = "Default",
["Gopea - Arugal"] = "Default",
["Creditfraud - Shadowstrike (AU)"] = "Default",
["Raasclaat - Skull Rock"] = "Default",
["Fuccwit - Bigglesworth"] = "Default",
["Lavy - Shadowstrike (AU)"] = "Default",
["Rightclicker - Skull Rock"] = "Default",
["Adadadad - Skull Rock"] = "Default",
["Emz - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Shadowstrike (AU)"] = "Default",
["Squishcow - Shadowstrike (AU)"] = "Default",
["Poisongrace - Maladath (AU)"] = "Default",
},
["profiles"] = {
["Default"] = {
["rules"] = {
{
["enabled"] = false,
["patterns"] = {
"Aura",
"Buff",
"Debuff",
},
["name"] = "Auras",
["id"] = "auras",
},
{
["enabled"] = false,
["patterns"] = {
"Plate",
},
["name"] = "Unit Nameplates",
["id"] = "plates",
},
{
["enabled"] = false,
["patterns"] = {
"ActionButton",
},
["name"] = "Action Bars",
["id"] = "actions",
},
},
["themes"] = {
["Default"] = {
["textStyles"] = {
["soon"] = {
},
["minutes"] = {
},
["seconds"] = {
},
},
["minSize"] = 0.2,
},
},
},
},
}
OmniCC4Config = nil

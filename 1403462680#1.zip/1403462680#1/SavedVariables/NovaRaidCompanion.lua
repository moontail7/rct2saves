
NRCdatabase = {
["profileKeys"] = {
["Emz - Shadowstrike (AU)"] = "Default",
["Poisongrace - Maladath (AU)"] = "Default",
},
["global"] = {
["NRCScrollingRaidEvents_x"] = 291.1117553710938,
["NRCRaidCooldowns1_relativePoint"] = "RIGHT",
["NRCRaidCooldowns1_y"] = -179.5556640625,
["NRCRaidCooldowns1_x"] = -293,
["NRCScrollingRaidEvents_relativePoint"] = "CENTER",
["copyGlobalToProfile"] = false,
["Shadowstrike (AU)"] = {
["Horde"] = {
["myChars"] = {
["Emz"] = {
["race"] = "Troll",
["localizedClass"] = "Mage",
["englishClass"] = "MAGE",
["level"] = 47,
["faction"] = "Horde",
["savedInstances"] = {
},
},
},
["hasSoulstone"] = {
},
["raidCooldowns"] = {
},
},
},
["npcData"] = {
},
["NRCRaidManaFrame_point"] = "RIGHT",
["NRCRaidManaFrame_relativePoint"] = "RIGHT",
["Maladath (AU)"] = {
["Alliance"] = {
["myChars"] = {
["Poisongrace"] = {
["race"] = "Night Elf",
["localizedClass"] = "Rogue",
["englishClass"] = "ROGUE",
["level"] = 11,
["faction"] = "Alliance",
["savedInstances"] = {
},
},
},
["hasSoulstone"] = {
},
["raidCooldowns"] = {
},
},
},
["NRCRaidCooldowns1_point"] = "RIGHT",
["NRCScrollingRaidEvents_y"] = -56.00004577636719,
["versions"] = {
[1.55] = 1732587376,
},
["trades"] = {
},
["NRCRaidManaFrame_x"] = -307.4442138671875,
["instances"] = {
},
["NRCScrollingRaidEvents_point"] = "CENTER",
["NRCRaidManaFrame_y"] = -126.444450378418,
},
["profiles"] = {
["Default"] = {
},
},
}

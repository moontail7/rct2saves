
OneRing_Config = nil
OPie_SavedData = {
["CharProfiles"] = {
},
["_OPieVersion"] = "Ørred 2a (4.132)",
["_StoreVersion"] = 122,
["_GameLocale"] = "enUS",
["_StoreVersion2"] = 122,
["ProfileStorage"] = {
["default"] = {
},
},
["PersistentStorage"] = {
["RingKeeper"] = {
["OPieFlagStore"] = {
["StoreVersion"] = 3,
},
},
},
["_GameVersion"] = "1.15.5",
}


AFOptions = {
["profileKeys"] = {
["Emz - Shadowstrike (AU)"] = "Default",
["Skeeboo - Shadowstrike (AU)"] = "Default",
["Poisongrace - Maladath (AU)"] = "Default",
},
}

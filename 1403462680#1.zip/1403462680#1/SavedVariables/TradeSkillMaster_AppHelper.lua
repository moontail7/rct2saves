
TradeSkillMaster_AppHelperDB = {
["blackMarket"] = {
},
["region"] = "US-Classic",
["errorReports"] = {
["data"] = {
},
["updateTime"] = 0,
},
["shoppingMaxPrices"] = {
},
["analytics"] = {
["data"] = {
"[\"AC\",\"v4.13.21\",1732586338661,1732586334,1,\"ADDON_INITIALIZE\",0]",
"[\"AC\",\"v4.13.21\",1732586343875,1732586334,2,\"ADDON_ENABLE\",0]",
"[\"AC\",\"v4.13.21\",1732586358208,1732586334,3,\"ADDON_DISABLE\",0]",
"[\"AC\",\"v4.13.21\",1732586366104,1732586365,1,\"ADDON_INITIALIZE\",0]",
"[\"AC\",\"v4.13.21\",1732586366969,1732586365,2,\"ADDON_ENABLE\",0]",
"[\"AC\",\"v4.13.21\",1732586415182,1732586365,3,\"ADDON_DISABLE\",0]",
},
["updateTime"] = 1732586415,
},
}

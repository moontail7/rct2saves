
Blizzard_CompactRaidFrameManager_FilterOptions = nil

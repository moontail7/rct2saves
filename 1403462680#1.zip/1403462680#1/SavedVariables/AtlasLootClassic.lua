
AtlasLootClassicDB = {
["profileKeys"] = {
["Poisongrace - Maladath (AU)"] = "Poisongrace - Maladath (AU)",
["Skeeboo - Shadowstrike (AU)"] = "Skeeboo - Shadowstrike (AU)",
["Poisongrace - Shadowstrike (AU)"] = "Poisongrace - Shadowstrike (AU)",
["Squishcow - Shadowstrike (AU)"] = "Squishcow - Shadowstrike (AU)",
["Falseclaimin - Shadowstrike (AU)"] = "Falseclaimin - Shadowstrike (AU)",
["Logoutnow - Shadowstrike (AU)"] = "Logoutnow - Shadowstrike (AU)",
["Emz - Shadowstrike (AU)"] = "Emz - Shadowstrike (AU)",
["Lavy - Shadowstrike (AU)"] = "Lavy - Shadowstrike (AU)",
["Creditfraud - Shadowstrike (AU)"] = "Creditfraud - Shadowstrike (AU)",
["Bumboclaat - Shadowstrike (AU)"] = "Bumboclaat - Shadowstrike (AU)",
},
["global"] = {
["__addonrevision"] = 3020000,
},
["profiles"] = {
["Poisongrace - Maladath (AU)"] = {
},
["Skeeboo - Shadowstrike (AU)"] = {
},
["Poisongrace - Shadowstrike (AU)"] = {
},
["Squishcow - Shadowstrike (AU)"] = {
["minimap"] = {
["minimapPos"] = 200.7566138333887,
},
},
["Falseclaimin - Shadowstrike (AU)"] = {
["GUI"] = {
["point"] = {
"TOP",
nil,
"TOP",
-12.44448089599609,
-15.11116695404053,
},
["selected"] = {
nil,
"BlackfathomDeeps2",
7,
1,
0,
},
},
["ContentPhase"] = {
["enableOnItems"] = true,
},
["minimap"] = {
["minimapPos"] = 214.5699079243246,
},
},
["Logoutnow - Shadowstrike (AU)"] = {
},
["Emz - Shadowstrike (AU)"] = {
["minimap"] = {
["minimapPos"] = 198.8622536379743,
},
["GUI"] = {
["selected"] = {
nil,
"BlackfathomDeeps2",
7,
1,
0,
},
},
},
["Lavy - Shadowstrike (AU)"] = {
["GUI"] = {
["selected"] = {
nil,
"Ragefire",
nil,
1,
0,
},
},
},
["Creditfraud - Shadowstrike (AU)"] = {
["GUI"] = {
["point"] = {
nil,
nil,
"CENTER",
190.2225646972656,
83.66668701171875,
},
["selected"] = {
nil,
"BlackfathomDeeps2",
4,
1,
0,
},
},
["ContentPhase"] = {
["enableOnItems"] = true,
},
["minimap"] = {
["minimapPos"] = 316.5119855548828,
},
},
["Bumboclaat - Shadowstrike (AU)"] = {
["minimap"] = {
["minimapPos"] = 162.7830208029971,
},
["GUI"] = {
["selected"] = {
nil,
"Gnomeregan2",
nil,
1,
0,
},
},
},
},
}


TomTomDB = {
["profileKeys"] = {
["Poisongrace - Maladath (AU)"] = "Default",
["Logoutnow - Shadowstrike (AU)"] = "Default",
["Bumboclaat - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Shadowstrike (AU)"] = "Default",
["Creditfraud - Shadowstrike (AU)"] = "Default",
["Lavy - Shadowstrike (AU)"] = "Default",
},
["profiles"] = {
["Default"] = {
["arrow"] = {
["position"] = {
"CENTER",
nil,
"CENTER",
117.3341674804688,
-63.99993133544922,
},
},
["block"] = {
["position"] = {
"LEFT",
nil,
"LEFT",
266.4433288574219,
-194.2223815917969,
},
},
},
},
}
TomTomWaypoints = nil
TomTomWaypointsM = {
["profileKeys"] = {
["Poisongrace - Maladath (AU)"] = "Poisongrace - Maladath (AU)",
["Logoutnow - Shadowstrike (AU)"] = "Logoutnow - Shadowstrike (AU)",
["Bumboclaat - Shadowstrike (AU)"] = "Bumboclaat - Shadowstrike (AU)",
["Falseclaimin - Shadowstrike (AU)"] = "Falseclaimin - Shadowstrike (AU)",
["Creditfraud - Shadowstrike (AU)"] = "Creditfraud - Shadowstrike (AU)",
["Lavy - Shadowstrike (AU)"] = "Lavy - Shadowstrike (AU)",
},
["profiles"] = {
["Poisongrace - Maladath (AU)"] = {
},
["Logoutnow - Shadowstrike (AU)"] = {
},
["Bumboclaat - Shadowstrike (AU)"] = {
},
["Falseclaimin - Shadowstrike (AU)"] = {
},
["Creditfraud - Shadowstrike (AU)"] = {
},
["Lavy - Shadowstrike (AU)"] = {
},
},
}

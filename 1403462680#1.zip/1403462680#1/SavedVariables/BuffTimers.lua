
BuffTimersOptions = {
["seconds"] = true,
["yellow_text"] = false,
["colored_text"] = false,
["milliseconds"] = true,
["font_size"] = 9,
["vertical_position"] = -40,
["seconds_threshold"] = 30,
["time_stamp"] = "m",
["customize_text"] = true,
}


SpyDB = {
["kosData"] = {
["Shadowstrike (AU)"] = {
["Horde"] = {
["Emz"] = {
},
["Falseclaimin"] = {
},
["Squishcow"] = {
},
["Skeeboo"] = {
},
["Bumboclaat"] = {
},
["Logoutnow"] = {
},
["Poisongrace"] = {
},
["Lavy"] = {
},
["Creditfraud"] = {
},
},
},
["Maladath (AU)"] = {
["Alliance"] = {
["Poisongrace"] = {
},
},
},
},
["removeKOSData"] = {
["Shadowstrike (AU)"] = {
["Horde"] = {
},
},
["Maladath (AU)"] = {
["Alliance"] = {
},
},
},
["profileKeys"] = {
["Poisongrace - Maladath (AU)"] = "Poisongrace - Maladath (AU)",
["Skeeboo - Shadowstrike (AU)"] = "Skeeboo - Shadowstrike (AU)",
["Poisongrace - Shadowstrike (AU)"] = "Poisongrace - Shadowstrike (AU)",
["Squishcow - Shadowstrike (AU)"] = "Squishcow - Shadowstrike (AU)",
["Falseclaimin - Shadowstrike (AU)"] = "Falseclaimin - Shadowstrike (AU)",
["Logoutnow - Shadowstrike (AU)"] = "Logoutnow - Shadowstrike (AU)",
["Emz - Shadowstrike (AU)"] = "Emz - Shadowstrike (AU)",
["Lavy - Shadowstrike (AU)"] = "Lavy - Shadowstrike (AU)",
["Creditfraud - Shadowstrike (AU)"] = "Creditfraud - Shadowstrike (AU)",
["Bumboclaat - Shadowstrike (AU)"] = "Bumboclaat - Shadowstrike (AU)",
},
["profiles"] = {
["Poisongrace - Maladath (AU)"] = {
["Colors"] = {
["Bar"] = {
["Bar Text"] = {
["a"] = 1,
},
},
},
["AppendUnitNameCheck"] = true,
["MainWindowVis"] = false,
["AppendUnitKoSCheck"] = true,
},
["Skeeboo - Shadowstrike (AU)"] = {
["AppendUnitNameCheck"] = true,
["MainWindowVis"] = false,
["Colors"] = {
["Bar"] = {
["Bar Text"] = {
["a"] = 1,
},
},
},
["AppendUnitKoSCheck"] = true,
},
["Poisongrace - Shadowstrike (AU)"] = {
["AppendUnitNameCheck"] = true,
["MainWindowVis"] = false,
["Colors"] = {
["Bar"] = {
["Bar Text"] = {
["a"] = 1,
},
},
},
["AppendUnitKoSCheck"] = true,
},
["Squishcow - Shadowstrike (AU)"] = {
["AppendUnitNameCheck"] = true,
["MainWindowVis"] = false,
["Colors"] = {
["Bar"] = {
["Bar Text"] = {
["a"] = 1,
},
},
},
["AppendUnitKoSCheck"] = true,
},
["Falseclaimin - Shadowstrike (AU)"] = {
["AppendUnitNameCheck"] = true,
["MainWindow"] = {
["Position"] = {
["y"] = 679.5,
["x"] = 0,
["h"] = 50.99991989135742,
},
},
["Colors"] = {
["Alert"] = {
["Stealth Text"] = {
["a"] = 1,
},
["Name Text"] = {
["a"] = 1,
},
},
["Bar"] = {
["Bar Text"] = {
["a"] = 1,
},
},
},
["AppendUnitKoSCheck"] = true,
["MainWindowVis"] = false,
},
["Logoutnow - Shadowstrike (AU)"] = {
["AppendUnitNameCheck"] = true,
["MainWindowVis"] = false,
["Colors"] = {
["Bar"] = {
["Bar Text"] = {
["a"] = 1,
},
},
},
["AppendUnitKoSCheck"] = true,
},
["Emz - Shadowstrike (AU)"] = {
["AppendUnitNameCheck"] = true,
["Colors"] = {
["Alert"] = {
["Stealth Text"] = {
["a"] = 1,
},
["Name Text"] = {
["a"] = 1,
},
},
["Bar"] = {
["Bar Text"] = {
["a"] = 1,
},
},
},
["AppendUnitKoSCheck"] = true,
},
["Lavy - Shadowstrike (AU)"] = {
["AppendUnitNameCheck"] = true,
["MainWindow"] = {
["Position"] = {
["y"] = 681.2777709960938,
["x"] = 68.22225952148438,
["w"] = 96.22222137451172,
["h"] = 127.333366394043,
},
},
["Colors"] = {
["Bar"] = {
["Bar Text"] = {
["a"] = 1,
},
},
},
["AppendUnitKoSCheck"] = true,
["MainWindowVis"] = false,
},
["Creditfraud - Shadowstrike (AU)"] = {
["AppendUnitNameCheck"] = true,
["MainWindow"] = {
["Position"] = {
["y"] = 954.4446411132812,
["x"] = 95.77781677246094,
["w"] = 160.0000305175781,
["h"] = 147.0000152587891,
},
},
["Colors"] = {
["Alert"] = {
["Stealth Text"] = {
["a"] = 1,
},
["Name Text"] = {
["a"] = 1,
},
},
["Bar"] = {
["Bar Text"] = {
["a"] = 1,
},
},
},
["AppendUnitKoSCheck"] = true,
["MainWindowVis"] = false,
},
["Bumboclaat - Shadowstrike (AU)"] = {
["AppendUnitNameCheck"] = true,
["MainWindow"] = {
["Position"] = {
["y"] = 960.0000610351562,
["x"] = 23.5555419921875,
["h"] = 35.00003051757813,
},
},
["Colors"] = {
["Bar"] = {
["Bar Text"] = {
["a"] = 1,
},
},
},
["AppendUnitKoSCheck"] = true,
["MainWindowVis"] = false,
},
},
}


EnhancedRaidFramesDB = {
["profileKeys"] = {
["Emz - Shadowstrike (AU)"] = "Emz - Shadowstrike (AU)",
["Skeeboo - Shadowstrike (AU)"] = "Skeeboo - Shadowstrike (AU)",
["Poisongrace - Maladath (AU)"] = "Poisongrace - Maladath (AU)",
},
["profiles"] = {
["Emz - Shadowstrike (AU)"] = {
["DB_VERSION"] = 2.2,
},
["Skeeboo - Shadowstrike (AU)"] = {
["DB_VERSION"] = 2.2,
},
["Poisongrace - Maladath (AU)"] = {
["DB_VERSION"] = 2.2,
},
},
}

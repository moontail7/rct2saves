
WeakAurasSaved = {
["dynamicIconCache"] = {
},
["editor_tab_spaces"] = 4,
["displays"] = {
["Evasion"] = {
["iconSource"] = -1,
["wagoID"] = "dTwWQJRhb",
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["url"] = "https://wago.io/dTwWQJRhb/24",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["auranames"] = {
"5278",
"26669",
},
["event"] = "Health",
["unit"] = "player",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["useName"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = true,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["border_size"] = 1,
["border_offset"] = 0,
["text_color"] = {
},
["border_color"] = {
0,
0,
0,
1,
},
["border_visible"] = true,
["border_edge"] = "Blizzard Chat Bubble",
["type"] = "subborder",
},
{
["text_text_format_p_time_format"] = 0,
["text_text"] = "%p",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["text_text_format_p_time_dynamic_threshold"] = 3,
["text_text_format_p_time_mod_rate"] = true,
["type"] = "subtext",
["text_text_format_p_format"] = "timed",
["text_color"] = {
1,
1,
1,
1,
},
["border_color"] = {
},
["text_font"] = "Gilroy Bold",
["text_shadowYOffset"] = 0,
["text_fontType"] = "OUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_anchorYOffset"] = 0,
["text_text_format_p_time_precision"] = 1,
["text_fontSize"] = 18,
["anchorXOffset"] = 0,
["text_text_format_p_time_legacy_floor"] = true,
},
},
["height"] = 30,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["width"] = 30,
["source"] = "import",
["adjustedMax"] = "",
["progressSource"] = {
-1,
"",
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["cooldownEdge"] = false,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "Simonize Rogue Non-Essential buffs",
["config"] = {
},
["cooldownTextDisabled"] = true,
["anchorFrameParent"] = false,
["useCooldownModRate"] = true,
["auto"] = true,
["zoom"] = 0,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Evasion",
["frameStrata"] = 1,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["uid"] = "8m)abq(6YVa",
["inverse"] = false,
["xOffset"] = 0,
["conditions"] = {
},
["cooldown"] = false,
["authorOptions"] = {
},
},
["mana regen"] = {
["sparkWidth"] = 10,
["iconSource"] = -1,
["xOffset"] = 0,
["adjustedMax"] = "",
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["sparkRotation"] = 0,
["sparkRotationMode"] = "AUTO",
["icon"] = false,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["subeventSuffix"] = "_CAST_START",
["event"] = "Health",
["subeventPrefix"] = "SPELL",
["spellIds"] = {
},
["auranames"] = {
"Drink",
},
["unit"] = "player",
["names"] = {
},
["useName"] = true,
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["icon_color"] = {
1,
1,
1,
1,
},
["enableGradient"] = false,
["progressSource"] = {
-1,
"",
},
["selfPoint"] = "CENTER",
["barColor"] = {
0.1529411822557449,
0.3686274588108063,
1,
1,
},
["desaturate"] = false,
["width"] = 200,
["sparkOffsetY"] = 0,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["type"] = "subforeground",
},
{
["text_shadowXOffset"] = 1,
["text_text"] = "Drink",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_text_format_p_time_precision"] = 1,
["type"] = "subtext",
["anchorXOffset"] = 0,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_text_format_p_format"] = "timed",
["text_shadowYOffset"] = -1,
["text_visible"] = true,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "None",
["text_anchorPoint"] = "INNER_LEFT",
["text_text_format_p_time_format"] = 0,
["text_text_format_p_time_mod_rate"] = true,
["text_fontSize"] = 12,
["text_text_format_p_time_dynamic_threshold"] = 60,
["text_text_format_p_time_legacy_floor"] = false,
},
{
["text_shadowXOffset"] = 1,
["text_text"] = "%p",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_text_format_p_time_precision"] = 1,
["anchorXOffset"] = 0,
["type"] = "subtext",
["text_text_format_n_format"] = "none",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_text_format_p_format"] = "timed",
["text_shadowYOffset"] = -1,
["text_visible"] = true,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "None",
["text_anchorPoint"] = "INNER_RIGHT",
["text_text_format_p_time_format"] = 0,
["text_text_format_p_time_mod_rate"] = true,
["text_fontSize"] = 12,
["text_text_format_p_time_dynamic_threshold"] = 60,
["text_text_format_p_time_legacy_floor"] = false,
},
},
["height"] = 15,
["textureSource"] = "LSM",
["load"] = {
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["sparkBlendMode"] = "ADD",
["useAdjustededMax"] = false,
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["information"] = {
},
["gradientOrientation"] = "HORIZONTAL",
["backgroundColor"] = {
0,
0,
0,
0.5,
},
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["useAdjustededMin"] = false,
["regionType"] = "aurabar",
["sparkOffsetX"] = 0,
["uid"] = "PxU2nwlOxlz",
["icon_side"] = "RIGHT",
["authorOptions"] = {
},
["sparkHeight"] = 30,
["texture"] = "Blizzard",
["alpha"] = 1,
["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
["spark"] = false,
["zoom"] = 0,
["id"] = "mana regen",
["sparkHidden"] = "NEVER",
["frameStrata"] = 1,
["anchorFrameType"] = "SCREEN",
["sparkColor"] = {
1,
1,
1,
1,
},
["config"] = {
},
["inverse"] = false,
["internalVersion"] = 78,
["orientation"] = "HORIZONTAL",
["conditions"] = {
},
["barColor2"] = {
1,
1,
0,
1,
},
["parent"] = "regen Group",
},
["Envenom"] = {
["iconSource"] = -1,
["wagoID"] = "dTwWQJRhb",
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["url"] = "https://wago.io/dTwWQJRhb/24",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["auraspellids"] = {
"399963",
"57993",
},
["event"] = "Health",
["unit"] = "player",
["names"] = {
},
["useExactSpellId"] = true,
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["useName"] = false,
["subeventSuffix"] = "_CAST_START",
["auranames"] = {
"57993",
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = true,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_text_format_p_time_format"] = 0,
["text_text"] = "%p",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["text_text_format_p_time_dynamic_threshold"] = 10,
["text_text_format_p_time_mod_rate"] = true,
["type"] = "subtext",
["text_text_format_p_format"] = "timed",
["text_color"] = {
1,
1,
1,
1,
},
["border_color"] = {
},
["text_font"] = "Gilroy Bold",
["text_shadowYOffset"] = 0,
["text_fontType"] = "THICKOUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_anchorYOffset"] = 0,
["text_text_format_p_time_precision"] = 1,
["text_fontSize"] = 18,
["anchorXOffset"] = 0,
["text_text_format_p_time_legacy_floor"] = true,
},
},
["height"] = 32,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["width"] = 32,
["source"] = "import",
["zoom"] = 0,
["progressSource"] = {
-1,
"",
},
["adjustedMax"] = "",
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["colorR"] = 1,
["duration"] = "30",
["alphaType"] = "alphaPulse",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0.26,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "alphaPulse",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "relative",
},
["finish"] = {
["colorR"] = 1,
["scalex"] = 1,
["alphaType"] = "alphaPulse",
["colorB"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["colorA"] = 1,
["duration"] = "8",
["rotate"] = 0,
["easeStrength"] = 3,
["duration_type"] = "seconds",
},
},
["authorOptions"] = {
},
["config"] = {
},
["useCooldownModRate"] = true,
["auto"] = true,
["cooldownTextDisabled"] = true,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Envenom",
["frameStrata"] = 1,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["xOffset"] = 0,
["uid"] = "D3)DhXBROZ6",
["inverse"] = false,
["parent"] = "SimonizeBars",
["conditions"] = {
},
["cooldown"] = false,
["cooldownEdge"] = false,
},
["Sno - Rogue Combo Points"] = {
["controlledChildren"] = {
"CP 1",
"CP 2",
"CP 3",
"CP 4",
"CP 5",
"CP1BlackOutline",
"CP2BlackOutline",
"CP3BlackOutline",
"CP4BlackOutline",
"CP5BlackOutline",
"CP1YellowOutline GCD",
"CP2YellowOutline GCD",
"CP3YellowOutline GCD",
"CP4YellowOutline GCD",
"CP5YellowOutline GCD",
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "dTwWQJRhb",
["xOffset"] = -1.2166170491799,
["preferToUpdate"] = true,
["yOffset"] = -16.870843725682,
["anchorPoint"] = "CENTER",
["borderColor"] = {
0,
0,
0,
1,
},
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["unit"] = "player",
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["debuffType"] = "HELPFUL",
["event"] = "Health",
["names"] = {
},
},
["untrigger"] = {
},
},
},
["internalVersion"] = 78,
["selfPoint"] = "BOTTOMLEFT",
["desc"] = "",
["version"] = 24,
["subRegions"] = {
},
["load"] = {
["use_class"] = "true",
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["backdropColor"] = {
1,
1,
1,
0.5,
},
["source"] = "import",
["scale"] = 0.95,
["border"] = false,
["borderEdge"] = "Square Full White",
["regionType"] = "group",
["borderSize"] = 2,
["config"] = {
},
["borderOffset"] = 4,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Sno - Rogue Combo Points",
["alpha"] = 1,
["frameStrata"] = 1,
["anchorFrameType"] = "SCREEN",
["authorOptions"] = {
},
["borderInset"] = 1,
["parent"] = "Rogue Auras",
["uid"] = "ESfLgjn5jDO",
["conditions"] = {
},
["information"] = {
["ignoreOptionsEventErrors"] = true,
["forceEvents"] = true,
["groupOffset"] = true,
},
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
},
["Gelihast Shield"] = {
["iconSource"] = 0,
["wagoID"] = "A3Z0KIoeL",
["authorOptions"] = {
},
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = 100.34576416016,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["spellId"] = {
"412456",
},
["duration"] = "24",
["genericShowOn"] = "showOnCooldown",
["names"] = {
},
["use_delay"] = false,
["debuffType"] = "HARMFUL",
["use_track"] = true,
["use_cloneId"] = false,
["spellName"] = {
0,
},
["auraspellids"] = {
"429541",
},
["type"] = "combatlog",
["useExactSpellId"] = true,
["subeventSuffix"] = "_CAST_SUCCESS",
["use_count"] = false,
["subeventPrefix"] = "SPELL",
["event"] = "Combat Log",
["use_spellId"] = true,
["realSpellName"] = 0,
["use_spellName"] = false,
["spellIds"] = {
},
["use_sourceUnit"] = false,
["use_genericShowOn"] = true,
["unit"] = "target",
["sourceUnit"] = "target",
["use_auraType"] = false,
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "%p",
["text_text_format_p_format"] = "timed",
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_p_time_legacy_floor"] = false,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_text_format_p_time_mod_rate"] = true,
["type"] = "subtext",
["text_text_format_p_time_dynamic_threshold"] = 60,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_text_format_p_time_format"] = 0,
["text_shadowYOffset"] = 0,
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "CENTER",
["anchorYOffset"] = 0,
["text_visible"] = true,
["text_fontSize"] = 48,
["anchorXOffset"] = 0,
["text_text_format_p_time_precision"] = 1,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = false,
["glowLength"] = 10,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 96,
["load"] = {
["use_never"] = true,
["talent"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["anchorFrameType"] = "SCREEN",
["source"] = "import",
["actions"] = {
["start"] = {
["sound_channel"] = "Master",
["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\AirHorn.ogg",
["do_sound"] = false,
},
["finish"] = {
},
["init"] = {
},
},
["adjustedMax"] = "",
["cooldownEdge"] = false,
["cooldown"] = true,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["conditions"] = {
},
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "SOD - BFD",
["config"] = {
},
["frameStrata"] = 1,
["zoom"] = 0,
["cooldownTextDisabled"] = true,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Gelihast Shield",
["useCooldownModRate"] = true,
["alpha"] = 1,
["width"] = 96,
["progressSource"] = {
-1,
"",
},
["uid"] = "dnq85BkYKQ2",
["inverse"] = false,
["color"] = {
1,
1,
1,
1,
},
["displayIcon"] = "136121",
["information"] = {
},
["xOffset"] = -101.13610839844,
},
["CP 3"] = {
["wagoID"] = "dTwWQJRhb",
["authorOptions"] = {
},
["preferToUpdate"] = true,
["yOffset"] = -165,
["anchorPoint"] = "CENTER",
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["names"] = {
},
["type"] = "unit",
["subeventPrefix"] = "SPELL",
["power"] = {
"1",
},
["power_operator"] = {
">=",
},
["duration"] = "1",
["event"] = "Power",
["use_unit"] = true,
["unevent"] = "auto",
["powertype"] = 4,
["spellIds"] = {
},
["unit"] = "player",
["use_power"] = false,
["subeventSuffix"] = "_CAST_START",
["use_powertype"] = true,
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 42.765598297119,
["rotate"] = true,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["textureWrapMode"] = "CLAMP",
["source"] = "import",
["mirror"] = false,
["regionType"] = "texture",
["blendMode"] = "BLEND",
["desc"] = "Rogue Combo Points - Classic WoW                                                              - created by Johadan                                                                                                                        - https://wago.io/p/Johadan#1650                                                                                         - Discord: https://discord.gg/QJs5SHH",
["color"] = {
0,
0,
0,
1,
},
["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Circle_Smooth_Border",
["parent"] = "Sno - Rogue Combo Points",
["xOffset"] = 0,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "CP 3",
["anchorFrameType"] = "SCREEN",
["alpha"] = 1,
["width"] = 42.76575088501,
["frameStrata"] = 1,
["uid"] = "mWc21ADA3tl",
["config"] = {
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
},
["conditions"] = {
{
["check"] = {
["trigger"] = 1,
["op"] = ">=",
["variable"] = "power",
["value"] = "3",
},
["changes"] = {
{
["value"] = {
0.94509803921569,
0.019607843137255,
0,
1,
},
["property"] = "color",
},
{
["value"] = 1,
["property"] = "alpha",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["variable"] = "power",
["value"] = "5",
},
["changes"] = {
{
["value"] = {
1,
0.22352941176471,
0.72156862745098,
1,
},
["property"] = "color",
},
},
},
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["discrete_rotation"] = 0,
},
["Rogue Auras"] = {
["controlledChildren"] = {
"Cooldown Reminders 2",
"Sno - Rogue Combo Points",
"SimonizeBars",
"Simonize Meme Auras",
"Simonize Rogue Non-Essential buffs",
"Energy Bar Simonize Basic",
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "dTwWQJRhb",
["xOffset"] = 0.7044982647710178,
["preferToUpdate"] = true,
["yOffset"] = 8.888969090246796,
["anchorPoint"] = "CENTER",
["borderColor"] = {
0,
0,
0,
1,
},
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["unit"] = "player",
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["debuffType"] = "HELPFUL",
["event"] = "Health",
["names"] = {
},
},
["untrigger"] = {
},
},
},
["internalVersion"] = 78,
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["version"] = 24,
["subRegions"] = {
},
["load"] = {
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["backdropColor"] = {
1,
1,
1,
0.5,
},
["source"] = "import",
["scale"] = 0.8000000000000002,
["border"] = false,
["borderEdge"] = "Square Full White",
["regionType"] = "group",
["borderSize"] = 2,
["borderOffset"] = 4,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Rogue Auras",
["selfPoint"] = "CENTER",
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["authorOptions"] = {
},
["borderInset"] = 1,
["uid"] = "1oU(i8KtfU4",
["config"] = {
},
["conditions"] = {
},
["information"] = {
},
["frameStrata"] = 1,
},
["Mana - 2 Second Ticks"] = {
["sparkWidth"] = 3,
["sparkOffsetX"] = 0,
["width"] = 114,
["xOffset"] = 3.04833984375,
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["iconSource"] = -1,
["parent"] = "Player mana regen",
["sparkRotation"] = 0,
["sparkRotationMode"] = "AUTO",
["url"] = "https://wago.io/mana-ticker/4",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["custom_hide"] = "timed",
["type"] = "custom",
["dynamicDuration"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["duration"] = "2",
["event"] = "Chat Message",
["unit"] = "player",
["customDuration"] = "function()\n    return 2, (aura_env.tickTimestamp or GetTime()) + 2\nend",
["custom"] = "function(event, unit, power)\n    if not (\"player\" == unit and \"MANA\" == power) then\n        return\n    end\n    \n    local currentMana = UnitPower(unit, Enum.PowerType.Mana, true)\n    local maxMana = UnitPowerMax(unit, Enum.PowerType.Mana, true)\n    local prevMana = aura_env.prevMana or maxMana\n    local ts = GetTime()\n    local tickTimestamp = aura_env.tickTimestamp or ts\n    \n    aura_env.prevMana = currentMana\n    \n    if currentMana >= maxMana then\n        -- Mana is full\n        return\n    elseif currentMana <= prevMana then\n        -- Mana used\n        if (ts - tickTimestamp) < 2 then\n            -- Tick in progress or first tick\n            return\n        end\n        aura_env.tickTimestamp = (ts - ts % 2) + (tickTimestamp % 2)\n    else\n        -- Mana replenished\n        aura_env.tickTimestamp = ts\n    end\n    \n    return true\nend",
["events"] = "UNIT_POWER_FREQUENT",
["unevent"] = "timed",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["custom_type"] = "event",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = 1,
},
["icon_color"] = {
1,
1,
1,
1,
},
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["adjustedMax"] = "",
["uid"] = "iEE3Qsxg5AK",
["barColor"] = {
0.60392156862745,
0.8078431372549,
0.87450980392157,
0,
},
["desaturate"] = false,
["color"] = {
},
["backgroundColor"] = {
0,
0,
0,
0,
},
["sparkOffsetY"] = 0,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["type"] = "subforeground",
},
},
["height"] = 20,
["textureSource"] = "LSM",
["load"] = {
["use_level"] = true,
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["use_class"] = false,
["zoneIds"] = "",
["class"] = {
["multi"] = {
["HUNTER"] = true,
["WARLOCK"] = true,
["SHAMAN"] = true,
["MAGE"] = true,
["DRUID"] = true,
["PRIEST"] = true,
},
},
["level_operator"] = {
">",
},
["level"] = {
"2",
},
["use_never"] = false,
["size"] = {
["multi"] = {
},
},
},
["sparkBlendMode"] = "ADD",
["useAdjustededMax"] = false,
["enableGradient"] = false,
["source"] = "import",
["selfPoint"] = "CENTER",
["barColor2"] = {
1,
1,
0,
1,
},
["authorOptions"] = {
},
["icon"] = false,
["useAdjustededMin"] = false,
["regionType"] = "aurabar",
["version"] = 4,
["gradientOrientation"] = "HORIZONTAL",
["icon_side"] = "RIGHT",
["auto"] = true,
["sparkColor"] = {
0.60392156862745,
0.8078431372549,
0.87450980392157,
1,
},
["sparkHeight"] = 20,
["texture"] = "Details Flat",
["anchorFrameFrame"] = "PlayerFrameManaBar",
["zoom"] = 0,
["spark"] = true,
["tocversion"] = 11306,
["id"] = "Mana - 2 Second Ticks",
["semver"] = "1.0.3",
["frameStrata"] = 5,
["anchorFrameType"] = "SELECTFRAME",
["alpha"] = 1,
["config"] = {
},
["inverse"] = true,
["sparkTexture"] = "honorsystem-bar-spark",
["orientation"] = "HORIZONTAL",
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["sparkHidden"] = "NEVER",
},
["nanShield:Segment"] = {
["wagoID"] = "6HHBMDHTD",
["parent"] = "nanShield Classic",
["preferToUpdate"] = false,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["url"] = "https://wago.io/6HHBMDHTD/3",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
["custom"] = "-- Package common/logging\naura_env.logPalette = {\n    \"ff6e7dda\",\n    \"ff21dfb9\",\n    \"ffe3f57a\",\n    \"ffed705a\",\n    \"fff8a3e6\",\n}\n\nfunction aura_env:log(...)\n    if self.config and self.config.debugEnabled then\n        local palette = self.logPalette\n        local args = {\n            self.cloneId and\n            format(\"[%s:%s]\", self.id, self.cloneId) or\n            format(\"[%s]\", self.id),\n            ...\n        }\n        for i = 1, #args do\n            args[i] = format(\n                \"|c%s%s|r\",\n                palette[1 + (i - 1) % #palette],\n                tostring(args[i]))\n        end\n        print(unpack(args))\n    end\nend\n-- Package end\n\n-- Package common/lowabsorb\nfunction aura_env:LowestAbsorb(totalAbsorb, all, physical, magic, ...)\n    self:log('LowestAbsorb', all, physical, magic, ...)\n    local minValue\n    local minIdx\n    local value\n    \n    for i = 1, select('#', ...) do\n        value = select(i, ...)\n        if value > 0 and value <= (minValue or value) then\n            minIdx = i + 3\n            minValue = value\n        end\n    end\n    \n    if minIdx then\n        minValue = minValue + magic\n    elseif magic > 0 then\n        minValue = magic\n        minIdx = 3\n    end\n    \n    if physical > 0 and physical <= (minValue or physical) then\n        minValue = physical\n        minIdx = 2\n    end\n    \n    if minIdx then\n        minValue = minValue + all\n    else\n        minValue = all\n        minIdx = 1\n    end\n    \n    self:log('LowestAbsorbResult', minValue, totalAbsorb, minIdx)\n    return minValue, totalAbsorb, minIdx\nend\n-- Package end\n\n-- Package common/schools\naura_env.schools = {\n    \"All\",\n    \"Physical\",\n    \"Magic\",\n    \"Holy\",\n    \"Fire\",\n    \"Nature\",\n    \"Frost\",\n    \"Shadow\",\n    \"Arcane\",\n}\naura_env.schoolIds = { 127, 1, 126, 2, 4, 8, 16, 32, 64 }\naura_env.schoolIdx = {}\nfor idx, id in ipairs(aura_env.schoolIds) do\n    aura_env.schoolIdx[id] = idx\nend\n-- Package end\n\n-- Package segment/rotate\nfunction aura_env:rotate()\n    local segments = self.config.segmentCount\n    local angle = self.config.curveAngle\n    local direction = -(self.config.direction - 1.5) * 2\n    local base = (self.config.rotationOffset + self.config.direction * 180)\n    -- Since WeakAuras-5.3.5 the region:Rotate has been renamed to SetRotation\n    self.region:SetRotation(base + direction * (angle / (segments - 1)) * (self.cloneId - (segments + 1) / 2))\nend\n-- Package end\n\n-- Package segment/tsu\nfunction aura_env:on_tsu(allstates, ...)\n    -- self:log('TSU', self.config.segmentCount)\n    local now = GetTime()\n    local timestamp = self.timestamp or 0\n    local active = self.active or 0\n    local changed\n    \n    for i = #allstates + 1, self.config.segmentCount do\n        allstates[i] = {\n            changed = true,\n            show = false,\n            school = \"All\"\n        }\n    end\n    \n    if now - timestamp > 0.25 / self.config.segmentCount then\n        self.timestamp = now\n        if active < #allstates and allstates[active + 1].show then\n            for i = #allstates, active + 1, -1 do\n                if allstates[i].show then\n                    allstates[i].show = false\n                    allstates[i].changed = true\n                    changed = true\n                    break\n                end\n            end\n        else\n            for i = 1, active do\n                if i <= #allstates and not allstates[i].show then\n                    allstates[i].show = true\n                    allstates[i].changed = true\n                    changed = true\n                    break\n                end\n            end\n        end\n        for i = 1, active do\n            if i <= #allstates and allstates[i].show then\n                if allstates[i].school ~= self.segmentSchool[i] then\n                    self:log('TSUSchool', i, allstates[i].school, self.segmentSchool[i])\n                    allstates[i].school = self.segmentSchool[i]\n                    allstates[i].changed = true\n                    changed = true\n                end\n            end\n        end\n    end\n    return changed\nend\n-- Package end\n\n-- Package segment/update\naura_env.segmentSchool = {}\n\nfunction aura_env:on_nan_shield(event, totalAbsorb, ...)\n    self:log(event, totalAbsorb, ...)\n    local currentAbsorb = 0\n    local value\n    local prevSegment = 0\n    local segment\n    self.active = 0\n    \n    if event == 'OPTIONS' then\n        self.active = self.config.segmentCount or 10\n        self:log(event, self.active)\n    else\n        for i = 1, select(\"#\", ...) do\n            value = select(i, ...)\n            currentAbsorb = currentAbsorb + value\n            \n            if currentAbsorb > 0 and totalAbsorb > 0 then\n                segment = ceil(currentAbsorb / totalAbsorb * self.config.segmentCount)\n                if value > 0 then\n                    for s = prevSegment + 1, segment do\n                        self.segmentSchool[s] = self.schools[i]\n                    end\n                    prevSegment = segment\n                end\n            end\n            \n        end\n        \n        if currentAbsorb > 0 and totalAbsorb > 0 then\n            self.active = ceil(currentAbsorb / totalAbsorb * self.config.segmentCount)\n        end\n    end\nend\n-- Package end\n\n\n\n",
["do_custom"] = true,
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "custom",
["custom_type"] = "stateupdate",
["debuffType"] = "HELPFUL",
["event"] = "Health",
["unit"] = "player",
["custom"] = "function(...)\n    return aura_env:on_tsu(...)\nend",
["spellIds"] = {
},
["events"] = "PLAYER_ENTERING_WORLD WA_NAN_SHIELD",
["names"] = {
},
["check"] = "update",
["subeventPrefix"] = "SPELL",
["subeventSuffix"] = "_CAST_START",
["customVariables"] = "{\n    school = {\n        type = \"select\",\n        display = \"Damage Type\",\n        values = {\n            [\"All\"] = \"All\",\n            [\"Physical\"] = \"Physical\",\n            [\"Magic\"] = \"Magic\",\n            [\"Holy\"] = \"Holy\",\n            [\"Fire\"] = \"Fire\",\n            [\"Nature\"] = \"Nature\",\n            [\"Frost\"] = \"Frost\",\n            [\"Shadow\"] = \"Shadow\",\n            [\"Arcane\"] = \"Arcane\"\n        }\n    }\n}",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["subeventPrefix"] = "SPELL",
["type"] = "custom",
["events"] = "WA_NAN_SHIELD",
["custom_type"] = "event",
["subeventSuffix"] = "_CAST_START",
["custom"] = "function(...)\n    return aura_env:on_nan_shield(...)\nend",
["event"] = "Health",
["custom_hide"] = "custom",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = 1,
},
["internalVersion"] = 78,
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration_type"] = "seconds",
["alphaType"] = "straight",
["colorB"] = 1,
["colorG"] = 1,
["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
["use_alpha"] = true,
["type"] = "none",
["duration"] = "0.2",
["easeType"] = "none",
["scaley"] = 1,
["preset"] = "fade",
["alpha"] = 0,
["rotate"] = 0,
["y"] = 0,
["x"] = 0,
["scaleType"] = "straightScale",
["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\n    end\n  ",
["scalex"] = 2,
["easeStrength"] = 3,
["use_scale"] = true,
["colorA"] = 1,
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration_type"] = "seconds",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_translate"] = true,
["use_alpha"] = true,
["duration"] = "0.2",
["type"] = "custom",
["scaleType"] = "straightScale",
["easeType"] = "none",
["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
["scaley"] = 1.5,
["alpha"] = 0,
["rotate"] = 0,
["y"] = 20,
["x"] = 5,
["translateType"] = "straightTranslate",
["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
["use_scale"] = true,
["easeStrength"] = 3,
["scalex"] = 1.5,
["colorB"] = 1,
},
},
["desaturate"] = false,
["rotation"] = 180,
["version"] = 3,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 25,
["rotate"] = true,
["load"] = {
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["zoneIds"] = "",
},
["textureWrapMode"] = "CLAMP",
["source"] = "import",
["mirror"] = false,
["regionType"] = "texture",
["blendMode"] = "ADD",
["anchorFrameParent"] = false,
["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\target_indicator_glow.tga",
["config"] = {
["direction"] = 1,
["segmentCount"] = 20,
["rotationOffset"] = 0,
["curveAngle"] = 15,
["debugEnabled"] = false,
},
["selfPoint"] = "CENTER",
["semver"] = "1.0.2",
["tocversion"] = 11500,
["id"] = "nanShield:Segment",
["anchorFrameType"] = "SCREEN",
["alpha"] = 1,
["width"] = 50,
["xOffset"] = 0,
["uid"] = "VWzp20EQnk3",
["authorOptions"] = {
{
["type"] = "range",
["useDesc"] = false,
["max"] = 360,
["step"] = 1,
["width"] = 1,
["min"] = 1,
["key"] = "curveAngle",
["default"] = 15,
["name"] = "Curve",
},
{
["type"] = "range",
["useDesc"] = false,
["max"] = 180,
["step"] = 1,
["width"] = 1,
["min"] = -180,
["key"] = "rotationOffset",
["default"] = 0,
["name"] = "Rotation",
},
{
["type"] = "range",
["useDesc"] = false,
["max"] = 100,
["step"] = 1,
["width"] = 1,
["min"] = 3,
["key"] = "segmentCount",
["default"] = 20,
["name"] = "Segments",
},
{
["type"] = "select",
["default"] = 1,
["values"] = {
"Counter Clockwise",
"Clockwise",
},
["name"] = "Direction",
["useDesc"] = false,
["key"] = "direction",
["width"] = 1,
},
{
["text"] = "",
["type"] = "header",
["useName"] = false,
["width"] = 1,
},
{
["type"] = "toggle",
["default"] = false,
["key"] = "debugEnabled",
["name"] = "Enable Debug Info",
["useDesc"] = false,
["width"] = 1,
},
},
["frameStrata"] = 1,
["conditions"] = {
{
["check"] = {
["trigger"] = 1,
["variable"] = "show",
["value"] = 1,
},
["changes"] = {
{
["value"] = {
["custom"] = "aura_env:rotate()",
},
["property"] = "customcode",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "All",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0.94901960784314,
0.89411764705882,
0.56078431372549,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Magic",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0,
0.50196078431373,
1,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Physical",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0.9921568627451,
0.7921568627451,
0.63529411764706,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Arcane",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
1,
0.61176470588235,
1,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Fire",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
1,
0.50196078431373,
0,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Frost",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0,
1,
1,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Holy",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
1,
1,
0,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Nature",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0.50196078431373,
1,
0,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Shadow",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0.72941176470588,
0.45882352941176,
1,
1,
},
["property"] = "color",
},
},
},
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["color"] = {
1,
0.7921568627451,
0,
1,
},
},
["Melee Range Reminder"] = {
["outline"] = "OUTLINE",
["wagoID"] = "A3Z0KIoeL",
["authorOptions"] = {
},
["displayText"] = "%c",
["customText"] = "function()\n    \n    if not aura_env.last or aura_env.last < GetTime() - 0.05 then\n        aura_env.last = GetTime()\n        \n        if UnitExists(\"target\") then\n            if not IsItemInRange(16114, \"target\") then\n                aura_env.displayText = \"TOO FAR\"\n            elseif IsCurrentSpell(6603) == false then\n                aura_env.displayText = \"NOT ATTACKING\"\n            else \n                aura_env.displayText = \"\"\n            end\n        end\n        \n    end\n    \n    return aura_env.displayText\n    \nend\n\n\n",
["shadowYOffset"] = -1,
["anchorPoint"] = "CENTER",
["customTextUpdate"] = "update",
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
["custom"] = "aura_env.displayText=\"\"",
["do_custom"] = true,
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "unit",
["use_incombat"] = true,
["unevent"] = "auto",
["subeventPrefix"] = "SPELL",
["percenthealth"] = "0",
["event"] = "Conditions",
["use_unit"] = true,
["subeventSuffix"] = "_CAST_START",
["unit"] = "target",
["spellIds"] = {
},
["duration"] = "1",
["names"] = {
},
["use_percenthealth"] = true,
["percenthealth_operator"] = ">",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
["unit"] = "target",
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["font"] = "Emblem",
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["load"] = {
["use_namerealm"] = false,
["namerealm"] = "Wherefore",
["talent"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
["DEATHKNIGHT"] = true,
["WARRIOR"] = true,
["ROGUE"] = true,
["DRUID"] = true,
["PALADIN"] = true,
},
},
["use_class"] = false,
["zoneIds"] = "",
["spec"] = {
["multi"] = {
},
},
["use_never"] = false,
["size"] = {
["multi"] = {
},
},
},
["fontSize"] = 46,
["source"] = "import",
["shadowXOffset"] = 1,
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["preset"] = "alphaPulse",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["regionType"] = "text",
["conditions"] = {
},
["parent"] = "General Auras",
["preferToUpdate"] = false,
["automaticWidth"] = "Auto",
["yOffset"] = 352.9386596679688,
["config"] = {
},
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Melee Range Reminder",
["xOffset"] = 12.0331909179688,
["frameStrata"] = 1,
["anchorFrameType"] = "SCREEN",
["color"] = {
1,
0.011764705882353,
0,
1,
},
["uid"] = "0XxQZlEF0)k",
["justify"] = "LEFT",
["wordWrap"] = "WordWrap",
["shadowColor"] = {
0,
0,
0,
1,
},
["fixedWidth"] = 200,
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["displayText_format_c_format"] = "none",
},
["Energy Bar Simonize Basic"] = {
["sparkWidth"] = 10,
["iconSource"] = -1,
["xOffset"] = 0.13,
["preferToUpdate"] = true,
["yOffset"] = -143.38,
["anchorPoint"] = "CENTER",
["sparkRotation"] = 0,
["url"] = "https://wago.io/dTwWQJRhb/24",
["backgroundColor"] = {
0,
0,
0,
0.50757801532745,
},
["icon_color"] = {
1,
1,
1,
1,
},
["enableGradient"] = false,
["selfPoint"] = "CENTER",
["barColor"] = {
0.91372555494308,
0.8156863451004,
0,
1,
},
["desaturate"] = false,
["sparkOffsetY"] = 0,
["gradientOrientation"] = "HORIZONTAL",
["load"] = {
["use_petbattle"] = false,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["use_class"] = true,
["use_spec"] = false,
["size"] = {
["multi"] = {
},
},
["spec"] = {
["single"] = 3,
["multi"] = {
[3] = true,
},
},
["use_vehicleUi"] = false,
["zoneIds"] = "",
},
["smoothProgress"] = false,
["useAdjustededMin"] = false,
["regionType"] = "aurabar",
["texture"] = "Solid",
["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
["spark"] = false,
["tocversion"] = 30403,
["alpha"] = 1,
["config"] = {
},
["sparkOffsetX"] = 0,
["wagoID"] = "dTwWQJRhb",
["parent"] = "Rogue Auras",
["adjustedMin"] = "",
["sparkRotationMode"] = "AUTO",
["triggers"] = {
{
["trigger"] = {
["type"] = "unit",
["subeventPrefix"] = "SPELL",
["unevent"] = "auto",
["names"] = {
},
["duration"] = "1",
["use_showCost"] = false,
["use_unit"] = true,
["use_absorbMode"] = true,
["powertype"] = 3,
["spellIds"] = {
},
["unit"] = "player",
["event"] = "Power",
["subeventSuffix"] = "_CAST_START",
["use_powertype"] = true,
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["type"] = "subforeground",
},
{
["border_size"] = 4,
["border_anchor"] = "bar",
["border_offset"] = 0,
["border_color"] = {
0,
0,
0,
1,
},
["border_visible"] = true,
["border_edge"] = "Square Full White",
["type"] = "subborder",
},
{
["text_text_format_p_time_precision"] = 1,
["text_text"] = "%p",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "CENTER",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["text_text_format_p_time_dynamic_threshold"] = 0,
["text_text_format_p_format"] = "timed",
["type"] = "subtext",
["text_anchorXOffset"] = 0,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Expressway",
["text_text_format_p_time_mod_rate"] = true,
["text_anchorYOffset"] = -2,
["text_visible"] = true,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "THICKOUTLINE",
["text_anchorPoint"] = "INNER_CENTER",
["text_text_format_p_time_format"] = 0,
["text_shadowYOffset"] = 0,
["text_fontSize"] = 24,
["anchorXOffset"] = 0,
["text_text_format_p_time_legacy_floor"] = true,
},
{
["tick_rotation"] = 0,
["tick_xOffset"] = 0,
["tick_desaturate"] = false,
["use_texture"] = false,
["tick_placement_mode"] = "AtValue",
["tick_texture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
["tick_length"] = 25,
["tick_blend_mode"] = "ADD",
["type"] = "subtick",
["tick_placements"] = {
"50",
},
["automatic_length"] = false,
["tick_thickness"] = 2,
["tick_color"] = {
1,
1,
1,
1,
},
["tick_yOffset"] = 0,
["progressSources"] = {
{
-2,
"",
},
},
["tick_mirror"] = false,
["tick_visible"] = false,
},
},
["height"] = 33,
["textureSource"] = "LSM",
["sparkBlendMode"] = "ADD",
["useAdjustededMax"] = false,
["source"] = "import",
["overlays"] = {
{
1,
0.87450980392157,
0.20392156862745,
1,
},
},
["icon_side"] = "RIGHT",
["zoom"] = 0,
["authorOptions"] = {
},
["sparkHeight"] = 30,
["adjustedMax"] = "",
["information"] = {
["forceEvents"] = false,
["ignoreOptionsEventErrors"] = false,
},
["icon"] = false,
["semver"] = "1.0.23",
["id"] = "Energy Bar Simonize Basic",
["sparkHidden"] = "NEVER",
["anchorFrameType"] = "SCREEN",
["frameStrata"] = 1,
["width"] = 170,
["auto"] = true,
["uid"] = "x0PsosoioWs",
["inverse"] = false,
["actions"] = {
["start"] = {
["do_message"] = false,
},
["init"] = {
["custom"] = "aura_env.region.bar.fg:SetGradient(\"HORIZONTAL\",1.00,0.75,0.16,1.00,0.83,0.32)",
["do_custom"] = false,
},
["finish"] = {
},
},
["orientation"] = "HORIZONTAL",
["conditions"] = {
},
["barColor2"] = {
1,
1,
0,
1,
},
["sparkColor"] = {
1,
1,
1,
1,
},
},
["CP 2"] = {
["wagoID"] = "dTwWQJRhb",
["authorOptions"] = {
},
["preferToUpdate"] = true,
["yOffset"] = -165,
["anchorPoint"] = "CENTER",
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["names"] = {
},
["type"] = "unit",
["subeventPrefix"] = "SPELL",
["power"] = {
"1",
},
["power_operator"] = {
">=",
},
["duration"] = "1",
["event"] = "Power",
["use_unit"] = true,
["unevent"] = "auto",
["powertype"] = 4,
["spellIds"] = {
},
["unit"] = "player",
["use_power"] = false,
["subeventSuffix"] = "_CAST_START",
["use_powertype"] = true,
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 42.765598297119,
["rotate"] = true,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["textureWrapMode"] = "CLAMP",
["source"] = "import",
["mirror"] = false,
["regionType"] = "texture",
["blendMode"] = "BLEND",
["desc"] = "Rogue Combo Points - Classic WoW                                                              - created by Johadan                                                                                                                        - https://wago.io/p/Johadan#1650                                                                                         - Discord: https://discord.gg/QJs5SHH",
["color"] = {
0,
0,
0,
1,
},
["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Circle_Smooth_Border",
["parent"] = "Sno - Rogue Combo Points",
["xOffset"] = -35,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "CP 2",
["anchorFrameType"] = "SCREEN",
["alpha"] = 1,
["width"] = 42.76575088501,
["frameStrata"] = 1,
["uid"] = "NHOOpGEFL7W",
["config"] = {
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
},
["conditions"] = {
{
["check"] = {
["trigger"] = 1,
["op"] = ">=",
["variable"] = "power",
["value"] = "2",
},
["changes"] = {
{
["value"] = {
0.94509803921569,
0.019607843137255,
0,
1,
},
["property"] = "color",
},
{
["value"] = 1,
["property"] = "alpha",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["variable"] = "power",
["value"] = "5",
},
["changes"] = {
{
["value"] = {
1,
0.22352941176471,
0.72156862745098,
1,
},
["property"] = "color",
},
},
},
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["discrete_rotation"] = 0,
},
["nanShield Classic"] = {
["grow"] = "CUSTOM",
["controlledChildren"] = {
"nanShield:Value",
"nanShield:Text",
"nanShield:Bar",
"nanShield:Segment",
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "6HHBMDHTD",
["authorOptions"] = {
},
["preferToUpdate"] = false,
["yOffset"] = -108.6873498457477,
["gridType"] = "RD",
["stepAngle"] = 15,
["fullCircle"] = true,
["space"] = 2,
["url"] = "https://wago.io/6HHBMDHTD/3",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["names"] = {
},
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["debuffType"] = "HELPFUL",
["event"] = "Health",
["unit"] = "player",
},
["untrigger"] = {
},
},
},
["columnSpace"] = 1,
["radius"] = 300,
["frameStrata"] = 1,
["useLimit"] = false,
["align"] = "CENTER",
["growOn"] = "changed",
["arcLength"] = 30,
["internalVersion"] = 78,
["rotation"] = 345,
["borderColor"] = {
0,
0,
0,
1,
},
["version"] = 3,
["subRegions"] = {
},
["stagger"] = 0,
["gridWidth"] = 5,
["load"] = {
["use_class"] = false,
["talent"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["zoneIds"] = "",
},
["xOffset"] = 290.1000819368742,
["backdropColor"] = {
1,
1,
1,
0.5,
},
["config"] = {
},
["animate"] = false,
["customGrow"] = "-- Package group/layout\nfunction(newPositions, activeRegions)\n    local offset = 9/64 -- target_indicator_glow texture center offset\n    local distance = 18/64\n    local angle, x, y, h, w, s, c, sb, cb, da, radius\n    local curveAngle, segmentCount, direction, base\n    \n    for i, r in ipairs(activeRegions) do\n        if r.region.GetBaseRotation then\n            direction = r.data.config.direction\n            base = (r.data.config.rotationOffset + direction * 180)\n            angle = r.region:GetBaseRotation() - direction * 180\n            h = r.data.height\n            w = r.data.width\n            curveAngle = r.data.config.curveAngle\n            segmentCount = r.data.config.segmentCount\n            s = sin(angle)\n            c = cos(angle)\n            sb = sin(base + (direction - 1) * 180)\n            cb = cos(base + (direction - 1) * 180)\n            da = curveAngle / (segmentCount - 1)\n            radius = 0.5 * w * distance / sin(da / 2)\n            x = c * radius + s * w * offset * (direction - 1.5) * 2 + radius * cb\n            y = s * radius * h / w - c * h * offset * (direction - 1.5) * 2 + radius * h / w * sb\n        else\n            x = 0\n            y = 0\n        end\n        \n        if newPositions[i] then\n            newPositions[i][1] = x\n            newPositions[i][2] = y\n        else\n            newPositions[i] = {x, y}\n        end\n    end\nend\n-- Package end\n\n\n\n",
["scale"] = 0.55,
["centerType"] = "LR",
["border"] = false,
["borderEdge"] = "1 Pixel",
["regionType"] = "dynamicgroup",
["borderSize"] = 2,
["limit"] = 5,
["borderInset"] = 1,
["sort"] = "none",
["constantFactor"] = "RADIUS",
["rowSpace"] = 1,
["borderOffset"] = 4,
["semver"] = "1.0.2",
["tocversion"] = 11500,
["id"] = "nanShield Classic",
["source"] = "import",
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["anchorPoint"] = "CENTER",
["uid"] = "QYuwGRyspxh",
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["sortHybridTable"] = {
["nanShield:Text"] = false,
["nanShield:Value"] = false,
["nanShield:Bar"] = false,
["nanShield:Segment"] = false,
},
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["selfPoint"] = "CENTER",
},
["Bolt 4"] = {
["user_y"] = 0,
["wagoID"] = "br2BQB5LA",
["xOffset"] = -63.730125808716,
["preferToUpdate"] = false,
["yOffset"] = -49.507968704789,
["anchorPoint"] = "CENTER",
["desaturateBackground"] = false,
["compress"] = false,
["user_x"] = 0,
["sameTexture"] = true,
["url"] = "https://wago.io/br2BQB5LA/1",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["useStacks"] = true,
["auranames"] = {
"400574",
},
["ownOnly"] = true,
["event"] = "Health",
["subeventPrefix"] = "SPELL",
["useName"] = true,
["stacks"] = "4",
["spellIds"] = {
},
["stacksOperator"] = ">=",
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["unit"] = "player",
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["endAngle"] = 360,
["internalVersion"] = 78,
["color"] = {
0.97254908084869,
0.59215688705444,
1,
1,
},
["selfPoint"] = "CENTER",
["foregroundColor"] = {
0.88627457618713,
0.52156865596771,
1,
1,
},
["authorOptions"] = {
},
["backgroundColor"] = {
0.5,
0.5,
0.5,
0.5,
},
["desaturate"] = false,
["rotation"] = 0,
["font"] = "Friz Quadrata TT",
["version"] = 1,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 30,
["rotate"] = false,
["crop_y"] = 0.41,
["conditions"] = {
},
["useAdjustededMax"] = false,
["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
["source"] = "import",
["startAngle"] = 0,
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "Bolts Left",
["mirror"] = false,
["useAdjustededMin"] = false,
["regionType"] = "texture",
["fontSize"] = 12,
["blendMode"] = "BLEND",
["load"] = {
["use_class"] = true,
["use_spellknown"] = true,
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "MAGE",
["multi"] = {
},
},
["spellknown"] = 400574,
["size"] = {
["multi"] = {
},
},
},
["uid"] = "e(i13ie)wj2",
["slantMode"] = "INSIDE",
["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura45",
["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura2",
["frameStrata"] = 1,
["semver"] = "1.0.0",
["tocversion"] = 11500,
["id"] = "Bolt 4",
["anchorFrameType"] = "SCREEN",
["alpha"] = 0.58,
["width"] = 30,
["desaturateForeground"] = false,
["auraRotation"] = 0,
["inverse"] = false,
["config"] = {
},
["orientation"] = "VERTICAL",
["crop_x"] = 0.41,
["information"] = {
},
["backgroundOffset"] = 2,
},
["food regen"] = {
["sparkWidth"] = 10,
["iconSource"] = -1,
["authorOptions"] = {
},
["adjustedMax"] = "",
["adjustedMin"] = "",
["yOffset"] = -17.25638709523933,
["anchorPoint"] = "CENTER",
["sparkRotation"] = 0,
["sparkRotationMode"] = "AUTO",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["useName"] = true,
["auranames"] = {
"Food",
},
["event"] = "Health",
["subeventPrefix"] = "SPELL",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["type"] = "aura2",
["names"] = {
},
["unit"] = "player",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["icon_color"] = {
1,
1,
1,
1,
},
["enableGradient"] = false,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["barColor"] = {
1,
0.4627451300621033,
0.2274509966373444,
1,
},
["desaturate"] = false,
["anchorFrameType"] = "SCREEN",
["sparkOffsetY"] = 0,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["type"] = "subforeground",
},
{
["text_text_format_p_time_precision"] = 1,
["text_text"] = "Food",
["text_text_format_p_time_mod_rate"] = true,
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_p_time_legacy_floor"] = false,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["anchorYOffset"] = 0,
["text_text_format_p_time_dynamic_threshold"] = 60,
["type"] = "subtext",
["text_shadowXOffset"] = 1,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_shadowYOffset"] = -1,
["text_text_format_p_time_format"] = 0,
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "INNER_LEFT",
["text_fontType"] = "None",
["text_text_format_p_format"] = "timed",
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_text_format_n_format"] = "none",
},
{
["text_shadowXOffset"] = 1,
["text_text"] = "%p",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_text_format_n_format"] = "none",
["anchorXOffset"] = 0,
["type"] = "subtext",
["text_text_format_p_time_precision"] = 1,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_text_format_p_format"] = "timed",
["text_shadowYOffset"] = -1,
["text_visible"] = true,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "None",
["text_anchorPoint"] = "INNER_RIGHT",
["text_text_format_p_time_format"] = 0,
["text_text_format_p_time_mod_rate"] = true,
["text_fontSize"] = 12,
["text_text_format_p_time_dynamic_threshold"] = 60,
["text_text_format_p_time_legacy_floor"] = false,
},
},
["gradientOrientation"] = "HORIZONTAL",
["textureSource"] = "LSM",
["load"] = {
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["talent"] = {
["multi"] = {
},
},
},
["sparkBlendMode"] = "ADD",
["useAdjustededMax"] = false,
["xOffset"] = 0,
["barColor2"] = {
1,
1,
0,
1,
},
["backgroundColor"] = {
0,
0,
0,
0.5,
},
["selfPoint"] = "CENTER",
["parent"] = "regen Group",
["useAdjustededMin"] = false,
["regionType"] = "aurabar",
["sparkColor"] = {
1,
1,
1,
1,
},
["config"] = {
},
["icon_side"] = "RIGHT",
["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
["sparkHeight"] = 30,
["texture"] = "Blizzard",
["alpha"] = 1,
["zoom"] = 0,
["spark"] = false,
["id"] = "food regen",
["sparkHidden"] = "NEVER",
["sparkOffsetX"] = 0,
["frameStrata"] = 1,
["width"] = 200,
["height"] = 15,
["uid"] = "jKfTPrzgMcI",
["inverse"] = false,
["internalVersion"] = 78,
["orientation"] = "HORIZONTAL",
["conditions"] = {
},
["information"] = {
},
["icon"] = false,
},
["RockbiterCDText"] = {
["outline"] = "OUTLINE",
["parent"] = "Rockbiter",
["displayText_format_p_time_dynamic_threshold"] = 60,
["shadowYOffset"] = -1,
["anchorPoint"] = "CENTER",
["displayText_format_p_time_format"] = 0,
["customTextUpdate"] = "update",
["url"] = "https://wago.io/RrBFPkRTq/4",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["weapon"] = "main",
["itemName"] = 0,
["unit"] = "player",
["unevent"] = "auto",
["subeventPrefix"] = "SPELL",
["duration"] = "1",
["use_itemName"] = true,
["use_unit"] = true,
["event"] = "Weapon Enchant",
["subeventSuffix"] = "_CAST_START",
["use_weapon"] = true,
["spellIds"] = {
},
["showOn"] = "showOnActive",
["names"] = {
},
["type"] = "item",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["displayText_format_p_format"] = "timed",
["displayText_format_p_time_legacy_floor"] = true,
["animation"] = {
["start"] = {
["duration_type"] = "seconds",
["type"] = "none",
["easeStrength"] = 3,
["easeType"] = "none",
},
["main"] = {
["duration_type"] = "seconds",
["type"] = "none",
["easeStrength"] = 3,
["easeType"] = "none",
},
["finish"] = {
["duration_type"] = "seconds",
["type"] = "none",
["easeStrength"] = 3,
["easeType"] = "none",
},
},
["font"] = "Friz Quadrata TT",
["version"] = 4,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["load"] = {
["use_class"] = true,
["use_spellknown"] = false,
["zoneIds"] = "",
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "SHAMAN",
["multi"] = {
},
},
["spellknown"] = 8017,
["size"] = {
["multi"] = {
},
},
},
["fontSize"] = 12,
["source"] = "import",
["shadowXOffset"] = 1,
["selfPoint"] = "BOTTOM",
["displayText"] = "%p",
["regionType"] = "text",
["automaticWidth"] = "Auto",
["conditions"] = {
{
["check"] = {
["trigger"] = 1,
["op"] = ">",
["value"] = 1,
["variable"] = "show",
},
["changes"] = {
{
["value"] = false,
["property"] = "sub.2.text_visible",
},
},
},
},
["xOffset"] = 0,
["internalVersion"] = 78,
["displayText_format_p_time_precision"] = 1,
["uid"] = "SHsGmpBVoL2",
["wordWrap"] = "WordWrap",
["justify"] = "LEFT",
["semver"] = "1.0.3",
["tocversion"] = 11302,
["id"] = "RockbiterCDText",
["color"] = {
1,
1,
1,
1,
},
["frameStrata"] = 1,
["anchorFrameType"] = "SCREEN",
["authorOptions"] = {
},
["config"] = {
},
["yOffset"] = 0,
["displayText_format_p_time_mod_rate"] = true,
["shadowColor"] = {
0,
0,
0,
1,
},
["fixedWidth"] = 200,
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["preferToUpdate"] = false,
},
["RBW icon RH"] = {
["iconSource"] = 0,
["wagoID"] = "7-GPE9UP7",
["xOffset"] = 0,
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["url"] = "https://wago.io/7-GPE9UP7/1",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["enchant"] = "Rockbiter",
["itemName"] = 0,
["auranames"] = {
"",
},
["ownOnly"] = true,
["genericShowOn"] = "showAlways",
["unit"] = "player",
["useRem"] = true,
["use_weapon"] = true,
["use_enchant"] = true,
["names"] = {
},
["matchesShowOn"] = "showOnMissing",
["spellName"] = 425339,
["debuffType"] = "HELPFUL",
["use_remaining"] = false,
["type"] = "item",
["use_showOn"] = true,
["subeventSuffix"] = "_CAST_START",
["use_spellCount"] = false,
["event"] = "Weapon Enchant",
["use_itemName"] = true,
["useName"] = true,
["realSpellName"] = "Всплеск лавы",
["use_spellName"] = true,
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["showOn"] = "showAlways",
["use_genericShowOn"] = true,
["use_track"] = true,
["weapon"] = "main",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 1,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = false,
["glowLength"] = 4,
["glowLines"] = 12,
["glowBorder"] = false,
},
{
["text_shadowXOffset"] = 0,
["text_text"] = "RH",
["text_text_format_p_time_mod_rate"] = true,
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_p_time_legacy_floor"] = false,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_text_format_p_format"] = "timed",
["type"] = "subtext",
["text_text_format_p_time_dynamic_threshold"] = 60,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_text_format_p_time_precision"] = 1,
["text_shadowYOffset"] = 0,
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_BOTTOMLEFT",
["anchorYOffset"] = 0,
["text_visible"] = true,
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_text_format_p_time_format"] = 0,
},
{
["text_shadowXOffset"] = 0,
["text_text"] = "%p",
["text_text_format_p_time_mod_rate"] = true,
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_p_time_legacy_floor"] = false,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_text_format_p_format"] = "timed",
["type"] = "subtext",
["text_text_format_p_time_dynamic_threshold"] = 0,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_text_format_p_time_precision"] = 1,
["text_shadowYOffset"] = 0,
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_TOPRIGHT",
["anchorYOffset"] = 0,
["text_visible"] = true,
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_text_format_p_time_format"] = 0,
},
},
["height"] = 35,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
[67] = true,
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "SHAMAN",
["multi"] = {
["MAGE"] = true,
},
},
["size"] = {
["multi"] = {
},
},
},
["useCooldownModRate"] = false,
["useAdjustededMax"] = false,
["anchorFrameType"] = "SCREEN",
["source"] = "import",
["authorOptions"] = {
{
["type"] = "select",
["default"] = 1,
["values"] = {
"hide",
"desaturate",
},
["name"] = "Hide/Desaturate",
["useDesc"] = false,
["key"] = "option",
["width"] = 1,
},
},
["desc"] = "",
["cooldown"] = true,
["conditions"] = {
{
["check"] = {
["trigger"] = -2,
["variable"] = "AND",
["checks"] = {
{
["trigger"] = 1,
["variable"] = "enchanted",
["value"] = 1,
},
{
["trigger"] = -1,
["variable"] = "customcheck",
["value"] = "function()\n    if aura_env.config[\"option\"] == 1 then\n        return true\n    end\nend",
},
},
},
["changes"] = {
{
["value"] = true,
["property"] = "desaturate",
},
{
["property"] = "sub.2.glow",
},
{
["value"] = 0,
["property"] = "alpha",
},
},
},
{
["check"] = {
["trigger"] = -2,
["variable"] = "AND",
["checks"] = {
{
["trigger"] = 1,
["variable"] = "enchanted",
["value"] = 1,
},
{
["trigger"] = -1,
["variable"] = "customcheck",
["value"] = "function()\n    if aura_env.config[\"option\"] == 2 then\n    return true\nend\nend",
},
},
},
["changes"] = {
{
["value"] = true,
["property"] = "desaturate",
},
{
["property"] = "sub.2.glow",
},
{
["value"] = 1,
["property"] = "alpha",
},
},
},
{
["check"] = {
["trigger"] = 1,
["variable"] = "enchanted",
["value"] = 0,
},
["changes"] = {
{
["property"] = "desaturate",
},
{
["value"] = true,
["property"] = "sub.2.glow",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "<",
["value"] = "30",
["variable"] = "expirationTime",
},
["changes"] = {
{
["property"] = "desaturate",
},
{
["value"] = true,
["property"] = "sub.2.glow",
},
{
["value"] = 1,
["property"] = "alpha",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "<=",
["value"] = "5",
["variable"] = "expirationTime",
},
["changes"] = {
{
["value"] = {
1,
0.039215687662363,
0,
1,
},
["property"] = "sub.4.text_color",
},
},
},
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["progressSource"] = {
-1,
"",
},
["adjustedMax"] = "",
["config"] = {
["option"] = 1,
},
["parent"] = "RBW Group",
["alpha"] = 1,
["cooldownTextDisabled"] = true,
["zoom"] = 0,
["semver"] = "1.0.0",
["tocversion"] = 11500,
["id"] = "RBW icon RH",
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["frameStrata"] = 3,
["width"] = 35,
["cooldownEdge"] = false,
["uid"] = "7F1TFCn06eE",
["inverse"] = false,
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["displayIcon"] = 136086,
["information"] = {
},
["color"] = {
1,
1,
1,
0.7182275056839,
},
},
["CP 4"] = {
["wagoID"] = "dTwWQJRhb",
["authorOptions"] = {
},
["preferToUpdate"] = true,
["yOffset"] = -165,
["anchorPoint"] = "CENTER",
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["duration"] = "1",
["unit"] = "player",
["powertype"] = 4,
["use_powertype"] = true,
["debuffType"] = "HELPFUL",
["type"] = "unit",
["unevent"] = "auto",
["power_operator"] = {
">=",
},
["use_requirePowerType"] = false,
["subeventPrefix"] = "SPELL",
["names"] = {
},
["spellIds"] = {
},
["use_power"] = false,
["power"] = {
"1",
},
["event"] = "Power",
["use_unit"] = true,
["subeventSuffix"] = "_CAST_START",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 42.765598297119,
["rotate"] = true,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["textureWrapMode"] = "CLAMP",
["source"] = "import",
["mirror"] = false,
["regionType"] = "texture",
["blendMode"] = "BLEND",
["desc"] = "Rogue Combo Points - Classic WoW                                                              - created by Johadan                                                                                                                        - https://wago.io/p/Johadan#1650                                                                                         - Discord: https://discord.gg/QJs5SHH",
["color"] = {
0,
0,
0,
1,
},
["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Circle_Smooth_Border",
["parent"] = "Sno - Rogue Combo Points",
["xOffset"] = 35,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "CP 4",
["anchorFrameType"] = "SCREEN",
["alpha"] = 1,
["width"] = 42.76575088501,
["frameStrata"] = 1,
["uid"] = "bj8)zYdmcmX",
["config"] = {
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
},
["conditions"] = {
{
["check"] = {
["trigger"] = 1,
["op"] = ">=",
["variable"] = "power",
["value"] = "4",
},
["changes"] = {
{
["value"] = {
0.94509803921569,
0.019607843137255,
0,
1,
},
["property"] = "color",
},
{
["value"] = 1,
["property"] = "alpha",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["variable"] = "power",
["value"] = "5",
},
["changes"] = {
{
["value"] = {
1,
0.22352941176471,
0.72156862745098,
1,
},
["property"] = "color",
},
},
},
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["discrete_rotation"] = 0,
},
["Sunder Debuff Inactive"] = {
["iconSource"] = 0,
["wagoID"] = "A3Z0KIoeL",
["authorOptions"] = {
},
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = -219.70006103516,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["subeventSuffix"] = "_CAST_START",
["matchesShowOn"] = "showOnMissing",
["event"] = "Health",
["names"] = {
},
["useExactSpellId"] = false,
["spellIds"] = {
},
["unit"] = "target",
["subeventPrefix"] = "SPELL",
["auranames"] = {
"Sunder Armor",
},
["useName"] = true,
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = 0,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "CENTER",
["text_fontSize"] = 24,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = false,
["glowLength"] = 10,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 43,
["load"] = {
["use_ingroup"] = true,
["talent"] = {
["multi"] = {
},
},
["ingroup"] = {
["single"] = "raid",
},
["class"] = {
["single"] = "WARRIOR",
["multi"] = {
["WARRIOR"] = true,
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["anchorFrameType"] = "SCREEN",
["source"] = "import",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["adjustedMax"] = "",
["cooldownEdge"] = false,
["cooldown"] = true,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["conditions"] = {
{
["check"] = {
["trigger"] = 1,
["op"] = "<",
["value"] = 1,
["variable"] = "show",
},
["changes"] = {
{
["value"] = true,
["property"] = "desaturate",
},
},
},
},
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "Armor Debuffs",
["config"] = {
},
["frameStrata"] = 1,
["zoom"] = 0,
["cooldownTextDisabled"] = true,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Sunder Debuff Inactive",
["useCooldownModRate"] = true,
["alpha"] = 1,
["width"] = 43,
["progressSource"] = {
-1,
"",
},
["uid"] = "Yay7tgJp5mL",
["inverse"] = false,
["color"] = {
1,
1,
1,
1,
},
["displayIcon"] = "132363",
["information"] = {
},
["xOffset"] = -93.533312988281,
},
["nanShield:Text"] = {
["outline"] = "OUTLINE",
["wagoID"] = "6HHBMDHTD",
["parent"] = "nanShield Classic",
["displayText_format_p_time_dynamic_threshold"] = 0,
["shadowYOffset"] = -1,
["anchorPoint"] = "CENTER",
["displayText_format_p_time_format"] = 0,
["customTextUpdate"] = "update",
["url"] = "https://wago.io/6HHBMDHTD/3",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
["custom"] = "-- Package common/logging\naura_env.logPalette = {\n    \"ff6e7dda\",\n    \"ff21dfb9\",\n    \"ffe3f57a\",\n    \"ffed705a\",\n    \"fff8a3e6\",\n}\n\nfunction aura_env:log(...)\n    if self.config and self.config.debugEnabled then\n        local palette = self.logPalette\n        local args = {\n            self.cloneId and\n            format(\"[%s:%s]\", self.id, self.cloneId) or\n            format(\"[%s]\", self.id),\n            ...\n        }\n        for i = 1, #args do\n            args[i] = format(\n                \"|c%s%s|r\",\n                palette[1 + (i - 1) % #palette],\n                tostring(args[i]))\n        end\n        print(unpack(args))\n    end\nend\n-- Package end\n\n-- Package common/lowabsorb\nfunction aura_env:LowestAbsorb(totalAbsorb, all, physical, magic, ...)\n    self:log('LowestAbsorb', all, physical, magic, ...)\n    local minValue\n    local minIdx\n    local value\n    \n    for i = 1, select('#', ...) do\n        value = select(i, ...)\n        if value > 0 and value <= (minValue or value) then\n            minIdx = i + 3\n            minValue = value\n        end\n    end\n    \n    if minIdx then\n        minValue = minValue + magic\n    elseif magic > 0 then\n        minValue = magic\n        minIdx = 3\n    end\n    \n    if physical > 0 and physical <= (minValue or physical) then\n        minValue = physical\n        minIdx = 2\n    end\n    \n    if minIdx then\n        minValue = minValue + all\n    else\n        minValue = all\n        minIdx = 1\n    end\n    \n    self:log('LowestAbsorbResult', minValue, totalAbsorb, minIdx)\n    return minValue, totalAbsorb, minIdx\nend\n-- Package end\n\n-- Package common/schools\naura_env.schools = {\n    \"All\",\n    \"Physical\",\n    \"Magic\",\n    \"Holy\",\n    \"Fire\",\n    \"Nature\",\n    \"Frost\",\n    \"Shadow\",\n    \"Arcane\",\n}\naura_env.schoolIds = { 127, 1, 126, 2, 4, 8, 16, 32, 64 }\naura_env.schoolIdx = {}\nfor idx, id in ipairs(aura_env.schoolIds) do\n    aura_env.schoolIdx[id] = idx\nend\n-- Package end\n\n-- Package text/tsu\nfunction aura_env:on_tsu(allstates, ...)\n    -- self:log('TSU', self.config.segmentCount)\n    local now = GetTime()\n    local currentAbsorb = self.currentAbsorb or 0\n    local state = allstates[1]\n    \n    if not state then\n        state = {\n            changed = true,\n            show = false,\n            progressType = \"static\",\n            school = \"All\",\n            value = 0,\n            total = 0,\n        }\n        allstates[1] = state\n    end\n    \n    if state.show ~= (currentAbsorb > 0) then\n        state.show = currentAbsorb > 0\n        state.changed = true\n        state.value = currentAbsorb\n        state.total = self.totalAbsorb\n        state.school = self.currentSchool\n        self.timestamp = now\n    elseif state.value ~= currentAbsorb then\n        state.changed = true\n        state.value = currentAbsorb\n        state.total = self.totalAbsorb\n        state.school = self.currentSchool\n        self.timestamp = now\n    end\n    \n    return state.changed\nend\n-- Package end\n\n-- Package text/update\nfunction aura_env:on_nan_shield(event, ...)\n    self:log(event, ...)\n    local minValue, totalAbsorb, minIdx = self:LowestAbsorb(...)\n    self.currentAbsorb = ceil(minValue)\n    self.currentSchool = self.schools[minIdx]\n    self.totalAbsorb = ceil(totalAbsorb)\n    self:log('SetValues', self.currentSchool, self.currentAbsorb, self.totalAbsorb)\nend\n-- Package end\n\n\n\n",
["do_custom"] = true,
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "custom",
["subeventSuffix"] = "_CAST_START",
["event"] = "Health",
["unit"] = "player",
["customVariables"] = "{\n    school = {\n        type = \"select\",\n        display = \"Damage Type\",\n        values = {\n            [\"All\"] = \"All\",\n            [\"Physical\"] = \"Physical\",\n            [\"Magic\"] = \"Magic\",\n            [\"Holy\"] = \"Holy\",\n            [\"Fire\"] = \"Fire\",\n            [\"Nature\"] = \"Nature\",\n            [\"Frost\"] = \"Frost\",\n            [\"Shadow\"] = \"Shadow\",\n            [\"Arcane\"] = \"Arcane\"\n        }\n    }\n}",
["custom"] = "function(...)\n    local theTime = GetTime()\n    if not aura_env.last or aura_env.last < theTime - 0.05 then\n        aura_env.last = theTime\n        \n        return aura_env:on_tsu(...)\n    end\nend",
["spellIds"] = {
},
["custom_type"] = "stateupdate",
["check"] = "update",
["names"] = {
},
["subeventPrefix"] = "SPELL",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["subeventPrefix"] = "SPELL",
["type"] = "custom",
["events"] = "WA_NAN_SHIELD",
["custom_type"] = "event",
["subeventSuffix"] = "_CAST_START",
["custom"] = "function(...)\n    return aura_env:on_nan_shield(...)\nend",
["event"] = "Health",
["custom_hide"] = "custom",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = 1,
},
["displayText_format_p_time_mod_rate"] = true,
["displayText_format_p_time_legacy_floor"] = true,
["wordWrap"] = "WordWrap",
["font"] = "FORCED SQUARE",
["version"] = 3,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["load"] = {
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["zoneIds"] = "",
},
["fontSize"] = 20,
["source"] = "import",
["config"] = {
["debugEnabled"] = false,
},
["shadowXOffset"] = 1,
["displayText_format_p_format"] = "timed",
["automaticWidth"] = "Auto",
["regionType"] = "text",
["conditions"] = {
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "All",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0.94901960784314,
0.89411764705882,
0.56078431372549,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Magic",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0,
0.50196078431373,
1,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Physical",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0.9921568627451,
0.7921568627451,
0.63529411764706,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Arcane",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
1,
0.61176470588235,
1,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Fire",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
1,
0.50196078431373,
0,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Frost",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0,
1,
1,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Holy",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
1,
1,
0,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Nature",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0.50196078431373,
1,
0,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Shadow",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0.72941176470588,
0.45882352941176,
1,
1,
},
["property"] = "color",
},
},
},
},
["internalVersion"] = 78,
["yOffset"] = -80,
["anchorFrameParent"] = false,
["displayText_format_p_time_precision"] = 1,
["displayText"] = "%p",
["xOffset"] = -10,
["semver"] = "1.0.2",
["justify"] = "CENTER",
["tocversion"] = 11500,
["id"] = "nanShield:Text",
["color"] = {
1,
1,
1,
1,
},
["frameStrata"] = 1,
["anchorFrameType"] = "SCREEN",
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["uid"] = "pGdpCt6LJm)",
["authorOptions"] = {
{
["type"] = "toggle",
["default"] = false,
["key"] = "debugEnabled",
["name"] = "Enable Debug Info",
["useDesc"] = false,
["width"] = 1,
},
},
["selfPoint"] = "BOTTOM",
["shadowColor"] = {
0,
0,
0,
1,
},
["fixedWidth"] = 200,
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["preferToUpdate"] = false,
},
["Bogling Root Spawn Alert"] = {
["outline"] = "OUTLINE",
["wagoID"] = "A3Z0KIoeL",
["authorOptions"] = {
},
["displayText_format_p_time_dynamic_threshold"] = 60,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["displayText_format_p_time_format"] = 0,
["customTextUpdate"] = "event",
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
["message_type"] = "SAY",
["message"] = "Yes chef!",
["do_message"] = false,
["message_dest"] = "Darkenedlife",
},
["finish"] = {
["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\AirHorn.ogg",
["do_sound"] = true,
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["auranames"] = {
"Food & Drink",
},
["message_operator"] = "find('%s')",
["unit"] = "player",
["debuffType"] = "HELPFUL",
["useName"] = false,
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["event"] = "Chat Message",
["use_sourceName"] = true,
["message"] = "Glowing Fruit",
["type"] = "event",
["spellIds"] = {
},
["names"] = {
},
["use_message"] = true,
["sourceName"] = "Denalan",
["use_messageType"] = false,
["messageType"] = "CHAT_MSG_EMOTE",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["displayText_format_p_time_mod_rate"] = true,
["displayText_format_p_time_legacy_floor"] = false,
["selfPoint"] = "BOTTOM",
["font"] = "Friz Quadrata TT",
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["load"] = {
["talent"] = {
["multi"] = {
},
},
["use_zone"] = true,
["use_encounter"] = false,
["zone"] = "Teldrassil",
["class"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["use_combat"] = false,
["size"] = {
["multi"] = {
},
},
},
["fontSize"] = 12,
["source"] = "import",
["shadowXOffset"] = 1,
["automaticWidth"] = "Auto",
["internalVersion"] = 78,
["regionType"] = "text",
["parent"] = "General Auras",
["fixedWidth"] = 200,
["displayText_format_p_format"] = "timed",
["wordWrap"] = "WordWrap",
["displayText_format_p_time_precision"] = 1,
["config"] = {
},
["xOffset"] = 0,
["semver"] = "1.0.18",
["justify"] = "LEFT",
["tocversion"] = 11500,
["id"] = "Bogling Root Spawn Alert",
["shadowYOffset"] = -1,
["frameStrata"] = 1,
["anchorFrameType"] = "SCREEN",
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["uid"] = ")fBN2gRKzJx",
["displayText"] = "",
["color"] = {
1,
1,
1,
1,
},
["shadowColor"] = {
0,
0,
0,
1,
},
["conditions"] = {
},
["information"] = {
},
["preferToUpdate"] = false,
},
["tick 2"] = {
["sparkWidth"] = 3,
["iconSource"] = -1,
["authorOptions"] = {
},
["preferToUpdate"] = false,
["yOffset"] = -107.4389579490379,
["anchorPoint"] = "CENTER",
["sparkRotation"] = 0,
["url"] = "https://wago.io/zDdQRtUiL/1",
["icon"] = false,
["icon_color"] = {
1,
1,
1,
1,
},
["enableGradient"] = false,
["selfPoint"] = "CENTER",
["barColor"] = {
1,
0,
0,
0,
},
["desaturate"] = false,
["sparkOffsetY"] = 0,
["gradientOrientation"] = "HORIZONTAL",
["load"] = {
["use_class"] = true,
["talent"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["zoneIds"] = "",
},
["smoothProgress"] = false,
["useAdjustededMin"] = false,
["regionType"] = "aurabar",
["sparkDesaturate"] = true,
["texture"] = "Solid",
["zoom"] = 0,
["spark"] = true,
["tocversion"] = 11500,
["alpha"] = 1,
["sparkColor"] = {
0,
0,
0,
1,
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "zDdQRtUiL",
["adjustedMin"] = "",
["sparkRotationMode"] = "AUTO",
["triggers"] = {
{
["trigger"] = {
["duration"] = "2",
["names"] = {
},
["debuffType"] = "HELPFUL",
["type"] = "custom",
["custom_type"] = "stateupdate",
["subeventPrefix"] = "SPELL",
["use_unit"] = true,
["event"] = "Health",
["unevent"] = "auto",
["spellIds"] = {
},
["events"] = "UNIT_POWER_FREQUENT:player ENERGYTICK",
["custom"] = "function(a, e, t)\n    local currEnergy = UnitPower(\"player\", 3)\n    local dur = 2\n    if (e == \"UNIT_POWER_FREQUENT\" and currEnergy > (aura_env.lastEnergy or 0))\n    or (e == \"ENERGYTICK\" and t and currEnergy == UnitPowerMax(\"player\", 3))\n    then\n        if not a[\"\"]  then\n            a[\"\"] = {\n                show = true,\n                changed = true,\n                duration = dur,\n                expirationTime = GetTime() + dur,\n                progressType = \"timed\"\n            }\n        else\n            local s = a[\"\"]\n            s.changed = true\n            s.duration = dur\n            s.expirationTime = GetTime() + dur\n            s.show = true\n            C_Timer.After(2, function() WeakAuras.ScanEvents(\"ENERGYTICK\", true) end)\n        end\n    end\n    aura_env.lastEnergy = currEnergy\n    return true\nend",
["use_sourceUnit"] = true,
["check"] = "event",
["subeventSuffix"] = "_ENERGIZE",
["sourceUnit"] = "player",
["unit"] = "player",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["type"] = "unit",
["power"] = {
"100",
},
["power_operator"] = {
"<",
},
["duration"] = "1",
["event"] = "Power",
["use_unit"] = true,
["powertype"] = 3,
["subeventPrefix"] = "SPELL",
["unit"] = "player",
["subeventSuffix"] = "_CAST_START",
["use_power"] = false,
["use_powertype"] = true,
["unevent"] = "auto",
},
["untrigger"] = {
},
},
["disjunctive"] = "all",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["backdropInFront"] = false,
["stickyDuration"] = false,
["version"] = 1,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["type"] = "subforeground",
},
{
["border_offset"] = 5,
["border_anchor"] = "bar",
["type"] = "subborder",
["border_color"] = {
1,
1,
1,
0.5,
},
["border_visible"] = false,
["border_edge"] = "None",
["border_size"] = 16,
},
},
["height"] = 20.00003623962402,
["textureSource"] = "LSM",
["sparkBlendMode"] = "BLEND",
["backdropColor"] = {
1,
1,
1,
0.5,
},
["source"] = "import",
["config"] = {
},
["borderInFront"] = true,
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["icon_side"] = "RIGHT",
["actions"] = {
["start"] = {
},
["finish"] = {
["custom"] = "WeakAuras.ScanEvents(\"TICKUPDATE\", true)",
["do_custom"] = false,
},
["init"] = {
},
},
["xOffset"] = 1.1529541015625,
["sparkHeight"] = 20,
["auto"] = true,
["uid"] = "c1zfJfZhAai",
["sparkOffsetX"] = 0,
["semver"] = "1.0.0",
["useAdjustededMax"] = false,
["id"] = "tick 2",
["width"] = 130.1940307617188,
["frameStrata"] = 5,
["anchorFrameType"] = "SCREEN",
["sparkHidden"] = "NEVER",
["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
["inverse"] = true,
["backgroundColor"] = {
0,
0,
0,
0,
},
["orientation"] = "HORIZONTAL",
["conditions"] = {
},
["barColor2"] = {
1,
1,
0,
1,
},
["adjustedMax"] = "",
},
["Cooldown Reminders 2"] = {
["grow"] = "LEFT",
["controlledChildren"] = {
"Cold Blood Reminder",
"Vanish Reminder",
"Adrenaline Rush Reminder",
"Blade Flurry Reminder",
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "dTwWQJRhb",
["xOffset"] = -157.57517567682,
["preferToUpdate"] = true,
["yOffset"] = -1.6161553634213,
["gridType"] = "RD",
["borderColor"] = {
0,
0,
0,
1,
},
["space"] = 2,
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["unit"] = "player",
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["debuffType"] = "HELPFUL",
["event"] = "Health",
["names"] = {
},
},
["untrigger"] = {
},
},
},
["columnSpace"] = 1,
["radius"] = 200,
["frameStrata"] = 1,
["useLimit"] = false,
["align"] = "CENTER",
["source"] = "import",
["arcLength"] = 360,
["sortHybridTable"] = {
["Adrenaline Rush Reminder"] = false,
["Blade Flurry Reminder"] = false,
["Vanish Reminder"] = false,
["Cold Blood Reminder"] = false,
},
["rotation"] = 0,
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["version"] = 24,
["subRegions"] = {
},
["parent"] = "Rogue Auras",
["selfPoint"] = "RIGHT",
["load"] = {
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["rowSpace"] = 1,
["backdropColor"] = {
1,
1,
1,
0.5,
},
["config"] = {
},
["animate"] = true,
["stagger"] = 0,
["scale"] = 1,
["centerType"] = "LR",
["border"] = false,
["borderEdge"] = "Square Full White",
["stepAngle"] = 15,
["borderSize"] = 2,
["sort"] = "ascending",
["limit"] = 5,
["gridWidth"] = 5,
["constantFactor"] = "RADIUS",
["regionType"] = "dynamicgroup",
["borderOffset"] = 4,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Cooldown Reminders 2",
["borderInset"] = 1,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["anchorPoint"] = "CENTER",
["uid"] = "OkJGXLGDUwv",
["fullCircle"] = true,
["internalVersion"] = 78,
["conditions"] = {
},
["information"] = {
},
["authorOptions"] = {
},
},
["CP3YellowOutline GCD"] = {
["user_y"] = 0,
["user_x"] = 0,
["authorOptions"] = {
},
["preferToUpdate"] = true,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["sameTexture"] = true,
["url"] = "https://wago.io/dTwWQJRhb/24",
["backgroundColor"] = {
0.23921568627451,
0.23921568627451,
0.23921568627451,
0,
},
["selfPoint"] = "CENTER",
["desaturate"] = false,
["rotation"] = 0,
["font"] = "Friz Quadrata TT",
["crop_y"] = 0,
["textureWrapMode"] = "CLAMP",
["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura73",
["smoothProgress"] = false,
["useAdjustededMin"] = false,
["regionType"] = "progresstexture",
["blendMode"] = "BLEND",
["slantMode"] = "INSIDE",
["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura73",
["compress"] = false,
["alpha"] = 1,
["uid"] = "zZJlRgXf6FC",
["backgroundOffset"] = 0,
["wagoID"] = "dTwWQJRhb",
["parent"] = "Sno - Rogue Combo Points",
["adjustedMin"] = "",
["desaturateBackground"] = false,
["desaturateForeground"] = false,
["triggers"] = {
{
["trigger"] = {
["type"] = "spell",
["unevent"] = "auto",
["duration"] = "1",
["event"] = "Global Cooldown",
["unit"] = "player",
["subeventPrefix"] = "SPELL",
["spellIds"] = {
},
["use_inverse"] = false,
["use_unit"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["type"] = "unit",
["use_alwaystrue"] = true,
["subeventSuffix"] = "_CAST_START",
["duration"] = "1",
["event"] = "Conditions",
["use_unit"] = true,
["unevent"] = "auto",
["subeventPrefix"] = "SPELL",
["unit"] = "player",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["endAngle"] = 360,
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
},
["discrete_rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 63,
["rotate"] = true,
["useAdjustededMax"] = false,
["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
["source"] = "import",
["foregroundColor"] = {
0.84705882352941,
0.89019607843137,
0.87843137254902,
1,
},
["mirror"] = false,
["anchorFrameFrame"] = "WeakAuras:CP 3",
["color"] = {
1,
0.91764705882353,
0,
1,
},
["auraRotation"] = 0,
["crop_x"] = 0,
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["config"] = {
},
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["startAngle"] = 0,
["semver"] = "1.0.23",
["width"] = 63,
["id"] = "CP3YellowOutline GCD",
["fontSize"] = 12,
["frameStrata"] = 4,
["anchorFrameType"] = "SELECTFRAME",
["tocversion"] = 30403,
["desc"] = "Rogue Combo Points - Classic WoW                                                              - created by Johadan                                                                                                                        - https://wago.io/p/Johadan#1650                                                                                         - Discord: https://discord.gg/QJs5SHH",
["inverse"] = true,
["xOffset"] = 0,
["orientation"] = "CLOCKWISE",
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["adjustedMax"] = "",
},
["Depth Charge"] = {
["iconSource"] = -1,
["wagoID"] = "A3Z0KIoeL",
["parent"] = "SOD - BFD",
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = 100.34576416016,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
["sound_channel"] = "Master",
["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\AirHorn.ogg",
["do_sound"] = true,
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["auraspellids"] = {
"404806",
},
["event"] = "Health",
["subeventPrefix"] = "SPELL",
["spellIds"] = {
},
["unit"] = "player",
["useExactSpellId"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = 0,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = false,
["glowLength"] = 10,
["glowLines"] = 8,
["glowBorder"] = false,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = true,
["glowLength"] = 10,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 96,
["load"] = {
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["talent"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["source"] = "import",
["cooldownTextDisabled"] = false,
["config"] = {
},
["adjustedMax"] = "",
["authorOptions"] = {
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["information"] = {
},
["cooldownEdge"] = false,
["xOffset"] = -101.13610839844,
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["anchorFrameType"] = "SCREEN",
["frameStrata"] = 1,
["zoom"] = 0,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Depth Charge",
["useCooldownModRate"] = true,
["alpha"] = 1,
["width"] = 96,
["color"] = {
1,
1,
1,
1,
},
["uid"] = "1NOZI0127O0",
["inverse"] = false,
["icon"] = true,
["conditions"] = {
},
["cooldown"] = true,
["progressSource"] = {
-1,
"",
},
},
["Icon"] = {
["sparkWidth"] = 10,
["iconSource"] = -1,
["xOffset"] = 0,
["preferToUpdate"] = false,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["sparkRotation"] = 0,
["url"] = "https://wago.io/Wj2dOxJp_/1",
["icon"] = true,
["icon_color"] = {
1,
1,
1,
1,
},
["enableGradient"] = false,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["barColor"] = {
0.96078437566757,
0.98431378602982,
1,
1,
},
["desaturate"] = false,
["sparkOffsetY"] = 0,
["gradientOrientation"] = "HORIZONTAL",
["load"] = {
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["talent"] = {
["multi"] = {
},
},
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["texture"] = "Blizzard",
["zoom"] = 0,
["spark"] = false,
["tocversion"] = 11500,
["alpha"] = 1,
["config"] = {
},
["displayIcon"] = "237570",
["sparkOffsetX"] = 0,
["wagoID"] = "Wj2dOxJp_",
["parent"] = "Homonculi Tracker",
["adjustedMin"] = "",
["cooldownSwipe"] = true,
["sparkRotationMode"] = "AUTO",
["cooldownEdge"] = false,
["triggers"] = {
{
["trigger"] = {
["type"] = "custom",
["subeventSuffix"] = "_CAST_START",
["event"] = "Health",
["unit"] = "player",
["names"] = {
},
["custom"] = "function(allstates, event, ...)\n\n    -- Make Options look pretty - these settings are for the options page only.\n    if event == \"OPTIONS\" then\n        allstates[1] = {\n            show = true,\n            changed = true,\n            progressType = \"timed\",\n            duration = 120,\n            autoHide = true,\n            icon = 237561,\n            name = \"|cFFff5349- Attack\\nPower\",\n        }\n        allstates[2] = {\n            show = true,\n            changed = true,\n            progressType = \"timed\",\n            duration = 120,\n            autoHide = true,\n            icon = 132358,\n            name = \"|cFF00FF00- Armor\",\n        }\n        allstates[3] = {\n            show = true,\n            changed = true,\n            progressType = \"timed\",\n            duration = 120,\n            autoHide = true,\n            icon = 136135,\n            name = \"|cFFFFFF00- Attack\\nSpeed\",\n        }\n        \n        return true\n        \n    end\n    -- Clear states when dead\n    if event == \"PLAYER_DEAD\" then\n        \n        for _, state in pairs(allstates) do\n            state.show = false\n            state.changed = true\n        end\n        \n        return true\n        \n    end\n    \n    -- Extract extra parameters\n    local subevent = select(2, ...)\n    local sourceGUID = select(4, ...)\n    local destGUID = select(8, ...)\n    local spellid = select(12, ...)\n    \n    -- Summon homonculi\n    if subevent == \"SPELL_SUMMON\" and sourceGUID == WeakAuras.myGUID then\n        allstates[destGUID] = {\n            show = true,\n            changed = true,\n            progressType = \"timed\",\n            duration = 120,\n            autoHide = true,\n            icon = nil,\n            name = \"\",\n        }\n        return true\n    end\n    \n    -- Homonculi Demoralize Applied\n    if subevent == \"SPELL_AURA_APPLIED\" and allstates[sourceGUID] ~= nil and spellid == 402811 then\n        \n        local state = allstates[sourceGUID]\n        state.icon = select(3, GetSpellInfo(spellid))\n        state.name = \"|cFFff5349- Attack\\nPower\"\n        state.changed = true\n        \n        return true\n        \n    end\n    -- Homonculi Degrade Applied\n    if subevent == \"SPELL_AURA_APPLIED\" and allstates[sourceGUID] ~= nil and spellid == 402818 then\n        \n        local state = allstates[sourceGUID]\n        state.icon = select(3, GetSpellInfo(spellid))\n        state.name = \"|cFF00FF00- Armor\"\n        state.changed = true\n        \n        return true\n        \n    end\n    -- Homonculi Cripple Applied\n    if subevent == \"SPELL_AURA_APPLIED\" and allstates[sourceGUID] ~= nil and spellid == 402808 then\n        \n        local state = allstates[sourceGUID]\n        state.icon = select(3, GetSpellInfo(spellid))\n        state.name = \"|cFFFFFF00- Attack\\nSpeed\"\n        state.changed = true\n        \n        return true\n        \n    end\n    \n    -- Homunculi Death Event\n    if subevent == \"UNIT_DIED\" and allstates[destGUID] ~= nil then\n        \n        local state = allstates[destGUID]\n        state.show = false\n        state.changed = true\n        \n        return true\n        \n    end\nend",
["events"] = "CLEU:SPELL_SUMMON, CLEU:SPELL_AURA_APPLIED,  CLEU:UNIT_DIED, PLAYER_DEAD",
["custom_type"] = "stateupdate",
["check"] = "event",
["subeventPrefix"] = "SPELL",
["spellIds"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["version"] = 1,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 1,
["text_text"] = "%n",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_p_time_legacy_floor"] = false,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_text_format_n_format"] = "none",
["anchorXOffset"] = 0,
["text_text_format_p_time_precision"] = 1,
["type"] = "subtext",
["anchorYOffset"] = 0,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Accidental Presidency",
["text_shadowYOffset"] = -1,
["text_anchorYOffset"] = 0,
["text_fontType"] = "OUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_text_format_p_time_format"] = 0,
["text_text_format_p_time_mod_rate"] = true,
["text_fontSize"] = 15,
["text_text_format_p_time_dynamic_threshold"] = 60,
["text_text_format_p_format"] = "timed",
},
},
["height"] = 50,
["sparkBlendMode"] = "ADD",
["useAdjustededMax"] = false,
["source"] = "import",
["sparkColor"] = {
1,
1,
1,
1,
},
["barColor2"] = {
1,
1,
0,
1,
},
["color"] = {
1,
1,
1,
1,
},
["icon_side"] = "RIGHT",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["cooldownTextDisabled"] = false,
["sparkHeight"] = 30,
["backgroundColor"] = {
0,
0,
0,
0.5,
},
["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
["sparkHidden"] = "NEVER",
["semver"] = "1.0.0",
["width"] = 50,
["id"] = "Icon",
["frameStrata"] = 1,
["useCooldownModRate"] = true,
["anchorFrameType"] = "SCREEN",
["uid"] = "qem7SmdBJ0w",
["cooldown"] = true,
["inverse"] = false,
["authorOptions"] = {
},
["orientation"] = "VERTICAL_INVERSE",
["conditions"] = {
},
["information"] = {
},
["adjustedMax"] = "",
},
["Bolt"] = {
["user_y"] = 0,
["wagoID"] = "br2BQB5LA",
["xOffset"] = -62.968265597026,
["preferToUpdate"] = false,
["yOffset"] = 53.095336914063,
["anchorPoint"] = "CENTER",
["desaturateBackground"] = false,
["compress"] = false,
["user_x"] = 0,
["sameTexture"] = true,
["url"] = "https://wago.io/br2BQB5LA/1",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["useStacks"] = true,
["auranames"] = {
"400574",
},
["ownOnly"] = true,
["event"] = "Health",
["subeventPrefix"] = "SPELL",
["useName"] = true,
["stacks"] = "1",
["spellIds"] = {
},
["stacksOperator"] = ">=",
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["unit"] = "player",
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["endAngle"] = 360,
["internalVersion"] = 78,
["color"] = {
0.97254908084869,
0.59215688705444,
1,
1,
},
["selfPoint"] = "CENTER",
["foregroundColor"] = {
0.88627457618713,
0.52156865596771,
1,
1,
},
["authorOptions"] = {
},
["backgroundColor"] = {
0.5,
0.5,
0.5,
0.5,
},
["desaturate"] = false,
["rotation"] = 0,
["font"] = "Friz Quadrata TT",
["version"] = 1,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 30,
["rotate"] = false,
["crop_y"] = 0.41,
["conditions"] = {
},
["useAdjustededMax"] = false,
["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
["source"] = "import",
["startAngle"] = 0,
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "Bolts Left",
["mirror"] = false,
["useAdjustededMin"] = false,
["regionType"] = "texture",
["fontSize"] = 12,
["blendMode"] = "BLEND",
["load"] = {
["use_class"] = true,
["use_spellknown"] = true,
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "MAGE",
["multi"] = {
},
},
["spellknown"] = 400574,
["size"] = {
["multi"] = {
},
},
},
["uid"] = "y6k345VhkH7",
["slantMode"] = "INSIDE",
["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura45",
["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura2",
["frameStrata"] = 1,
["semver"] = "1.0.0",
["tocversion"] = 11500,
["id"] = "Bolt",
["anchorFrameType"] = "SCREEN",
["alpha"] = 0.58,
["width"] = 30,
["desaturateForeground"] = false,
["auraRotation"] = 0,
["inverse"] = false,
["config"] = {
},
["orientation"] = "VERTICAL",
["crop_x"] = 0.41,
["information"] = {
},
["backgroundOffset"] = 2,
},
["Berserking 2 2"] = {
["iconSource"] = -1,
["wagoID"] = "dTwWQJRhb",
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["url"] = "https://wago.io/dTwWQJRhb/24",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["auranames"] = {
"26297",
},
["event"] = "Health",
["unit"] = "player",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["useName"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = true,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["border_size"] = 1,
["border_offset"] = 0,
["text_color"] = {
},
["border_color"] = {
0,
0,
0,
1,
},
["border_visible"] = true,
["border_edge"] = "Blizzard Chat Bubble",
["type"] = "subborder",
},
{
["text_text_format_p_time_format"] = 0,
["text_text"] = "%p",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["text_text_format_p_time_dynamic_threshold"] = 3,
["text_text_format_p_time_mod_rate"] = true,
["type"] = "subtext",
["text_text_format_p_format"] = "timed",
["text_color"] = {
1,
1,
1,
1,
},
["border_color"] = {
},
["text_font"] = "Gilroy Bold",
["text_shadowYOffset"] = 0,
["text_fontType"] = "OUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_anchorYOffset"] = 0,
["text_text_format_p_time_precision"] = 1,
["text_fontSize"] = 18,
["anchorXOffset"] = 0,
["text_text_format_p_time_legacy_floor"] = true,
},
},
["height"] = 30,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["width"] = 30,
["source"] = "import",
["adjustedMax"] = "",
["progressSource"] = {
-1,
"",
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["cooldownEdge"] = false,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "Simonize Rogue Non-Essential buffs",
["config"] = {
},
["cooldownTextDisabled"] = true,
["anchorFrameParent"] = false,
["useCooldownModRate"] = true,
["auto"] = true,
["zoom"] = 0,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Berserking 2 2",
["frameStrata"] = 1,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["uid"] = "E2ht0OUoc7x",
["inverse"] = false,
["xOffset"] = 0,
["conditions"] = {
},
["cooldown"] = false,
["authorOptions"] = {
},
},
["Blood Fury Reminder"] = {
["iconSource"] = -1,
["wagoID"] = "A3Z0KIoeL",
["parent"] = "General Auras",
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = -175.22213745117,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["auranames"] = {
"Battle Shout",
},
["matchesShowOn"] = "showOnMissing",
["genericShowOn"] = "showOnCooldown",
["unit"] = "player",
["debuffType"] = "HELPFUL",
["useName"] = true,
["useExactSpellId"] = false,
["names"] = {
},
["event"] = "Action Usable",
["subeventPrefix"] = "SPELL",
["realSpellName"] = "Blood Fury",
["use_spellName"] = true,
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["type"] = "spell",
["use_genericShowOn"] = true,
["use_track"] = true,
["spellName"] = 20572,
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = 0,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "ACShine",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = true,
["glowLength"] = 10,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 43,
["load"] = {
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "WARRIOR",
["multi"] = {
["WARRIOR"] = true,
},
},
["talent"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["source"] = "import",
["cooldownTextDisabled"] = false,
["config"] = {
},
["adjustedMax"] = "",
["authorOptions"] = {
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["information"] = {
},
["cooldownEdge"] = false,
["xOffset"] = -256.22235107422,
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["anchorFrameType"] = "SCREEN",
["frameStrata"] = 1,
["zoom"] = 0,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Blood Fury Reminder",
["useCooldownModRate"] = true,
["alpha"] = 1,
["width"] = 43,
["color"] = {
1,
1,
1,
1,
},
["uid"] = "5k8kr6LeC96",
["inverse"] = false,
["icon"] = true,
["conditions"] = {
},
["cooldown"] = true,
["progressSource"] = {
-1,
"",
},
},
["SimonizeBars"] = {
["grow"] = "RIGHT",
["controlledChildren"] = {
"Slice and Dice",
"Blade Dance",
"Expose",
"Rupture track",
"Saber Slash",
"Deadly Poison",
"Envenom",
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "dTwWQJRhb",
["xOffset"] = -53.913047892652,
["preferToUpdate"] = true,
["yOffset"] = -49.585777061329,
["gridType"] = "RD",
["borderColor"] = {
0,
0,
0,
1,
},
["space"] = 2,
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["unit"] = "player",
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["debuffType"] = "HELPFUL",
["event"] = "Health",
["names"] = {
},
},
["untrigger"] = {
},
},
},
["columnSpace"] = 1,
["radius"] = 200,
["frameStrata"] = 1,
["useLimit"] = false,
["align"] = "LEFT",
["source"] = "import",
["arcLength"] = 360,
["sortHybridTable"] = {
["Slice and Dice"] = false,
["Blade Dance"] = false,
["Deadly Poison"] = false,
["Envenom"] = false,
["Expose"] = false,
["Saber Slash"] = false,
["Rupture track"] = false,
},
["rotation"] = 0,
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["version"] = 24,
["subRegions"] = {
},
["parent"] = "Rogue Auras",
["selfPoint"] = "TOPLEFT",
["load"] = {
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["rowSpace"] = 1,
["backdropColor"] = {
1,
1,
1,
0.5,
},
["config"] = {
},
["animate"] = false,
["stagger"] = 0,
["scale"] = 1.5,
["centerType"] = "LR",
["border"] = false,
["borderEdge"] = "Square Full White",
["stepAngle"] = 15,
["borderSize"] = 2,
["sort"] = "ascending",
["limit"] = 5,
["gridWidth"] = 5,
["constantFactor"] = "RADIUS",
["regionType"] = "dynamicgroup",
["borderOffset"] = 4,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "SimonizeBars",
["borderInset"] = 1,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["anchorPoint"] = "CENTER",
["uid"] = "DWcgb18drbU",
["fullCircle"] = true,
["internalVersion"] = 78,
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
},
["authorOptions"] = {
},
},
["Adrenaline Rush"] = {
["iconSource"] = -1,
["wagoID"] = "dTwWQJRhb",
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["url"] = "https://wago.io/dTwWQJRhb/24",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["auranames"] = {
"13750",
},
["event"] = "Health",
["unit"] = "player",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["useName"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = true,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["border_size"] = 1,
["border_offset"] = 0,
["text_color"] = {
},
["border_color"] = {
0,
0,
0,
1,
},
["border_visible"] = true,
["border_edge"] = "Blizzard Chat Bubble",
["type"] = "subborder",
},
{
["text_text_format_p_time_format"] = 0,
["text_text"] = "%p",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["text_text_format_p_time_dynamic_threshold"] = 3,
["text_text_format_p_time_mod_rate"] = true,
["type"] = "subtext",
["text_text_format_p_format"] = "timed",
["text_color"] = {
1,
1,
1,
1,
},
["border_color"] = {
},
["text_font"] = "Gilroy Bold",
["text_shadowYOffset"] = 0,
["text_fontType"] = "OUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_anchorYOffset"] = 0,
["text_text_format_p_time_precision"] = 1,
["text_fontSize"] = 18,
["anchorXOffset"] = 0,
["text_text_format_p_time_legacy_floor"] = true,
},
},
["height"] = 30,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["width"] = 30,
["source"] = "import",
["adjustedMax"] = "",
["progressSource"] = {
-1,
"",
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["cooldownEdge"] = false,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "Simonize Rogue Non-Essential buffs",
["config"] = {
},
["cooldownTextDisabled"] = true,
["anchorFrameParent"] = false,
["useCooldownModRate"] = true,
["auto"] = true,
["zoom"] = 0,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Adrenaline Rush",
["frameStrata"] = 1,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["uid"] = "Q0crz6Tszmf",
["inverse"] = false,
["xOffset"] = 0,
["conditions"] = {
},
["cooldown"] = false,
["authorOptions"] = {
},
},
["Dankmantle proc"] = {
["wagoID"] = "dTwWQJRhb",
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = true,
["yOffset"] = 14.415310165269,
["anchorPoint"] = "CENTER",
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["spellId"] = {
"27788",
},
["duration"] = "0.5",
["subeventPrefix"] = "SPELL",
["use_cloneId"] = true,
["debuffType"] = "HELPFUL",
["type"] = "combatlog",
["use_extraAmount"] = false,
["names"] = {
},
["event"] = "Combat Log",
["spellName"] = {
"Power of the Sun King",
},
["use_spellName"] = false,
["use_spellId"] = true,
["spellIds"] = {
},
["use_sourceUnit"] = true,
["use_powerType"] = false,
["subeventSuffix"] = "_ENERGIZE",
["sourceUnit"] = "player",
["unit"] = "player",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["animation"] = {
["start"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "shrink",
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "slideleft",
["duration_type"] = "seconds",
},
},
["desaturate"] = false,
["discrete_rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 300,
["rotate"] = true,
["load"] = {
["use_class"] = true,
["talent"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
["source"] = "import",
["mirror"] = false,
["regionType"] = "texture",
["blendMode"] = "BLEND",
["frameStrata"] = 1,
["texture"] = "Interface\\Icons\\dankmantleproc512.tga",
["authorOptions"] = {
},
["xOffset"] = -406.00877815979,
["semver"] = "1.0.23",
["tocversion"] = 11500,
["id"] = "Dankmantle proc",
["rotation"] = 0,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["parent"] = "Simonize Meme Auras",
["uid"] = "5PZaIK9YBCg",
["width"] = 300,
["config"] = {
},
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
},
["selfPoint"] = "CENTER",
},
["CP5YellowOutline GCD"] = {
["user_y"] = 0,
["user_x"] = 0,
["authorOptions"] = {
},
["preferToUpdate"] = true,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["sameTexture"] = true,
["url"] = "https://wago.io/dTwWQJRhb/24",
["backgroundColor"] = {
0.23921568627451,
0.23921568627451,
0.23921568627451,
0,
},
["selfPoint"] = "CENTER",
["desaturate"] = false,
["rotation"] = 0,
["font"] = "Friz Quadrata TT",
["crop_y"] = 0,
["textureWrapMode"] = "CLAMP",
["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura73",
["smoothProgress"] = false,
["useAdjustededMin"] = false,
["regionType"] = "progresstexture",
["blendMode"] = "BLEND",
["slantMode"] = "INSIDE",
["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura73",
["compress"] = false,
["alpha"] = 1,
["uid"] = "oijEvRxH6NM",
["backgroundOffset"] = 0,
["wagoID"] = "dTwWQJRhb",
["parent"] = "Sno - Rogue Combo Points",
["adjustedMin"] = "",
["desaturateBackground"] = false,
["desaturateForeground"] = false,
["triggers"] = {
{
["trigger"] = {
["type"] = "spell",
["unevent"] = "auto",
["duration"] = "1",
["event"] = "Global Cooldown",
["unit"] = "player",
["subeventPrefix"] = "SPELL",
["spellIds"] = {
},
["use_inverse"] = false,
["use_unit"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["type"] = "unit",
["use_alwaystrue"] = true,
["subeventSuffix"] = "_CAST_START",
["duration"] = "1",
["event"] = "Conditions",
["use_unit"] = true,
["unevent"] = "auto",
["subeventPrefix"] = "SPELL",
["unit"] = "player",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["endAngle"] = 360,
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
},
["discrete_rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 63,
["rotate"] = true,
["useAdjustededMax"] = false,
["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
["source"] = "import",
["foregroundColor"] = {
0.84705882352941,
0.89019607843137,
0.87843137254902,
1,
},
["mirror"] = false,
["anchorFrameFrame"] = "WeakAuras:CP 5",
["color"] = {
1,
0.91764705882353,
0,
1,
},
["auraRotation"] = 0,
["crop_x"] = 0,
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["config"] = {
},
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["startAngle"] = 0,
["semver"] = "1.0.23",
["width"] = 63,
["id"] = "CP5YellowOutline GCD",
["fontSize"] = 12,
["frameStrata"] = 4,
["anchorFrameType"] = "SELECTFRAME",
["tocversion"] = 30403,
["desc"] = "Rogue Combo Points - Classic WoW                                                              - created by Johadan                                                                                                                        - https://wago.io/p/Johadan#1650                                                                                         - Discord: https://discord.gg/QJs5SHH",
["inverse"] = true,
["xOffset"] = 0,
["orientation"] = "CLOCKWISE",
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["adjustedMax"] = "",
},
["Timer"] = {
["user_y"] = 0,
["desaturateForeground"] = false,
["wagoID"] = "br2BQB5LA",
["authorOptions"] = {
},
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = 0,
["foregroundColor"] = {
0.88627457618713,
0.52156865596771,
1,
1,
},
["desaturateBackground"] = false,
["sameTexture"] = true,
["url"] = "https://wago.io/br2BQB5LA/1",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["auranames"] = {
"400574",
},
["ownOnly"] = true,
["event"] = "Health",
["names"] = {
},
["spellIds"] = {
},
["unit"] = "player",
["useName"] = true,
["subeventPrefix"] = "SPELL",
["subeventSuffix"] = "_CAST_START",
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["endAngle"] = 360,
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["backgroundColor"] = {
0.5,
0.5,
0.5,
0.5,
},
["adjustedMax"] = "",
["conditions"] = {
},
["user_x"] = 0,
["rotation"] = 0,
["font"] = "Friz Quadrata TT",
["version"] = 1,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 200,
["parent"] = "Arcane Blast",
["load"] = {
["use_class"] = true,
["use_spellknown"] = true,
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "MAGE",
["multi"] = {
},
},
["spellknown"] = 400574,
["size"] = {
["multi"] = {
},
},
},
["crop_y"] = 0.41,
["useAdjustededMax"] = false,
["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
["source"] = "import",
["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura2",
["uid"] = "c4g0Cf8uOPs",
["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
["mirror"] = false,
["useAdjustededMin"] = false,
["regionType"] = "progresstexture",
["width"] = 200,
["blendMode"] = "BLEND",
["frameStrata"] = 3,
["startAngle"] = 0,
["slantMode"] = "INSIDE",
["compress"] = false,
["selfPoint"] = "CENTER",
["anchorPoint"] = "CENTER",
["semver"] = "1.0.0",
["tocversion"] = 11500,
["id"] = "Timer",
["config"] = {
},
["alpha"] = 0.56,
["anchorFrameType"] = "SCREEN",
["fontSize"] = 12,
["auraRotation"] = 0,
["inverse"] = false,
["xOffset"] = 0,
["orientation"] = "VERTICAL",
["crop_x"] = 0.41,
["information"] = {
},
["backgroundOffset"] = 2,
},
["CP4YellowOutline GCD"] = {
["user_y"] = 0,
["user_x"] = 0,
["authorOptions"] = {
},
["preferToUpdate"] = true,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["sameTexture"] = true,
["url"] = "https://wago.io/dTwWQJRhb/24",
["backgroundColor"] = {
0.23921568627451,
0.23921568627451,
0.23921568627451,
0,
},
["selfPoint"] = "CENTER",
["desaturate"] = false,
["rotation"] = 0,
["font"] = "Friz Quadrata TT",
["crop_y"] = 0,
["textureWrapMode"] = "CLAMP",
["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura73",
["smoothProgress"] = false,
["useAdjustededMin"] = false,
["regionType"] = "progresstexture",
["blendMode"] = "BLEND",
["slantMode"] = "INSIDE",
["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura73",
["compress"] = false,
["alpha"] = 1,
["uid"] = "l2be3AG2Lp1",
["backgroundOffset"] = 0,
["wagoID"] = "dTwWQJRhb",
["parent"] = "Sno - Rogue Combo Points",
["adjustedMin"] = "",
["desaturateBackground"] = false,
["desaturateForeground"] = false,
["triggers"] = {
{
["trigger"] = {
["type"] = "spell",
["unevent"] = "auto",
["duration"] = "1",
["event"] = "Global Cooldown",
["unit"] = "player",
["subeventPrefix"] = "SPELL",
["spellIds"] = {
},
["use_inverse"] = false,
["use_unit"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["type"] = "unit",
["use_alwaystrue"] = true,
["subeventSuffix"] = "_CAST_START",
["duration"] = "1",
["event"] = "Conditions",
["use_unit"] = true,
["unevent"] = "auto",
["subeventPrefix"] = "SPELL",
["unit"] = "player",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["endAngle"] = 360,
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
},
["discrete_rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 63,
["rotate"] = true,
["useAdjustededMax"] = false,
["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
["source"] = "import",
["foregroundColor"] = {
0.84705882352941,
0.89019607843137,
0.87843137254902,
1,
},
["mirror"] = false,
["anchorFrameFrame"] = "WeakAuras:CP 4",
["color"] = {
1,
0.91764705882353,
0,
1,
},
["auraRotation"] = 0,
["crop_x"] = 0,
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["config"] = {
},
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["startAngle"] = 0,
["semver"] = "1.0.23",
["width"] = 63,
["id"] = "CP4YellowOutline GCD",
["fontSize"] = 12,
["frameStrata"] = 4,
["anchorFrameType"] = "SELECTFRAME",
["tocversion"] = 30403,
["desc"] = "Rogue Combo Points - Classic WoW                                                              - created by Johadan                                                                                                                        - https://wago.io/p/Johadan#1650                                                                                         - Discord: https://discord.gg/QJs5SHH",
["inverse"] = true,
["xOffset"] = 0,
["orientation"] = "CLOCKWISE",
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["adjustedMax"] = "",
},
["Mainhand"] = {
["iconSource"] = 1,
["wagoID"] = "A3Z0KIoeL",
["parent"] = "General Auras",
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = -360,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["itemName"] = 0,
["itemTypeName"] = {
["multi"] = {
[527] = true,
},
},
["use_genericShowOn"] = true,
["genericShowOn"] = "showAlways",
["unit"] = "player",
["itemSlot"] = 16,
["remaining"] = "0",
["debuffType"] = "HELPFUL",
["use_unit"] = true,
["type"] = "item",
["use_itemTypeName"] = false,
["subeventSuffix"] = "_CAST_START",
["use_remaining"] = false,
["use_equipped"] = true,
["event"] = "Cooldown Progress (Equipment Slot)",
["use_itemName"] = true,
["use_itemSlot"] = true,
["use_itemSetId"] = true,
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["remaining_operator"] = ">=",
["matchesShowOn"] = "showAlways",
["names"] = {
},
["use_inverse"] = false,
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = false,
["glowLength"] = 10,
["glowLines"] = 8,
["glowBorder"] = false,
},
{
["border_size"] = 8,
["type"] = "subborder",
["border_color"] = {
1,
1,
1,
1,
},
["border_visible"] = true,
["border_edge"] = "Gladdy Tooltip round",
["border_offset"] = 0,
},
},
["height"] = 48,
["load"] = {
["use_never"] = true,
["talent"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["source"] = "import",
["cooldownTextDisabled"] = false,
["config"] = {
},
["adjustedMax"] = "",
["authorOptions"] = {
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["information"] = {
},
["cooldownEdge"] = false,
["xOffset"] = -31,
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["anchorFrameType"] = "SCREEN",
["frameStrata"] = 1,
["zoom"] = 0,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Mainhand",
["useCooldownModRate"] = true,
["alpha"] = 1,
["width"] = 48,
["color"] = {
1,
1,
1,
1,
},
["uid"] = "PaZHUA9K8vY",
["inverse"] = false,
["icon"] = true,
["conditions"] = {
},
["cooldown"] = false,
["progressSource"] = {
-1,
"",
},
},
["Blade Flurry Reminder"] = {
["iconSource"] = 1,
["wagoID"] = "dTwWQJRhb",
["authorOptions"] = {
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
["do_glow"] = false,
["glow_action"] = "hide",
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["track"] = "auto",
["duration"] = "3",
["genericShowOn"] = "showOnCooldown",
["names"] = {
},
["remaining"] = ".5",
["debuffType"] = "HELPFUL",
["type"] = "spell",
["use_debuffClass"] = true,
["subeventSuffix"] = "_CAST_START",
["remaining_operator"] = "<=",
["use_remaining"] = true,
["event"] = "Cooldown Ready (Spell)",
["use_exact_spellName"] = true,
["realSpellName"] = 13877,
["use_spellName"] = true,
["spellIds"] = {
},
["use_genericShowOn"] = true,
["spellName"] = 13877,
["subeventPrefix"] = "SPELL",
["use_track"] = true,
["unit"] = "player",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = 0,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowLength"] = 10,
["glow"] = false,
["glowScale"] = 1,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 64,
["load"] = {
["use_class"] = true,
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["source"] = "import",
["cooldownTextDisabled"] = false,
["uid"] = "JiVNhjF7EOx",
["adjustedMax"] = "",
["xOffset"] = 0,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["information"] = {
},
["color"] = {
1,
1,
1,
1,
},
["parent"] = "Cooldown Reminders 2",
["cooldownEdge"] = false,
["anchorFrameType"] = "SCREEN",
["useCooldownModRate"] = true,
["zoom"] = 0,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Blade Flurry Reminder",
["alpha"] = 0.5,
["frameStrata"] = 1,
["width"] = 64,
["icon"] = true,
["config"] = {
},
["inverse"] = false,
["animation"] = {
["start"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "shrink",
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "shrink",
["duration_type"] = "seconds",
},
},
["conditions"] = {
},
["cooldown"] = true,
["progressSource"] = {
-1,
"",
},
},
["Bolt 3"] = {
["user_y"] = 0,
["wagoID"] = "br2BQB5LA",
["xOffset"] = -78.968143526713,
["preferToUpdate"] = false,
["yOffset"] = -14.968295853226,
["anchorPoint"] = "CENTER",
["desaturateBackground"] = false,
["compress"] = false,
["user_x"] = 0,
["sameTexture"] = true,
["url"] = "https://wago.io/br2BQB5LA/1",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["useStacks"] = true,
["auranames"] = {
"400574",
},
["ownOnly"] = true,
["event"] = "Health",
["subeventPrefix"] = "SPELL",
["useName"] = true,
["stacks"] = "3",
["spellIds"] = {
},
["stacksOperator"] = ">=",
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["unit"] = "player",
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["endAngle"] = 360,
["internalVersion"] = 78,
["color"] = {
0.97254908084869,
0.59215688705444,
1,
1,
},
["selfPoint"] = "CENTER",
["foregroundColor"] = {
0.88627457618713,
0.52156865596771,
1,
1,
},
["authorOptions"] = {
},
["backgroundColor"] = {
0.5,
0.5,
0.5,
0.5,
},
["desaturate"] = false,
["rotation"] = 0,
["font"] = "Friz Quadrata TT",
["version"] = 1,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 30,
["rotate"] = false,
["crop_y"] = 0.41,
["conditions"] = {
},
["useAdjustededMax"] = false,
["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
["source"] = "import",
["startAngle"] = 0,
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "Bolts Left",
["mirror"] = false,
["useAdjustededMin"] = false,
["regionType"] = "texture",
["fontSize"] = 12,
["blendMode"] = "BLEND",
["load"] = {
["use_class"] = true,
["use_spellknown"] = true,
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "MAGE",
["multi"] = {
},
},
["spellknown"] = 400574,
["size"] = {
["multi"] = {
},
},
},
["uid"] = "ClM6DI4uMGF",
["slantMode"] = "INSIDE",
["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura45",
["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura2",
["frameStrata"] = 1,
["semver"] = "1.0.0",
["tocversion"] = 11500,
["id"] = "Bolt 3",
["anchorFrameType"] = "SCREEN",
["alpha"] = 0.58,
["width"] = 30,
["desaturateForeground"] = false,
["auraRotation"] = 0,
["inverse"] = false,
["config"] = {
},
["orientation"] = "VERTICAL",
["crop_x"] = 0.41,
["information"] = {
},
["backgroundOffset"] = 2,
},
["CP4BlackOutline"] = {
["wagoID"] = "dTwWQJRhb",
["parent"] = "Sno - Rogue Combo Points",
["preferToUpdate"] = true,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "unit",
["unevent"] = "auto",
["duration"] = "1",
["event"] = "Conditions",
["unit"] = "player",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["use_unit"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["discrete_rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 75,
["rotate"] = true,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["textureWrapMode"] = "CLAMP",
["source"] = "import",
["mirror"] = false,
["anchorFrameFrame"] = "WeakAuras:CP 4",
["regionType"] = "texture",
["blendMode"] = "BLEND",
["color"] = {
0,
0,
0,
1,
},
["xOffset"] = 0,
["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura73",
["authorOptions"] = {
},
["desc"] = "Rogue Combo Points - Classic WoW                                                              - created by Johadan                                                                                                                        - https://wago.io/p/Johadan#1650                                                                                         - Discord: https://discord.gg/QJs5SHH",
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "CP4BlackOutline",
["frameStrata"] = 3,
["alpha"] = 1,
["width"] = 75,
["anchorFrameType"] = "SELECTFRAME",
["uid"] = "v7(ANH59PYq",
["config"] = {
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
},
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["rotation"] = 0,
},
["CP3BlackOutline"] = {
["wagoID"] = "dTwWQJRhb",
["parent"] = "Sno - Rogue Combo Points",
["preferToUpdate"] = true,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "unit",
["unevent"] = "auto",
["duration"] = "1",
["event"] = "Conditions",
["unit"] = "player",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["use_unit"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["discrete_rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 75,
["rotate"] = true,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["textureWrapMode"] = "CLAMP",
["source"] = "import",
["mirror"] = false,
["anchorFrameFrame"] = "WeakAuras:CP 3",
["regionType"] = "texture",
["blendMode"] = "BLEND",
["color"] = {
0,
0,
0,
1,
},
["xOffset"] = 0,
["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura73",
["authorOptions"] = {
},
["desc"] = "Rogue Combo Points - Classic WoW                                                              - created by Johadan                                                                                                                        - https://wago.io/p/Johadan#1650                                                                                         - Discord: https://discord.gg/QJs5SHH",
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "CP3BlackOutline",
["frameStrata"] = 3,
["alpha"] = 1,
["width"] = 75,
["anchorFrameType"] = "SELECTFRAME",
["uid"] = "HUSb)8FnToQ",
["config"] = {
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
},
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["rotation"] = 0,
},
["Deadly Poison"] = {
["iconSource"] = -1,
["wagoID"] = "dTwWQJRhb",
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["cooldownEdge"] = false,
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["useStacks"] = false,
["auranames"] = {
"Deadly Poison",
"Deadly Poison II",
},
["ownOnly"] = true,
["event"] = "Health",
["unit"] = "target",
["spellIds"] = {
},
["names"] = {
},
["useName"] = true,
["subeventPrefix"] = "SPELL",
["subeventSuffix"] = "_CAST_START",
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = true,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_text_format_p_time_precision"] = 1,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_text_format_p_time_mod_rate"] = true,
["text_selfPoint"] = "BOTTOMRIGHT",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_p_time_legacy_floor"] = true,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["anchorXOffset"] = 0,
["text_shadowColor"] = {
0,
0,
0,
1,
},
["type"] = "subtext",
["text_text_format_p_format"] = "timed",
["text_color"] = {
1,
1,
1,
1,
},
["border_color"] = {
},
["text_font"] = "Gilroy Bold",
["text_anchorYOffset"] = 0,
["text_fontType"] = "THICKOUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_shadowYOffset"] = 0,
["text_text_format_p_time_format"] = 0,
["text_fontSize"] = 14,
["text_text_format_p_time_dynamic_threshold"] = 10,
["anchorYOffset"] = 0,
},
},
["height"] = 32,
["load"] = {
["ingroup"] = {
},
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["use_encounterid"] = false,
["use_class"] = true,
["size"] = {
["multi"] = {
["flexible"] = true,
["scenario"] = true,
["twenty"] = true,
["ten"] = true,
["twentyfive"] = true,
["fortyman"] = true,
["party"] = true,
},
},
["spec"] = {
["multi"] = {
},
},
["zoneIds"] = "",
},
["useAdjustededMax"] = false,
["anchorFrameType"] = "SCREEN",
["source"] = "import",
["useCooldownModRate"] = true,
["progressSource"] = {
-1,
"",
},
["adjustedMax"] = "",
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["colorR"] = 1,
["duration"] = "30",
["alphaType"] = "alphaPulse",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0.26,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "alphaPulse",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "relative",
},
["finish"] = {
["colorR"] = 1,
["scalex"] = 1,
["alphaType"] = "alphaPulse",
["colorB"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["colorA"] = 1,
["duration"] = "8",
["easeStrength"] = 3,
["rotate"] = 0,
["duration_type"] = "seconds",
},
},
["icon"] = true,
["authorOptions"] = {
},
["uid"] = "RoFxpZTXkzx",
["frameStrata"] = 1,
["zoom"] = 0,
["cooldownTextDisabled"] = true,
["semver"] = "1.0.23",
["tocversion"] = 11500,
["id"] = "Deadly Poison",
["auto"] = true,
["alpha"] = 1,
["width"] = 32,
["xOffset"] = 0,
["config"] = {
},
["inverse"] = false,
["parent"] = "SimonizeBars",
["conditions"] = {
},
["cooldown"] = true,
["url"] = "https://wago.io/dTwWQJRhb/24",
},
["Saber Slash"] = {
["iconSource"] = -1,
["wagoID"] = "dTwWQJRhb",
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["cooldownEdge"] = false,
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["useStacks"] = false,
["auranames"] = {
"424785",
},
["ownOnly"] = true,
["event"] = "Health",
["unit"] = "target",
["spellIds"] = {
},
["names"] = {
},
["useName"] = true,
["subeventPrefix"] = "SPELL",
["subeventSuffix"] = "_CAST_START",
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = true,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_text_format_p_time_precision"] = 1,
["text_text_format_s_format"] = "none",
["text_text"] = "%p",
["text_text_format_p_time_mod_rate"] = true,
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_p_time_legacy_floor"] = true,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["anchorXOffset"] = 0,
["text_shadowColor"] = {
0,
0,
0,
1,
},
["type"] = "subtext",
["text_text_format_p_format"] = "timed",
["text_color"] = {
1,
1,
1,
1,
},
["border_color"] = {
},
["text_font"] = "Gilroy Bold",
["text_anchorYOffset"] = 0,
["text_fontType"] = "THICKOUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_shadowYOffset"] = 0,
["text_text_format_p_time_format"] = 0,
["text_fontSize"] = 18,
["text_text_format_p_time_dynamic_threshold"] = 10,
["anchorYOffset"] = 0,
},
},
["height"] = 32,
["load"] = {
["ingroup"] = {
},
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["use_encounterid"] = false,
["use_class"] = true,
["size"] = {
["multi"] = {
["flexible"] = true,
["scenario"] = true,
["twenty"] = true,
["ten"] = true,
["twentyfive"] = true,
["fortyman"] = true,
["party"] = true,
},
},
["spec"] = {
["multi"] = {
},
},
["zoneIds"] = "",
},
["useAdjustededMax"] = false,
["anchorFrameType"] = "SCREEN",
["source"] = "import",
["useCooldownModRate"] = true,
["progressSource"] = {
-1,
"",
},
["adjustedMax"] = "",
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["colorR"] = 1,
["duration"] = "30",
["alphaType"] = "alphaPulse",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0.26,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "alphaPulse",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "relative",
},
["finish"] = {
["colorR"] = 1,
["scalex"] = 1,
["alphaType"] = "alphaPulse",
["colorB"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["colorA"] = 1,
["duration"] = "8",
["easeStrength"] = 3,
["rotate"] = 0,
["duration_type"] = "seconds",
},
},
["icon"] = true,
["authorOptions"] = {
},
["uid"] = "882vNTGC3eQ",
["frameStrata"] = 1,
["zoom"] = 0,
["cooldownTextDisabled"] = true,
["semver"] = "1.0.23",
["tocversion"] = 11500,
["id"] = "Saber Slash",
["auto"] = true,
["alpha"] = 1,
["width"] = 32,
["xOffset"] = 0,
["config"] = {
},
["inverse"] = false,
["parent"] = "SimonizeBars",
["conditions"] = {
},
["cooldown"] = false,
["url"] = "https://wago.io/dTwWQJRhb/24",
},
["Armor Debuffs"] = {
["controlledChildren"] = {
"Sunder Debuff Inactive",
"Sunder Debuff",
"Sunder Debuff NonWarrior",
"Expose Debuff",
"Homunculus",
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "A3Z0KIoeL",
["xOffset"] = -20,
["preferToUpdate"] = false,
["yOffset"] = 2,
["anchorPoint"] = "CENTER",
["borderColor"] = {
0,
0,
0,
1,
},
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["unit"] = "player",
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["names"] = {
},
["event"] = "Health",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
},
["internalVersion"] = 78,
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["version"] = 19,
["subRegions"] = {
},
["load"] = {
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["talent"] = {
["multi"] = {
},
},
},
["backdropColor"] = {
1,
1,
1,
0.5,
},
["source"] = "import",
["scale"] = 1,
["border"] = false,
["borderEdge"] = "Square Full White",
["regionType"] = "group",
["borderSize"] = 2,
["parent"] = "General Auras",
["borderOffset"] = 4,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Armor Debuffs",
["selfPoint"] = "CENTER",
["frameStrata"] = 1,
["anchorFrameType"] = "SCREEN",
["authorOptions"] = {
},
["uid"] = "bm9vUqxeB1p",
["config"] = {
},
["borderInset"] = 1,
["conditions"] = {
},
["information"] = {
},
["alpha"] = 1,
},
["Shadow Crash Warning"] = {
["iconSource"] = 0,
["wagoID"] = "A3Z0KIoeL",
["authorOptions"] = {
},
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = 100.35,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["spellId"] = {
426199,
},
["subeventSuffix"] = "_DAMAGE",
["auraspellids"] = {
"426199",
},
["duration"] = "1",
["event"] = "Combat Log",
["subeventPrefix"] = "SPELL",
["destUnit"] = "player",
["use_spellId"] = true,
["spellIds"] = {
},
["useExactSpellId"] = true,
["names"] = {
},
["use_destUnit"] = true,
["unit"] = "player",
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = 0,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = true,
["glowLength"] = 10,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 96,
["load"] = {
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["talent"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["anchorFrameType"] = "SCREEN",
["source"] = "import",
["cooldownEdge"] = false,
["adjustedMax"] = "",
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["cooldown"] = true,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["conditions"] = {
},
["icon"] = true,
["xOffset"] = -101.14,
["config"] = {
},
["alpha"] = 1,
["zoom"] = 0,
["cooldownTextDisabled"] = false,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Shadow Crash Warning",
["useCooldownModRate"] = true,
["frameStrata"] = 1,
["width"] = 96,
["progressSource"] = {
-1,
"",
},
["uid"] = "lcMK5JSrH86",
["inverse"] = false,
["color"] = {
1,
1,
1,
1,
},
["displayIcon"] = "136201",
["information"] = {
},
["parent"] = "SOD - BFD",
},
["Dark Protection"] = {
["iconSource"] = 0,
["wagoID"] = "A3Z0KIoeL",
["authorOptions"] = {
},
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = 100.4776489257813,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["spellId"] = {
"429541",
},
["duration"] = "17",
["genericShowOn"] = "showOnCooldown",
["unit"] = "target",
["use_genericShowOn"] = true,
["debuffType"] = "HARMFUL",
["use_track"] = true,
["type"] = "combatlog",
["names"] = {
},
["auraspellids"] = {
"429541",
},
["spellName"] = {
0,
},
["subeventSuffix"] = "_AURA_APPLIED",
["event"] = "Combat Log",
["use_spellId"] = true,
["realSpellName"] = 0,
["use_spellName"] = false,
["spellIds"] = {
},
["use_sourceUnit"] = false,
["subeventPrefix"] = "SPELL",
["useExactSpellId"] = true,
["sourceUnit"] = "target",
["use_auraType"] = false,
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "%p",
["text_text_format_p_format"] = "timed",
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_p_time_legacy_floor"] = false,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_text_format_p_time_mod_rate"] = true,
["type"] = "subtext",
["text_text_format_p_time_dynamic_threshold"] = 60,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_text_format_p_time_format"] = 0,
["text_shadowYOffset"] = 0,
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "CENTER",
["anchorYOffset"] = 0,
["text_visible"] = true,
["text_fontSize"] = 48,
["anchorXOffset"] = 0,
["text_text_format_p_time_precision"] = 1,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = false,
["glowLength"] = 10,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 96,
["load"] = {
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["talent"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["anchorFrameType"] = "SCREEN",
["source"] = "import",
["actions"] = {
["start"] = {
["sound_channel"] = "Master",
["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\AirHorn.ogg",
["do_sound"] = false,
},
["finish"] = {
},
["init"] = {
},
},
["adjustedMax"] = "",
["cooldownEdge"] = false,
["cooldown"] = true,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["conditions"] = {
},
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "SOD - BFD",
["config"] = {
},
["frameStrata"] = 1,
["zoom"] = 0,
["cooldownTextDisabled"] = true,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Dark Protection",
["useCooldownModRate"] = true,
["alpha"] = 1,
["width"] = 96,
["progressSource"] = {
-1,
"",
},
["uid"] = "OR9lhLcStsG",
["inverse"] = false,
["color"] = {
1,
1,
1,
1,
},
["displayIcon"] = "236407",
["information"] = {
},
["xOffset"] = -101.3224731445313,
},
["Death-Fatality"] = {
["iconSource"] = -1,
["wagoID"] = "A3Z0KIoeL",
["parent"] = "General Auras",
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
["do_loop"] = false,
["do_sound"] = true,
["sound_path"] = "Interface\\Sounds\\MortalKombatFatalityLoud.mp3",
["sound"] = " custom",
["do_custom"] = false,
["sound_channel"] = "Dialog",
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["auranames"] = {
"Killing Spree",
},
["ownOnly"] = true,
["names"] = {
},
["spellName"] = "Killing Spree",
["debuffType"] = "HELPFUL",
["type"] = "unit",
["use_health"] = true,
["health_operator"] = {
"<",
},
["useName"] = true,
["subeventSuffix"] = "_AURA_APPLIED",
["event"] = "Health",
["classification"] = {
},
["health"] = {
"1",
},
["use_spellName"] = true,
["spellIds"] = {
},
["use_sourceUnit"] = true,
["subeventPrefix"] = "SPELL",
["use_unit"] = true,
["sourceUnit"] = "player",
["unit"] = "player",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 1,
["load"] = {
["use_class"] = true,
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["source"] = "import",
["cooldownTextDisabled"] = false,
["config"] = {
},
["adjustedMax"] = "",
["authorOptions"] = {
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["information"] = {
},
["cooldownEdge"] = false,
["xOffset"] = 0,
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["anchorFrameType"] = "SCREEN",
["frameStrata"] = 1,
["zoom"] = 0,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Death-Fatality",
["useCooldownModRate"] = true,
["alpha"] = 1,
["width"] = 1,
["color"] = {
1,
1,
1,
1,
},
["uid"] = "ysPKBrWiMAA",
["inverse"] = false,
["icon"] = true,
["conditions"] = {
},
["cooldown"] = false,
["progressSource"] = {
-1,
"",
},
},
["CP 1"] = {
["wagoID"] = "dTwWQJRhb",
["authorOptions"] = {
},
["preferToUpdate"] = true,
["yOffset"] = -165,
["anchorPoint"] = "CENTER",
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["duration"] = "1",
["unit"] = "player",
["powertype"] = 4,
["use_powertype"] = true,
["debuffType"] = "HELPFUL",
["type"] = "unit",
["unevent"] = "auto",
["power_operator"] = {
">=",
},
["use_requirePowerType"] = false,
["subeventPrefix"] = "SPELL",
["names"] = {
},
["spellIds"] = {
},
["use_power"] = false,
["power"] = {
"1",
},
["event"] = "Power",
["use_unit"] = true,
["subeventSuffix"] = "_CAST_START",
},
["untrigger"] = {
},
},
["disjunctive"] = "all",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 42.765598297119,
["rotate"] = true,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["textureWrapMode"] = "CLAMP",
["source"] = "import",
["mirror"] = false,
["regionType"] = "texture",
["blendMode"] = "BLEND",
["desc"] = "Rogue Combo Points - Classic WoW                                                              - created by Johadan                                                                                                                        - https://wago.io/p/Johadan#1650                                                                                         - Discord: https://discord.gg/QJs5SHH",
["color"] = {
0,
0,
0,
1,
},
["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Circle_Smooth_Border",
["parent"] = "Sno - Rogue Combo Points",
["xOffset"] = -70,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "CP 1",
["anchorFrameType"] = "SCREEN",
["alpha"] = 1,
["width"] = 42.76575088501,
["frameStrata"] = 1,
["uid"] = "MygDhl8J6CJ",
["config"] = {
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
},
["conditions"] = {
{
["check"] = {
["trigger"] = 1,
["op"] = ">=",
["variable"] = "power",
["value"] = "1",
},
["changes"] = {
{
["value"] = {
0.94509803921569,
0.019607843137255,
0,
1,
},
["property"] = "color",
},
{
["value"] = 1,
["property"] = "alpha",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["variable"] = "power",
["value"] = "5",
},
["changes"] = {
{
["value"] = {
1,
0.22352941176471,
0.72156862745098,
1,
},
["property"] = "color",
},
},
},
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["discrete_rotation"] = 0,
},
["Barney Pull Timer-Timer"] = {
["sparkWidth"] = 6,
["iconSource"] = -1,
["xOffset"] = 0,
["displayText"] = "%p",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["sparkRotation"] = 0,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\AcousticGuitar.ogg",
["do_sound"] = false,
},
["finish"] = {
["custom"] = "aura_env.clear()",
["do_custom"] = true,
["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Glass.mp3",
["do_sound"] = false,
},
["init"] = {
["custom"] = "aura_env.npc = {\n    [\"36612\"] = 1,\n    [\"36855\"] = 2,\n    [\"37813\"] = 4,\n    [\"36626\"] = 5,\n    [\"36627\"] = 6,\n    [\"36678\"] = 7,\n    [\"37970\"] = 8,\n    [\"37972\"] = 8,\n    [\"37973\"] = 8,\n    [\"36597\"] = 12,\n    [\"38995\"] = 12,\n}\n\naura_env.timed = function(a, aid, duration)\n    if duration and duration > 0 then\n        a[aid] = {\n            show = true,\n            changed = true,\n            autoHide = true,\n            progressType = \"timed\",\n            duration = duration,\n            expirationTime = duration + GetTime(),\n        }\n    end\nend\n\naura_env.off = function(a, aid)\n    a[aid] = {\n        show = false,\n    }\nend\n\naura_env.countset = function(startnum)\n    aura_env.counttick(startnum)\n    aura_env.ticker = C_Timer.NewTicker(1, function()\n            if ceil(aura_env.state.expirationTime - GetTime()) > 0 then\n                aura_env.counttick(ceil(aura_env.state.expirationTime - GetTime()))\n            else\n                if aura_env.ticker then\n                    aura_env.ticker:Cancel()\n                    aura_env.ticker = nil\n                end\n            end\n    end)\nend\n\naura_env.counttick = function(countnum)\n    WeakAuras.ScanEvents(\"PULLTIMER_TICK_START\", 1, countnum)\n    if aura_env.config.voice then\n        C_VoiceChat.SpeakText(0, countnum, 0, 3, 100)\n    end\nend\n\naura_env.clear = function()\n    WeakAuras.ScanEvents(\"PULLTIMER_END\")\n    WeakAuras.ScanEvents(\"PULLTIMER_TICK_END\")\n    if aura_env.ticker then\n        aura_env.ticker:Cancel()\n        aura_env.ticker = nil\n    end\n    WeakAuras.timer:CancelTimer(aura_env.swaptimer)\n    WeakAuras.timer:CancelTimer(aura_env.willtimer)\n    WeakAuras.timer:CancelTimer(aura_env.lichtimer)\n    WeakAuras.timer:CancelTimer(aura_env.scaletimer)\n    WeakAuras.timer:CancelTimer(aura_env.comettimer)\n    WeakAuras.timer:CancelTimer(aura_env.gossiptimer)\n    C_VoiceChat.StopSpeakingText()\nend\n\naura_env.swap = function()\n    ClearCursor()\n    PickupInventoryItem(13)\n    if CursorHasItem() then\n        EquipCursorItem(14)\n    end\n    C_Timer.After(1, function()\n            if not InCombatLockdown() then\n                ClearCursor()\n                PickupInventoryItem(13)\n                if CursorHasItem() then\n                    EquipCursorItem(14)\n                end\n            end\n    end)\nend\n\naura_env.swapset = function(timing)\n    aura_env.swaptimer = WeakAuras.timer:ScheduleTimer(WeakAuras.ScanEvents, timing, \"SWAP_TRINKET\")\nend\n\naura_env.unequipandreequip = function(equipslot, equipid)\n    local emptyslot = aura_env.scanemptyslot()\n    if emptyslot then\n        PickupInventoryItem(equipslot)\n        if emptyslot == 0 then\n            PutItemInBackpack() \n        else\n            PutItemInBag(30 + emptyslot)\n        end\n        ClearCursor()\n        C_Timer.After(1, function()\n                aura_env.reequip(equipslot, equipid)\n        end)\n    end\nend\n\naura_env.scanemptyslot = function()\n    for i = 0, 4 do\n        if C_Container.GetContainerNumFreeSlots(i) ~= 0 then\n            return i\n        end\n    end\n    return nil\nend\n\naura_env.reequip = function(equipslot, equipid)\n    if not InCombatLockdown() then\n        if not GetInventoryItemID(\"player\", equipslot) then\n            EquipItemByName(equipid)\n            C_Timer.After(1, function()\n                    aura_env.reequip(equipslot, equipid)\n            end)\n        end\n    end\nend\n\naura_env.will = {\n    [50363] = 60,\n    [50362] = 60,\n}\n\naura_env.lich = {\n    [50365] = 55,\n    [50360] = 55,\n}\n\naura_env.scale = {\n    [54588] = 5,\n    [54572] = 5,\n}\n\naura_env.willset = function(timing)\n    aura_env.willtimer = WeakAuras.timer:ScheduleTimer(WeakAuras.ScanEvents, timing, \"WILL_ADVANCE\")\nend\n\naura_env.lichset = function(timing)\n    aura_env.lichtimer = WeakAuras.timer:ScheduleTimer(WeakAuras.ScanEvents, timing, \"LICH_ADVANCE\")\nend\n\naura_env.scaleset = function(timing)\n    aura_env.scaletimer = WeakAuras.timer:ScheduleTimer(WeakAuras.ScanEvents, timing, \"SCALE_ADVANCE\")\nend\n\naura_env.cometset = function()\n    if IsSpellKnown(49206) and (GetInventoryItemID(\"player\", 13) == 45609 or GetInventoryItemID(\"player\", 14) == 45609) then\n        aura_env.comettimer = WeakAuras.timer:ScheduleTimer(WeakAuras.ScanEvents, aura_env.config.cometdelayed - 1, \"COMET_DELAY\")\n    end\nend\n\naura_env.gossipset = function(extra, timing)\n    if extra >= timing then\n        aura_env.gossiptimer = WeakAuras.timer:ScheduleTimer(WeakAuras.ScanEvents, extra - timing, \"GOSSIP_SELECT\", timing)\n    end\nend\n\naura_env.gossipselect = function()\n    for _, option in pairs(C_GossipInfo.GetOptions()) do\n        C_GossipInfo.SelectOption(option.gossipOptionID)\n    end\nend\n\nif not C_ChatInfo.IsAddonMessagePrefixRegistered(\"D5\") then\n    C_ChatInfo.RegisterAddonMessagePrefix(\"D5\")\nend\n\nif not C_ChatInfo.IsAddonMessagePrefixRegistered(\"D5C\") then\n    C_ChatInfo.RegisterAddonMessagePrefix(\"D5C\")\nend\n\nif not C_ChatInfo.IsAddonMessagePrefixRegistered(\"D5WC\") then\n    C_ChatInfo.RegisterAddonMessagePrefix(\"D5WC\")\nend\n\nlocal pt = function(value)\n    WeakAuras.ScanEvents(\"PULLTIMER_SEND\", value, \"PT\")\nend\n\nlocal bt = function(value)\n    WeakAuras.ScanEvents(\"PULLTIMER_SEND\", value * 60, \"BT\")\nend\n\nsetglobal(\"pull\", pt)\nsetglobal(\"PULL\", pt)\nsetglobal(\"kai\", pt)\nsetglobal(\"KAI\", pt)\nsetglobal(\"BREAK\", bt)\nsetglobal(\"xiuxi\", bt)\nsetglobal(\"XIUXI\", bt)\n\naura_env.toggleraidframe = function()\n    ToggleRaidFrame()\n    ToggleRaidFrame()\nend\naura_env.toggleraidframe()",
["do_custom"] = true,
},
},
["icon_color"] = {
1,
1,
1,
1,
},
["enableGradient"] = false,
["wordWrap"] = "WordWrap",
["barColor"] = {
1,
1,
0.24705883860588,
1,
},
["desc"] = "This is a fork of [Cozroth]DBM/BigWigs PULL TIMER https://wago.io/-fj4L_nlD",
["font"] = "默认",
["sparkOffsetY"] = 0,
["gradientOrientation"] = "HORIZONTAL",
["load"] = {
["ingroup"] = {
["single"] = "raid",
["multi"] = {
["group"] = true,
["raid"] = true,
},
},
["use_zoneIds"] = false,
["instance_type"] = {
["multi"] = {
},
},
["group_leader"] = {
},
["class"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["use_encounterid"] = false,
["difficulty"] = {
},
["use_zone"] = false,
["use_never"] = false,
["spec"] = {
["multi"] = {
},
},
["talent"] = {
["multi"] = {
},
},
["zone"] = "",
["use_ingroup"] = false,
["size"] = {
["multi"] = {
["party"] = true,
["flexible"] = true,
["ten"] = true,
["twentyfive"] = true,
["fortyman"] = true,
["twenty"] = true,
},
},
},
["shadowXOffset"] = 0,
["useAdjustededMin"] = false,
["regionType"] = "text",
["sparkDesaturate"] = true,
["texture"] = "Solid",
["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
["spark"] = true,
["tocversion"] = 11500,
["alpha"] = 1,
["sparkColor"] = {
1,
1,
1,
1,
},
["fixedWidth"] = 200,
["outline"] = "OUTLINE",
["sparkOffsetX"] = 0,
["wagoID"] = "A3Z0KIoeL",
["parent"] = "Barney Raid Kit - Pull Timer",
["shadowYOffset"] = 0,
["customTextUpdate"] = "event",
["automaticWidth"] = "Auto",
["triggers"] = {
{
["trigger"] = {
["dynamicDuration"] = true,
["debuffType"] = "HELPFUL",
["type"] = "custom",
["custom_hide"] = "timed",
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["unit"] = "player",
["event"] = "Health",
["custom"] = "function(a, event, extra, content)\n    if event == \"CHAT_MSG_ADDON\" then\n        if extra == \"D5\" or extra == \"D5C\" or extra == \"D5WC\"then\n            local _, _, cmd, value = strsplit(\"\\t\", content)\n            if cmd == \"PT\" then\n                WeakAuras.ScanEvents(\"PULLTIMER_PULL\", tonumber(value))\n            elseif cmd == \"BT\" then\n                WeakAuras.ScanEvents(\"PULLTIMER_BREAK\", tonumber(value))\n            end\n        elseif extra == \"BigWigs\" then\n            local _, cmd, value = strsplit(\"^\", content)\n            if cmd == \"PT\" then\n                WeakAuras.ScanEvents(\"PULLTIMER_PULL\", tonumber(value))\n            elseif cmd == \"BT\" then\n                WeakAuras.ScanEvents(\"PULLTIMER_BREAK\", tonumber(value))\n            end\n        end\n        \n    elseif event == \"PULLTIMER_SEND\" then\n        if not extra then\n            extra = 0\n        end\n        local value = extra\n        local cmd = content\n        local playerName = UnitName(\"player\")\n        local playerRealm = GetRealmName()\n        local normalizedPlayerRealm = playerRealm:gsub(\"[%s-]+\", \"\")\n        local fullname = playerName..\"-\"..normalizedPlayerRealm\n        local content = fullname..\"\\t\"..\"1\"..\"\\t\"..cmd..\"\\t\"..value\n        if IsInRaid() and (UnitIsGroupLeader(\"player\") or UnitIsGroupAssistant(\"player\")) then\n            C_ChatInfo.SendAddonMessage(\"D5\", content, \"RAID\")\n        elseif IsInGroup() then\n            C_ChatInfo.SendAddonMessage(\"D5\", content, \"PARTY\")\n        else\n            if cmd == \"PT\" then\n                WeakAuras.ScanEvents(\"PULLTIMER_PULL\", value)\n            elseif cmd == \"BT\" then\n                WeakAuras.ScanEvents(\"PULLTIMER_BREAK\", value)\n            end\n        end\n        \n    elseif event == \"PULLTIMER_PULL\" then\n        aura_env.clear()                    \n        local value = extra\n        if value > 0 then\n            aura_env.timed(a, \"\", value)\n            a[\"\"].name = aura_env.text1\n            a[\"\"].pull = true\n            PlaySoundFile(565853)\n            WeakAuras.ScanEvents(\"PULLTIMER_START\", value, a[\"\"].pull)\n            if value <= 10 then\n                aura_env.countset(value)\n            end\n            if select(8, GetInstanceInfo()) ~= 631 then\n                if UnitGroupRolesAssigned(\"player\") ~= \"HEALER\" and aura_env.config.autoswap then\n                    if aura_env.config.common > 0 then\n                        if value >= aura_env.config.common + 60 then\n                            if value - aura_env.config.common - 60 < 1 then\n                                aura_env.willset(value - aura_env.config.common - 60)\n                            else\n                                aura_env.willset(value - aura_env.config.common - 60 - 1)\n                            end\n                        end\n                        if value >= aura_env.config.common + 55 then\n                            if value - aura_env.config.common - 55 < 1 then\n                                aura_env.lichset(value - aura_env.config.common - 55)\n                            else\n                                aura_env.lichset(value - aura_env.config.common - 55 - 1)\n                            end\n                        end\n                        if value >= aura_env.config.common + 5 then\n                            if value - aura_env.config.common - 5 < 1 then\n                                aura_env.scaleset(value - aura_env.config.common - 55)\n                            else\n                                aura_env.scaleset(value - aura_env.config.common - 55 - 1)\n                            end\n                        end\n                        if value >= aura_env.config.common then\n                            if value - aura_env.config.common < 1 then\n                                aura_env.swapset(value - aura_env.config.common)\n                            else\n                                aura_env.swapset(value - aura_env.config.common - 1)\n                            end\n                        end\n                    end\n                end\n            end\n        else\n            aura_env.off(a, \"\")\n        end\n        return true\n        \n    elseif event == \"PULLTIMER_BREAK\" then\n        aura_env.clear()                    \n        local value = extra\n        if value > 0 then\n            aura_env.timed(a, \"\", value)\n            a[\"\"].name = aura_env.text2\n            a[\"\"].pull = false\n            PlaySoundFile(566564)\n            WeakAuras.ScanEvents(\"PULLTIMER_START\", value, a[\"\"].pull)\n        else\n            aura_env.off(a, \"\")\n        end\n        return true\n        \n    elseif event == \"SWAP_TRINKET\" then\n        if not InCombatLockdown() then\n            local trinket1 = GetInventoryItemID(\"player\", 13)\n            local trinket2 = GetInventoryItemID(\"player\", 14)\n            if trinket1 and trinket2 then\n                if IsUsableItem(trinket1) and IsUsableItem(trinket2) then\n                    return\n                elseif not IsUsableItem(trinket1) and not IsUsableItem(trinket2) and not aura_env.will[trinket1] and not aura_env.will[trinket2] and not aura_env.lich[trinket1] and not aura_env.lich[trinket2] and not aura_env.scale[trinket1] and not aura_env.scale[trinket2] then\n                    aura_env.swap()\n                    if aura_env.config.cometdelay then\n                        aura_env.cometset()\n                    end\n                else\n                    local equipslot = nil\n                    local equipid = nil\n                    if not IsUsableItem(trinket1) and not aura_env.will[trinket1] and not aura_env.lich[trinket1] and not aura_env.scale[trinket1] then\n                        equipslot = 13\n                        equipid = trinket1\n                    elseif not IsUsableItem(trinket2) and not aura_env.will[trinket2] and not aura_env.lich[trinket2] and not aura_env.scale[trinket2] then\n                        equipslot = 14\n                        equipid = trinket2\n                    end\n                    if equipslot and equipid then\n                        aura_env.unequipandreequip(equipslot, equipid)\n                    end\n                    if aura_env.config.cometdelay then\n                        aura_env.cometset()\n                    end\n                end\n            end\n        end\n        \n    elseif event == \"WILL_ADVANCE\" then\n        if not InCombatLockdown() then\n            local equipslot = nil\n            for equipid in pairs(aura_env.will) do\n                if GetInventoryItemID(\"player\", 13) == equipid then\n                    equipslot = 13\n                elseif GetInventoryItemID(\"player\", 14) == equipid then\n                    equipslot = 14\n                end\n                if equipslot then\n                    aura_env.unequipandreequip(equipslot, equipid)\n                    break\n                end\n            end\n        end\n        \n    elseif event == \"LICH_ADVANCE\" then\n        if not InCombatLockdown() then\n            local equipslot = nil\n            for equipid in pairs(aura_env.lich) do\n                if GetInventoryItemID(\"player\", 13) == equipid then\n                    equipslot = 13\n                elseif GetInventoryItemID(\"player\", 14) == equipid then\n                    equipslot = 14\n                end\n                if equipslot then\n                    aura_env.unequipandreequip(equipslot, equipid)\n                    break\n                end\n            end\n        end\n        \n    elseif event == \"SCALE_ADVANCE\" then\n        if not InCombatLockdown() then\n            local equipslot = nil\n            for equipid in pairs(aura_env.scale) do\n                if GetInventoryItemID(\"player\", 13) == equipid then\n                    equipslot = 13\n                elseif GetInventoryItemID(\"player\", 14) == equipid then\n                    equipslot = 14\n                end\n                if equipslot then\n                    aura_env.unequipandreequip(equipslot, equipid)\n                    break\n                end\n            end\n        end\n        \n    elseif event == \"COMET_DELAY\" then\n        if not InCombatLockdown() then\n            local equipslot = nil\n            local equipid = 45609\n            if GetInventoryItemID(\"player\", 13) == equipid then\n                equipslot = 13\n            elseif GetInventoryItemID(\"player\", 14) == equipid then\n                equipslot = 14\n            end\n            if equipslot and equipid then\n                aura_env.unequipandreequip(equipslot, equipid)\n            end\n        end\n    end\nend",
["customDuration"] = "function()\n    if WeakAuras.IsOptionsOpen() then\n        return 1337, 1337, true\n    else\n        local duration, expirationTime = aura_env.duration, GetTime() + aura_env.duration\n        return duration, expirationTime\n    end\nend\n\n\n",
["customName"] = "function()\n    if WeakAuras.IsOptionsOpen() then\n        return \"PULL\"\n    else\n        return aura_env.name\n    end\nend",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["check"] = "event",
["events"] = "CHAT_MSG_ADDON,PULLTIMER_SEND,PULLTIMER_PULL,PULLTIMER_BREAK,SWAP_TRINKET,WILL_ADVANCE,LICH_ADVANCE,SCALE_ADVANCE,COMET_DELAY",
["custom_type"] = "stateupdate",
["customVariables"] = "{\n    duration = true,\n    expirationTime = true,\n    pull = \"bool\",\n}",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["type"] = "unit",
["use_incombat"] = false,
["unit"] = "player",
["debuffType"] = "HELPFUL",
["use_alive"] = true,
["event"] = "Conditions",
["use_unit"] = true,
},
["untrigger"] = {
},
},
{
["trigger"] = {
["type"] = "custom",
["events"] = "PULLTIMER_PULL,GOSSIP_SELECT,GOSSIP_SHOW,CHAT_MSG_MONSTER_YELL,ENCOUNTER_END,UPDATE_MOUSEOVER_UNIT,PLAYER_ENTERING_WORLD,ZONE_CHANGED_NEW_AREA,RAIDFRAME_TOGGLE",
["custom_type"] = "stateupdate",
["check"] = "event",
["debuffType"] = "HELPFUL",
["custom"] = "function(a, event, extra, _, _, _, success)\n    if select(8, GetInstanceInfo()) == 631 then\n        if event == \"PULLTIMER_PULL\" then\n            local boss = 0\n            local timing = 0\n            local mapid = C_Map.GetBestMapForUnit(\"player\")\n            if mapid == 188 then\n                boss = 4\n            elseif mapid == 191 then\n                boss = 9\n            elseif mapid == 189 then\n                boss = 11\n            elseif mapid == 192 then\n                boss = 12\n            else\n                if UnitExists(\"target\") and not UnitIsDead(\"target\") and UnitIsEnemy(\"target\", \"player\") and aura_env.npc[select(6, strsplit(\"-\", UnitGUID(\"target\")))] then\n                    boss = aura_env.npc[select(6, strsplit(\"-\", UnitGUID(\"target\")))]\n                end\n            end\n            \n            if boss == 0 then\n                local instance = select(8, GetInstanceInfo())\n                local size = select(5, GetInstanceInfo())\n                local index = 0\n                for i = 1, GetNumSavedInstances() do\n                    if select(14, GetSavedInstanceInfo(i)) == instance and select(9, GetSavedInstanceInfo(i)) == size then\n                        index = i\n                        break\n                    end\n                end\n                \n                if index == 0 then\n                    boss = 1\n                else\n                    boss = select(12, GetSavedInstanceInfo(index)) + 1\n                end\n                \n                if boss == 3 and mapid == 187 then\n                    boss = 4\n                elseif boss == 11 and (mapid == 187 or mapid == 192) then\n                    boss = 12\n                end\n            end\n            \n            if UnitGroupRolesAssigned(\"player\") ~= \"HEALER\" and aura_env.config.autoswap then\n                if boss == 1 and aura_env.config.icc1 > 0 then\n                    timing = aura_env.config.icc1\n                elseif boss == 2 and aura_env.config.icc2 > 0 then\n                    timing = aura_env.config.icc2\n                elseif boss == 4 and aura_env.config.icc4 > 0 then\n                    timing = aura_env.config.icc4\n                elseif boss == 7 and aura_env.config.icc4 > 0 then\n                    timing = aura_env.config.icc7\n                elseif boss == 9 and aura_env.config.icc9 > 0 then\n                    timing = aura_env.config.icc9\n                elseif boss == 11 and aura_env.config.icc11 > 0 then\n                    timing = aura_env.config.icc11\n                elseif boss == 12 and aura_env.config.icc12 > 0 then\n                    timing = aura_env.config.icc12\n                else\n                    timing = aura_env.config.common\n                end\n                \n                if timing > 0 then\n                    if extra >= timing + 60 then\n                        if extra - timing - 60 < 1 then\n                            aura_env.willset(extra - timing - 60)\n                        else\n                            aura_env.willset(extra - timing - 60 - 1)\n                        end\n                    end\n                    if extra >= timing + 55 then\n                        if extra - timing - 55 < 1 then\n                            aura_env.lichset(extra - timing - 55)\n                        else\n                            aura_env.lichset(extra - timing - 55 - 1)\n                        end\n                    end\n                    if extra >= timing then\n                        if extra - timing < 1 then\n                            aura_env.swapset(extra - timing)\n                        else\n                            aura_env.swapset(extra - timing - 1)\n                        end\n                    end\n                end\n            end\n            \n            if (GetRaidDifficultyID() == 5 or GetRaidDifficultyID() == 6) and aura_env.config.tocgossip and (UnitIsGroupLeader(\"player\") or UnitIsGroupAssistant(\"player\")) then\n                if boss == 4 then\n                    if UnitFactionGroup(\"player\") == \"Alliance\" then\n                        aura_env.gossipset(extra, 50.5)\n                    elseif UnitFactionGroup(\"player\") == \"Horde\" then\n                        aura_env.gossipset(extra, 98)\n                    end\n                elseif boss == 12 then\n                    aura_env.gossipset(extra, 64)\n                end\n            end\n            \n        elseif event == \"GOSSIP_SELECT\" then\n            aura_env.timed(a, \"gossip\", extra)\n            aura_env.gossipselect()\n            return true\n            \n        elseif event == \"GOSSIP_SHOW\" then\n            if UnitExists(\"target\") and not UnitIsPlayer(\"target\") then\n                local npcid = select(6, strsplit(\"-\", UnitGUID(\"target\")))\n                if npcid == \"37187\" or npcid == \"37200\" or npcid == \"38995\" then\n                    if a[\"gossip\"] then\n                        aura_env.gossipselect()\n                    else\n                        if (aura_env.config.autoswap and (aura_env.config.icc4 > 0 or aura_env.config.icc12 > 0)) or aura_env.config.iccgossip then\n                            if aura_env.toggleraid then\n                                WeakAuras.ScanEvents(\"RAIDFRAME_TOGGLE\")\n                            end\n                        end\n                    end\n                end                    \n            end\n            \n        elseif event == \"CHAT_MSG_MONSTER_YELL\" and a[\"gossip\"] then\n            a[\"gossip\"].show = false\n            return true\n            \n        elseif event == \"ENCOUNTER_END\" and success == 1 then\n            if (aura_env.config.autoswap and ((aura_env.config.icc2 > 0 and extra == 845) or (aura_env.config.icc4 > 0 and extra == 847) or (aura_env.config.icc12 > 0 and (extra == 851 or extra == 853 or extra == 855)))) or aura_env.config.iccgossip then\n                aura_env.toggleraid = true\n                WeakAuras.ScanEvents(\"RAIDFRAME_TOGGLE\")\n            end\n            \n        elseif event == \"UPDATE_MOUSEOVER_UNIT\" then\n            if not InCombatLockdown() then\n                if UnitExists(\"mouseover\") and not UnitIsPlayer(\"mouseover\") then\n                    local npcid = select(6, strsplit(\"-\", UnitGUID(\"mouseover\")))\n                    if npcid == \"37187\" or npcid == \"37200\" or npcid == \"38995\" then\n                        if (aura_env.config.autoswap and (aura_env.config.icc4 > 0 or aura_env.config.icc12)) or aura_env.config.iccgossip then\n                            if aura_env.toggleraid then\n                                WeakAuras.ScanEvents(\"RAIDFRAME_TOGGLE\")\n                            end\n                        end\n                    end\n                end\n            end\n            \n        elseif event == \"PLAYER_ENTERING_WORLD\" or event == \"ZONE_CHANGED_NEW_AREA\" then\n            if (aura_env.config.autoswap and (aura_env.config.icc1 > 0 or aura_env.config.icc2 > 0 or aura_env.config.icc4 > 0 or aura_env.config.icc12 > 0)) or aura_env.config.iccgossip then\n                WeakAuras.ScanEvents(\"RAIDFRAME_TOGGLE\")\n            end\n            \n        elseif event == \"RAIDFRAME_TOGGLE\" then\n            if not RaidFrame:IsShown() then\n                if not InCombatLockdown() then\n                    aura_env.toggleraidframe()\n                    aura_env.toggleraid = false\n                else\n                    C_Timer.After(1, function()\n                            WeakAuras.ScanEvents(\"RAIDFRAME_TOGGLE\")\n                    end)\n                end\n            else\n                aura_env.toggleraid = false\n            end\n        end\n    end\nend",
["unit"] = "player",
},
["untrigger"] = {
},
},
["disjunctive"] = "custom",
["customTriggerLogic"] = "function(t)\n    return t[1] and t[2]\nend",
["activeTriggerMode"] = -10,
},
["displayText_format_p_format"] = "timed",
["displayText_format_p_time_legacy_floor"] = false,
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["colorR"] = 1,
["duration"] = "100%",
["alphaType"] = "alphaPulse",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
["use_translate"] = true,
["use_alpha"] = false,
["type"] = "custom",
["easeType"] = "easeOutIn",
["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    if aura_env.state.pull and aura_env.state.expirationTime - GetTime() <= 10 then\n        local bounceDistance = math.sin((aura_env.state.expirationTime - GetTime()) % 1 * math.pi)\n        return startX + ((bounceDistance - 0.25) * deltaX), startY + ((bounceDistance - 0.25) * deltaY)\n    end\nend",
["scaley"] = 1,
["alpha"] = 0,
["scalex"] = 1,
["y"] = 20,
["x"] = 0,
["duration_type"] = "relative",
["rotate"] = 0,
["translateType"] = "custom",
["easeStrength"] = 5,
["preset"] = "bounce",
["colorB"] = 1,
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["zoom"] = 0,
["information"] = {
["forceEvents"] = false,
["ignoreOptionsEventErrors"] = true,
},
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 30,
["color"] = {
1,
1,
0,
1,
},
["orientation"] = "HORIZONTAL",
["sparkBlendMode"] = "ADD",
["useAdjustededMax"] = false,
["fontSize"] = 80,
["source"] = "import",
["displayText_format_n_format"] = "none",
["displayIcon"] = 132349,
["displayText_format_p_time_mod_rate"] = true,
["backgroundColor"] = {
0,
0,
0,
0.5,
},
["sparkRotationMode"] = "AUTO",
["width"] = 300,
["internalVersion"] = 78,
["displayText_format_p_time_dynamic_threshold"] = 0,
["icon_side"] = "LEFT",
["id"] = "Barney Pull Timer-Timer",
["displayText_format_p_time_format"] = 0,
["sparkHeight"] = 45,
["semver"] = "1.0.18",
["icon"] = true,
["authorOptions"] = {
{
["type"] = "toggle",
["default"] = true,
["key"] = "voice",
["name"] = "Play countdown voice(播放倒计时语音）",
["useDesc"] = false,
["width"] = 2,
},
{
["type"] = "toggle",
["default"] = true,
["key"] = "autoswap",
["name"] = "Auto swap trinkets(自动交换饰品)",
["useDesc"] = false,
["width"] = 2,
},
{
["useName"] = true,
["type"] = "header",
["text"] = "How many seconds left to auto swap trinkets(剩余多少秒时自动交换饰品)",
["noMerge"] = true,
["width"] = 2,
},
{
["text"] = "Common swapping timing\n0 = No Swapping\n|TInterface\\Icons\\inv_jewelry_trinket_04:18|t This timing will automatically add 60s to Deathbringer's Will.\n|TInterface\\Icons\\inv_jewelry_trinket_03:18|t This timing will automatically add 55s to Phylactery of the Nameless Lich.\n|TInterface\\Icons\\inv_misc_rubysanctum2:18|t This timing will automatically add 5s to Charred Twilight Scale.\n\n通用交换时间\n0 = 不交换\n|TInterface\\Icons\\inv_jewelry_trinket_04:18|t 此时间将自动为死神的意志增加60秒。\n|TInterface\\Icons\\inv_jewelry_trinket_03:18|t 此时间将自动为无名巫妖的护符匣增加55秒。\n|TInterface\\Icons\\inv_misc_rubysanctum2:18|t 此时间将自动为焦黑暮光龙鳞增加5秒。",
["type"] = "description",
["fontSize"] = "medium",
["width"] = 2,
},
{
["type"] = "range",
["useDesc"] = false,
["max"] = 45,
["step"] = 1,
["width"] = 2,
["min"] = 0,
["key"] = "common",
["default"] = 0,
["name"] = "",
},
{
["type"] = "toggle",
["default"] = true,
["key"] = "cometdelay",
["name"] = "|TInterface\\Icons\\spell_deathknight_unholypresence:18|t |TInterface\\Icons\\spell_arcane_starfire:18|t Delay swapping Comet for Unholy DK(邪DK延迟交换彗星)",
["useDesc"] = false,
["width"] = 2,
},
{
["type"] = "range",
["useDesc"] = false,
["max"] = 9,
["step"] = 1,
["width"] = 2,
["min"] = 5,
["key"] = "cometdelayed",
["default"] = 7,
["name"] = "How many seconds to delay swapping Comet(延迟多少秒交换彗星)",
},
{
["useName"] = true,
["type"] = "header",
["text"] = "Icecrown Citadel(冰冠堡垒)",
["noMerge"] = true,
["width"] = 2,
},
{
["text"] = "Trinkets swapping timing specific for ICC Bosses\n0 = Use common timing\n\nICC BOSS专属饰品交换时间\n0 = 使用通用时间\n",
["type"] = "description",
["fontSize"] = "medium",
["width"] = 2,
},
{
["softMin"] = 0,
["type"] = "range",
["useDesc"] = true,
["max"] = 45,
["step"] = 1,
["desc"] = "Can't be 1-11(不能选择1-11)",
["min"] = 0,
["key"] = "icc1",
["default"] = 0,
["name"] = "Lord Marrowgar(玛洛加尔领主)",
["width"] = 2,
},
{
["type"] = "range",
["useDesc"] = false,
["max"] = 45,
["step"] = 1,
["width"] = 2,
["min"] = 0,
["key"] = "icc2",
["default"] = 0,
["name"] = "Lady Deathwhisper(亡语者女士)",
},
{
["type"] = "range",
["useDesc"] = false,
["max"] = 45,
["step"] = 1,
["width"] = 2,
["min"] = 0,
["key"] = "icc4",
["default"] = 0,
["name"] = "Deathbringer Saurfang(死亡使者萨鲁法尔)",
},
{
["type"] = "range",
["useDesc"] = false,
["max"] = 45,
["step"] = 1,
["width"] = 2,
["min"] = 0,
["key"] = "icc7",
["default"] = 0,
["name"] = "Professor Putricide(普崔塞德教授)",
},
{
["type"] = "range",
["useDesc"] = false,
["max"] = 45,
["step"] = 1,
["width"] = 2,
["min"] = 0,
["key"] = "icc9",
["default"] = 0,
["name"] = "Queen Lana'thel(兰娜瑟尔女王)",
},
{
["type"] = "range",
["useDesc"] = false,
["max"] = 45,
["step"] = 1,
["width"] = 2,
["min"] = 0,
["key"] = "icc11",
["default"] = 0,
["name"] = "Sindragosa(辛达苟萨)",
},
{
["type"] = "range",
["useDesc"] = false,
["max"] = 45,
["step"] = 1,
["width"] = 2,
["min"] = 0,
["key"] = "icc12",
["default"] = 0,
["name"] = "Lich King(巫妖王)",
},
{
["useName"] = false,
["type"] = "header",
["text"] = "",
["noMerge"] = true,
["width"] = 1,
},
{
["type"] = "toggle",
["default"] = true,
["key"] = "iccgossip",
["name"] = "Auto gossip in long countdown(长倒计时自动对话)",
["useDesc"] = false,
["width"] = 2,
},
{
["text"] = "Required being raid leader or assistant to prevent wrong operation.\n(必须拥有团长或助理权限以防止误操作。)",
["type"] = "description",
["fontSize"] = "medium",
["width"] = 2,
},
},
["justify"] = "CENTER",
["displayText_format_p_time_precision"] = 1,
["sparkHidden"] = "BOTH",
["desaturate"] = false,
["frameStrata"] = 6,
["anchorFrameType"] = "SCREEN",
["selfPoint"] = "CENTER",
["uid"] = "vT7Uci2X701",
["inverse"] = true,
["config"] = {
["icc7"] = 0,
["icc4"] = 0,
["common"] = 39,
["autoswap"] = true,
["cometdelay"] = true,
["icc9"] = 0,
["icc12"] = 0,
["icc2"] = 0,
["cometdelayed"] = 7,
["icc11"] = 0,
["icc1"] = 0,
["iccgossip"] = true,
["voice"] = true,
},
["shadowColor"] = {
0,
0,
0,
1,
},
["conditions"] = {
{
["check"] = {
["trigger"] = 1,
["variable"] = "pull",
["value"] = 1,
},
["changes"] = {
{
["value"] = {
["sound_kit_id"] = "",
["sound_path"] = "Sound\\Doodad\\BellTollNightElf.ogg1",
["sound_repeat"] = 1,
["sound_type"] = "Play",
["sound"] = " custom",
["sound_channel"] = "Master",
},
["property"] = "sound",
},
},
},
{
["check"] = {
["trigger"] = -2,
["variable"] = "AND",
["checks"] = {
{
["trigger"] = 1,
["variable"] = "pull",
["value"] = 1,
},
{
["trigger"] = 1,
["op"] = "<=",
["value"] = "10",
["variable"] = "expirationTime",
},
},
},
["changes"] = {
{
["value"] = {
1,
0.49803924560547,
0,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = -2,
["variable"] = "AND",
["checks"] = {
{
["trigger"] = 1,
["variable"] = "pull",
["value"] = 1,
},
{
["trigger"] = 1,
["op"] = ">",
["value"] = "10",
["variable"] = "duration",
},
{
["trigger"] = 1,
["op"] = "<=",
["value"] = "10",
["variable"] = "expirationTime",
},
},
},
["changes"] = {
{
["value"] = {
["custom"] = "aura_env.countset(ceil(aura_env.state.expirationTime - GetTime()))",
},
["property"] = "customcode",
},
},
},
{
["check"] = {
["trigger"] = -2,
["variable"] = "AND",
["checks"] = {
{
["trigger"] = 1,
["variable"] = "pull",
["value"] = 1,
},
{
["trigger"] = 1,
["op"] = "<=",
["value"] = "3",
["variable"] = "expirationTime",
},
},
},
["changes"] = {
{
["value"] = {
1,
0,
0,
1,
},
["property"] = "color",
},
{
["value"] = 100,
["property"] = "fontSize",
},
},
},
{
["check"] = {
["trigger"] = -2,
["variable"] = "AND",
["checks"] = {
{
["trigger"] = 1,
["variable"] = "pull",
["value"] = 1,
},
{
["trigger"] = 1,
["op"] = "<=",
["value"] = "0.2",
["variable"] = "expirationTime",
},
},
},
["changes"] = {
{
["value"] = {
["sound_type"] = "Play",
["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Glass.mp3",
["sound_channel"] = "Master",
},
["property"] = "sound",
},
},
},
{
["check"] = {
["trigger"] = -2,
["variable"] = "AND",
["checks"] = {
{
["trigger"] = 1,
["variable"] = "pull",
["value"] = 0,
},
{
["trigger"] = 1,
["op"] = ">",
["value"] = "60",
["variable"] = "expirationTime",
},
},
},
["changes"] = {
{
["value"] = {
0,
1,
0,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = -2,
["variable"] = "AND",
["checks"] = {
{
["trigger"] = 1,
["variable"] = "pull",
["value"] = 0,
},
{
["trigger"] = 1,
["op"] = "<=",
["value"] = "1",
["variable"] = "expirationTime",
},
},
},
["changes"] = {
{
["value"] = {
["sound_type"] = "Play",
["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\phone.ogg",
["sound_channel"] = "Master",
},
["property"] = "sound",
},
},
},
},
["barColor2"] = {
1,
1,
0,
1,
},
["preferToUpdate"] = false,
},
["CP2BlackOutline"] = {
["wagoID"] = "dTwWQJRhb",
["parent"] = "Sno - Rogue Combo Points",
["preferToUpdate"] = true,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "unit",
["unevent"] = "auto",
["duration"] = "1",
["event"] = "Conditions",
["unit"] = "player",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["use_unit"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["discrete_rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 75,
["rotate"] = true,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["textureWrapMode"] = "CLAMP",
["source"] = "import",
["mirror"] = false,
["anchorFrameFrame"] = "WeakAuras:CP 2",
["regionType"] = "texture",
["blendMode"] = "BLEND",
["color"] = {
0,
0,
0,
1,
},
["xOffset"] = 0,
["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura73",
["authorOptions"] = {
},
["desc"] = "Rogue Combo Points - Classic WoW                                                              - created by Johadan                                                                                                                        - https://wago.io/p/Johadan#1650                                                                                         - Discord: https://discord.gg/QJs5SHH",
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "CP2BlackOutline",
["frameStrata"] = 3,
["alpha"] = 1,
["width"] = 75,
["anchorFrameType"] = "SELECTFRAME",
["uid"] = "EOWc38Eax4K",
["config"] = {
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
},
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["rotation"] = 0,
},
["Sunder Debuff NonWarrior"] = {
["iconSource"] = 0,
["wagoID"] = "A3Z0KIoeL",
["authorOptions"] = {
},
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = -219.70006103516,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["subeventSuffix"] = "_CAST_START",
["matchesShowOn"] = "showOnActive",
["event"] = "Health",
["names"] = {
},
["useExactSpellId"] = false,
["spellIds"] = {
},
["unit"] = "target",
["subeventPrefix"] = "SPELL",
["auranames"] = {
"Sunder Armor",
},
["useName"] = true,
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = 0,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "CENTER",
["text_fontSize"] = 24,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = false,
["glowLength"] = 10,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 43,
["load"] = {
["use_class"] = false,
["use_not_spellknown"] = false,
["ingroup"] = {
["single"] = "raid",
},
["talent"] = {
["multi"] = {
},
},
["use_ingroup"] = true,
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "WARRIOR",
["multi"] = {
["HUNTER"] = true,
["PALADIN"] = true,
["WARLOCK"] = true,
["ROGUE"] = true,
["MAGE"] = true,
["DRUID"] = true,
["SHAMAN"] = true,
["PRIEST"] = true,
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["anchorFrameType"] = "SCREEN",
["source"] = "import",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["adjustedMax"] = "",
["cooldownEdge"] = false,
["cooldown"] = true,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["conditions"] = {
},
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "Armor Debuffs",
["config"] = {
},
["frameStrata"] = 1,
["zoom"] = 0,
["cooldownTextDisabled"] = true,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Sunder Debuff NonWarrior",
["useCooldownModRate"] = true,
["alpha"] = 1,
["width"] = 43,
["progressSource"] = {
-1,
"",
},
["uid"] = ")jDoSMR1XAG",
["inverse"] = false,
["color"] = {
1,
1,
1,
1,
},
["displayIcon"] = "132363",
["information"] = {
},
["xOffset"] = -93.533312988281,
},
["Expose"] = {
["iconSource"] = -1,
["wagoID"] = "dTwWQJRhb",
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["url"] = "https://wago.io/dTwWQJRhb/24",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["auranames"] = {
"8647",
"26866",
},
["ownOnly"] = true,
["event"] = "Health",
["unit"] = "target",
["spellIds"] = {
},
["names"] = {
},
["useName"] = true,
["subeventPrefix"] = "SPELL",
["subeventSuffix"] = "_CAST_START",
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = true,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_text_format_p_time_format"] = 0,
["text_text"] = "%p",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["text_text_format_p_time_dynamic_threshold"] = 10,
["text_text_format_p_time_mod_rate"] = true,
["type"] = "subtext",
["text_text_format_p_format"] = "timed",
["text_color"] = {
1,
1,
1,
1,
},
["border_color"] = {
},
["text_font"] = "Gilroy Bold",
["text_shadowYOffset"] = 0,
["text_fontType"] = "THICKOUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_anchorYOffset"] = 0,
["text_text_format_p_time_precision"] = 1,
["text_fontSize"] = 18,
["anchorXOffset"] = 0,
["text_text_format_p_time_legacy_floor"] = true,
},
},
["height"] = 32,
["load"] = {
["ingroup"] = {
},
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["use_encounterid"] = false,
["use_class"] = true,
["size"] = {
["multi"] = {
["party"] = true,
["scenario"] = true,
["fortyman"] = true,
["ten"] = true,
["twentyfive"] = true,
["twenty"] = true,
["flexible"] = true,
},
},
["spec"] = {
["multi"] = {
},
},
["zoneIds"] = "",
},
["useAdjustededMax"] = false,
["width"] = 32,
["source"] = "import",
["zoom"] = 0,
["progressSource"] = {
-1,
"",
},
["adjustedMax"] = "",
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["colorR"] = 1,
["duration"] = "30",
["alphaType"] = "alphaPulse",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0.26,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "alphaPulse",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "relative",
},
["finish"] = {
["colorR"] = 1,
["scalex"] = 1,
["alphaType"] = "alphaPulse",
["colorB"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["colorA"] = 1,
["duration"] = "8",
["rotate"] = 0,
["easeStrength"] = 3,
["duration_type"] = "seconds",
},
},
["authorOptions"] = {
},
["config"] = {
},
["useCooldownModRate"] = true,
["auto"] = true,
["cooldownTextDisabled"] = true,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Expose",
["frameStrata"] = 1,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["xOffset"] = 0,
["uid"] = "hBMtna7v2Lx",
["inverse"] = false,
["parent"] = "SimonizeBars",
["conditions"] = {
},
["cooldown"] = false,
["cooldownEdge"] = false,
},
["Slice and Dice"] = {
["iconSource"] = -1,
["wagoID"] = "dTwWQJRhb",
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["url"] = "https://wago.io/dTwWQJRhb/24",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["auranames"] = {
"6774",
"6434",
"5171",
},
["event"] = "Health",
["unit"] = "player",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["useName"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = true,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_text_format_p_time_format"] = 0,
["text_text"] = "%p",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["text_text_format_p_time_dynamic_threshold"] = 10,
["text_text_format_p_time_mod_rate"] = true,
["type"] = "subtext",
["text_text_format_p_format"] = "timed",
["text_color"] = {
1,
1,
1,
1,
},
["border_color"] = {
},
["text_font"] = "Gilroy Bold",
["text_shadowYOffset"] = 0,
["text_fontType"] = "THICKOUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_anchorYOffset"] = 0,
["text_text_format_p_time_precision"] = 1,
["text_fontSize"] = 18,
["anchorXOffset"] = 0,
["text_text_format_p_time_legacy_floor"] = true,
},
},
["height"] = 32,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["width"] = 32,
["source"] = "import",
["zoom"] = 0,
["progressSource"] = {
-1,
"",
},
["adjustedMax"] = "",
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["actions"] = {
["start"] = {
["do_glow"] = false,
},
["init"] = {
},
["finish"] = {
},
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["scalex"] = 1,
["alphaType"] = "straight",
["colorB"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = false,
["type"] = "none",
["easeType"] = "easeIn",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["colorA"] = 1,
["duration"] = "30",
["rotate"] = 0,
["easeStrength"] = 3,
["duration_type"] = "relative",
},
["main"] = {
["colorR"] = 1,
["duration"] = "30",
["alphaType"] = "alphaPulse",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0.26,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "alphaPulse",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "relative",
},
["finish"] = {
["colorR"] = 1,
["scalex"] = 1,
["alphaType"] = "alphaPulse",
["colorB"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["colorA"] = 1,
["duration"] = "8",
["rotate"] = 0,
["easeStrength"] = 3,
["duration_type"] = "seconds",
},
},
["authorOptions"] = {
},
["config"] = {
},
["useCooldownModRate"] = true,
["auto"] = true,
["cooldownTextDisabled"] = true,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Slice and Dice",
["frameStrata"] = 1,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["xOffset"] = 0,
["uid"] = "wXJyqm2QGbR",
["inverse"] = false,
["parent"] = "SimonizeBars",
["conditions"] = {
},
["cooldown"] = false,
["cooldownEdge"] = false,
},
["Praise the Sun"] = {
["wagoID"] = "dTwWQJRhb",
["xOffset"] = -473.07949829102,
["preferToUpdate"] = true,
["yOffset"] = 132.39489746094,
["anchorPoint"] = "CENTER",
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["debuffType"] = "HELPFUL",
["type"] = "combatlog",
["use_cloneId"] = true,
["subeventSuffix"] = "_ENERGIZE",
["use_extraAmount"] = false,
["duration"] = ".5",
["event"] = "Combat Log",
["names"] = {
},
["subeventPrefix"] = "SPELL",
["use_spellName"] = true,
["spellIds"] = {
},
["use_sourceUnit"] = true,
["use_powerType"] = false,
["unit"] = "player",
["sourceUnit"] = "player",
["spellName"] = {
"Power of the Sun King",
},
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["discrete_rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 300,
["rotate"] = true,
["load"] = {
["use_class"] = true,
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
["source"] = "import",
["mirror"] = false,
["regionType"] = "texture",
["blendMode"] = "BLEND",
["frameStrata"] = 1,
["texture"] = "Interface\\Icons\\praisethesun512.tga",
["color"] = {
1,
1,
1,
1,
},
["authorOptions"] = {
},
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Praise the Sun",
["rotation"] = 0,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["uid"] = "PdDqzuaAJZP",
["config"] = {
},
["parent"] = "Simonize Meme Auras",
["width"] = 300,
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
},
["animation"] = {
["start"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "shrink",
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "slideleft",
["duration_type"] = "seconds",
},
},
},
["CP1BlackOutline"] = {
["wagoID"] = "dTwWQJRhb",
["parent"] = "Sno - Rogue Combo Points",
["preferToUpdate"] = true,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "unit",
["unevent"] = "auto",
["duration"] = "1",
["event"] = "Conditions",
["unit"] = "player",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["use_unit"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["discrete_rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 75,
["rotate"] = true,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["textureWrapMode"] = "CLAMP",
["source"] = "import",
["mirror"] = false,
["anchorFrameFrame"] = "WeakAuras:CP 1",
["regionType"] = "texture",
["blendMode"] = "BLEND",
["color"] = {
0,
0,
0,
1,
},
["xOffset"] = 0,
["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura73",
["authorOptions"] = {
},
["desc"] = "Rogue Combo Points - Classic WoW                                                              - created by Johadan                                                                                                                        - https://wago.io/p/Johadan#1650                                                                                         - Discord: https://discord.gg/QJs5SHH",
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "CP1BlackOutline",
["frameStrata"] = 3,
["alpha"] = 1,
["width"] = 75,
["anchorFrameType"] = "SELECTFRAME",
["uid"] = "s6HbQzHj7eh",
["config"] = {
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
},
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["rotation"] = 0,
},
["Simonize Meme Auras"] = {
["controlledChildren"] = {
"Storm That Is Approaching",
"Morbin Time",
"Praise the Sun",
"Dankmantle proc",
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "dTwWQJRhb",
["xOffset"] = 0,
["preferToUpdate"] = true,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["borderColor"] = {
0,
0,
0,
1,
},
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["unit"] = "player",
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["debuffType"] = "HELPFUL",
["event"] = "Health",
["names"] = {
},
},
["untrigger"] = {
},
},
},
["internalVersion"] = 78,
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["version"] = 24,
["subRegions"] = {
},
["load"] = {
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["backdropColor"] = {
1,
1,
1,
0.5,
},
["source"] = "import",
["scale"] = 1,
["border"] = false,
["borderEdge"] = "Square Full White",
["regionType"] = "group",
["borderSize"] = 2,
["borderInset"] = 1,
["borderOffset"] = 4,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Simonize Meme Auras",
["alpha"] = 1,
["frameStrata"] = 1,
["anchorFrameType"] = "SCREEN",
["authorOptions"] = {
},
["config"] = {
},
["uid"] = ")fB3UPTdxZA",
["parent"] = "Rogue Auras",
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
},
["selfPoint"] = "CENTER",
},
["Vanish Reminder"] = {
["iconSource"] = 1,
["wagoID"] = "dTwWQJRhb",
["authorOptions"] = {
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
["do_glow"] = false,
["glow_action"] = "hide",
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["track"] = "auto",
["duration"] = "3",
["genericShowOn"] = "showOnCooldown",
["names"] = {
},
["remaining"] = ".5",
["debuffType"] = "HELPFUL",
["type"] = "spell",
["use_debuffClass"] = true,
["subeventSuffix"] = "_CAST_START",
["remaining_operator"] = "<=",
["use_remaining"] = true,
["event"] = "Cooldown Ready (Spell)",
["use_exact_spellName"] = true,
["realSpellName"] = 1856,
["use_spellName"] = true,
["spellIds"] = {
},
["use_genericShowOn"] = true,
["spellName"] = 1856,
["subeventPrefix"] = "SPELL",
["use_track"] = true,
["unit"] = "player",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["track"] = "auto",
["duration"] = "3",
["genericShowOn"] = "showOnCooldown",
["unit"] = "player",
["remaining"] = ".5",
["debuffType"] = "HELPFUL",
["use_remaining"] = true,
["use_debuffClass"] = true,
["subeventSuffix"] = "_CAST_START",
["remaining_operator"] = "<=",
["type"] = "spell",
["event"] = "Cooldown Ready (Spell)",
["use_exact_spellName"] = true,
["realSpellName"] = 1857,
["use_spellName"] = true,
["spellIds"] = {
},
["use_genericShowOn"] = true,
["spellName"] = 1857,
["subeventPrefix"] = "SPELL",
["use_track"] = true,
["names"] = {
},
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = 0,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowLength"] = 10,
["glow"] = false,
["glowScale"] = 1,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 64,
["load"] = {
["use_class"] = true,
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["source"] = "import",
["cooldownTextDisabled"] = false,
["uid"] = "E0vd6cgy(hC",
["adjustedMax"] = "",
["xOffset"] = 0,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["information"] = {
},
["color"] = {
1,
1,
1,
1,
},
["parent"] = "Cooldown Reminders 2",
["cooldownEdge"] = false,
["anchorFrameType"] = "SCREEN",
["useCooldownModRate"] = true,
["zoom"] = 0,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Vanish Reminder",
["alpha"] = 0.5,
["frameStrata"] = 1,
["width"] = 64,
["icon"] = true,
["config"] = {
},
["inverse"] = false,
["animation"] = {
["start"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "shrink",
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "shrink",
["duration_type"] = "seconds",
},
},
["conditions"] = {
},
["cooldown"] = true,
["progressSource"] = {
-1,
"",
},
},
["Bolt 2"] = {
["user_y"] = 0,
["wagoID"] = "br2BQB5LA",
["xOffset"] = -79,
["preferToUpdate"] = false,
["yOffset"] = 20.587219238281,
["anchorPoint"] = "CENTER",
["desaturateBackground"] = false,
["compress"] = false,
["user_x"] = 0,
["sameTexture"] = true,
["url"] = "https://wago.io/br2BQB5LA/1",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["useStacks"] = true,
["auranames"] = {
"400574",
},
["ownOnly"] = true,
["event"] = "Health",
["subeventPrefix"] = "SPELL",
["useName"] = true,
["stacks"] = "2",
["spellIds"] = {
},
["stacksOperator"] = ">=",
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["unit"] = "player",
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["endAngle"] = 360,
["internalVersion"] = 78,
["color"] = {
0.97254908084869,
0.59215688705444,
1,
1,
},
["selfPoint"] = "CENTER",
["foregroundColor"] = {
0.88627457618713,
0.52156865596771,
1,
1,
},
["authorOptions"] = {
},
["backgroundColor"] = {
0.5,
0.5,
0.5,
0.5,
},
["desaturate"] = false,
["rotation"] = 0,
["font"] = "Friz Quadrata TT",
["version"] = 1,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 30,
["rotate"] = false,
["crop_y"] = 0.41,
["conditions"] = {
},
["useAdjustededMax"] = false,
["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
["source"] = "import",
["startAngle"] = 0,
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "Bolts Left",
["mirror"] = false,
["useAdjustededMin"] = false,
["regionType"] = "texture",
["fontSize"] = 12,
["blendMode"] = "BLEND",
["load"] = {
["use_class"] = true,
["use_spellknown"] = true,
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "MAGE",
["multi"] = {
},
},
["spellknown"] = 400574,
["size"] = {
["multi"] = {
},
},
},
["uid"] = "8wJ5T8G6(s1",
["slantMode"] = "INSIDE",
["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura45",
["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura2",
["frameStrata"] = 1,
["semver"] = "1.0.0",
["tocversion"] = 11500,
["id"] = "Bolt 2",
["anchorFrameType"] = "SCREEN",
["alpha"] = 0.58,
["width"] = 30,
["desaturateForeground"] = false,
["auraRotation"] = 0,
["inverse"] = false,
["config"] = {
},
["orientation"] = "VERTICAL",
["crop_x"] = 0.41,
["information"] = {
},
["backgroundOffset"] = 2,
},
["Player mana regen"] = {
["controlledChildren"] = {
"Mana - 2 Second Ticks",
"5 Second Rule Background - Regenerating",
"5 Second Rule Background - Not Regenerating Timer",
"5 Second Rule Background - Not Regenerating",
"Spirit Tap - Timer",
},
["borderBackdrop"] = "Blizzard Tooltip",
["xOffset"] = 3.4761962890625,
["preferToUpdate"] = false,
["yOffset"] = -0.6669921875,
["anchorPoint"] = "CENTER",
["borderColor"] = {
0,
0,
0,
1,
},
["url"] = "https://wago.io/mana-ticker/4",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["debuffType"] = "HELPFUL",
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["unit"] = "player",
["event"] = "Health",
["names"] = {
},
},
["untrigger"] = {
},
},
},
["internalVersion"] = 78,
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["desc"] = "Features:\n\n- Mana regen spark\n- 5 second rule timer\n- Spirit Tap proc timer\n- Attached to default player frame so it's plug and play (can be easily modified to any other unit frame mod)\n\nForked and modified from Classic Priest - with MP5 and Spirit Tap - Riv (https://wago.io/ixGev0rhd)",
["version"] = 4,
["subRegions"] = {
},
["load"] = {
["use_class"] = "false",
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["backdropColor"] = {
1,
1,
1,
0.5,
},
["source"] = "import",
["scale"] = 1,
["border"] = false,
["borderEdge"] = "1 Pixel",
["regionType"] = "group",
["borderSize"] = 2,
["borderOffset"] = 4,
["semver"] = "1.0.3",
["tocversion"] = 11306,
["id"] = "Player mana regen",
["borderInset"] = 1,
["frameStrata"] = 1,
["anchorFrameType"] = "SCREEN",
["authorOptions"] = {
},
["config"] = {
},
["alpha"] = 1,
["uid"] = "VhoF1uzX7bA",
["conditions"] = {
},
["information"] = {
["groupOffset"] = true,
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["selfPoint"] = "BOTTOMLEFT",
},
["Blood Fury 2 2"] = {
["iconSource"] = -1,
["wagoID"] = "dTwWQJRhb",
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["url"] = "https://wago.io/dTwWQJRhb/24",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["auranames"] = {
"20572",
},
["event"] = "Health",
["unit"] = "player",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["useName"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = true,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["border_size"] = 1,
["border_offset"] = 0,
["text_color"] = {
},
["border_color"] = {
0,
0,
0,
1,
},
["border_visible"] = true,
["border_edge"] = "Blizzard Chat Bubble",
["type"] = "subborder",
},
{
["text_text_format_p_time_format"] = 0,
["text_text"] = "%p",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["text_text_format_p_time_dynamic_threshold"] = 3,
["text_text_format_p_time_mod_rate"] = true,
["type"] = "subtext",
["text_text_format_p_format"] = "timed",
["text_color"] = {
1,
1,
1,
1,
},
["border_color"] = {
},
["text_font"] = "Gilroy Bold",
["text_shadowYOffset"] = 0,
["text_fontType"] = "OUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_anchorYOffset"] = 0,
["text_text_format_p_time_precision"] = 1,
["text_fontSize"] = 18,
["anchorXOffset"] = 0,
["text_text_format_p_time_legacy_floor"] = true,
},
},
["height"] = 30,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["width"] = 30,
["source"] = "import",
["adjustedMax"] = "",
["progressSource"] = {
-1,
"",
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["cooldownEdge"] = false,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "Simonize Rogue Non-Essential buffs",
["config"] = {
},
["cooldownTextDisabled"] = true,
["anchorFrameParent"] = false,
["useCooldownModRate"] = true,
["auto"] = true,
["zoom"] = 0,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Blood Fury 2 2",
["frameStrata"] = 1,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["uid"] = "Y88fg(T7D4F",
["inverse"] = false,
["xOffset"] = 0,
["conditions"] = {
},
["cooldown"] = false,
["authorOptions"] = {
},
},
["Offhand"] = {
["iconSource"] = 1,
["wagoID"] = "A3Z0KIoeL",
["parent"] = "General Auras",
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = -360,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["itemName"] = 0,
["itemTypeName"] = {
["multi"] = {
[527] = true,
},
},
["use_genericShowOn"] = true,
["genericShowOn"] = "showAlways",
["unit"] = "player",
["itemSlot"] = 17,
["remaining"] = "0",
["debuffType"] = "HELPFUL",
["use_unit"] = true,
["type"] = "item",
["use_itemTypeName"] = false,
["subeventSuffix"] = "_CAST_START",
["use_remaining"] = false,
["use_equipped"] = true,
["event"] = "Cooldown Progress (Equipment Slot)",
["use_itemName"] = true,
["use_itemSlot"] = true,
["use_itemSetId"] = true,
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["remaining_operator"] = ">=",
["matchesShowOn"] = "showAlways",
["names"] = {
},
["use_inverse"] = false,
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = false,
["glowLength"] = 10,
["glowLines"] = 8,
["glowBorder"] = false,
},
{
["border_size"] = 8,
["type"] = "subborder",
["border_color"] = {
1,
1,
1,
1,
},
["border_visible"] = true,
["border_edge"] = "Gladdy Tooltip round",
["border_offset"] = 0,
},
},
["height"] = 48,
["load"] = {
["use_never"] = true,
["talent"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["source"] = "import",
["cooldownTextDisabled"] = false,
["config"] = {
},
["adjustedMax"] = "",
["authorOptions"] = {
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["information"] = {
},
["cooldownEdge"] = false,
["xOffset"] = 20,
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["anchorFrameType"] = "SCREEN",
["frameStrata"] = 1,
["zoom"] = 0,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Offhand",
["useCooldownModRate"] = true,
["alpha"] = 1,
["width"] = 48,
["color"] = {
1,
1,
1,
1,
},
["uid"] = "jfJbcj5wNDa",
["inverse"] = false,
["icon"] = true,
["conditions"] = {
},
["cooldown"] = false,
["progressSource"] = {
-1,
"",
},
},
["SOD - BFD"] = {
["controlledChildren"] = {
"Shadow Crash Warning",
"Akumai Death Boon",
"Depth Charge",
"Dark Protection",
"Gelihast Shield",
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "A3Z0KIoeL",
["xOffset"] = 0,
["preferToUpdate"] = false,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["borderColor"] = {
0,
0,
0,
1,
},
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["unit"] = "player",
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["names"] = {
},
["event"] = "Health",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
},
["internalVersion"] = 78,
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["version"] = 19,
["subRegions"] = {
},
["load"] = {
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["talent"] = {
["multi"] = {
},
},
},
["backdropColor"] = {
1,
1,
1,
0.5,
},
["source"] = "import",
["scale"] = 1,
["border"] = false,
["borderEdge"] = "Square Full White",
["regionType"] = "group",
["borderSize"] = 2,
["parent"] = "General Auras",
["borderOffset"] = 4,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "SOD - BFD",
["selfPoint"] = "CENTER",
["frameStrata"] = 1,
["anchorFrameType"] = "SCREEN",
["authorOptions"] = {
},
["uid"] = "trVNSKiHSrA",
["config"] = {
},
["borderInset"] = 1,
["conditions"] = {
},
["information"] = {
},
["alpha"] = 1,
},
["5 Second Rule Background - Not Regenerating Timer"] = {
["sparkWidth"] = 6,
["iconSource"] = -1,
["xOffset"] = 0,
["preferToUpdate"] = false,
["yOffset"] = -6,
["anchorPoint"] = "BOTTOM",
["sparkRotation"] = 0,
["url"] = "https://wago.io/mana-ticker/4",
["backgroundColor"] = {
0.37647058823529,
0.37647058823529,
0.37647058823529,
0,
},
["fontFlags"] = "OUTLINE",
["icon_color"] = {
1,
1,
1,
1,
},
["enableGradient"] = false,
["selfPoint"] = "CENTER",
["barColor"] = {
0.37647058823529,
0.37647058823529,
0.37647058823529,
1,
},
["desaturate"] = false,
["sparkOffsetY"] = 0,
["gradientOrientation"] = "HORIZONTAL",
["load"] = {
["ingroup"] = {
["multi"] = {
},
},
["use_never"] = false,
["class"] = {
["single"] = "PRIEST",
["multi"] = {
["HUNTER"] = true,
["WARLOCK"] = true,
["SHAMAN"] = true,
["MAGE"] = true,
["DRUID"] = true,
["PRIEST"] = true,
},
},
["use_class"] = false,
["role"] = {
["multi"] = {
},
},
["use_spec"] = true,
["level"] = {
"2",
},
["size"] = {
["multi"] = {
},
},
["talent2"] = {
["multi"] = {
},
},
["use_level"] = true,
["talent"] = {
["single"] = 12,
["multi"] = {
[12] = true,
},
},
["spec"] = {
["single"] = 1,
["multi"] = {
[3] = true,
},
},
["difficulty"] = {
["multi"] = {
},
},
["faction"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["pvptalent"] = {
["multi"] = {
},
},
["level_operator"] = {
">",
},
["race"] = {
["multi"] = {
},
},
},
["smoothProgress"] = true,
["useAdjustededMin"] = false,
["regionType"] = "aurabar",
["texture"] = "ElvUI Norm",
["zoom"] = 0,
["auto"] = true,
["tocversion"] = 11306,
["alpha"] = 1,
["uid"] = "ZUOWeXsMIwz",
["sparkOffsetX"] = 0,
["parent"] = "Player mana regen",
["customText"] = "function()\n    local timeLeft = aura_env.state.duration\n    if timeLeft == 0 then\n        return \"\"\n    else\n        \n        return (\"%i\"):format(timeLeft)\n    end\nend\n\n\n\n\n",
["customTextUpdate"] = "update",
["triggers"] = {
{
["trigger"] = {
["duration"] = "2",
["use_unit"] = true,
["debuffType"] = "HELPFUL",
["type"] = "custom",
["unevent"] = "auto",
["names"] = {
},
["unit"] = "player",
["event"] = "Health",
["custom_type"] = "stateupdate",
["spellIds"] = {
},
["events"] = "PLAYER_ENTERING_WORLD, UNIT_SPELLCAST_SUCCEEDED, UNIT_MAXPOWER, CURRENT_SPELL_CAST_CHANGED",
["custom"] = "function(a, e, t)\n    local currentMana = UnitPower(\"player\" , 0)\n    \n    if e == \"UNIT_SPELLCAST_SUCCEEDED\" and currentMana < aura_env.lastMana and currentMana < UnitPowerMax(\"player\", 0) then\n        \n        aura_env.lastMana = currentMana\n        local duration = 5.5\n        a[\"\"] = {\n            show = true,\n            changed = true,\n            duration = duration,\n            expirationTime = GetTime() + duration,\n            progressType = \"timed\",\n            autoHide = true\n        }   \n        return true\n    end\n    \n    aura_env.lastMana = currentMana\n    return false\nend",
["use_sourceUnit"] = true,
["check"] = "event",
["subeventSuffix"] = "_ENERGIZE",
["sourceUnit"] = "player",
["subeventPrefix"] = "SPELL",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["useName"] = true,
["auranames"] = {
"Spirit Tap",
},
["matchesShowOn"] = "showOnMissing",
["event"] = "Health",
["unit"] = "player",
["subeventPrefix"] = "SPELL",
["type"] = "aura2",
["subeventSuffix"] = "_CAST_START",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["preset"] = "fade",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["preset"] = "shrink",
},
},
["backdropInFront"] = false,
["sparkMirror"] = false,
["stickyDuration"] = true,
["version"] = 4,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["type"] = "subforeground",
},
{
["text_text_format_p_time_format"] = 0,
["text_text"] = " %p",
["text_text_format_p_format"] = "timed",
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_p_time_legacy_floor"] = true,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["anchorYOffset"] = 0,
["type"] = "subtext",
["text_text_format_p_time_dynamic_threshold"] = 3,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Expressway",
["text_text_format_p_time_precision"] = 1,
["text_shadowYOffset"] = -1,
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_CENTER",
["text_shadowXOffset"] = 1,
["text_visible"] = false,
["text_fontSize"] = 13,
["anchorXOffset"] = 0,
["text_text_format_p_time_mod_rate"] = true,
},
{
["text_shadowXOffset"] = 1,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Myriad Condensed Web",
["text_shadowYOffset"] = -1,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "None",
["text_anchorPoint"] = "ICON_CENTER",
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_visible"] = false,
},
{
["border_offset"] = 1,
["border_size"] = 1,
["border_anchor"] = "bar",
["text_color"] = {
},
["border_color"] = {
0,
0,
0,
1,
},
["border_visible"] = true,
["border_edge"] = "1 Pixel",
["type"] = "subborder",
},
},
["height"] = 5,
["textureSource"] = "LSM",
["sparkBlendMode"] = "ADD",
["backdropColor"] = {
1,
1,
1,
0.5,
},
["source"] = "import",
["authorOptions"] = {
},
["barColor2"] = {
1,
1,
0,
1,
},
["config"] = {
},
["adjustedMax"] = "",
["anchorFrameFrame"] = "PlayerFrameManaBar",
["sparkColor"] = {
1,
1,
1,
1,
},
["borderInFront"] = true,
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["icon_side"] = "LEFT",
["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
["icon"] = false,
["sparkHeight"] = 15,
["anchorFrameType"] = "SELECTFRAME",
["sparkRotationMode"] = "AUTO",
["useAdjustededMax"] = false,
["semver"] = "1.0.3",
["sparkHidden"] = "BOTH",
["id"] = "5 Second Rule Background - Not Regenerating Timer",
["spark"] = true,
["frameStrata"] = 4,
["width"] = 114,
["color"] = {
},
["borderBackdrop"] = "Blizzard Tooltip",
["inverse"] = false,
["sparkDesature"] = false,
["orientation"] = "HORIZONTAL_INVERSE",
["conditions"] = {
{
["check"] = {
["trigger"] = -1,
["variable"] = "incombat",
["value"] = 0,
},
["changes"] = {
{
["value"] = 0.6,
["property"] = "alpha",
},
},
},
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["adjustedMin"] = "",
},
["Storm That Is Approaching"] = {
["wagoID"] = "dTwWQJRhb",
["xOffset"] = -287.40023803711,
["preferToUpdate"] = true,
["yOffset"] = -166.27157592773,
["anchorPoint"] = "CENTER",
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["spellId"] = {
"23864",
},
["duration"] = ".5",
["unit"] = "player",
["use_cloneId"] = true,
["debuffType"] = "HELPFUL",
["type"] = "combatlog",
["subeventSuffix"] = "_ENERGIZE",
["names"] = {
},
["event"] = "Combat Log",
["spellName"] = {
"Revitalize",
},
["use_spellId"] = true,
["use_spellName"] = false,
["spellIds"] = {
},
["use_sourceUnit"] = true,
["use_powerType"] = false,
["use_extraAmount"] = false,
["sourceUnit"] = "player",
["subeventPrefix"] = "SPELL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["discrete_rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 400,
["rotate"] = true,
["load"] = {
["use_class"] = true,
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
["source"] = "import",
["mirror"] = false,
["regionType"] = "texture",
["blendMode"] = "BLEND",
["frameStrata"] = 1,
["texture"] = "Interface\\Icons\\virgilstorm512.tga",
["color"] = {
1,
1,
1,
1,
},
["authorOptions"] = {
},
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Storm That Is Approaching",
["rotation"] = 0,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["uid"] = "spDBpu3gAfl",
["config"] = {
},
["parent"] = "Simonize Meme Auras",
["width"] = 400,
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
},
["animation"] = {
["start"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "shrink",
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "slideleft",
["duration_type"] = "seconds",
},
},
},
["Akumai Death Boon"] = {
["iconSource"] = 0,
["wagoID"] = "A3Z0KIoeL",
["authorOptions"] = {
},
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = 100.35,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["npcId"] = "213334",
["itemName"] = 0,
["spellId"] = {
426199,
},
["use_encounterName"] = false,
["duration"] = "15",
["genericShowOn"] = "showOnCooldown",
["subeventPrefix"] = "UNIT_DIED",
["destUnit"] = "player",
["use_unit"] = true,
["names"] = {
},
["use_genericShowOn"] = true,
["debuffType"] = "HELPFUL",
["unit"] = "player",
["type"] = "event",
["subeventSuffix"] = "",
["use_eventtype"] = true,
["event"] = "Encounter Events",
["encounterId"] = "2891",
["use_itemName"] = true,
["eventtype"] = "ENCOUNTER_END",
["use_npcId"] = true,
["use_spellId"] = true,
["spellIds"] = {
},
["use_sourceUnit"] = false,
["use_encounterId"] = true,
["use_destUnit"] = false,
["sourceUnit"] = "player",
["encounterName"] = "Aku'mai",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["type"] = "aura2",
["useExactSpellId"] = true,
["debuffType"] = "HELPFUL",
["auraspellids"] = {
"23768",
},
["unit"] = "player",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = 0,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = true,
["glowLength"] = 10,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 96,
["load"] = {
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["talent"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["anchorFrameType"] = "SCREEN",
["source"] = "import",
["cooldownEdge"] = false,
["adjustedMax"] = "",
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["cooldown"] = true,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["conditions"] = {
},
["icon"] = true,
["xOffset"] = -101.14,
["config"] = {
},
["alpha"] = 1,
["zoom"] = 0,
["cooldownTextDisabled"] = false,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Akumai Death Boon",
["useCooldownModRate"] = true,
["frameStrata"] = 1,
["width"] = 96,
["progressSource"] = {
-1,
"",
},
["uid"] = "vqC)puEvtBj",
["inverse"] = false,
["color"] = {
1,
1,
1,
1,
},
["displayIcon"] = "133879",
["information"] = {
},
["parent"] = "SOD - BFD",
},
["Barney Pull Timer-Title"] = {
["sparkWidth"] = 6,
["iconSource"] = -1,
["authorOptions"] = {
},
["displayText"] = "%p",
["yOffset"] = 130,
["anchorPoint"] = "CENTER",
["displayText_format_p_time_format"] = 0,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["icon"] = true,
["icon_color"] = {
1,
1,
1,
1,
},
["enableGradient"] = false,
["selfPoint"] = "BOTTOM",
["barColor"] = {
1,
1,
0.24705883860588,
1,
},
["desc"] = "This is a fork of [Cozroth]DBM/BigWigs PULL TIMER https://wago.io/-fj4L_nlD\n\nThis WA don't require you have to DBM / Bigwigs to display pull timers. For different versions of the came, look at the \"Actions\" > \"On Init\" > \"Custom Code\" tab for commented out text for all versions of the game. Default for this WA is Wrath of the Lichking Classic.",
["rotation"] = 0,
["font"] = "默认",
["sparkOffsetY"] = 0,
["gradientOrientation"] = "HORIZONTAL",
["load"] = {
["ingroup"] = {
["single"] = "raid",
["multi"] = {
["group"] = true,
["raid"] = true,
},
},
["use_zoneIds"] = false,
["instance_type"] = {
},
["group_leader"] = {
},
["class"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["use_encounterid"] = false,
["difficulty"] = {
},
["use_zone"] = false,
["use_never"] = false,
["spec"] = {
["multi"] = {
},
},
["talent"] = {
["multi"] = {
},
},
["zone"] = "",
["use_ingroup"] = false,
["size"] = {
["multi"] = {
["party"] = true,
["flexible"] = true,
["ten"] = true,
["twentyfive"] = true,
["fortyman"] = true,
["twenty"] = true,
},
},
},
["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
["shadowXOffset"] = 0,
["useAdjustededMin"] = false,
["regionType"] = "texture",
["blendMode"] = "BLEND",
["sparkDesaturate"] = true,
["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
["spark"] = true,
["tocversion"] = 11500,
["alpha"] = 1,
["sparkColor"] = {
1,
1,
1,
1,
},
["fixedWidth"] = 200,
["outline"] = "OUTLINE",
["sparkOffsetX"] = 0,
["wagoID"] = "A3Z0KIoeL",
["color"] = {
1,
1,
0,
1,
},
["shadowYOffset"] = 0,
["customTextUpdate"] = "event",
["automaticWidth"] = "Auto",
["triggers"] = {
{
["trigger"] = {
["dynamicDuration"] = true,
["debuffType"] = "HELPFUL",
["type"] = "custom",
["custom_hide"] = "timed",
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["unit"] = "player",
["event"] = "Health",
["custom"] = "function(a, event, duration, pull)\n    if event == \"PULLTIMER_START\" then\n        aura_env.timed(a, \"\", duration)\n        if pull then\n            a[\"\"].name = aura_env.text1\n        else\n            a[\"\"].name = aura_env.text2\n        end\n        a[\"\"].pull = pull\n        return true\n        \n    elseif event == \"PULLTIMER_END\" then\n        aura_env.off(a, \"\")\n        return true\n    end\nend",
["customDuration"] = "function()\n    if WeakAuras.IsOptionsOpen() then\n        return 1337, 1337, true\n    else\n        local duration, expirationTime = aura_env.duration, GetTime() + aura_env.duration\n        return duration, expirationTime\n    end\nend\n\n\n",
["customName"] = "function()\n    if WeakAuras.IsOptionsOpen() then\n        return \"PULL\"\n    else\n        return aura_env.name\n    end\nend",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["check"] = "event",
["events"] = "PULLTIMER_START,PULLTIMER_END",
["custom_type"] = "stateupdate",
["customVariables"] = "{\n    expirationTime = true,\n    pull = \"bool\",\n}",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["type"] = "unit",
["use_incombat"] = false,
["unit"] = "player",
["debuffType"] = "HELPFUL",
["use_alive"] = true,
["event"] = "Conditions",
["use_unit"] = true,
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["displayText_format_p_format"] = "timed",
["displayText_format_p_time_legacy_floor"] = false,
["animation"] = {
["start"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["preset"] = "grow",
},
["main"] = {
["colorR"] = 1,
["duration"] = "100%",
["alphaType"] = "custom",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    if aura_env.state.pull and aura_env.state.expirationTime - GetTime() <= 10 then\n        local angle = ((aura_env.state.expirationTime - GetTime()) % 1 * 2 * math.pi) - (math.pi / 2)\n        return start + (((math.sin(angle) + 1)/2) * delta)\n    end\nend",
["use_translate"] = false,
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "easeOutIn",
["translateFunc"] = "",
["scaley"] = 1,
["alpha"] = 0.5,
["scalex"] = 1,
["y"] = 20,
["x"] = 0,
["duration_type"] = "relative",
["rotate"] = 0,
["translateType"] = "custom",
["easeStrength"] = 5,
["preset"] = "bounce",
["colorB"] = 1,
},
["finish"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["preset"] = "grow",
},
},
["parent"] = "Barney Raid Kit - Pull Timer",
["information"] = {
["forceEvents"] = false,
["ignoreOptionsEventErrors"] = true,
},
["sparkRotationMode"] = "AUTO",
["orientation"] = "HORIZONTAL",
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_text_format_n_format"] = "none",
["text_text"] = "%n",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
0,
0,
0,
1,
},
["text_font"] = "默认",
["text_shadowYOffset"] = 0,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "None",
["text_anchorPoint"] = "CENTER",
["text_shadowXOffset"] = 0,
["text_fontSize"] = 40,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
},
["height"] = 60,
["rotate"] = false,
["config"] = {
},
["sparkBlendMode"] = "ADD",
["useAdjustededMax"] = false,
["fontSize"] = 80,
["source"] = "import",
["displayText_format_n_format"] = "none",
["displayText_format_p_time_mod_rate"] = true,
["displayText_format_p_time_dynamic_threshold"] = 0,
["mirror"] = false,
["uid"] = "ExRnxtRO4dx",
["anchorFrameType"] = "SCREEN",
["zoom"] = 0,
["xOffset"] = 0,
["icon_side"] = "LEFT",
["id"] = "Barney Pull Timer-Title",
["actions"] = {
["start"] = {
["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\AcousticGuitar.ogg",
["do_sound"] = false,
},
["finish"] = {
["custom"] = "",
["do_custom"] = false,
["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Glass.mp3",
["do_sound"] = false,
},
["init"] = {
["custom"] = "if GetLocale() == \"zhCN\" then\n    aura_env.text1 = \"开怪\"\n    aura_env.text2 = \"休息\"\nelse\n    aura_env.text1 = \"PULL\"\n    aura_env.text2 = \"BREAK\"\nend\n\naura_env.timed = function(a, aid, duration)\n    a[aid] = {\n        show = true,\n        changed = true,\n        autoHide = true,\n        progressType = \"timed\",\n        duration = duration,\n        expirationTime = duration + GetTime(),\n    }\nend\n\naura_env.off = function(a, aid)\n    a[aid] = {\n        show = false,\n    }\nend",
["do_custom"] = true,
},
},
["sparkHeight"] = 45,
["semver"] = "1.0.18",
["backgroundColor"] = {
0,
0,
0,
0.5,
},
["internalVersion"] = 78,
["justify"] = "CENTER",
["displayText_format_p_time_precision"] = 1,
["sparkHidden"] = "BOTH",
["desaturate"] = false,
["frameStrata"] = 6,
["width"] = 300,
["wordWrap"] = "WordWrap",
["displayIcon"] = 132349,
["inverse"] = true,
["sparkRotation"] = 0,
["shadowColor"] = {
0,
0,
0,
1,
},
["conditions"] = {
{
["check"] = {
["trigger"] = -2,
["variable"] = "AND",
["checks"] = {
{
["trigger"] = 1,
["variable"] = "pull",
["value"] = 1,
},
{
["trigger"] = 1,
["op"] = "<=",
["value"] = "10",
["variable"] = "expirationTime",
},
},
},
["changes"] = {
{
["value"] = {
1,
0.49803924560547,
0,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = -2,
["variable"] = "AND",
["checks"] = {
{
["trigger"] = 1,
["variable"] = "pull",
["value"] = 1,
},
{
["trigger"] = 1,
["op"] = "<=",
["value"] = "3",
["variable"] = "expirationTime",
},
},
},
["changes"] = {
{
["value"] = {
1,
0,
0,
1,
},
["property"] = "color",
},
},
},
{
["check"] = {
["trigger"] = -2,
["variable"] = "AND",
["checks"] = {
{
["trigger"] = 1,
["variable"] = "pull",
["value"] = 0,
},
{
["trigger"] = 1,
["op"] = ">",
["value"] = "60",
["variable"] = "expirationTime",
},
},
},
["changes"] = {
{
["value"] = {
0,
1,
0,
1,
},
["property"] = "color",
},
},
},
},
["barColor2"] = {
1,
1,
0,
1,
},
["preferToUpdate"] = false,
},
["CP5BlackOutline"] = {
["wagoID"] = "dTwWQJRhb",
["parent"] = "Sno - Rogue Combo Points",
["preferToUpdate"] = true,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "unit",
["unevent"] = "auto",
["duration"] = "1",
["event"] = "Conditions",
["unit"] = "player",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["use_unit"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["discrete_rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 75,
["rotate"] = true,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["textureWrapMode"] = "CLAMP",
["source"] = "import",
["mirror"] = false,
["anchorFrameFrame"] = "WeakAuras:CP 5",
["regionType"] = "texture",
["blendMode"] = "BLEND",
["color"] = {
0,
0,
0,
1,
},
["xOffset"] = 0,
["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura73",
["authorOptions"] = {
},
["desc"] = "Rogue Combo Points - Classic WoW                                                              - created by Johadan                                                                                                                        - https://wago.io/p/Johadan#1650                                                                                         - Discord: https://discord.gg/QJs5SHH",
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "CP5BlackOutline",
["frameStrata"] = 3,
["alpha"] = 1,
["width"] = 75,
["anchorFrameType"] = "SELECTFRAME",
["uid"] = "hiv(HBHvAg9",
["config"] = {
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
},
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["rotation"] = 0,
},
["Sprint"] = {
["iconSource"] = -1,
["wagoID"] = "dTwWQJRhb",
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["url"] = "https://wago.io/dTwWQJRhb/24",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["auranames"] = {
"8696",
},
["event"] = "Health",
["unit"] = "player",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["useName"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = true,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["border_size"] = 1,
["border_offset"] = 0,
["text_color"] = {
},
["border_color"] = {
0,
0,
0,
1,
},
["border_visible"] = true,
["border_edge"] = "Blizzard Chat Bubble",
["type"] = "subborder",
},
{
["text_text_format_p_time_format"] = 0,
["text_text"] = "%p",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["text_text_format_p_time_dynamic_threshold"] = 3,
["text_text_format_p_time_mod_rate"] = true,
["type"] = "subtext",
["text_text_format_p_format"] = "timed",
["text_color"] = {
1,
1,
1,
1,
},
["border_color"] = {
},
["text_font"] = "Gilroy Bold",
["text_shadowYOffset"] = 0,
["text_fontType"] = "OUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_anchorYOffset"] = 0,
["text_text_format_p_time_precision"] = 1,
["text_fontSize"] = 18,
["anchorXOffset"] = 0,
["text_text_format_p_time_legacy_floor"] = true,
},
},
["height"] = 30,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["width"] = 30,
["source"] = "import",
["adjustedMax"] = "",
["progressSource"] = {
-1,
"",
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["cooldownEdge"] = false,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "Simonize Rogue Non-Essential buffs",
["config"] = {
},
["cooldownTextDisabled"] = true,
["anchorFrameParent"] = false,
["useCooldownModRate"] = true,
["auto"] = true,
["zoom"] = 0,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Sprint",
["frameStrata"] = 1,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["uid"] = "SVbkHLdrwCv",
["inverse"] = false,
["xOffset"] = 0,
["conditions"] = {
},
["cooldown"] = false,
["authorOptions"] = {
},
},
["Cast - Bar"] = {
["sparkWidth"] = 10,
["iconSource"] = -1,
["wagoID"] = "A3Z0KIoeL",
["authorOptions"] = {
},
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = -290.76553344727,
["anchorPoint"] = "CENTER",
["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
["sparkOffsetX"] = 0,
["sparkRotation"] = 0,
["sparkRotationMode"] = "AUTO",
["url"] = "https://wago.io/A3Z0KIoeL/19",
["backgroundColor"] = {
0,
0,
0,
0.30000001192093,
},
["triggers"] = {
{
["trigger"] = {
["use_inverse"] = false,
["genericShowOn"] = "showOnCooldown",
["names"] = {
},
["powertype"] = 6,
["use_powertype"] = true,
["debuffType"] = "HELPFUL",
["type"] = "unit",
["spellName"] = 0,
["unevent"] = "auto",
["subeventSuffix"] = "_CAST_START",
["use_unit"] = true,
["event"] = "Cast",
["subeventPrefix"] = "SPELL",
["realSpellName"] = 0,
["use_spellName"] = true,
["spellIds"] = {
},
["use_genericShowOn"] = true,
["unit"] = "player",
["use_absorbMode"] = true,
["use_track"] = true,
["duration"] = "1",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["customTriggerLogic"] = "",
["activeTriggerMode"] = 1,
},
["icon_color"] = {
1,
1,
1,
1,
},
["enableGradient"] = false,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["xOffset"] = 3.6423950195313,
["adjustedMax"] = "",
["barColor"] = {
0.71372549019608,
0.16078431372549,
0.16078431372549,
1,
},
["desaturate"] = false,
["parent"] = "General Auras",
["icon"] = false,
["version"] = 19,
["subRegions"] = {
{
["type"] = "subforeground",
},
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 1,
["text_text"] = "%p",
["text_text_format_p_time_mod_rate"] = true,
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_p_time_legacy_floor"] = true,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_text_format_p_format"] = "timed",
["type"] = "subtext",
["text_text_format_p_time_dynamic_threshold"] = 60,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_text_format_p_time_precision"] = 1,
["text_shadowYOffset"] = -1,
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_RIGHT",
["anchorYOffset"] = 0,
["text_visible"] = true,
["text_fontSize"] = 13,
["anchorXOffset"] = 0,
["text_text_format_p_time_format"] = 0,
},
{
["text_text_format_n_format"] = "none",
["text_text"] = "%n",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = -1,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_LEFT",
["text_shadowXOffset"] = 1,
["text_fontSize"] = 13,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
},
["gradientOrientation"] = "HORIZONTAL",
["textureSource"] = "LSM",
["load"] = {
["size"] = {
["multi"] = {
},
},
["race"] = {
},
["use_never"] = true,
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
["ROGUE"] = true,
},
},
["role"] = {
["single"] = "DAMAGER",
["multi"] = {
["DAMAGER"] = true,
},
},
["zoneIds"] = "",
},
["sparkBlendMode"] = "ADD",
["useAdjustededMax"] = false,
["internalVersion"] = 78,
["source"] = "import",
["selfPoint"] = "CENTER",
["auto"] = true,
["barColor2"] = {
1,
1,
0,
1,
},
["smoothProgress"] = true,
["useAdjustededMin"] = false,
["regionType"] = "aurabar",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
["custom"] = "CastingBarFrame:UnregisterAllEvents()",
["do_custom"] = true,
},
},
["sparkOffsetY"] = -25,
["icon_side"] = "LEFT",
["height"] = 17.629579544067,
["semver"] = "1.0.18",
["sparkHeight"] = 30,
["texture"] = "Solid",
["config"] = {
},
["zoom"] = 0,
["spark"] = true,
["tocversion"] = 11500,
["id"] = "Cast - Bar",
["anchorFrameType"] = "SCREEN",
["frameStrata"] = 4,
["width"] = 296,
["sparkHidden"] = "BOTH",
["sparkColor"] = {
1,
1,
1,
1,
},
["inverse"] = false,
["alpha"] = 1,
["orientation"] = "HORIZONTAL",
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["uid"] = "Rhn0lhVGHfi",
},
["Cold Blood Reminder"] = {
["iconSource"] = 1,
["wagoID"] = "dTwWQJRhb",
["authorOptions"] = {
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
["do_glow"] = false,
["glow_action"] = "hide",
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["track"] = "auto",
["duration"] = "3",
["genericShowOn"] = "showOnCooldown",
["names"] = {
},
["remaining"] = ".5",
["debuffType"] = "HELPFUL",
["type"] = "spell",
["use_debuffClass"] = true,
["subeventSuffix"] = "_CAST_START",
["remaining_operator"] = "<=",
["use_remaining"] = true,
["event"] = "Cooldown Ready (Spell)",
["use_exact_spellName"] = true,
["realSpellName"] = 14177,
["use_spellName"] = true,
["spellIds"] = {
},
["use_genericShowOn"] = true,
["spellName"] = 14177,
["subeventPrefix"] = "SPELL",
["use_track"] = true,
["unit"] = "player",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = 0,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowLength"] = 10,
["glow"] = false,
["glowScale"] = 1,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 64,
["load"] = {
["use_class"] = true,
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["source"] = "import",
["cooldownTextDisabled"] = false,
["uid"] = "AYNL4PSU1Vk",
["adjustedMax"] = "",
["xOffset"] = 0,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["information"] = {
},
["color"] = {
1,
1,
1,
1,
},
["parent"] = "Cooldown Reminders 2",
["cooldownEdge"] = false,
["anchorFrameType"] = "SCREEN",
["useCooldownModRate"] = true,
["zoom"] = 0,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Cold Blood Reminder",
["alpha"] = 0.5,
["frameStrata"] = 1,
["width"] = 64,
["icon"] = true,
["config"] = {
},
["inverse"] = false,
["animation"] = {
["start"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "shrink",
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "shrink",
["duration_type"] = "seconds",
},
},
["conditions"] = {
},
["cooldown"] = true,
["progressSource"] = {
-1,
"",
},
},
["Arcane Blast"] = {
["controlledChildren"] = {
"Bolts Left",
"Timer",
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "br2BQB5LA",
["xOffset"] = 0,
["preferToUpdate"] = false,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["borderColor"] = {
0,
0,
0,
1,
},
["url"] = "https://wago.io/br2BQB5LA/1",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["names"] = {
},
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["unit"] = "player",
["event"] = "Health",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
},
["internalVersion"] = 78,
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["version"] = 1,
["subRegions"] = {
},
["load"] = {
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["backdropColor"] = {
1,
1,
1,
0.5,
},
["source"] = "import",
["scale"] = 1,
["border"] = false,
["borderEdge"] = "Square Full White",
["regionType"] = "group",
["borderSize"] = 2,
["borderInset"] = 1,
["borderOffset"] = 4,
["semver"] = "1.0.0",
["tocversion"] = 11500,
["id"] = "Arcane Blast",
["groupIcon"] = 135735,
["frameStrata"] = 4,
["anchorFrameType"] = "SCREEN",
["selfPoint"] = "CENTER",
["config"] = {
},
["uid"] = "Y(u1BQFFK5c",
["authorOptions"] = {
},
["conditions"] = {
},
["information"] = {
},
["alpha"] = 1,
},
["fingers"] = {
["iconSource"] = -1,
["color"] = {
1,
1,
1,
1,
},
["adjustedMax"] = "",
["adjustedMin"] = "",
["yOffset"] = -22.46359252929688,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["cooldownEdge"] = false,
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["subeventSuffix"] = "_CAST_START",
["event"] = "Health",
["subeventPrefix"] = "SPELL",
["spellIds"] = {
},
["auranames"] = {
"Fingers of Frost",
},
["useName"] = true,
["names"] = {
},
["unit"] = "player",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = 0,
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
["text_fontSize"] = 29,
["anchorXOffset"] = 0,
["text_fontType"] = "OUTLINE",
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["useGlowColor"] = false,
["glowType"] = "buttonOverlay",
["glowLength"] = 10,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["glowDuration"] = 1,
["glowXOffset"] = 0,
["glow"] = false,
["glowScale"] = 1,
["glowThickness"] = 1,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 44.92708969116211,
["load"] = {
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["talent"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["cooldown"] = true,
["xOffset"] = -159.8496704101563,
["progressSource"] = {
-1,
"",
},
["authorOptions"] = {
},
["zoom"] = 0,
["cooldownTextDisabled"] = true,
["frameStrata"] = 1,
["config"] = {
},
["id"] = "fingers",
["width"] = 49.46799468994141,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["useCooldownModRate"] = true,
["uid"] = "VROXbRDAX0j",
["inverse"] = false,
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["conditions"] = {
},
["information"] = {
},
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
},
["Morbin Time"] = {
["wagoID"] = "dTwWQJRhb",
["xOffset"] = -371.35757446289,
["preferToUpdate"] = true,
["yOffset"] = 51.357849121094,
["anchorPoint"] = "CENTER",
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "combatlog",
["subeventSuffix"] = "_AURA_APPLIED",
["duration"] = "3",
["event"] = "Combat Log",
["unit"] = "player",
["debuffType"] = "HELPFUL",
["use_spellName"] = true,
["spellIds"] = {
},
["use_sourceUnit"] = true,
["subeventPrefix"] = "SPELL",
["names"] = {
},
["sourceUnit"] = "player",
["spellName"] = {
"Felstriker",
},
},
["untrigger"] = {
},
},
{
["trigger"] = {
["type"] = "combatlog",
["subeventSuffix"] = "_AURA_REFRESH",
["duration"] = "3",
["event"] = "Combat Log",
["unit"] = "player",
["use_spellName"] = true,
["use_sourceUnit"] = true,
["debuffType"] = "HELPFUL",
["subeventPrefix"] = "SPELL",
["sourceUnit"] = "player",
["spellName"] = {
"Felstriker",
},
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["discrete_rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 400,
["rotate"] = true,
["load"] = {
["use_class"] = true,
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
["source"] = "import",
["mirror"] = false,
["regionType"] = "texture",
["blendMode"] = "BLEND",
["frameStrata"] = 1,
["texture"] = "Interface\\Icons\\itsmorbintimesticker512.tga",
["color"] = {
1,
1,
1,
1,
},
["authorOptions"] = {
},
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Morbin Time",
["rotation"] = 0,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["uid"] = "VFiu1Gn9kqz",
["config"] = {
},
["parent"] = "Simonize Meme Auras",
["width"] = 400,
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
},
["animation"] = {
["start"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "shrink",
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "pulse",
["duration_type"] = "seconds",
},
["finish"] = {
["type"] = "none",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "fade",
["duration_type"] = "seconds",
},
},
},
["Rockbiter"] = {
["grow"] = "DOWN",
["controlledChildren"] = {
"RockbiterIcon",
"RockbiterCDText",
},
["borderBackdrop"] = "Blizzard Tooltip",
["xOffset"] = -508.9997863769531,
["preferToUpdate"] = false,
["yOffset"] = 77.5555419921875,
["gridType"] = "RD",
["fullCircle"] = true,
["rowSpace"] = 1,
["url"] = "https://wago.io/RrBFPkRTq/4",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["debuffType"] = "HELPFUL",
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["subeventPrefix"] = "SPELL",
["event"] = "Health",
["unit"] = "player",
},
["untrigger"] = {
},
},
},
["columnSpace"] = 1,
["internalVersion"] = 78,
["useLimit"] = false,
["align"] = "CENTER",
["config"] = {
},
["frameStrata"] = 1,
["anchorPoint"] = "CENTER",
["stagger"] = 0,
["animation"] = {
["start"] = {
["duration_type"] = "seconds",
["type"] = "none",
["easeStrength"] = 3,
["easeType"] = "none",
},
["main"] = {
["duration_type"] = "seconds",
["type"] = "none",
["easeStrength"] = 3,
["easeType"] = "none",
},
["finish"] = {
["duration_type"] = "seconds",
["type"] = "none",
["easeStrength"] = 3,
["easeType"] = "none",
},
},
["version"] = 4,
["subRegions"] = {
},
["authorOptions"] = {
},
["sortHybridTable"] = {
["RockbiterIcon"] = false,
["RockbiterCDText"] = false,
},
["load"] = {
["use_class"] = "true",
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "SHAMAN",
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["borderColor"] = {
0,
0,
0,
1,
},
["backdropColor"] = {
1,
1,
1,
0.5,
},
["radius"] = 200,
["source"] = "import",
["borderInset"] = 1,
["scale"] = 1,
["centerType"] = "LR",
["border"] = false,
["borderEdge"] = "1 Pixel",
["stepAngle"] = 15,
["borderSize"] = 2,
["limit"] = 5,
["sort"] = "none",
["animate"] = false,
["constantFactor"] = "RADIUS",
["gridWidth"] = 5,
["borderOffset"] = 4,
["semver"] = "1.0.3",
["tocversion"] = 11302,
["id"] = "Rockbiter",
["rotation"] = 0,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["regionType"] = "dynamicgroup",
["uid"] = "HDvQW)hw2qE",
["arcLength"] = 360,
["selfPoint"] = "TOP",
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["space"] = 2,
},
["Barney Raid Kit - Pull Timer"] = {
["controlledChildren"] = {
"Barney Pull Timer-Texture",
"Barney Pull Timer-Timer",
"Barney Pull Timer-Title",
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "A3Z0KIoeL",
["parent"] = "General Auras",
["preferToUpdate"] = false,
["yOffset"] = 140,
["anchorPoint"] = "CENTER",
["borderColor"] = {
0,
0,
0,
1,
},
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["unit"] = "player",
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["names"] = {
},
["event"] = "Health",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
},
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["version"] = 19,
["subRegions"] = {
},
["load"] = {
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["talent"] = {
["multi"] = {
},
},
},
["backdropColor"] = {
1,
1,
1,
0.5,
},
["source"] = "import",
["scale"] = 1,
["border"] = false,
["borderEdge"] = "Square Full White",
["regionType"] = "group",
["borderSize"] = 2,
["uid"] = "ex(vRZchOfR",
["groupIcon"] = 132337,
["borderOffset"] = 4,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Barney Raid Kit - Pull Timer",
["frameStrata"] = 1,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["xOffset"] = 0,
["config"] = {
},
["borderInset"] = 1,
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["conditions"] = {
},
["information"] = {
},
["authorOptions"] = {
},
},
["regen Group"] = {
["backdropColor"] = {
1,
1,
1,
0.5,
},
["controlledChildren"] = {
"mana regen",
"food regen",
},
["borderBackdrop"] = "Blizzard Tooltip",
["xOffset"] = -101,
["information"] = {
},
["border"] = false,
["yOffset"] = -177.1047973632813,
["regionType"] = "group",
["borderSize"] = 2,
["borderEdge"] = "Square Full White",
["borderColor"] = {
0,
0,
0,
1,
},
["scale"] = 1,
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["debuffType"] = "HELPFUL",
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["unit"] = "player",
["subeventPrefix"] = "SPELL",
["event"] = "Health",
["names"] = {
},
},
["untrigger"] = {
},
},
},
["anchorPoint"] = "CENTER",
["borderOffset"] = 4,
["selfPoint"] = "CENTER",
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["id"] = "regen Group",
["internalVersion"] = 78,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["uid"] = "7p3Axh)AxQF",
["config"] = {
},
["borderInset"] = 1,
["frameStrata"] = 1,
["conditions"] = {
},
["load"] = {
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["authorOptions"] = {
},
},
["CP2YellowOutline GCD"] = {
["user_y"] = 0,
["user_x"] = 0,
["authorOptions"] = {
},
["preferToUpdate"] = true,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["sameTexture"] = true,
["url"] = "https://wago.io/dTwWQJRhb/24",
["backgroundColor"] = {
0.23921568627451,
0.23921568627451,
0.23921568627451,
0,
},
["selfPoint"] = "CENTER",
["desaturate"] = false,
["rotation"] = 0,
["font"] = "Friz Quadrata TT",
["crop_y"] = 0,
["textureWrapMode"] = "CLAMP",
["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura73",
["smoothProgress"] = false,
["useAdjustededMin"] = false,
["regionType"] = "progresstexture",
["blendMode"] = "BLEND",
["slantMode"] = "INSIDE",
["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura73",
["compress"] = false,
["alpha"] = 1,
["uid"] = "Ajh4dVnfpYV",
["backgroundOffset"] = 0,
["wagoID"] = "dTwWQJRhb",
["parent"] = "Sno - Rogue Combo Points",
["adjustedMin"] = "",
["desaturateBackground"] = false,
["desaturateForeground"] = false,
["triggers"] = {
{
["trigger"] = {
["type"] = "spell",
["unevent"] = "auto",
["duration"] = "1",
["event"] = "Global Cooldown",
["unit"] = "player",
["subeventPrefix"] = "SPELL",
["spellIds"] = {
},
["use_inverse"] = false,
["use_unit"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["type"] = "unit",
["use_alwaystrue"] = true,
["subeventSuffix"] = "_CAST_START",
["duration"] = "1",
["event"] = "Conditions",
["use_unit"] = true,
["unevent"] = "auto",
["subeventPrefix"] = "SPELL",
["unit"] = "player",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["endAngle"] = 360,
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
},
["discrete_rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 63,
["rotate"] = true,
["useAdjustededMax"] = false,
["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
["source"] = "import",
["foregroundColor"] = {
0.84705882352941,
0.89019607843137,
0.87843137254902,
1,
},
["mirror"] = false,
["anchorFrameFrame"] = "WeakAuras:CP 2",
["color"] = {
1,
0.91764705882353,
0,
1,
},
["auraRotation"] = 0,
["crop_x"] = 0,
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["config"] = {
},
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["startAngle"] = 0,
["semver"] = "1.0.23",
["width"] = 63,
["id"] = "CP2YellowOutline GCD",
["fontSize"] = 12,
["frameStrata"] = 4,
["anchorFrameType"] = "SELECTFRAME",
["tocversion"] = 30403,
["desc"] = "Rogue Combo Points - Classic WoW                                                              - created by Johadan                                                                                                                        - https://wago.io/p/Johadan#1650                                                                                         - Discord: https://discord.gg/QJs5SHH",
["inverse"] = true,
["xOffset"] = 0,
["orientation"] = "CLOCKWISE",
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["adjustedMax"] = "",
},
["Adrenaline Rush Reminder"] = {
["iconSource"] = 1,
["wagoID"] = "dTwWQJRhb",
["authorOptions"] = {
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
["do_glow"] = false,
["glow_action"] = "hide",
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["track"] = "auto",
["duration"] = "3",
["genericShowOn"] = "showOnCooldown",
["names"] = {
},
["remaining"] = ".5",
["debuffType"] = "HELPFUL",
["type"] = "spell",
["use_debuffClass"] = true,
["subeventSuffix"] = "_CAST_START",
["remaining_operator"] = "<=",
["use_remaining"] = true,
["event"] = "Cooldown Ready (Spell)",
["use_exact_spellName"] = true,
["realSpellName"] = 13750,
["use_spellName"] = true,
["spellIds"] = {
},
["use_genericShowOn"] = true,
["spellName"] = 13750,
["subeventPrefix"] = "SPELL",
["use_track"] = true,
["unit"] = "player",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = 0,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowLength"] = 10,
["glow"] = false,
["glowScale"] = 1,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 64,
["load"] = {
["use_class"] = true,
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["source"] = "import",
["cooldownTextDisabled"] = false,
["uid"] = "iSZ14ScIGqb",
["adjustedMax"] = "",
["xOffset"] = 0,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["information"] = {
},
["color"] = {
1,
1,
1,
1,
},
["parent"] = "Cooldown Reminders 2",
["cooldownEdge"] = false,
["anchorFrameType"] = "SCREEN",
["useCooldownModRate"] = true,
["zoom"] = 0,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Adrenaline Rush Reminder",
["alpha"] = 0.5,
["frameStrata"] = 1,
["width"] = 64,
["icon"] = true,
["config"] = {
},
["inverse"] = false,
["animation"] = {
["start"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "shrink",
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["preset"] = "shrink",
["duration_type"] = "seconds",
},
},
["conditions"] = {
},
["cooldown"] = true,
["progressSource"] = {
-1,
"",
},
},
["Blade Flurry"] = {
["iconSource"] = -1,
["wagoID"] = "dTwWQJRhb",
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["url"] = "https://wago.io/dTwWQJRhb/24",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["auranames"] = {
"13877",
},
["event"] = "Health",
["unit"] = "player",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["useName"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = true,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["border_size"] = 1,
["border_offset"] = 0,
["text_color"] = {
},
["border_color"] = {
0,
0,
0,
1,
},
["border_visible"] = true,
["border_edge"] = "Blizzard Chat Bubble",
["type"] = "subborder",
},
{
["text_text_format_p_time_format"] = 0,
["text_text"] = "%p",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["text_text_format_p_time_dynamic_threshold"] = 3,
["text_text_format_p_time_mod_rate"] = true,
["type"] = "subtext",
["text_text_format_p_format"] = "timed",
["text_color"] = {
1,
1,
1,
1,
},
["border_color"] = {
},
["text_font"] = "Gilroy Bold",
["text_shadowYOffset"] = 0,
["text_fontType"] = "OUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_anchorYOffset"] = 0,
["text_text_format_p_time_precision"] = 1,
["text_fontSize"] = 18,
["anchorXOffset"] = 0,
["text_text_format_p_time_legacy_floor"] = true,
},
},
["height"] = 30,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["width"] = 30,
["source"] = "import",
["adjustedMax"] = "",
["progressSource"] = {
-1,
"",
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["cooldownEdge"] = false,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "Simonize Rogue Non-Essential buffs",
["config"] = {
},
["cooldownTextDisabled"] = true,
["anchorFrameParent"] = false,
["useCooldownModRate"] = true,
["auto"] = true,
["zoom"] = 0,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Blade Flurry",
["frameStrata"] = 1,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["uid"] = "F5XybAOfYYl",
["inverse"] = false,
["xOffset"] = 0,
["conditions"] = {
},
["cooldown"] = false,
["authorOptions"] = {
},
},
["RBW Group"] = {
["grow"] = "UP",
["controlledChildren"] = {
"RBW icon RH",
"RBW icon LH",
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "7-GPE9UP7",
["authorOptions"] = {
},
["preferToUpdate"] = false,
["yOffset"] = -250.2221221923828,
["anchorPoint"] = "CENTER",
["fullCircle"] = true,
["rowSpace"] = 1,
["url"] = "https://wago.io/7-GPE9UP7/1",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["names"] = {
},
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["debuffType"] = "HELPFUL",
["event"] = "Health",
["unit"] = "player",
},
["untrigger"] = {
},
},
},
["columnSpace"] = 1,
["internalVersion"] = 78,
["selfPoint"] = "BOTTOM",
["align"] = "CENTER",
["source"] = "import",
["alpha"] = 1,
["gridType"] = "RD",
["stagger"] = 0,
["radius"] = 200,
["version"] = 1,
["subRegions"] = {
},
["xOffset"] = -257.7776489257813,
["rotation"] = 0,
["load"] = {
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["talent"] = {
["multi"] = {
},
},
},
["sortHybridTable"] = {
["RBW icon RH"] = false,
["RBW icon LH"] = false,
},
["backdropColor"] = {
1,
1,
1,
0.5,
},
["arcLength"] = 360,
["animate"] = true,
["config"] = {
},
["scale"] = 1,
["centerType"] = "LR",
["border"] = false,
["borderEdge"] = "Square Full White",
["regionType"] = "dynamicgroup",
["borderSize"] = 2,
["limit"] = 5,
["useLimit"] = false,
["uid"] = "6XXu9IwaUhQ",
["constantFactor"] = "RADIUS",
["frameStrata"] = 1,
["borderOffset"] = 4,
["semver"] = "1.0.0",
["tocversion"] = 11500,
["id"] = "RBW Group",
["stepAngle"] = 15,
["gridWidth"] = 5,
["anchorFrameType"] = "SCREEN",
["sort"] = "none",
["borderInset"] = 1,
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["borderColor"] = {
0,
0,
0,
1,
},
["conditions"] = {
},
["information"] = {
},
["space"] = 0,
},
["CP 5"] = {
["wagoID"] = "dTwWQJRhb",
["authorOptions"] = {
},
["preferToUpdate"] = true,
["yOffset"] = -165,
["anchorPoint"] = "CENTER",
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["duration"] = "1",
["unit"] = "player",
["powertype"] = 4,
["use_powertype"] = true,
["debuffType"] = "HELPFUL",
["type"] = "unit",
["unevent"] = "auto",
["power_operator"] = {
">=",
},
["use_requirePowerType"] = false,
["subeventPrefix"] = "SPELL",
["names"] = {
},
["spellIds"] = {
},
["use_power"] = false,
["power"] = {
"1",
},
["event"] = "Power",
["use_unit"] = true,
["subeventSuffix"] = "_CAST_START",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 42.765598297119,
["rotate"] = true,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["textureWrapMode"] = "CLAMP",
["source"] = "import",
["mirror"] = false,
["regionType"] = "texture",
["blendMode"] = "BLEND",
["desc"] = "Rogue Combo Points - Classic WoW                                                              - created by Johadan                                                                                                                        - https://wago.io/p/Johadan#1650                                                                                         - Discord: https://discord.gg/QJs5SHH",
["color"] = {
0,
0,
0,
1,
},
["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Circle_Smooth_Border",
["parent"] = "Sno - Rogue Combo Points",
["xOffset"] = 70,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "CP 5",
["anchorFrameType"] = "SCREEN",
["alpha"] = 1,
["width"] = 42.76575088501,
["frameStrata"] = 1,
["uid"] = "7wcRNpqKcgs",
["config"] = {
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
},
["conditions"] = {
{
["check"] = {
["trigger"] = 1,
["op"] = ">=",
["variable"] = "power",
["value"] = "5",
},
["changes"] = {
{
["value"] = {
0.94509803921569,
0.019607843137255,
0,
1,
},
["property"] = "color",
},
{
["value"] = 1,
["property"] = "alpha",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["variable"] = "power",
["value"] = "5",
},
["changes"] = {
{
["value"] = {
1,
0.22352941176471,
0.72156862745098,
1,
},
["property"] = "color",
},
{
["value"] = 1,
["property"] = "alpha",
},
},
},
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["discrete_rotation"] = 0,
},
["Will of the forsaken 2 2"] = {
["iconSource"] = -1,
["wagoID"] = "dTwWQJRhb",
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["url"] = "https://wago.io/dTwWQJRhb/24",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["auranames"] = {
"7744",
},
["event"] = "Health",
["unit"] = "player",
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["useName"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = true,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["border_size"] = 1,
["border_offset"] = 0,
["text_color"] = {
},
["border_color"] = {
0,
0,
0,
1,
},
["border_visible"] = true,
["border_edge"] = "Blizzard Chat Bubble",
["type"] = "subborder",
},
{
["text_text_format_p_time_format"] = 0,
["text_text"] = "%p",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["text_text_format_p_time_dynamic_threshold"] = 3,
["text_text_format_p_time_mod_rate"] = true,
["type"] = "subtext",
["text_text_format_p_format"] = "timed",
["text_color"] = {
1,
1,
1,
1,
},
["border_color"] = {
},
["text_font"] = "Gilroy Bold",
["text_shadowYOffset"] = 0,
["text_fontType"] = "OUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_anchorYOffset"] = 0,
["text_text_format_p_time_precision"] = 1,
["text_fontSize"] = 18,
["anchorXOffset"] = 0,
["text_text_format_p_time_legacy_floor"] = true,
},
},
["height"] = 30,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["width"] = 30,
["source"] = "import",
["adjustedMax"] = "",
["progressSource"] = {
-1,
"",
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["cooldownEdge"] = false,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "Simonize Rogue Non-Essential buffs",
["config"] = {
},
["cooldownTextDisabled"] = true,
["anchorFrameParent"] = false,
["useCooldownModRate"] = true,
["auto"] = true,
["zoom"] = 0,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Will of the forsaken 2 2",
["frameStrata"] = 1,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["uid"] = "RlJiU)qgHNg",
["inverse"] = false,
["xOffset"] = 0,
["conditions"] = {
},
["cooldown"] = false,
["authorOptions"] = {
},
},
["Simonize Rogue Non-Essential buffs"] = {
["arcLength"] = 360,
["controlledChildren"] = {
"Sprint",
"Evasion",
"Blade Flurry",
"Felstriker",
"Will of the forsaken 2 2",
"Blood Fury 2 2",
"Berserking 2 2",
"Adrenaline Rush",
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "dTwWQJRhb",
["parent"] = "Rogue Auras",
["preferToUpdate"] = true,
["yOffset"] = -149.82455088583,
["anchorPoint"] = "CENTER",
["stepAngle"] = 15,
["sortHybridTable"] = {
["Blade Flurry"] = false,
["Evasion"] = false,
["Blood Fury 2 2"] = false,
["Will of the forsaken 2 2"] = false,
["Adrenaline Rush"] = false,
["Berserking 2 2"] = false,
["Sprint"] = false,
["Felstriker"] = false,
},
["fullCircle"] = true,
["space"] = 4,
["url"] = "https://wago.io/dTwWQJRhb/24",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["unit"] = "player",
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["debuffType"] = "HELPFUL",
["event"] = "Health",
["names"] = {
},
},
["untrigger"] = {
},
},
},
["columnSpace"] = 1,
["internalVersion"] = 78,
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["selfPoint"] = "CENTER",
["align"] = "CENTER",
["useAnchorPerUnit"] = false,
["grow"] = "HORIZONTAL",
["useLimit"] = false,
["rotation"] = 0,
["groupIcon"] = 132320,
["version"] = 24,
["subRegions"] = {
},
["borderColor"] = {
0,
0,
0,
1,
},
["borderInset"] = 0,
["load"] = {
["use_class"] = "true",
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["xOffset"] = -2.9130860661174,
["backdropColor"] = {
1,
1,
1,
0.5,
},
["config"] = {
},
["animate"] = false,
["gridWidth"] = 5,
["scale"] = 1.5,
["centerType"] = "LR",
["border"] = false,
["borderEdge"] = "1 Pixel",
["regionType"] = "dynamicgroup",
["borderSize"] = 2,
["sort"] = "none",
["frameStrata"] = 1,
["limit"] = 5,
["constantFactor"] = "RADIUS",
["gridType"] = "RD",
["borderOffset"] = 16,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Simonize Rogue Non-Essential buffs",
["source"] = "import",
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["radius"] = 200,
["uid"] = "JngDW(Ldhrf",
["authorOptions"] = {
},
["stagger"] = 0,
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["rowSpace"] = 1,
},
["General Auras"] = {
["controlledChildren"] = {
"Barney Raid Kit - Pull Timer",
"Armor Debuffs",
"Bogling Root Spawn Alert",
"Cast - Bar",
"Health Bar",
"SOD - BFD",
"Offhand",
"Mainhand",
"Death-Fatality",
"Blood Fury Reminder",
"Melee Range Reminder",
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "A3Z0KIoeL",
["xOffset"] = 0.88897705078125,
["preferToUpdate"] = false,
["yOffset"] = 54.22238159179688,
["anchorPoint"] = "CENTER",
["borderColor"] = {
0,
0,
0,
1,
},
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["unit"] = "player",
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["names"] = {
},
["event"] = "Health",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
},
["internalVersion"] = 78,
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["version"] = 19,
["subRegions"] = {
},
["load"] = {
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["talent"] = {
["multi"] = {
},
},
},
["backdropColor"] = {
1,
1,
1,
0.5,
},
["source"] = "import",
["scale"] = 1,
["border"] = false,
["borderEdge"] = "Square Full White",
["regionType"] = "group",
["borderSize"] = 2,
["borderOffset"] = 4,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "General Auras",
["borderInset"] = 1,
["frameStrata"] = 1,
["anchorFrameType"] = "SCREEN",
["selfPoint"] = "CENTER",
["uid"] = "pQQi6Y3kP49",
["config"] = {
},
["authorOptions"] = {
},
["conditions"] = {
},
["information"] = {
},
["alpha"] = 1,
},
["5 Second Rule Background - Regenerating"] = {
["sparkWidth"] = 10,
["iconSource"] = -1,
["xOffset"] = 0,
["preferToUpdate"] = false,
["yOffset"] = -6,
["anchorPoint"] = "BOTTOM",
["sparkRotation"] = 0,
["url"] = "https://wago.io/mana-ticker/4",
["backgroundColor"] = {
0,
0.65490196078431,
0.27843137254902,
1,
},
["fontFlags"] = "OUTLINE",
["icon_color"] = {
1,
1,
1,
1,
},
["enableGradient"] = false,
["selfPoint"] = "CENTER",
["barColor"] = {
0,
1,
0,
1,
},
["desaturate"] = false,
["sparkOffsetY"] = 0,
["gradientOrientation"] = "HORIZONTAL",
["load"] = {
["ingroup"] = {
["multi"] = {
},
},
["use_never"] = false,
["class"] = {
["single"] = "PRIEST",
["multi"] = {
["HUNTER"] = true,
["WARLOCK"] = true,
["SHAMAN"] = true,
["MAGE"] = true,
["DRUID"] = true,
["PRIEST"] = true,
},
},
["use_class"] = false,
["role"] = {
["multi"] = {
},
},
["use_spec"] = true,
["level"] = {
"2",
},
["size"] = {
["multi"] = {
},
},
["talent2"] = {
["multi"] = {
},
},
["use_level"] = true,
["talent"] = {
["single"] = 12,
["multi"] = {
[12] = true,
},
},
["spec"] = {
["single"] = 1,
["multi"] = {
[3] = true,
},
},
["difficulty"] = {
["multi"] = {
},
},
["faction"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["pvptalent"] = {
["multi"] = {
},
},
["level_operator"] = {
">",
},
["race"] = {
["multi"] = {
},
},
},
["useAdjustededMin"] = false,
["regionType"] = "aurabar",
["texture"] = "ElvUI Norm",
["zoom"] = 0,
["auto"] = true,
["tocversion"] = 11306,
["alpha"] = 1,
["uid"] = "3TchdYwXiAc",
["borderBackdrop"] = "Solid",
["parent"] = "Player mana regen",
["customText"] = "function()\n    local percent = (UnitPower(\"player\")/UnitPowerMax(\"player\"))*100\n    return (\"%i\"):format(percent)\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
["customTextUpdate"] = "update",
["triggers"] = {
{
["trigger"] = {
["use_alwaystrue"] = true,
["ownOnly"] = true,
["genericShowOn"] = "showAlways",
["names"] = {
"Combustion",
},
["powertype"] = 3,
["use_trackcharge"] = true,
["spellName"] = 194509,
["use_powertype"] = true,
["custom_hide"] = "timed",
["subeventPrefix"] = "SPELL",
["type"] = "unit",
["unevent"] = "auto",
["subeventSuffix"] = "_CAST_START",
["use_showOn"] = true,
["trackcharge"] = "1",
["event"] = "Conditions",
["use_unit"] = true,
["realSpellName"] = 194509,
["use_spellName"] = true,
["spellIds"] = {
190319,
},
["unit"] = "player",
["use_genericShowOn"] = true,
["debuffType"] = "HELPFUL",
["use_track"] = true,
["duration"] = "1",
},
["untrigger"] = {
["showOn"] = "showAlways",
["spellName"] = 194509,
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = 1,
},
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["preset"] = "shrink",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["preset"] = "shrink",
},
},
["backdropInFront"] = false,
["sparkMirror"] = false,
["stickyDuration"] = false,
["version"] = 4,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["type"] = "subforeground",
},
{
["text_shadowXOffset"] = 1,
["text_text"] = " ",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Expressway",
["text_shadowYOffset"] = -1,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "None",
["text_anchorPoint"] = "INNER_RIGHT",
["text_fontSize"] = 23,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["text_shadowXOffset"] = 1,
["text_text"] = " ",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Expressway",
["text_shadowYOffset"] = -1,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_LEFT",
["text_fontSize"] = 15,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["text_shadowXOffset"] = 1,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = -1,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "None",
["text_anchorPoint"] = "ICON_CENTER",
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["border_size"] = 1,
["border_anchor"] = "bar",
["type"] = "subborder",
["border_color"] = {
0,
0,
0,
1,
},
["border_visible"] = true,
["border_edge"] = "1 Pixel",
["border_offset"] = 1,
},
},
["height"] = 5,
["textureSource"] = "LSM",
["sparkBlendMode"] = "ADD",
["backdropColor"] = {
1,
1,
1,
0.5,
},
["source"] = "import",
["authorOptions"] = {
},
["barColor2"] = {
1,
1,
0,
1,
},
["sparkColor"] = {
0.38039215686275,
0.84705882352941,
1,
1,
},
["adjustedMax"] = "",
["anchorFrameFrame"] = "PlayerFrameManaBar",
["sparkOffsetX"] = 0,
["borderInFront"] = true,
["color"] = {
},
["icon_side"] = "RIGHT",
["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
["config"] = {
},
["sparkHeight"] = 30,
["anchorFrameType"] = "SELECTFRAME",
["useAdjustededMax"] = false,
["spark"] = false,
["semver"] = "1.0.3",
["sparkHidden"] = "NEVER",
["id"] = "5 Second Rule Background - Regenerating",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["frameStrata"] = 2,
["width"] = 114,
["sparkRotationMode"] = "AUTO",
["icon"] = false,
["inverse"] = false,
["sparkDesature"] = false,
["orientation"] = "HORIZONTAL",
["conditions"] = {
{
["check"] = {
["trigger"] = -1,
["variable"] = "incombat",
["value"] = 0,
},
["changes"] = {
{
["value"] = 0.3,
["property"] = "alpha",
},
},
},
{
["check"] = {
["trigger"] = -1,
["variable"] = "incombat",
["value"] = 0,
},
["changes"] = {
{
},
},
},
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["adjustedMin"] = "",
},
["Spirit Tap - Timer"] = {
["sparkWidth"] = 6,
["iconSource"] = -1,
["xOffset"] = 0,
["preferToUpdate"] = false,
["yOffset"] = -6,
["anchorPoint"] = "BOTTOM",
["sparkRotation"] = 0,
["url"] = "https://wago.io/mana-ticker/4",
["backgroundColor"] = {
0,
1,
0,
0,
},
["fontFlags"] = "OUTLINE",
["icon_color"] = {
1,
1,
1,
1,
},
["enableGradient"] = false,
["selfPoint"] = "CENTER",
["barColor"] = {
0.47843137254902,
0.27058823529412,
0.63921568627451,
1,
},
["desaturate"] = false,
["sparkOffsetY"] = 0,
["gradientOrientation"] = "HORIZONTAL",
["load"] = {
["ingroup"] = {
["multi"] = {
},
},
["use_never"] = false,
["class"] = {
["single"] = "PRIEST",
["multi"] = {
["HUNTER"] = true,
["WARLOCK"] = true,
["SHAMAN"] = true,
["MAGE"] = true,
["DRUID"] = true,
["PRIEST"] = true,
},
},
["use_class"] = false,
["role"] = {
["multi"] = {
},
},
["use_spec"] = true,
["level"] = {
"2",
},
["size"] = {
["multi"] = {
},
},
["talent2"] = {
["multi"] = {
},
},
["use_level"] = true,
["talent"] = {
["single"] = 12,
["multi"] = {
[12] = true,
},
},
["spec"] = {
["single"] = 1,
["multi"] = {
[3] = true,
},
},
["difficulty"] = {
["multi"] = {
},
},
["faction"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["pvptalent"] = {
["multi"] = {
},
},
["level_operator"] = {
">",
},
["race"] = {
["multi"] = {
},
},
},
["smoothProgress"] = true,
["useAdjustededMin"] = false,
["regionType"] = "aurabar",
["texture"] = "ElvUI Norm",
["zoom"] = 0,
["auto"] = true,
["tocversion"] = 11306,
["alpha"] = 1,
["uid"] = "FB5AAOzkcBh",
["sparkOffsetX"] = 0,
["parent"] = "Player mana regen",
["customText"] = "function()\n    local timeLeft = aura_env.state.duration\n    if timeLeft == 0 then\n        return \"\"\n    else\n        \n        return (\"%i\"):format(timeLeft)\n    end\nend\n\n\n\n\n",
["customTextUpdate"] = "update",
["triggers"] = {
{
["trigger"] = {
["auranames"] = {
"Spirit Tap",
},
["duration"] = "2",
["names"] = {
},
["debuffType"] = "HELPFUL",
["type"] = "aura2",
["subeventSuffix"] = "_ENERGIZE",
["use_unit"] = true,
["custom_type"] = "stateupdate",
["event"] = "Health",
["unevent"] = "auto",
["subeventPrefix"] = "SPELL",
["events"] = "PLAYER_ENTERING_WORLD, UNIT_SPELLCAST_SUCCEEDED, UNIT_MAXPOWER, CURRENT_SPELL_CAST_CHANGED",
["spellIds"] = {
},
["use_sourceUnit"] = true,
["check"] = "event",
["unit"] = "player",
["sourceUnit"] = "player",
["useName"] = true,
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["preset"] = "fade",
},
["main"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["preset"] = "alphaPulse",
},
["finish"] = {
["type"] = "none",
["easeType"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["preset"] = "shrink",
},
},
["backdropInFront"] = false,
["sparkMirror"] = false,
["stickyDuration"] = true,
["version"] = 4,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["type"] = "subforeground",
},
{
["text_text_format_p_time_format"] = 0,
["text_text"] = " %p",
["text_text_format_p_format"] = "timed",
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_p_time_legacy_floor"] = true,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["anchorYOffset"] = 0,
["type"] = "subtext",
["text_text_format_p_time_dynamic_threshold"] = 3,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Expressway",
["text_text_format_p_time_precision"] = 1,
["text_shadowYOffset"] = -1,
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_CENTER",
["text_shadowXOffset"] = 1,
["text_visible"] = false,
["text_fontSize"] = 13,
["anchorXOffset"] = 0,
["text_text_format_p_time_mod_rate"] = true,
},
{
["text_shadowXOffset"] = 1,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Myriad Condensed Web",
["text_shadowYOffset"] = -1,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "None",
["text_anchorPoint"] = "ICON_CENTER",
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_visible"] = false,
},
{
["border_offset"] = 1,
["border_size"] = 2,
["border_anchor"] = "bar",
["text_color"] = {
},
["border_color"] = {
0,
0,
0,
1,
},
["border_visible"] = true,
["border_edge"] = "1 Pixel",
["type"] = "subborder",
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["useGlowColor"] = false,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = false,
["glow_anchor"] = "bar",
["glowLength"] = 10,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 5,
["textureSource"] = "LSM",
["sparkBlendMode"] = "ADD",
["backdropColor"] = {
1,
1,
1,
0.5,
},
["source"] = "import",
["authorOptions"] = {
},
["barColor2"] = {
1,
1,
0,
1,
},
["config"] = {
},
["adjustedMax"] = "",
["anchorFrameFrame"] = "PlayerFrameManaBar",
["sparkColor"] = {
1,
1,
1,
1,
},
["borderInFront"] = true,
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["icon_side"] = "RIGHT",
["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
["icon"] = false,
["sparkHeight"] = 15,
["anchorFrameType"] = "SELECTFRAME",
["sparkRotationMode"] = "AUTO",
["useAdjustededMax"] = false,
["semver"] = "1.0.3",
["sparkHidden"] = "BOTH",
["id"] = "Spirit Tap - Timer",
["spark"] = true,
["frameStrata"] = 4,
["width"] = 114,
["color"] = {
},
["borderBackdrop"] = "Blizzard Tooltip",
["inverse"] = false,
["sparkDesature"] = false,
["orientation"] = "HORIZONTAL",
["conditions"] = {
{
["check"] = {
["trigger"] = -1,
["variable"] = "incombat",
["value"] = 0,
},
["changes"] = {
{
["value"] = 0.3,
["property"] = "alpha",
},
},
},
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["adjustedMin"] = "",
},
["Felstriker"] = {
["iconSource"] = 0,
["wagoID"] = "dTwWQJRhb",
["authorOptions"] = {
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["cooldownEdge"] = false,
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["useName"] = true,
["debuffType"] = "HELPFUL",
["auranames"] = {
"16551",
},
["unit"] = "player",
["duration"] = "3",
["event"] = "Combat Log",
["names"] = {
},
["type"] = "combatlog",
["use_spellName"] = true,
["spellIds"] = {
},
["use_sourceUnit"] = true,
["subeventPrefix"] = "SPELL",
["subeventSuffix"] = "_AURA_APPLIED",
["sourceUnit"] = "player",
["spellName"] = {
"Felstriker",
},
},
["untrigger"] = {
},
},
{
["trigger"] = {
["type"] = "combatlog",
["subeventSuffix"] = "_AURA_REFRESH",
["duration"] = "3",
["event"] = "Combat Log",
["unit"] = "player",
["use_spellName"] = true,
["use_sourceUnit"] = true,
["debuffType"] = "HELPFUL",
["subeventPrefix"] = "SPELL",
["sourceUnit"] = "player",
["spellName"] = {
"Felstriker",
},
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = true,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["border_size"] = 2,
["border_offset"] = 0,
["text_color"] = {
},
["border_color"] = {
0,
1,
0.035294117647059,
1,
},
["border_visible"] = false,
["border_edge"] = "Blizzard Chat Bubble",
["type"] = "subborder",
},
{
["text_text_format_p_time_format"] = 0,
["text_text"] = "%p",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["text_text_format_p_time_dynamic_threshold"] = 3,
["text_text_format_p_time_mod_rate"] = true,
["type"] = "subtext",
["text_text_format_p_format"] = "timed",
["text_color"] = {
1,
1,
1,
1,
},
["border_color"] = {
},
["text_font"] = "Gilroy Bold",
["text_shadowYOffset"] = 0,
["text_fontType"] = "OUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_anchorYOffset"] = 0,
["text_text_format_p_time_precision"] = 1,
["text_fontSize"] = 18,
["anchorXOffset"] = 0,
["text_text_format_p_time_legacy_floor"] = true,
},
},
["height"] = 30,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["alpha"] = 1,
["useAdjustededMax"] = false,
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["source"] = "import",
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["displayIcon"] = "135661",
["progressSource"] = {
-1,
"",
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["xOffset"] = 0,
["config"] = {
},
["parent"] = "Simonize Rogue Non-Essential buffs",
["width"] = 30,
["anchorFrameParent"] = false,
["zoom"] = 0,
["semver"] = "1.0.23",
["cooldownTextDisabled"] = true,
["auto"] = true,
["tocversion"] = 30403,
["id"] = "Felstriker",
["frameStrata"] = 1,
["useCooldownModRate"] = true,
["anchorFrameType"] = "SCREEN",
["url"] = "https://wago.io/dTwWQJRhb/24",
["uid"] = "DPdMG1lRSYq",
["inverse"] = false,
["color"] = {
1,
1,
1,
1,
},
["conditions"] = {
},
["cooldown"] = false,
["adjustedMax"] = "",
},
["CP1YellowOutline GCD"] = {
["user_y"] = 0,
["user_x"] = 0,
["authorOptions"] = {
},
["preferToUpdate"] = true,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["sameTexture"] = true,
["url"] = "https://wago.io/dTwWQJRhb/24",
["backgroundColor"] = {
0.23921568627451,
0.23921568627451,
0.23921568627451,
0,
},
["selfPoint"] = "CENTER",
["desaturate"] = false,
["rotation"] = 0,
["font"] = "Friz Quadrata TT",
["crop_y"] = 0,
["textureWrapMode"] = "CLAMP",
["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura73",
["smoothProgress"] = false,
["useAdjustededMin"] = false,
["regionType"] = "progresstexture",
["blendMode"] = "BLEND",
["slantMode"] = "INSIDE",
["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura73",
["compress"] = false,
["alpha"] = 1,
["uid"] = "e61)eod)3im",
["backgroundOffset"] = 0,
["wagoID"] = "dTwWQJRhb",
["parent"] = "Sno - Rogue Combo Points",
["adjustedMin"] = "",
["desaturateBackground"] = false,
["desaturateForeground"] = false,
["triggers"] = {
{
["trigger"] = {
["type"] = "spell",
["unevent"] = "auto",
["duration"] = "1",
["event"] = "Global Cooldown",
["unit"] = "player",
["subeventPrefix"] = "SPELL",
["spellIds"] = {
},
["use_inverse"] = false,
["use_unit"] = true,
["subeventSuffix"] = "_CAST_START",
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["type"] = "unit",
["use_alwaystrue"] = true,
["subeventSuffix"] = "_CAST_START",
["duration"] = "1",
["event"] = "Conditions",
["use_unit"] = true,
["unevent"] = "auto",
["subeventPrefix"] = "SPELL",
["unit"] = "player",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["endAngle"] = 360,
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["colorR"] = 1,
["duration"] = "0.1",
["alphaType"] = "straight",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = true,
["type"] = "custom",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "fade",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "seconds",
},
},
["discrete_rotation"] = 0,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["height"] = 63,
["rotate"] = true,
["useAdjustededMax"] = false,
["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
["source"] = "import",
["foregroundColor"] = {
0.84705882352941,
0.89019607843137,
0.87843137254902,
1,
},
["mirror"] = false,
["anchorFrameFrame"] = "WeakAuras:CP 1",
["color"] = {
1,
0.91764705882353,
0,
1,
},
["auraRotation"] = 0,
["crop_x"] = 0,
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["config"] = {
},
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["startAngle"] = 0,
["semver"] = "1.0.23",
["width"] = 63,
["id"] = "CP1YellowOutline GCD",
["fontSize"] = 12,
["frameStrata"] = 4,
["anchorFrameType"] = "SELECTFRAME",
["tocversion"] = 30403,
["desc"] = "Rogue Combo Points - Classic WoW                                                              - created by Johadan                                                                                                                        - https://wago.io/p/Johadan#1650                                                                                         - Discord: https://discord.gg/QJs5SHH",
["inverse"] = true,
["xOffset"] = 0,
["orientation"] = "CLOCKWISE",
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["adjustedMax"] = "",
},
["nanShield:Value"] = {
["outline"] = "OUTLINE",
["wagoID"] = "6HHBMDHTD",
["parent"] = "nanShield Classic",
["displayText_format_p_time_dynamic_threshold"] = 0,
["customText"] = "",
["shadowYOffset"] = -1,
["anchorPoint"] = "CENTER",
["displayText_format_p_time_format"] = 0,
["customTextUpdate"] = "event",
["url"] = "https://wago.io/6HHBMDHTD/3",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
["custom"] = "-- Package common/logging\naura_env.logPalette = {\n    \"ff6e7dda\",\n    \"ff21dfb9\",\n    \"ffe3f57a\",\n    \"ffed705a\",\n    \"fff8a3e6\",\n}\n\nfunction aura_env:log(...)\n    if self.config and self.config.debugEnabled then\n        local palette = self.logPalette\n        local args = {\n            self.cloneId and\n            format(\"[%s:%s]\", self.id, self.cloneId) or\n            format(\"[%s]\", self.id),\n            ...\n        }\n        for i = 1, #args do\n            args[i] = format(\n                \"|c%s%s|r\",\n                palette[1 + (i - 1) % #palette],\n                tostring(args[i]))\n        end\n        print(unpack(args))\n    end\nend\n-- Package end\n\n-- Package common/lowabsorb\nfunction aura_env:LowestAbsorb(totalAbsorb, all, physical, magic, ...)\n    self:log('LowestAbsorb', all, physical, magic, ...)\n    local minValue\n    local minIdx\n    local value\n    \n    for i = 1, select('#', ...) do\n        value = select(i, ...)\n        if value > 0 and value <= (minValue or value) then\n            minIdx = i + 3\n            minValue = value\n        end\n    end\n    \n    if minIdx then\n        minValue = minValue + magic\n    elseif magic > 0 then\n        minValue = magic\n        minIdx = 3\n    end\n    \n    if physical > 0 and physical <= (minValue or physical) then\n        minValue = physical\n        minIdx = 2\n    end\n    \n    if minIdx then\n        minValue = minValue + all\n    else\n        minValue = all\n        minIdx = 1\n    end\n    \n    self:log('LowestAbsorbResult', minValue, totalAbsorb, minIdx)\n    return minValue, totalAbsorb, minIdx\nend\n-- Package end\n\n-- Package common/schools\naura_env.schools = {\n    \"All\",\n    \"Physical\",\n    \"Magic\",\n    \"Holy\",\n    \"Fire\",\n    \"Nature\",\n    \"Frost\",\n    \"Shadow\",\n    \"Arcane\",\n}\naura_env.schoolIds = { 127, 1, 126, 2, 4, 8, 16, 32, 64 }\naura_env.schoolIdx = {}\nfor idx, id in ipairs(aura_env.schoolIds) do\n    aura_env.schoolIdx[id] = idx\nend\n-- Package end\n\n-- Package value/calc\naura_env.active = 0\naura_env.spellSchool = {}\naura_env.currentAbsorb = {}\naura_env.maxAbsorb = {}\naura_env.totalAbsorb = 0\naura_env.schoolAbsorb = {0, 0, 0, 0, 0, 0, 0, 0, 0}\n\nlocal function improvedPowerWordShieldMultiplier()\n    -- FIXME: GetTalentInfo(1, 5)\n    --return 1.15\n    \n    local _,_,_,_,r = GetTalentInfo(1,5)\n    local m = r*0.05\n    \n    aura_env:log('improvedPowerWordShieldMultiplier', m)\n    return 1+m\nend\n\nlocal function improvedVoidwalkerMultiplier()\n    local _,_,_,_,r = GetTalentInfo(2,5)\n    local m = r*0.1\n    \n    aura_env:log('improvedVoidwalkerMultiplier', m)\n    return 1+m\nend\n\naura_env.talentMultiplier = {\n    [   17] = improvedPowerWordShieldMultiplier,\n    [  592] = improvedPowerWordShieldMultiplier,\n    [  600] = improvedPowerWordShieldMultiplier,\n    [ 3747] = improvedPowerWordShieldMultiplier,\n    [ 6065] = improvedPowerWordShieldMultiplier,\n    [ 6066] = improvedPowerWordShieldMultiplier,\n    [10898] = improvedPowerWordShieldMultiplier,\n    [10899] = improvedPowerWordShieldMultiplier,\n    [10900] = improvedPowerWordShieldMultiplier,\n    [10901] = improvedPowerWordShieldMultiplier,\n    [ 7812] = improvedVoidwalkerMultiplier,\n    [19438] = improvedVoidwalkerMultiplier,\n    [19440] = improvedVoidwalkerMultiplier,\n    [19441] = improvedVoidwalkerMultiplier,\n    [19442] = improvedVoidwalkerMultiplier,\n    [19443] = improvedVoidwalkerMultiplier,    \n}\n\nfunction aura_env:CalculateAbsorbValue(spellName, spellId, absorbInfo)\n    -- FIXME: if caster != player\n    local value\n    local keys = self.absorbDbKeys\n    local bonusHealing = GetSpellBonusHealing()\n    local level = UnitLevel(\"player\")\n    local base = absorbInfo[keys.basePoints]\n    local perLevel = absorbInfo[keys.pointsPerLevel]\n    local baseLevel = absorbInfo[keys.baseLevel]\n    local maxLevel = absorbInfo[keys.maxLevel]\n    local spellLevel = absorbInfo[keys.spellLevel]\n    local bonusMult = absorbInfo[keys.healingMultiplier]\n    local baseMultFn = self.talentMultiplier[spellId]\n    local levelPenalty = min(1, 1 - (20 - spellLevel) * .03)\n    local levels = max(0, min(level, maxLevel) - baseLevel)\n    local baseMult = baseMultFn and baseMultFn() or 1\n    \n    value = (\n        baseMult * (base + levels * perLevel) +\n        bonusHealing * bonusMult * levelPenalty\n    )\n    \n    self:log('CalculateAbsorbValue', spellName,\n        value, base, perLevel, levels, baseMult,\n    bonusHealing, bonusMult, levelPenalty)\n    \n    return value\nend\n\nfunction aura_env:GetBuffId(spellName)\n    local spellId\n    for i = 1, 255 do\n        local auraName, _, _, _, _, _, _, _, _, spell_id = UnitBuff(\"player\", i)\n        spellId = spell_id\n        if auraName == spellName then\n            break\n        elseif not auraName then\n            spellId = nil\n            break\n        end\n    end\n    return spellId\nend\n\nfunction aura_env:ApplyAura(spellName)\n    local school = self.spellSchool[spellName]\n    self:log('ApplyAura', spellName, school)\n    \n    if 0 ~= school then\n        local spellId = self:GetBuffId(spellName)\n        local absorbInfo = self.absorbDb[spellId]\n        \n        self:log('ApplyAuraAbsorbOrNew', spellId)\n        \n        if absorbInfo then\n            local value = self:CalculateAbsorbValue(\n            spellName, spellId, absorbInfo)\n            \n            self:log('ApplyAuraSchool', school)\n            if nil == school then\n                school = absorbInfo[self.absorbDbKeys.school]\n                self.spellSchool[spellName] = school\n            end\n            \n            if self.maxAbsorb[spellName] then\n                self:log('ApplyAuraUpdateCurrent', spellName, value)\n                self.currentAbsorb[spellName] = value\n            else\n                self:log('ApplyAuraSetCurrent', spellName, value)\n                self.active = self.active + 1\n                \n                -- If damage event happened before aura was removed\n                local prevValue = self.currentAbsorb[spellName]\n                self.currentAbsorb[spellName] = value + (prevValue or 0)\n            end\n            \n            self:log('ApplyAuraSetMax', spellName, value)\n            self.maxAbsorb[spellName] = value\n            self:UpdateValues()\n        end\n    end\nend\n\nfunction aura_env:RemoveAura(spellName)\n    self:log('RemoveAura', spellName)\n    if self.currentAbsorb[spellName] then\n        self.currentAbsorb[spellName] = nil\n        self.active = self.active - 1\n        self:log('RemoveAuraRemaining', self.active)\n        if self.active < 1 then\n            self.active = 0\n            wipe(self.maxAbsorb)\n        end\n\n        if self.config and self.config.fixRemoveAura then\n            self.maxAbsorb[spellName] = nil\n        end\n\n        self:UpdateValues()\n    end\nend\n\nfunction aura_env:ApplyDamage(spellName, value)\n    self:log('ApplyDamage', spellName, value)\n    local newValue = (self.currentAbsorb[spellName] or 0) - value\n    if self.maxAbsorb[spellName] then\n        self.currentAbsorb[spellName] = max(0, newValue)\n        self:UpdateValues()\n    else\n        self.currentAbsorb[spellName] = newValue\n    end\nend\n\nfunction aura_env:ResetValues()\n    self:log('ResetValues')\n    local spellName\n    wipe(self.currentAbsorb)\n    wipe(self.maxAbsorb)\n    self.active = 0\n    for i = 1, 255 do\n        spellName = UnitBuff(\"player\", i)\n        if not spellName then\n            break\n        end\n        self:ApplyAura(spellName)\n    end\n    self:UpdateValues()\nend\n\nfunction aura_env:UpdateValues()\n    self:log('UpdateValues')\n    local values = self.schoolAbsorb\n    local keys = self.schoolIdx\n    local spellSchool = self.spellSchool\n    local current = self.currentAbsorb\n    local total = 0\n    local key, value, school\n    \n    for i = 1, #values do\n        values[i] = 0\n    end\n    \n    for spell, maxValue in pairs(self.maxAbsorb) do\n        school = spellSchool[spell]\n        key = keys[school]\n        total = total + maxValue\n        value = (current[spell] or 0)\n        values[key] = values[key] + value\n        self:log('UpdateValues', spell, school, key, maxValue, value)\n    end\n    \n    self.totalAbsorb = total\n    WeakAuras.ScanEvents(\"WA_NAN_SHIELD\", total, unpack(values))\n    self:log('UpdateValues', total > 0)\nend\n-- Package end\n\n-- Package value/cleu\nfunction aura_env:on_cleu(triggerEvent, ...)\n    local event, spellName, value\n    local casterGUID = select(8, ...)\n    \n    if triggerEvent == 'OPTIONS' then\n        self:log(triggerEvent, ...)\n    elseif self.playerGUID == casterGUID then\n        self:log(triggerEvent, ...)\n        event = select(2, ...)\n        if event == \"SPELL_AURA_APPLIED\" or event == \"SPELL_AURA_REFRESH\" then\n            spellName = select(13, ...)\n            self:ApplyAura(spellName)\n        elseif event == \"SPELL_AURA_REMOVED\" then\n            spellName = select(13, ...)\n            self:RemoveAura(spellName)\n        elseif event == \"SPELL_ABSORBED\" then\n            if select(20, ...) then\n                spellName = select(20, ...)\n                value = select(22, ...) or 0\n            else\n                spellName = select(17, ...)\n                value = select(19, ...) or 0\n            end\n            self:ApplyDamage(spellName, value)\n        end\n    elseif not casterGUID then\n        self:log(triggerEvent, ...)\n        self:ResetValues()\n    end\nend\n-- Package end\n\n-- Package value/init\naura_env.playerGUID = UnitGUID(\"player\")\n-- Package end\n\n-- Generated by nan-wa-utils\naura_env.absorbDbKeys = {\n    [\"school\"] = 1,\n    [\"basePoints\"] = 2,\n    [\"pointsPerLevel\"] = 3,\n    [\"baseLevel\"] = 4,\n    [\"maxLevel\"] = 5,\n    [\"spellLevel\"] = 6,\n    [\"healingMultiplier\"] = 7,\n}\naura_env.absorbDb = {\n    [  7848] = {   1,    49,    0,  0,  0,  0, 0  }, -- Absorption\n    [ 25750] = {   1,   247,    0, 20,  0,  0, 0  }, -- Damage Absorb\n    [ 25747] = {   1,   309,    0, 20,  0,  0, 0  }, -- Damage Absorb\n    [ 25746] = {   1,   391,    0, 20,  0,  0, 0  }, -- Damage Absorb\n    [ 23991] = {   1,   494,    0, 20,  0,  0, 0  }, -- Damage Absorb\n    [ 11657] = {   1,    54,    0, 48,  0, 48, 0  }, -- Jang'thraze\n    [  7447] = {   1,    24,    0,  0,  0,  0, 0  }, -- Lesser Absorption\n    [  8373] = {   1,   999,    0,  0,  0,  0, 0  }, -- Mana Shield (PT)\n    [  7423] = {   1,     9,    0,  0,  0,  0, 0  }, -- Minor Absorption\n    [  3288] = {   1,    19,    0, 21,  0, 21, 0  }, -- Moss Hide\n    [ 21956] = {   1,   349,    0, 20,  0,  0, 0  }, -- Physical Protection\n    [  7245] = {   2,   299,    0, 20,  0,  0, 0  }, -- Holy Protection (Rank 1)\n    [ 16892] = {   2,   299,    0, 20,  0,  0, 0  }, -- Holy Protection (Rank 1)\n    [  7246] = {   2,   524,    0, 25,  0,  0, 0  }, -- Holy Protection (Rank 2)\n    [  7247] = {   2,   674,    0, 30,  0,  0, 0  }, -- Holy Protection (Rank 3)\n    [  7248] = {   2,   974,    0, 35,  0,  0, 0  }, -- Holy Protection (Rank 4)\n    [  7249] = {   2,  1349,    0, 40,  0,  0, 0  }, -- Holy Protection (Rank 5)\n    [ 17545] = {   2,  1949,    0, 40,  0,  0, 0  }, -- Holy Protection (Rank 6)\n    [ 27536] = {   2,   299,    0, 60,  0,  0, 0  }, -- Holy Resistance\n    [ 29432] = {   4,  1499,    0, 35,  0,  0, 0  }, -- Fire Protection\n    [ 17543] = {   4,  1949,    0, 35,  0,  0, 0  }, -- Fire Protection\n    [ 18942] = {   4,  1949,    0, 35,  0,  0, 0  }, -- Fire Protection\n    [  7230] = {   4,   299,    0, 20,  0,  0, 0  }, -- Fire Protection (Rank 1)\n    [ 12561] = {   4,   299,    0, 20,  0,  0, 0  }, -- Fire Protection (Rank 1)\n    [  7231] = {   4,   524,    0, 25,  0,  0, 0  }, -- Fire Protection (Rank 2)\n    [  7232] = {   4,   674,    0, 30,  0,  0, 0  }, -- Fire Protection (Rank 3)\n    [  7233] = {   4,   974,    0, 35,  0,  0, 0  }, -- Fire Protection (Rank 4)\n    [ 16894] = {   4,   974,    0, 35,  0,  0, 0  }, -- Fire Protection (Rank 4)\n    [  7234] = {   4,  1349,    0, 35,  0,  0, 0  }, -- Fire Protection (Rank 5)\n    [ 27533] = {   4,   299,    0, 60,  0,  0, 0  }, -- Fire Resistance\n    [  4057] = {   4,   499,    0,  0,  0, 25, 0  }, -- Fire Resistance\n    [ 17546] = {   8,  1949,    0, 40,  0,  0, 0  }, -- Nature Protection\n    [  7250] = {   8,   299,    0, 20,  0,  0, 0  }, -- Nature Protection (Rank 1)\n    [  7251] = {   8,   524,    0, 25,  0,  0, 0  }, -- Nature Protection (Rank 2)\n    [  7252] = {   8,   674,    0, 30,  0,  0, 0  }, -- Nature Protection (Rank 3)\n    [  7253] = {   8,   974,    0, 35,  0,  0, 0  }, -- Nature Protection (Rank 4)\n    [  7254] = {   8,  1349,    0, 40,  0,  0, 0  }, -- Nature Protection (Rank 5)\n    [ 16893] = {   8,  1349,    0, 40,  0,  0, 0  }, -- Nature Protection (Rank 5)\n    [ 27538] = {   8,   299,    0, 60,  0,  0, 0  }, -- Nature Resistance\n    [ 17544] = {  16,  1949,    0, 40,  0,  0, 0  }, -- Frost Protection\n    [  7240] = {  16,   299,    0, 20,  0,  0, 0  }, -- Frost Protection (Rank 1)\n    [  7236] = {  16,   524,    0, 25,  0,  0, 0  }, -- Frost Protection (Rank 2)\n    [  7238] = {  16,   674,    0, 30,  0,  0, 0  }, -- Frost Protection (Rank 3)\n    [  7237] = {  16,   974,    0, 35,  0,  0, 0  }, -- Frost Protection (Rank 4)\n    [  7239] = {  16,  1349,    0, 40,  0,  0, 0  }, -- Frost Protection (Rank 5)\n    [ 16895] = {  16,  1349,    0, 40,  0,  0, 0  }, -- Frost Protection (Rank 5)\n    [ 27534] = {  16,   299,    0, 60,  0,  0, 0  }, -- Frost Resistance\n    [  4077] = {  16,   599,    0,  0,  0, 25, 0  }, -- Frost Resistance\n    [ 17548] = {  32,  1949,    0, 40,  0,  0, 0  }, -- Shadow Protection\n    [  7235] = {  32,   299,    0, 20,  0,  0, 0  }, -- Shadow Protection (Rank 1)\n    [  7241] = {  32,   524,    0, 25,  0,  0, 0  }, -- Shadow Protection (Rank 2)\n    [  7242] = {  32,   674,    0, 30,  0,  0, 0  }, -- Shadow Protection (Rank 3)\n    [ 16891] = {  32,   674,    0, 30,  0,  0, 0  }, -- Shadow Protection (Rank 3)\n    [  7243] = {  32,   974,    0, 35,  0,  0, 0  }, -- Shadow Protection (Rank 4)\n    [  7244] = {  32,  1349,    0, 40,  0,  0, 0  }, -- Shadow Protection (Rank 5)\n    [ 27535] = {  32,   299,    0, 60,  0,  0, 0  }, -- Shadow Resistance\n    [  6229] = {  32,   289,    0, 32,  0, 32, 0  }, -- Shadow Ward (Rank 1)\n    [ 11739] = {  32,   469,    0, 42,  0, 42, 0  }, -- Shadow Ward (Rank 2)\n    [ 11740] = {  32,   674,    0, 52,  0, 52, 0  }, -- Shadow Ward (Rank 3)\n    [ 28610] = {  32,   919,    0, 60,  0, 60, 0  }, -- Shadow Ward (Rank 4)\n    [ 17549] = {  64,  1949,    0, 35,  0,  0, 0  }, -- Arcane Protection\n    [ 27540] = {  64,   299,    0, 60,  0,  0, 0  }, -- Arcane Resistance\n    [ 10618] = { 126,   599,    0, 30,  0,  0, 0  }, -- Elemental Protection\n    [ 20620] = { 127, 29999,    0, 20,  0, 20, 0  }, -- Aegis of Ragnaros\n    [ 23506] = { 127,   749,    0, 20,  0,  0, 0  }, -- Aura of Protection\n    [ 11445] = { 127,   277,    0, 35,  0, 35, 0  }, -- Bone Armor\n    [ 16431] = { 127,  1387,    0, 55,  0, 55, 0  }, -- Bone Armor\n    [ 27688] = { 127,  2499,    0,  0,  0,  0, 0  }, -- Bone Shield\n    [370391] = { 127,    99,    0,  0,  0,  0, 0  }, -- Failsafe Phylactery\n    [ 13234] = { 127,   499,    0,  0,  0,  0, 0  }, -- Harm Prevention Belt\n    [  9800] = { 127,   174,    0, 52,  0,  0, 0  }, -- Holy Shield\n    [ 17252] = { 127,   499,    0,  0,  0,  0, 0  }, -- Mark of the Dragon Lord\n    [ 11835] = { 127,   115,    0, 20,  0, 20, 0.1}, -- Power Word: Shield\n    [ 11974] = { 127,   136, 6.85, 20,  0, 20, 0.1}, -- Power Word: Shield\n    [ 22187] = { 127,   205, 10.2, 20,  0, 20, 0.1}, -- Power Word: Shield\n    [ 17139] = { 127,   273, 13.7, 20,  0, 20, 0.1}, -- Power Word: Shield\n    [ 11647] = { 127,   780,  3.9, 54, 59,  1, 0.1}, -- Power Word: Shield\n    [ 20697] = { 127,  4999,    0,  0,  0,  0, 0.1}, -- Power Word: Shield\n    [ 12040] = { 127,   199,   10, 20,  0, 20, 0  }, -- Shadow Shield\n    [ 22417] = { 127,   399,   20, 20,  0, 20, 0  }, -- Shadow Shield\n    [ 27759] = { 127,    49,    0,  0,  0,  0, 0  }, -- Shield Generator\n    [ 29506] = { 127,   899,    0, 20,  0,  0, 0  }, -- The Burrower's Shell\n    [  1234] = { 127,     0,    0,  0,  0,  0, 0  }, -- Tony's God Mode\n    [ 10368] = { 127,   199,  2.3, 30, 35, 30, 0  }, -- Uther's Light Effect (Rank 1)\n    [ 28810] = { 127,   499,    0,  0,  0,  1, 0  }, -- [Priest] Armor of Faith\n    [ 27779] = { 127,   349,  2.3,  0,  0,  0, 0  }, -- [Priest] Divine Protection\n    [    17] = { 127,    43,  0.8,  6, 11,  6, 0.1}, -- [Priest] Power Word: Shield (Rank 1)\n    [ 10901] = { 127,   941,  4.3, 60, 65, 60, 0.1}, -- [Priest] Power Word: Shield (Rank 10)\n    [ 27607] = { 127,   941,  4.3, 60, 65, 60, 0.1}, -- [Priest] Power Word: Shield (Rank 10)\n    [   592] = { 127,    87,  1.2, 12, 17, 12, 0.1}, -- [Priest] Power Word: Shield (Rank 2)\n    [   600] = { 127,   157,  1.6, 18, 23, 18, 0.1}, -- [Priest] Power Word: Shield (Rank 3)\n    [  3747] = { 127,   233,    2, 24, 29, 24, 0.1}, -- [Priest] Power Word: Shield (Rank 4)\n    [  6065] = { 127,   300,  2.3, 30, 35, 30, 0.1}, -- [Priest] Power Word: Shield (Rank 5)\n    [  6066] = { 127,   380,  2.6, 36, 41, 36, 0.1}, -- [Priest] Power Word: Shield (Rank 6)\n    [ 10898] = { 127,   483,    3, 42, 47, 42, 0.1}, -- [Priest] Power Word: Shield (Rank 7)\n    [ 10899] = { 127,   604,  3.4, 48, 53, 48, 0.1}, -- [Priest] Power Word: Shield (Rank 8)\n    [ 10900] = { 127,   762,  3.9, 54, 59, 54, 0.1}, -- [Priest] Power Word: Shield (Rank 9)\n    [ 20706] = { 127,   499,    3, 42, 47, 42, 0  }, -- [Priest] Power Word: Shield 500 (Rank 7)\n    [ 17740] = {   1,   119,    6, 20,  0, 20, 0  }, -- [Mage] Mana Shield\n    [ 17741] = {   1,   119,    6, 20,  0, 20, 0  }, -- [Mage] Mana Shield\n    [  1463] = {   1,   119,    0, 20,  0, 20, 0  }, -- [Mage] Mana Shield (Rank 1)\n    [  8494] = {   1,   209,    0, 28,  0, 28, 0  }, -- [Mage] Mana Shield (Rank 2)\n    [  8495] = {   1,   299,    0, 36,  0, 36, 0  }, -- [Mage] Mana Shield (Rank 3)\n    [ 10191] = {   1,   389,    0, 44,  0, 44, 0  }, -- [Mage] Mana Shield (Rank 4)\n    [ 10192] = {   1,   479,    0, 52,  0, 52, 0  }, -- [Mage] Mana Shield (Rank 5)\n    [ 10193] = {   1,   569,    0, 60,  0, 60, 0  }, -- [Mage] Mana Shield (Rank 6)\n    [ 15041] = {   4,   119,    0, 20,  0, 20, 0  }, -- [Mage] Fire Ward\n    [   543] = {   4,   164,    0, 20,  0, 20, 0  }, -- [Mage] Fire Ward (Rank 1)\n    [  8457] = {   4,   289,    0, 30,  0, 30, 0  }, -- [Mage] Fire Ward (Rank 2)\n    [  8458] = {   4,   469,    0, 40,  0, 40, 0  }, -- [Mage] Fire Ward (Rank 3)\n    [ 10223] = {   4,   674,    0, 50,  0, 50, 0  }, -- [Mage] Fire Ward (Rank 4)\n    [ 10225] = {   4,   919,    0, 60,  0, 60, 0  }, -- [Mage] Fire Ward (Rank 5)\n    [ 15044] = {  16,   119,    0, 20,  0, 20, 0  }, -- [Mage] Frost Ward\n    [  6143] = {  16,   164,    0, 22,  0, 22, 0  }, -- [Mage] Frost Ward (Rank 1)\n    [  8461] = {  16,   289,    0, 32,  0, 32, 0  }, -- [Mage] Frost Ward (Rank 2)\n    [  8462] = {  16,   469,    0, 42,  0, 42, 0  }, -- [Mage] Frost Ward (Rank 3)\n    [ 10177] = {  16,   674,    0, 52,  0, 52, 0  }, -- [Mage] Frost Ward (Rank 4)\n    [ 28609] = {  16,   919,    0, 60,  0, 60, 0  }, -- [Mage] Frost Ward (Rank 5)\n    [ 11426] = { 127,   437,  2.8, 40, 46, 40, 0.1}, -- [Mage] Ice Barrier (Rank 1)\n    [ 13031] = { 127,   548,  3.2, 46, 52, 46, 0.1}, -- [Mage] Ice Barrier (Rank 2)\n    [ 13032] = { 127,   677,  3.6, 52, 58, 52, 0.1}, -- [Mage] Ice Barrier (Rank 3)\n    [ 13033] = { 127,   817,    4, 58, 64, 58, 0.1}, -- [Mage] Ice Barrier (Rank 4)\n    [ 26470] = { 127,     0,    0,  0,  0,  1, 0  }, -- [Mage] Persistent Shield\n    [ 17729] = { 126,   649,    0, 48,  0, 48, 0  }, -- [Warlock] Greater Spellstone\n    [ 17730] = { 126,   899,    0, 60,  0, 60, 0  }, -- [Warlock] Major Spellstone\n    [   128] = { 126,   399,    0, 36,  0, 36, 0  }, -- [Warlock] Spellstone\n    [  7812] = { 127,   304,  2.3, 16, 22, 16, 0  }, -- [Warlock] Sacrifice (Rank 1)\n    [ 19438] = { 127,   509,  3.1, 24, 30, 24, 0  }, -- [Warlock] Sacrifice (Rank 2)\n    [ 19440] = { 127,   769,  3.9, 32, 38, 32, 0  }, -- [Warlock] Sacrifice (Rank 3)\n    [ 19441] = { 127,  1094,  4.7, 40, 46, 40, 0  }, -- [Warlock] Sacrifice (Rank 4)\n    [ 19442] = { 127,  1469,  5.5, 48, 54, 48, 0  }, -- [Warlock] Sacrifice (Rank 5)\n    [ 19443] = { 127,  1904,  6.4, 56, 62, 56, 0  }, -- [Warlock] Sacrifice (Rank 6)\n}\n\n\n",
["do_custom"] = true,
},
},
["triggers"] = {
{
["trigger"] = {
["duration"] = "1",
["subeventPrefix"] = "SPELL",
["debuffType"] = "HELPFUL",
["custom_hide"] = "custom",
["type"] = "custom",
["names"] = {
},
["custom_type"] = "status",
["spellIds"] = {
},
["custom"] = "function(...)\n    aura_env:on_cleu(...)\nend\n\n\n",
["event"] = "Conditions",
["customStacks"] = "",
["customDuration"] = "",
["customName"] = "",
["events"] = "COMBAT_LOG_EVENT_UNFILTERED DELAYED_PLAYER_ENTERING_WORLD",
["unit"] = "player",
["check"] = "event",
["subeventSuffix"] = "_CAST_START",
["unevent"] = "auto",
["use_unit"] = true,
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["displayText_format_p_time_mod_rate"] = true,
["displayText_format_p_time_legacy_floor"] = true,
["wordWrap"] = "WordWrap",
["font"] = "FORCED SQUARE",
["version"] = 3,
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["load"] = {
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["zoneIds"] = "",
},
["fontSize"] = 20,
["source"] = "import",
["uid"] = "gURA36O1i4T",
["shadowXOffset"] = 1,
["selfPoint"] = "BOTTOM",
["preferToUpdate"] = false,
["regionType"] = "text",
["fixedWidth"] = 200,
["color"] = {
1,
1,
1,
1,
},
["displayText_format_p_format"] = "timed",
["automaticWidth"] = "Auto",
["anchorFrameParent"] = false,
["xOffset"] = 0,
["displayText"] = "%p",
["semver"] = "1.0.2",
["justify"] = "CENTER",
["tocversion"] = 11500,
["id"] = "nanShield:Value",
["authorOptions"] = {
{
["type"] = "toggle",
["default"] = false,
["key"] = "debugEnabled",
["name"] = "Enable Debug Info",
["useDesc"] = false,
["width"] = 2,
},
{
["type"] = "toggle",
["default"] = false,
["key"] = "fixRemoveAura",
["name"] = "Fix remove aura",
["useDesc"] = false,
["width"] = 1,
},
},
["frameStrata"] = 1,
["anchorFrameType"] = "SCREEN",
["yOffset"] = -10,
["config"] = {
["debugEnabled"] = false,
["fixRemoveAura"] = false,
},
["displayText_format_p_time_precision"] = 1,
["internalVersion"] = 78,
["shadowColor"] = {
0,
0,
0,
1,
},
["conditions"] = {
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
},
["Sunder Debuff"] = {
["iconSource"] = 0,
["wagoID"] = "A3Z0KIoeL",
["authorOptions"] = {
},
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = -219.70006103516,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["subeventSuffix"] = "_CAST_START",
["matchesShowOn"] = "showOnActive",
["event"] = "Health",
["names"] = {
},
["useExactSpellId"] = false,
["spellIds"] = {
},
["unit"] = "target",
["subeventPrefix"] = "SPELL",
["auranames"] = {
"Sunder Armor",
},
["useName"] = true,
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = 0,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "CENTER",
["text_fontSize"] = 24,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = false,
["glowLength"] = 10,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 43,
["load"] = {
["use_class"] = true,
["use_ingroup"] = true,
["talent"] = {
["multi"] = {
},
},
["ingroup"] = {
["single"] = "raid",
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "WARRIOR",
["multi"] = {
["WARRIOR"] = true,
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["anchorFrameType"] = "SCREEN",
["source"] = "import",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["adjustedMax"] = "",
["cooldownEdge"] = false,
["cooldown"] = true,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["conditions"] = {
{
["check"] = {
["op"] = "<",
["checks"] = {
{
["trigger"] = 1,
["op"] = "<",
["value"] = "5",
["variable"] = "stacks",
},
},
["value"] = "5",
["variable"] = "stacks",
["trigger"] = 1,
},
["changes"] = {
{
["value"] = true,
["property"] = "sub.3.glow",
},
},
},
},
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "Armor Debuffs",
["config"] = {
},
["frameStrata"] = 1,
["zoom"] = 0,
["cooldownTextDisabled"] = true,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Sunder Debuff",
["useCooldownModRate"] = true,
["alpha"] = 1,
["width"] = 43,
["progressSource"] = {
-1,
"",
},
["uid"] = "B6SrvVnCB7n",
["inverse"] = false,
["color"] = {
1,
1,
1,
1,
},
["displayIcon"] = "132363",
["information"] = {
},
["xOffset"] = -93.533312988281,
},
["Blade Dance"] = {
["iconSource"] = -1,
["wagoID"] = "dTwWQJRhb",
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["cooldownEdge"] = false,
["actions"] = {
["start"] = {
["do_glow"] = false,
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["auranames"] = {
"6774",
"6434",
"5171",
},
["event"] = "Health",
["unit"] = "player",
["names"] = {
},
["auraspellids"] = {
"400012",
},
["spellIds"] = {
},
["useName"] = false,
["useExactSpellId"] = true,
["subeventPrefix"] = "SPELL",
["subeventSuffix"] = "_CAST_START",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = true,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_text_format_p_time_precision"] = 1,
["text_text"] = "%p",
["text_text_format_p_time_mod_rate"] = true,
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_p_time_legacy_floor"] = true,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["text_text_format_p_time_dynamic_threshold"] = 10,
["text_shadowColor"] = {
0,
0,
0,
1,
},
["type"] = "subtext",
["text_text_format_p_format"] = "timed",
["text_color"] = {
1,
1,
1,
1,
},
["border_color"] = {
},
["text_font"] = "Gilroy Bold",
["text_anchorYOffset"] = 0,
["text_fontType"] = "THICKOUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_shadowYOffset"] = 0,
["text_text_format_p_time_format"] = 0,
["text_fontSize"] = 18,
["anchorXOffset"] = 0,
["anchorYOffset"] = 0,
},
},
["height"] = 32,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["anchorFrameType"] = "SCREEN",
["source"] = "import",
["useCooldownModRate"] = true,
["progressSource"] = {
-1,
"",
},
["adjustedMax"] = "",
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["animation"] = {
["start"] = {
["colorR"] = 1,
["scalex"] = 1,
["alphaType"] = "straight",
["colorB"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
["use_alpha"] = false,
["type"] = "none",
["easeType"] = "easeIn",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["colorA"] = 1,
["duration"] = "30",
["easeStrength"] = 3,
["rotate"] = 0,
["duration_type"] = "relative",
},
["main"] = {
["colorR"] = 1,
["duration"] = "30",
["alphaType"] = "alphaPulse",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0.26,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "alphaPulse",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "relative",
},
["finish"] = {
["colorR"] = 1,
["scalex"] = 1,
["alphaType"] = "alphaPulse",
["colorB"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["colorA"] = 1,
["duration"] = "8",
["easeStrength"] = 3,
["rotate"] = 0,
["duration_type"] = "seconds",
},
},
["icon"] = true,
["authorOptions"] = {
},
["uid"] = "K0XrhHjfkhd",
["frameStrata"] = 1,
["zoom"] = 0,
["cooldownTextDisabled"] = true,
["semver"] = "1.0.23",
["tocversion"] = 11500,
["id"] = "Blade Dance",
["auto"] = true,
["alpha"] = 1,
["width"] = 32,
["xOffset"] = 0,
["config"] = {
},
["inverse"] = false,
["parent"] = "SimonizeBars",
["conditions"] = {
},
["cooldown"] = false,
["url"] = "https://wago.io/dTwWQJRhb/24",
},
["Homunculus"] = {
["iconSource"] = -1,
["wagoID"] = "A3Z0KIoeL",
["parent"] = "Armor Debuffs",
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = -219.70006103516,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["useName"] = false,
["useExactSpellId"] = true,
["matchesShowOn"] = "showOnActive",
["event"] = "Health",
["subeventPrefix"] = "SPELL",
["auranames"] = {
"",
},
["names"] = {
},
["spellIds"] = {
},
["type"] = "aura2",
["subeventSuffix"] = "_CAST_START",
["unit"] = "target",
["auraspellids"] = {
"402818",
},
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = 0,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "CENTER",
["text_fontSize"] = 24,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = false,
["glowLength"] = 10,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 43,
["load"] = {
["use_ingroup"] = true,
["talent"] = {
["multi"] = {
},
},
["ingroup"] = {
["single"] = "raid",
},
["class"] = {
["single"] = "WARRIOR",
["multi"] = {
["WARRIOR"] = true,
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["source"] = "import",
["cooldownTextDisabled"] = true,
["config"] = {
},
["adjustedMax"] = "",
["authorOptions"] = {
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["information"] = {
},
["cooldownEdge"] = false,
["xOffset"] = -93.533312988281,
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["anchorFrameType"] = "SCREEN",
["frameStrata"] = 1,
["zoom"] = 0,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Homunculus",
["useCooldownModRate"] = true,
["alpha"] = 1,
["width"] = 43,
["color"] = {
1,
1,
1,
1,
},
["uid"] = "log9wYrRoTp",
["inverse"] = false,
["icon"] = true,
["conditions"] = {
},
["cooldown"] = true,
["progressSource"] = {
-1,
"",
},
},
["RockbiterIcon"] = {
["iconSource"] = -1,
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["cooldownEdge"] = true,
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
["do_custom"] = false,
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "item",
["subeventSuffix"] = "_CAST_START",
["weapon"] = "main",
["duration"] = "1",
["event"] = "Weapon Enchant",
["unit"] = "player",
["names"] = {
},
["spellIds"] = {
},
["use_weapon"] = true,
["subeventPrefix"] = "SPELL",
["showOn"] = "showOnActive",
["unevent"] = "auto",
["use_unit"] = true,
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["useName"] = true,
["subeventSuffix"] = "_CAST_START",
["ownOnly"] = true,
["event"] = "Health",
["unit"] = "player",
["auranames"] = {
"Rockbiter Weapon",
},
["type"] = "aura2",
["subeventPrefix"] = "SPELL",
["matchesShowOn"] = "showOnMissing",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["disjunctive"] = "any",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 4,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text"] = "Cast enchantment",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "CENTER",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_anchorXOffset"] = 0,
["text_color"] = {
1,
0.066666666666667,
0.24705882352941,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_anchorYOffset"] = -39,
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_shadowYOffset"] = 0,
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_fontType"] = "OUTLINE",
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowLength"] = 10,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["glowXOffset"] = 0,
["useGlowColor"] = false,
["glow"] = true,
["glowScale"] = 1,
["glowThickness"] = 1,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 64,
["load"] = {
["use_class"] = true,
["use_spellknown"] = false,
["zoneIds"] = "",
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "SHAMAN",
["multi"] = {
},
},
["spellknown"] = 8017,
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["width"] = 64,
["source"] = "import",
["frameStrata"] = 1,
["progressSource"] = {
-1,
"",
},
["adjustedMax"] = "",
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["authorOptions"] = {
},
["icon"] = true,
["xOffset"] = 0,
["uid"] = "8Cvw52(NOOu",
["useCooldownModRate"] = true,
["zoom"] = 0,
["cooldownTextDisabled"] = false,
["auto"] = true,
["tocversion"] = 11302,
["id"] = "RockbiterIcon",
["semver"] = "1.0.3",
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["url"] = "https://wago.io/RrBFPkRTq/4",
["config"] = {
},
["inverse"] = false,
["animation"] = {
["start"] = {
["duration_type"] = "seconds",
["type"] = "none",
["easeStrength"] = 3,
["easeType"] = "none",
},
["main"] = {
["duration_type"] = "seconds",
["type"] = "none",
["easeStrength"] = 3,
["easeType"] = "none",
},
["finish"] = {
["duration_type"] = "seconds",
["type"] = "none",
["easeStrength"] = 3,
["easeType"] = "none",
},
},
["conditions"] = {
{
["check"] = {
["trigger"] = 1,
["op"] = ">",
["variable"] = "expirationTime",
["value"] = "20",
},
["changes"] = {
{
["property"] = "sub.3.glow",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = ">",
["value"] = 1,
["variable"] = "show",
},
["changes"] = {
{
["value"] = false,
["property"] = "sub.2.text_visible",
},
},
},
},
["cooldown"] = true,
["parent"] = "Rockbiter",
},
["Bolts Left"] = {
["controlledChildren"] = {
"Bolt",
"Bolt 2",
"Bolt 3",
"Bolt 4",
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "br2BQB5LA",
["parent"] = "Arcane Blast",
["preferToUpdate"] = false,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["borderColor"] = {
0,
0,
0,
1,
},
["url"] = "https://wago.io/br2BQB5LA/1",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["names"] = {
},
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["unit"] = "player",
["event"] = "Health",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
},
["internalVersion"] = 78,
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["version"] = 1,
["subRegions"] = {
},
["load"] = {
["talent"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["backdropColor"] = {
1,
1,
1,
0.5,
},
["source"] = "import",
["scale"] = 1,
["border"] = false,
["borderEdge"] = "Square Full White",
["regionType"] = "group",
["borderSize"] = 2,
["authorOptions"] = {
},
["borderOffset"] = 4,
["semver"] = "1.0.0",
["tocversion"] = 11500,
["id"] = "Bolts Left",
["xOffset"] = 0,
["frameStrata"] = 1,
["anchorFrameType"] = "SCREEN",
["selfPoint"] = "CENTER",
["uid"] = "rUSTOuFjyvY",
["borderInset"] = 1,
["config"] = {
},
["conditions"] = {
},
["information"] = {
},
["alpha"] = 1,
},
["Expose Debuff"] = {
["iconSource"] = 0,
["wagoID"] = "A3Z0KIoeL",
["authorOptions"] = {
},
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = -219.70006103516,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = true,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["subeventSuffix"] = "_CAST_START",
["matchesShowOn"] = "showOnActive",
["event"] = "Health",
["names"] = {
},
["useExactSpellId"] = false,
["spellIds"] = {
},
["unit"] = "target",
["subeventPrefix"] = "SPELL",
["auranames"] = {
"Expose Armor",
},
["useName"] = true,
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_shadowXOffset"] = 0,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_shadowYOffset"] = 0,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "CENTER",
["text_fontSize"] = 24,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = false,
["glowLength"] = 10,
["glowLines"] = 8,
["glowBorder"] = false,
},
},
["height"] = 43,
["load"] = {
["use_ingroup"] = true,
["talent"] = {
["multi"] = {
},
},
["ingroup"] = {
["single"] = "raid",
},
["class"] = {
["single"] = "WARRIOR",
["multi"] = {
["WARRIOR"] = true,
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["useAdjustededMax"] = false,
["anchorFrameType"] = "SCREEN",
["source"] = "import",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["adjustedMax"] = "",
["cooldownEdge"] = false,
["cooldown"] = true,
["useAdjustededMin"] = false,
["regionType"] = "icon",
["conditions"] = {
},
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["parent"] = "Armor Debuffs",
["config"] = {
},
["frameStrata"] = 1,
["zoom"] = 0,
["cooldownTextDisabled"] = true,
["semver"] = "1.0.18",
["tocversion"] = 11500,
["id"] = "Expose Debuff",
["useCooldownModRate"] = true,
["alpha"] = 1,
["width"] = 43,
["progressSource"] = {
-1,
"",
},
["uid"] = "0(Yk98ED2Qx",
["inverse"] = false,
["color"] = {
1,
1,
1,
1,
},
["displayIcon"] = "132354",
["information"] = {
},
["xOffset"] = -93.533312988281,
},
["Health Bar"] = {
["sparkWidth"] = 10,
["sparkOffsetX"] = 0,
["wagoID"] = "A3Z0KIoeL",
["parent"] = "General Auras",
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = -295.8885345458984,
["anchorPoint"] = "CENTER",
["zoom"] = 0,
["sparkRotation"] = 0,
["sparkRotationMode"] = "AUTO",
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["type"] = "unit",
["use_health"] = true,
["subeventSuffix"] = "_CAST_START",
["event"] = "Health",
["subeventPrefix"] = "SPELL",
["use_unit"] = true,
["health_operator"] = {
">",
},
["health"] = {
"0",
},
["spellIds"] = {
},
["unit"] = "player",
["use_percenthealth"] = false,
["names"] = {
},
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["icon_color"] = {
1,
1,
1,
1,
},
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["selfPoint"] = "CENTER",
["backgroundColor"] = {
0,
0,
0,
0.5,
},
["barColor2"] = {
1,
0.003921568627451,
0,
1,
},
["barColor"] = {
0,
1,
0.031372549019608,
1,
},
["desaturate"] = false,
["iconSource"] = -1,
["adjustedMax"] = "",
["version"] = 19,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["type"] = "subforeground",
},
{
["text_shadowXOffset"] = 1,
["text_text_format_t_time_legacy_floor"] = false,
["text_text_format_p_format"] = "timed",
["text_text_format_p_time_dynamic_threshold"] = 60,
["text_text_format_p_time_mod_rate"] = true,
["text_text_format_p_time_legacy_floor"] = false,
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_t_time_format"] = 0,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_text_format_t_format"] = "timed",
["text_text_format_t_time_precision"] = 1,
["text_text"] = "%p / %t",
["type"] = "subtext",
["text_text_format_t_time_mod_rate"] = true,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_fontType"] = "None",
["text_shadowYOffset"] = -1,
["text_text_format_p_time_format"] = 0,
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "INNER_CENTER",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_text_format_p_time_precision"] = 1,
["text_fontSize"] = 16,
["anchorXOffset"] = 0,
["text_text_format_t_time_dynamic_threshold"] = 60,
},
{
["border_size"] = 2,
["border_anchor"] = "bar",
["type"] = "subborder",
["border_color"] = {
1,
1,
1,
1,
},
["border_visible"] = true,
["border_edge"] = "Blizzard Chat Bubble",
["border_offset"] = 0,
},
},
["gradientOrientation"] = "HORIZONTAL",
["textureSource"] = "LSM",
["load"] = {
["use_never"] = true,
["talent"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
},
["sparkBlendMode"] = "ADD",
["useAdjustededMax"] = false,
["authorOptions"] = {
},
["source"] = "import",
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["sparkColor"] = {
1,
1,
1,
1,
},
["config"] = {
},
["width"] = 117,
["useAdjustededMin"] = false,
["regionType"] = "aurabar",
["frameStrata"] = 1,
["sparkOffsetY"] = 0,
["icon_side"] = "RIGHT",
["id"] = "Health Bar",
["sparkHeight"] = 30,
["texture"] = "Blizzard",
["semver"] = "1.0.18",
["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
["spark"] = false,
["tocversion"] = 11500,
["sparkHidden"] = "NEVER",
["xOffset"] = -66.5001220703125,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["height"] = 23,
["uid"] = "XLd0zWRlgAk",
["inverse"] = false,
["icon"] = false,
["orientation"] = "HORIZONTAL",
["conditions"] = {
},
["information"] = {
},
["enableGradient"] = false,
},
["nanShield:Bar"] = {
["overlays"] = {
{
0.94901960784314,
0.89411764705882,
0.56078431372549,
1,
},
{
0.9921568627451,
0.7921568627451,
0.63529411764706,
1,
},
{
0,
0.50196078431373,
1,
1,
},
{
1,
1,
0,
1,
},
{
1,
0.50196078431373,
0,
1,
},
{
0.50196078431373,
1,
0,
1,
},
{
0,
1,
1,
1,
},
},
["iconSource"] = -1,
["authorOptions"] = {
{
["type"] = "toggle",
["default"] = false,
["width"] = 1,
["name"] = "Show as %HP",
["useDesc"] = true,
["key"] = "isHealthPct",
["desc"] = "When enabled, the bar's total will be set to player's max health",
},
{
["text"] = "",
["type"] = "header",
["useName"] = false,
["width"] = 1,
},
{
["type"] = "toggle",
["default"] = false,
["key"] = "debugEnabled",
["name"] = "Enable Debug Info",
["useDesc"] = false,
["width"] = 1,
},
},
["preferToUpdate"] = false,
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["sparkRotation"] = 0,
["url"] = "https://wago.io/6HHBMDHTD/3",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
["custom"] = "-- Package common/logging\naura_env.logPalette = {\n    \"ff6e7dda\",\n    \"ff21dfb9\",\n    \"ffe3f57a\",\n    \"ffed705a\",\n    \"fff8a3e6\",\n}\n\nfunction aura_env:log(...)\n    if self.config and self.config.debugEnabled then\n        local palette = self.logPalette\n        local args = {\n            self.cloneId and\n            format(\"[%s:%s]\", self.id, self.cloneId) or\n            format(\"[%s]\", self.id),\n            ...\n        }\n        for i = 1, #args do\n            args[i] = format(\n                \"|c%s%s|r\",\n                palette[1 + (i - 1) % #palette],\n                tostring(args[i]))\n        end\n        print(unpack(args))\n    end\nend\n-- Package end\n\n-- Package common/lowabsorb\nfunction aura_env:LowestAbsorb(totalAbsorb, all, physical, magic, ...)\n    self:log('LowestAbsorb', all, physical, magic, ...)\n    local minValue\n    local minIdx\n    local value\n    \n    for i = 1, select('#', ...) do\n        value = select(i, ...)\n        if value > 0 and value <= (minValue or value) then\n            minIdx = i + 3\n            minValue = value\n        end\n    end\n    \n    if minIdx then\n        minValue = minValue + magic\n    elseif magic > 0 then\n        minValue = magic\n        minIdx = 3\n    end\n    \n    if physical > 0 and physical <= (minValue or physical) then\n        minValue = physical\n        minIdx = 2\n    end\n    \n    if minIdx then\n        minValue = minValue + all\n    else\n        minValue = all\n        minIdx = 1\n    end\n    \n    self:log('LowestAbsorbResult', minValue, totalAbsorb, minIdx)\n    return minValue, totalAbsorb, minIdx\nend\n-- Package end\n\n-- Package common/schools\naura_env.schools = {\n    \"All\",\n    \"Physical\",\n    \"Magic\",\n    \"Holy\",\n    \"Fire\",\n    \"Nature\",\n    \"Frost\",\n    \"Shadow\",\n    \"Arcane\",\n}\naura_env.schoolIds = { 127, 1, 126, 2, 4, 8, 16, 32, 64 }\naura_env.schoolIdx = {}\nfor idx, id in ipairs(aura_env.schoolIds) do\n    aura_env.schoolIdx[id] = idx\nend\n-- Package end\n\n-- Package bar/tsu\nfunction aura_env:on_tsu(allstates, event, ...)\n    self:log(event, ...)\n    local changed = false\n    local state = allstates[1] or {\n        show = true,\n        changed = true,\n        progressType = 'static',\n        value = 0,\n        total = 0,\n        stacks = 0,\n        additionalProgress = {\n            {}, {}, {},\n            {}, {}, {},\n            {}, {}, {},\n        }\n    }\n    allstates[1] = state\n    \n    if event == 'WA_NAN_SHIELD' and select(1, ...) then\n        local value, school\n        local minValue, totalAbsorb, minIdx = self:LowestAbsorb(...)\n        minValue = ceil(minValue)\n        totalAbsorb = ceil(totalAbsorb)\n        \n        if self.config.isHealthPct then\n            totalAbsorb = UnitHealthMax(\"player\")\n        end\n        \n        changed = changed or state.total ~= totalAbsorb\n        changed = changed or state.stacks ~= minValue\n        changed = changed or state.show ~= (minValue > 0)\n        state.show = minValue > 0\n        state.total = totalAbsorb\n        state.stacks = minValue\n        state.school = self.schools[minIdx]\n        \n        local progressOffset = 0\n        for i, ap in ipairs(state.additionalProgress) do\n            value = select(i + 1, ...)\n            school = self.schools[i]\n            self:log('Set', school, value)\n            changed = changed or ap.width ~= value\n            ap.min = progressOffset\n            ap.max = progressOffset + value\n            ap.school = school\n            progressOffset = progressOffset + value\n        end\n        \n        allstates[1].changed = changed\n    end\n    return changed\nend\n-- Package end\n\n\n\n",
["do_custom"] = true,
},
},
["icon_color"] = {
1,
1,
1,
1,
},
["enableGradient"] = false,
["selfPoint"] = "CENTER",
["barColor"] = {
0,
0,
0,
1,
},
["desaturate"] = false,
["sparkOffsetY"] = 0,
["gradientOrientation"] = "HORIZONTAL",
["load"] = {
["use_never"] = true,
["talent"] = {
["multi"] = {
},
},
["size"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["zoneIds"] = "",
},
["useAdjustededMin"] = false,
["regionType"] = "aurabar",
["overlayclip"] = false,
["texture"] = "Details Flat",
["zoom"] = 0,
["spark"] = false,
["tocversion"] = 11500,
["alpha"] = 1,
["uid"] = "nNYjECvELIW",
["sparkOffsetX"] = 0,
["wagoID"] = "6HHBMDHTD",
["parent"] = "nanShield Classic",
["adjustedMin"] = "",
["sparkRotationMode"] = "AUTO",
["triggers"] = {
{
["trigger"] = {
["duration"] = "1",
["subeventPrefix"] = "SPELL",
["custom_hide"] = "custom",
["type"] = "custom",
["custom_type"] = "stateupdate",
["debuffType"] = "HELPFUL",
["customOverlay1"] = "",
["event"] = "Chat Message",
["names"] = {
},
["unit"] = "player",
["custom"] = "function(...)\n  return aura_env:on_tsu(...)\nend",
["spellIds"] = {
},
["events"] = "WA_NAN_SHIELD",
["check"] = "event",
["subeventSuffix"] = "_CAST_START",
["unevent"] = "timed",
["customVariables"] = "{\n    additionalProgress = 9,\n    school = {\n        type = \"select\",\n        display = \"Damage Type\",\n        values = {\n            [\"All\"] = \"All\",\n            [\"Physical\"] = \"Physical\",\n            [\"Magic\"] = \"Magic\",\n            [\"Holy\"] = \"Holy\",\n            [\"Fire\"] = \"Fire\",\n            [\"Nature\"] = \"Nature\",\n            [\"Frost\"] = \"Frost\",\n            [\"Shadow\"] = \"Shadow\",\n            [\"Arcane\"] = \"Arcane\"\n        }\n    }\n}",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["version"] = 3,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["type"] = "subforeground",
},
{
["text_shadowXOffset"] = 1,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "FORCED SQUARE",
["text_shadowYOffset"] = -1,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "THICKOUTLINE",
["text_anchorPoint"] = "INNER_CENTER",
["text_fontSize"] = 16,
["anchorXOffset"] = 0,
["text_visible"] = true,
},
},
["height"] = 20,
["textureSource"] = "LSM",
["sparkBlendMode"] = "ADD",
["useAdjustededMax"] = false,
["source"] = "import",
["useAdjustedMax"] = false,
["config"] = {
["debugEnabled"] = false,
["isHealthPct"] = false,
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["xOffset"] = 0,
["icon_side"] = "RIGHT",
["sparkWidth"] = 10,
["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
["sparkHeight"] = 30,
["backgroundColor"] = {
0,
0,
0,
0.5,
},
["sparkColor"] = {
1,
1,
1,
1,
},
["sparkHidden"] = "NEVER",
["semver"] = "1.0.2",
["anchorFrameType"] = "SCREEN",
["id"] = "nanShield:Bar",
["icon"] = false,
["frameStrata"] = 1,
["width"] = 200,
["auto"] = true,
["useAdjustedMin"] = false,
["inverse"] = false,
["anchorFrameParent"] = false,
["orientation"] = "HORIZONTAL",
["conditions"] = {
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "All",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0.94901960784314,
0.89411764705882,
0.56078431372549,
1,
},
["property"] = "sub.3.text_color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Magic",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0,
0.50196078431373,
1,
1,
},
["property"] = "sub.3.text_color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Physical",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0.9921568627451,
0.7921568627451,
0.63529411764706,
1,
},
["property"] = "sub.3.text_color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Arcane",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
1,
0.61176470588235,
1,
1,
},
["property"] = "sub.3.text_color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Fire",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
1,
0.50196078431373,
0,
1,
},
["property"] = "sub.3.text_color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Frost",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0,
1,
1,
1,
},
["property"] = "sub.3.text_color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Holy",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
1,
1,
0,
1,
},
["property"] = "sub.3.text_color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Nature",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0.50196078431373,
1,
0,
1,
},
["property"] = "sub.3.text_color",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "==",
["value"] = "Shadow",
["variable"] = "school",
},
["changes"] = {
{
["value"] = {
0.72941176470588,
0.45882352941177,
1,
1,
},
["property"] = "sub.3.text_color",
},
},
},
},
["barColor2"] = {
1,
1,
0,
1,
},
["adjustedMax"] = "",
},
["Homonculi Tracker"] = {
["grow"] = "HORIZONTAL",
["controlledChildren"] = {
"Icon",
},
["borderBackdrop"] = "Blizzard Tooltip",
["wagoID"] = "Wj2dOxJp_",
["authorOptions"] = {
},
["preferToUpdate"] = false,
["yOffset"] = -435.3508720397949,
["anchorPoint"] = "CENTER",
["fullCircle"] = true,
["rowSpace"] = 1,
["url"] = "https://wago.io/Wj2dOxJp_/1",
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["triggers"] = {
{
["trigger"] = {
["names"] = {
},
["type"] = "aura2",
["spellIds"] = {
},
["subeventSuffix"] = "_CAST_START",
["subeventPrefix"] = "SPELL",
["debuffType"] = "HELPFUL",
["event"] = "Health",
["unit"] = "player",
},
["untrigger"] = {
},
},
},
["columnSpace"] = 1,
["internalVersion"] = 78,
["selfPoint"] = "CENTER",
["align"] = "CENTER",
["uid"] = "wNRdyU0BedH",
["gridWidth"] = 5,
["radius"] = 200,
["stagger"] = 0,
["borderColor"] = {
0,
0,
0,
1,
},
["version"] = 1,
["subRegions"] = {
},
["sortHybridTable"] = {
["Icon"] = false,
},
["gridType"] = "RD",
["load"] = {
["size"] = {
["multi"] = {
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
},
},
["talent"] = {
["multi"] = {
},
},
},
["rotation"] = 0,
["backdropColor"] = {
1,
1,
1,
0.5,
},
["space"] = 2,
["source"] = "import",
["borderInset"] = 1,
["scale"] = 1,
["centerType"] = "LR",
["border"] = false,
["borderEdge"] = "Square Full White",
["stepAngle"] = 15,
["borderSize"] = 2,
["limit"] = 5,
["regionType"] = "dynamicgroup",
["animate"] = false,
["constantFactor"] = "RADIUS",
["sort"] = "none",
["borderOffset"] = 4,
["semver"] = "1.0.0",
["tocversion"] = 11500,
["id"] = "Homonculi Tracker",
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["frameStrata"] = 1,
["anchorFrameType"] = "SCREEN",
["xOffset"] = -316.523193359375,
["config"] = {
},
["useLimit"] = false,
["arcLength"] = 360,
["conditions"] = {
},
["information"] = {
},
["alpha"] = 1,
},
["5 Second Rule Background - Not Regenerating"] = {
["sparkWidth"] = 6,
["iconSource"] = -1,
["xOffset"] = 0,
["preferToUpdate"] = false,
["yOffset"] = -6,
["anchorPoint"] = "BOTTOM",
["sparkRotation"] = 0,
["url"] = "https://wago.io/mana-ticker/4",
["backgroundColor"] = {
0.37647058823529,
0.37647058823529,
0.37647058823529,
0,
},
["fontFlags"] = "OUTLINE",
["icon_color"] = {
1,
1,
1,
1,
},
["enableGradient"] = false,
["selfPoint"] = "CENTER",
["barColor"] = {
0.37647058823529,
0,
0,
1,
},
["desaturate"] = false,
["sparkOffsetY"] = 0,
["gradientOrientation"] = "HORIZONTAL",
["load"] = {
["ingroup"] = {
["multi"] = {
},
},
["use_never"] = false,
["class"] = {
["single"] = "PRIEST",
["multi"] = {
["HUNTER"] = true,
["WARLOCK"] = true,
["SHAMAN"] = true,
["MAGE"] = true,
["DRUID"] = true,
["PRIEST"] = true,
},
},
["use_class"] = false,
["role"] = {
["multi"] = {
},
},
["use_spec"] = true,
["level"] = {
"2",
},
["size"] = {
["multi"] = {
},
},
["talent2"] = {
["multi"] = {
},
},
["use_level"] = true,
["talent"] = {
["single"] = 12,
["multi"] = {
[12] = true,
},
},
["spec"] = {
["single"] = 1,
["multi"] = {
[3] = true,
},
},
["difficulty"] = {
["multi"] = {
},
},
["faction"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["pvptalent"] = {
["multi"] = {
},
},
["level_operator"] = {
">",
},
["race"] = {
["multi"] = {
},
},
},
["smoothProgress"] = true,
["useAdjustededMin"] = false,
["regionType"] = "aurabar",
["texture"] = "ElvUI Norm",
["zoom"] = 0,
["auto"] = true,
["tocversion"] = 11306,
["alpha"] = 1,
["uid"] = "MtdO(1NMr5O",
["sparkOffsetX"] = 0,
["parent"] = "Player mana regen",
["customText"] = "function()\n    local timeLeft = aura_env.state.duration\n    if timeLeft == 0 then\n        return \"\"\n    else\n        \n        return (\"%i\"):format(timeLeft)\n    end\nend\n\n\n\n\n",
["customTextUpdate"] = "update",
["triggers"] = {
{
["trigger"] = {
["duration"] = "2",
["use_unit"] = true,
["debuffType"] = "HELPFUL",
["type"] = "custom",
["unevent"] = "auto",
["names"] = {
},
["unit"] = "player",
["event"] = "Health",
["custom_type"] = "stateupdate",
["spellIds"] = {
},
["events"] = "PLAYER_ENTERING_WORLD, UNIT_SPELLCAST_SUCCEEDED, UNIT_MAXPOWER, CURRENT_SPELL_CAST_CHANGED",
["custom"] = "function(a, e, t)\n    local currentMana = UnitPower(\"player\" , 0)\n    \n    if e == \"UNIT_SPELLCAST_SUCCEEDED\" and currentMana < aura_env.lastMana and currentMana < UnitPowerMax(\"player\", 0) then\n        \n        aura_env.lastMana = currentMana\n        local duration = 5.5\n        a[\"\"] = {\n            show = true,\n            changed = true,\n            duration = duration,\n            expirationTime = GetTime() + duration,\n            progressType = \"timed\",\n            autoHide = true\n        }   \n        return true\n    end\n    \n    aura_env.lastMana = currentMana\n    return false\nend",
["use_sourceUnit"] = true,
["check"] = "event",
["subeventSuffix"] = "_ENERGIZE",
["sourceUnit"] = "player",
["subeventPrefix"] = "SPELL",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["useName"] = true,
["auranames"] = {
"Spirit Tap",
},
["matchesShowOn"] = "showOnMissing",
["event"] = "Health",
["unit"] = "player",
["subeventPrefix"] = "SPELL",
["type"] = "aura2",
["subeventSuffix"] = "_CAST_START",
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["preset"] = "fade",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["type"] = "preset",
["easeType"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["preset"] = "shrink",
},
},
["backdropInFront"] = false,
["sparkMirror"] = false,
["stickyDuration"] = true,
["version"] = 4,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["type"] = "subforeground",
},
{
["text_text_format_p_time_format"] = 0,
["text_text"] = " %p",
["text_text_format_p_format"] = "timed",
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_p_time_legacy_floor"] = true,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["anchorYOffset"] = 0,
["type"] = "subtext",
["text_text_format_p_time_dynamic_threshold"] = 3,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Expressway",
["text_text_format_p_time_precision"] = 1,
["text_shadowYOffset"] = -1,
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_CENTER",
["text_shadowXOffset"] = 1,
["text_visible"] = false,
["text_fontSize"] = 13,
["anchorXOffset"] = 0,
["text_text_format_p_time_mod_rate"] = true,
},
{
["text_shadowXOffset"] = 1,
["text_text_format_s_format"] = "none",
["text_text"] = "%s",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["type"] = "subtext",
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Myriad Condensed Web",
["text_shadowYOffset"] = -1,
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "None",
["text_anchorPoint"] = "ICON_CENTER",
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_visible"] = false,
},
{
["border_offset"] = 1,
["border_size"] = 1,
["border_anchor"] = "bar",
["text_color"] = {
},
["border_color"] = {
0,
0,
0,
1,
},
["border_visible"] = true,
["border_edge"] = "1 Pixel",
["type"] = "subborder",
},
},
["height"] = 5,
["textureSource"] = "LSM",
["sparkBlendMode"] = "ADD",
["backdropColor"] = {
1,
1,
1,
0.5,
},
["source"] = "import",
["authorOptions"] = {
},
["barColor2"] = {
1,
1,
0,
1,
},
["config"] = {
},
["adjustedMax"] = "",
["anchorFrameFrame"] = "PlayerFrameManaBar",
["sparkColor"] = {
1,
1,
1,
1,
},
["borderInFront"] = true,
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["icon_side"] = "RIGHT",
["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
["icon"] = false,
["sparkHeight"] = 15,
["anchorFrameType"] = "SELECTFRAME",
["sparkRotationMode"] = "AUTO",
["useAdjustededMax"] = false,
["semver"] = "1.0.3",
["sparkHidden"] = "BOTH",
["id"] = "5 Second Rule Background - Not Regenerating",
["spark"] = true,
["frameStrata"] = 4,
["width"] = 114,
["color"] = {
},
["borderBackdrop"] = "Blizzard Tooltip",
["inverse"] = true,
["sparkDesature"] = false,
["orientation"] = "HORIZONTAL",
["conditions"] = {
{
["check"] = {
["trigger"] = -1,
["variable"] = "incombat",
["value"] = 0,
},
["changes"] = {
{
["value"] = 0.6,
["property"] = "alpha",
},
},
},
},
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["adjustedMin"] = "",
},
["Barney Pull Timer-Texture"] = {
["user_y"] = 0,
["iconSource"] = 0,
["user_x"] = 0,
["xOffset"] = 0,
["displayText"] = "%number",
["yOffset"] = 0,
["foregroundColor"] = {
1,
0.49803924560547,
0,
1,
},
["displayText_format_p_time_format"] = 0,
["sameTexture"] = true,
["url"] = "https://wago.io/A3Z0KIoeL/19",
["actions"] = {
["start"] = {
["glow_frame_type"] = "UNITFRAME",
["glow_action"] = "show",
["do_message"] = false,
["do_glow"] = false,
["do_sound"] = false,
["glow_type"] = "Pixel",
["do_custom"] = false,
["glow_lines"] = 8,
["glow_thickness"] = 4,
["message_type"] = "TTS",
["glow_frequency"] = 0.2,
["glow_color"] = {
0,
0.74901962280273,
1,
1,
},
["message"] = "",
["message_tts_voice"] = 0,
["use_glow_color"] = true,
["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\AcousticGuitar.ogg",
["message_format_number_format"] = "none",
},
["finish"] = {
["hide_all_glows"] = false,
["custom"] = "",
["do_custom"] = false,
},
["init"] = {
["custom"] = "aura_env.timed = function(a, aid, duration)\n    a[aid] = {\n        show = true,\n        changed = true,\n        autoHide = true,\n        progressType = \"timed\",\n        duration = duration,\n        expirationTime = duration + GetTime(),\n    }\nend\n\naura_env.off = function(a, aid)\n    a[aid] = {\n        show = false,\n    }\nend",
["do_custom"] = true,
},
},
["useTooltip"] = false,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["displayText_format_1.unitName_format"] = "none",
["desc"] = "",
["rotation"] = 0,
["font"] = "默认",
["crop_y"] = 0.41,
["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
["foregroundTexture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Ring_30px.tga",
["shadowXOffset"] = 1,
["useAdjustededMin"] = false,
["regionType"] = "progresstexture",
["blendMode"] = "BLEND",
["displayText_format_1.name_abbreviate_max"] = 8,
["slantMode"] = "INSIDE",
["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
["cooldownTextDisabled"] = true,
["compress"] = false,
["icon"] = true,
["cooldown"] = true,
["alpha"] = 1,
["crop_x"] = 0.41,
["orientation"] = "ANTICLOCKWISE",
["auraRotation"] = 0,
["displayText_format_1.name_color"] = "class",
["displayText_format_1.health_format"] = "BigNumber",
["desaturate"] = false,
["fixedWidth"] = 200,
["backgroundColor"] = {
0,
0,
0,
0,
},
["backgroundOffset"] = 0,
["outline"] = "OUTLINE",
["parent"] = "Barney Raid Kit - Pull Timer",
["displayText_format_number_format"] = "none",
["wagoID"] = "A3Z0KIoeL",
["color"] = {
1,
1,
1,
1,
},
["frameStrata"] = 6,
["adjustedMin"] = "",
["shadowYOffset"] = -1,
["displayText_format_index_format"] = "none",
["desaturateBackground"] = true,
["cooldownSwipe"] = true,
["displayText_format_p_format"] = "timed",
["customTextUpdate"] = "event",
["cooldownEdge"] = false,
["desaturateForeground"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "custom",
["custom_type"] = "stateupdate",
["debuffType"] = "HELPFUL",
["event"] = "Health",
["unit"] = "player",
["spellIds"] = {
},
["events"] = "PULLTIMER_TICK_START,PULLTIMER_TICK_END",
["custom"] = "function(a, event, duration, number)\n    if event == \"PULLTIMER_TICK_START\" then\n        aura_env.timed(a, \"\", duration)\n        a[\"\"].number = number\n        return true\n        \n    elseif event == \"PULLTIMER_TICK_END\" then\n        aura_env.off(a, \"\")\n        return true\n    end\nend",
["names"] = {
},
["check"] = "event",
["subeventPrefix"] = "SPELL",
["subeventSuffix"] = "_CAST_START",
["customVariables"] = "{\n    number = \"number\",\n}",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["type"] = "unit",
["use_incombat"] = false,
["unit"] = "player",
["debuffType"] = "HELPFUL",
["use_alive"] = true,
["event"] = "Conditions",
["use_unit"] = true,
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["endAngle"] = 360,
["displayText_format_1.name_format"] = "Unit",
["progressSource"] = {
-1,
"",
},
["animation"] = {
["start"] = {
["type"] = "none",
["easeType"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["preset"] = "grow",
},
["main"] = {
["type"] = "none",
["easeType"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["preset"] = "alphaPulse",
},
["finish"] = {
["type"] = "none",
["easeType"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["preset"] = "grow",
},
},
["displayText_format_p_time_dynamic_threshold"] = 60,
["justify"] = "LEFT",
["uid"] = "4j5bssvk0oI",
["automaticWidth"] = "Auto",
["subRegions"] = {
{
["type"] = "subbackground",
},
},
["displayText_format_p_time_precision"] = 1,
["version"] = 19,
["displayText_format_unitName_format"] = "Unit",
["height"] = 160,
["rotate"] = false,
["internalVersion"] = 78,
["displayText_format_unitName_realm_name"] = "never",
["useAdjustededMax"] = false,
["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
["source"] = "import",
["displayText_format_1.health_big_number_format"] = "AbbreviateNumbers",
["fontSize"] = 80,
["displayText_format_unitName_abbreviate"] = false,
["mirror"] = false,
["config"] = {
},
["tocversion"] = 11500,
["displayText_format_unitName_abbreviate_max"] = 8,
["startAngle"] = 0,
["authorOptions"] = {
},
["width"] = 160,
["anchorPoint"] = "CENTER",
["anchorFrameParent"] = true,
["load"] = {
["ingroup"] = {
["single"] = "raid",
["multi"] = {
["group"] = true,
["raid"] = true,
},
},
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["zoneIds"] = "",
["encounterid"] = "",
["use_zoneIds"] = false,
["use_encounterid"] = false,
["difficulty"] = {
},
["use_ingroup"] = false,
["use_zone"] = false,
["spec"] = {
["multi"] = {
},
},
["class"] = {
["multi"] = {
["HUNTER"] = true,
["PRIEST"] = true,
["SHAMAN"] = true,
},
},
["instance_type"] = {
},
["zone"] = "",
["size"] = {
["multi"] = {
["party"] = true,
["flexible"] = true,
["ten"] = true,
["twentyfive"] = true,
["fortyman"] = true,
["twenty"] = true,
},
},
},
["displayText_format_1.name_abbreviate"] = false,
["zoom"] = 0,
["semver"] = "1.0.18",
["wordWrap"] = "WordWrap",
["id"] = "Barney Pull Timer-Texture",
["displayText_format_unitName_color"] = "class",
["useCooldownModRate"] = true,
["anchorFrameType"] = "UNITFRAME",
["displayIcon"] = 135838,
["displayText_format_1.name_realm_name"] = "never",
["inverse"] = false,
["preferToUpdate"] = false,
["shadowColor"] = {
0,
0,
0,
1,
},
["conditions"] = {
{
["check"] = {
["trigger"] = 1,
["op"] = "<=",
["value"] = "3",
["variable"] = "number",
},
["changes"] = {
{
["value"] = 200,
["property"] = "width",
},
{
["value"] = 200,
["property"] = "height",
},
{
["value"] = {
1,
0,
0,
1,
},
["property"] = "foregroundColor",
},
},
},
},
["information"] = {
["ignoreOptionsEventErrors"] = true,
},
["adjustedMax"] = "",
},
["RBW icon LH"] = {
["iconSource"] = 0,
["wagoID"] = "7-GPE9UP7",
["xOffset"] = 0,
["preferToUpdate"] = false,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["url"] = "https://wago.io/7-GPE9UP7/1",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["enchant"] = "Rockbiter",
["itemName"] = 0,
["auranames"] = {
"",
},
["ownOnly"] = true,
["genericShowOn"] = "showAlways",
["unit"] = "player",
["useRem"] = true,
["use_weapon"] = true,
["use_enchant"] = true,
["names"] = {
},
["matchesShowOn"] = "showOnMissing",
["spellName"] = 425339,
["debuffType"] = "HELPFUL",
["use_remaining"] = false,
["type"] = "item",
["use_showOn"] = true,
["subeventSuffix"] = "_CAST_START",
["use_spellCount"] = false,
["event"] = "Weapon Enchant",
["use_itemName"] = true,
["useName"] = true,
["realSpellName"] = "Всплеск лавы",
["use_spellName"] = true,
["spellIds"] = {
},
["subeventPrefix"] = "SPELL",
["showOn"] = "showAlways",
["use_genericShowOn"] = true,
["use_track"] = true,
["weapon"] = "off",
},
["untrigger"] = {
},
},
{
["trigger"] = {
["type"] = "item",
["use_itemTypeName"] = false,
["unit"] = "player",
["itemTypeName"] = {
["multi"] = {
[1030] = true,
},
},
["use_genericShowOn"] = true,
["genericShowOn"] = "showAlways",
["use_unit"] = true,
["use_itemSlot"] = true,
["itemSlot"] = 17,
["use_inverse"] = false,
["use_testForCooldown"] = true,
["itemName"] = 0,
["event"] = "Item Type Equipped",
["use_itemName"] = true,
["debuffType"] = "HELPFUL",
},
["untrigger"] = {
},
},
["disjunctive"] = "custom",
["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and not trigger[2]\nend",
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = false,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 1,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["glowFrequency"] = 0.25,
["type"] = "subglow",
["glowDuration"] = 1,
["glowType"] = "buttonOverlay",
["glowThickness"] = 1,
["glowYOffset"] = 0,
["glowColor"] = {
1,
1,
1,
1,
},
["useGlowColor"] = false,
["glowXOffset"] = 0,
["glowScale"] = 1,
["glow"] = false,
["glowLength"] = 4,
["glowLines"] = 12,
["glowBorder"] = false,
},
{
["text_shadowXOffset"] = 0,
["text_text"] = "LH",
["text_text_format_p_time_mod_rate"] = true,
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_p_time_legacy_floor"] = false,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_text_format_p_format"] = "timed",
["type"] = "subtext",
["text_text_format_p_time_dynamic_threshold"] = 60,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_text_format_p_time_precision"] = 1,
["text_shadowYOffset"] = 0,
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_BOTTOMLEFT",
["anchorYOffset"] = 0,
["text_visible"] = true,
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_text_format_p_time_format"] = 0,
},
{
["text_shadowXOffset"] = 0,
["text_text"] = "%p",
["text_text_format_p_time_mod_rate"] = true,
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["text_text_format_p_time_legacy_floor"] = false,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_text_format_p_format"] = "timed",
["type"] = "subtext",
["text_text_format_p_time_dynamic_threshold"] = 0,
["text_color"] = {
1,
1,
1,
1,
},
["text_font"] = "Friz Quadrata TT",
["text_text_format_p_time_precision"] = 1,
["text_shadowYOffset"] = 0,
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_wordWrap"] = "WordWrap",
["text_fontType"] = "OUTLINE",
["text_anchorPoint"] = "INNER_TOPRIGHT",
["anchorYOffset"] = 0,
["text_visible"] = true,
["text_fontSize"] = 12,
["anchorXOffset"] = 0,
["text_text_format_p_time_format"] = 0,
},
},
["height"] = 35,
["load"] = {
["use_class"] = true,
["use_never"] = false,
["talent"] = {
["multi"] = {
[67] = true,
},
},
["spec"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "SHAMAN",
["multi"] = {
["MAGE"] = true,
},
},
["size"] = {
["multi"] = {
},
},
},
["useCooldownModRate"] = false,
["useAdjustededMax"] = false,
["anchorFrameType"] = "SCREEN",
["source"] = "import",
["authorOptions"] = {
{
["type"] = "select",
["default"] = 1,
["values"] = {
"hide",
"desaturate",
},
["name"] = "Hide/Desaturate",
["useDesc"] = false,
["key"] = "option",
["width"] = 1,
},
},
["desc"] = "",
["cooldown"] = true,
["conditions"] = {
{
["check"] = {
["trigger"] = -2,
["variable"] = "AND",
["checks"] = {
{
["trigger"] = 1,
["variable"] = "enchanted",
["value"] = 1,
},
{
["trigger"] = -1,
["variable"] = "customcheck",
["value"] = "function()\n    if aura_env.config[\"option\"] == 1 then\n        return true\n    end\nend",
},
},
},
["changes"] = {
{
["value"] = true,
["property"] = "desaturate",
},
{
["property"] = "sub.2.glow",
},
{
["value"] = 0,
["property"] = "alpha",
},
},
},
{
["check"] = {
["trigger"] = -2,
["variable"] = "AND",
["checks"] = {
{
["trigger"] = 1,
["variable"] = "enchanted",
["value"] = 1,
},
{
["trigger"] = -1,
["variable"] = "customcheck",
["value"] = "function()\n    if aura_env.config[\"option\"] == 2 then\n    return true\nend\nend",
},
},
},
["changes"] = {
{
["value"] = true,
["property"] = "desaturate",
},
{
["property"] = "sub.2.glow",
},
{
["value"] = 1,
["property"] = "alpha",
},
},
},
{
["check"] = {
["trigger"] = 1,
["variable"] = "enchanted",
["value"] = 0,
},
["changes"] = {
{
["property"] = "desaturate",
},
{
["value"] = true,
["property"] = "sub.2.glow",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "<",
["value"] = "30",
["variable"] = "expirationTime",
},
["changes"] = {
{
["property"] = "desaturate",
},
{
["value"] = true,
["property"] = "sub.2.glow",
},
{
["value"] = 1,
["property"] = "alpha",
},
},
},
{
["check"] = {
["trigger"] = 1,
["op"] = "<=",
["value"] = "5",
["variable"] = "expirationTime",
},
["changes"] = {
{
["value"] = {
1,
0.039215687662363,
0,
1,
},
["property"] = "sub.4.text_color",
},
},
},
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["progressSource"] = {
-1,
"",
},
["adjustedMax"] = "",
["config"] = {
["option"] = 1,
},
["parent"] = "RBW Group",
["alpha"] = 1,
["cooldownTextDisabled"] = true,
["zoom"] = 0,
["semver"] = "1.0.0",
["tocversion"] = 11500,
["id"] = "RBW icon LH",
["animation"] = {
["start"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
["finish"] = {
["easeStrength"] = 3,
["type"] = "none",
["duration_type"] = "seconds",
["easeType"] = "none",
},
},
["frameStrata"] = 3,
["width"] = 35,
["cooldownEdge"] = false,
["uid"] = "yKU3PPG17GG",
["inverse"] = false,
["actions"] = {
["start"] = {
},
["finish"] = {
},
["init"] = {
},
},
["displayIcon"] = 136086,
["information"] = {
},
["color"] = {
1,
1,
1,
0.7182275056839,
},
},
["Rupture track"] = {
["iconSource"] = -1,
["wagoID"] = "dTwWQJRhb",
["color"] = {
1,
1,
1,
1,
},
["preferToUpdate"] = true,
["adjustedMin"] = "",
["yOffset"] = 0,
["anchorPoint"] = "CENTER",
["cooldownSwipe"] = false,
["url"] = "https://wago.io/dTwWQJRhb/24",
["icon"] = true,
["triggers"] = {
{
["trigger"] = {
["type"] = "aura2",
["auranames"] = {
"1943",
},
["ownOnly"] = true,
["event"] = "Health",
["unit"] = "target",
["spellIds"] = {
},
["names"] = {
},
["useName"] = true,
["subeventPrefix"] = "SPELL",
["subeventSuffix"] = "_CAST_START",
["debuffType"] = "HARMFUL",
},
["untrigger"] = {
},
},
["activeTriggerMode"] = -10,
},
["internalVersion"] = 78,
["keepAspectRatio"] = true,
["selfPoint"] = "CENTER",
["desaturate"] = false,
["version"] = 24,
["subRegions"] = {
{
["type"] = "subbackground",
},
{
["text_text_format_p_time_format"] = 0,
["text_text"] = "%p",
["text_shadowColor"] = {
0,
0,
0,
1,
},
["text_selfPoint"] = "AUTO",
["text_automaticWidth"] = "Auto",
["text_fixedWidth"] = 64,
["anchorYOffset"] = 0,
["text_justify"] = "CENTER",
["rotateText"] = "NONE",
["text_shadowXOffset"] = 0,
["text_text_format_p_time_dynamic_threshold"] = 10,
["text_text_format_p_time_mod_rate"] = true,
["type"] = "subtext",
["text_text_format_p_format"] = "timed",
["text_color"] = {
1,
1,
1,
1,
},
["border_color"] = {
},
["text_font"] = "Gilroy Bold",
["text_shadowYOffset"] = 0,
["text_fontType"] = "THICKOUTLINE",
["text_wordWrap"] = "WordWrap",
["text_visible"] = true,
["text_anchorPoint"] = "CENTER",
["text_anchorYOffset"] = 0,
["text_text_format_p_time_precision"] = 1,
["text_fontSize"] = 18,
["anchorXOffset"] = 0,
["text_text_format_p_time_legacy_floor"] = true,
},
},
["height"] = 32,
["load"] = {
["ingroup"] = {
},
["use_never"] = false,
["talent"] = {
["multi"] = {
},
},
["class"] = {
["single"] = "ROGUE",
["multi"] = {
},
},
["use_encounterid"] = false,
["use_class"] = true,
["size"] = {
["multi"] = {
["party"] = true,
["scenario"] = true,
["fortyman"] = true,
["ten"] = true,
["twentyfive"] = true,
["twenty"] = true,
["flexible"] = true,
},
},
["spec"] = {
["multi"] = {
},
},
["zoneIds"] = "",
},
["useAdjustededMax"] = false,
["width"] = 32,
["source"] = "import",
["zoom"] = 0,
["progressSource"] = {
-1,
"",
},
["adjustedMax"] = "",
["information"] = {
["forceEvents"] = true,
["ignoreOptionsEventErrors"] = true,
},
["useAdjustededMin"] = false,
["regionType"] = "icon",
["actions"] = {
["start"] = {
},
["init"] = {
},
["finish"] = {
},
},
["animation"] = {
["start"] = {
["type"] = "none",
["easeStrength"] = 3,
["duration_type"] = "seconds",
["easeType"] = "none",
},
["main"] = {
["colorR"] = 1,
["duration"] = "30",
["alphaType"] = "alphaPulse",
["colorA"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0.26,
["y"] = 0,
["x"] = 0,
["scalex"] = 1,
["preset"] = "alphaPulse",
["easeStrength"] = 3,
["rotate"] = 0,
["colorB"] = 1,
["duration_type"] = "relative",
},
["finish"] = {
["colorR"] = 1,
["scalex"] = 1,
["alphaType"] = "alphaPulse",
["colorB"] = 1,
["colorG"] = 1,
["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
["use_alpha"] = true,
["type"] = "none",
["easeType"] = "none",
["scaley"] = 1,
["alpha"] = 0,
["y"] = 0,
["x"] = 0,
["colorA"] = 1,
["duration"] = "8",
["rotate"] = 0,
["easeStrength"] = 3,
["duration_type"] = "seconds",
},
},
["authorOptions"] = {
},
["config"] = {
},
["useCooldownModRate"] = true,
["auto"] = true,
["cooldownTextDisabled"] = true,
["semver"] = "1.0.23",
["tocversion"] = 30403,
["id"] = "Rupture track",
["frameStrata"] = 1,
["alpha"] = 1,
["anchorFrameType"] = "SCREEN",
["xOffset"] = 0,
["uid"] = "SCiM5e(S5uN",
["inverse"] = false,
["parent"] = "SimonizeBars",
["conditions"] = {
},
["cooldown"] = false,
["cooldownEdge"] = false,
},
},
["registered"] = {
},
["login_squelch_time"] = 10,
["lastArchiveClear"] = 1732587373,
["minimap"] = {
["minimapPos"] = 267.4643365743445,
["hide"] = true,
},
["historyCutoff"] = 730,
["dbVersion"] = 78,
["migrationCutoff"] = 730,
["features"] = {
},
["editor_font_size"] = 12,
["lastUpgrade"] = 1732587399,
["editor_theme"] = "Monokai",
}

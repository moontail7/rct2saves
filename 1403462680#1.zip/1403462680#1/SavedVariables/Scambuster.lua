
ScambusterDB = {
["realm"] = {
["Shadowstrike (AU)"] = {
["n_scans"] = 49,
},
},
["profileKeys"] = {
["Emz - Shadowstrike (AU)"] = "Default",
["Skeeboo - Shadowstrike (AU)"] = "Default",
["Poisongrace - Maladath (AU)"] = "Default",
},
["global"] = {
["n_scans"] = 49,
["provider_settings"] = {
["Shadowstrike Discord Blacklist"] = {
["enabled"] = true,
},
},
},
["profiles"] = {
["Default"] = {
},
},
}

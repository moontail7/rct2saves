
FLogGlobalVars = {
["track"] = {
["misc"] = false,
["deaths"] = true,
["honor"] = true,
["drops"] = true,
["hks"] = true,
["levelup"] = true,
["xp"] = true,
["ranks"] = true,
["dks"] = true,
["kills"] = true,
["resets"] = true,
["rep"] = true,
["skill"] = false,
["money"] = true,
["consumes"] = true,
["bgs"] = true,
},
["blt"] = {
["Maladath (AU)"] = {
},
["Shadowstrike (AU)"] = {
},
},
["pauseOnLogin"] = true,
["ahMinQuality"] = 3,
["ignoredItems"] = {
},
["blp"] = {
},
["ahScan"] = {
["Maladath (AU)"] = {
},
["Shadowstrike (AU)"] = {
},
},
["instances"] = {
["Maladath (AU)"] = {
},
["Shadowstrike (AU)"] = {
},
},
["tsmPriceSource"] = 0,
["autoResumeBGs"] = true,
["bls"] = {
["Maladath (AU)"] = {
},
["Shadowstrike (AU)"] = {
},
},
["groupByMobName"] = true,
["sortSessionBy"] = "A",
["minQuantitySold"] = false,
["showHonorPercentOnTooltip"] = true,
["debug"] = false,
["sortBy"] = "A",
["autoSwitchInstances"] = false,
["ver"] = 1.24,
["fontName"] = "Fonts\\FRIZQT__.TTF",
["hud"] = {
["fontSize"] = 12,
["paddingX"] = 8,
["alpha"] = 0.6,
["fontName"] = "Fonts\\FRIZQT__.TTF",
["paddingY"] = 5,
},
["ahPrice"] = {
["Maladath (AU)"] = {
},
["Shadowstrike (AU)"] = {
},
},
["honorDRinBGs"] = true,
["reportTo"] = {
},
["dismissLootWindowOnEsc"] = false,
["showHonorFrenzyCounter"] = true,
["showBlackLotusTimer"] = true,
["resumeSessionOnSwitch"] = true,
["blackLotusTimeSeconds"] = 1200,
}

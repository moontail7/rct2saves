
MATAB = {
["PROFILES"] = {
["Emperor13tv"] = {
["FRAMES"] = {
["POINTS"] = {
["QuestLogFrame"] = {
},
["ReadyCheckFrame"] = {
},
["WorldStateScoreFrame"] = {
},
["GameMenuFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 451,
["RE"] = "BOTTOMLEFT",
["PX"] = 1302,
},
["SettingsPanel"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 229,
["PX"] = 940,
["RE"] = "BOTTOMLEFT",
},
["ItemTextFrame"] = {
},
["MailFrame"] = {
},
["OpenMailFrame"] = {
},
["ScriptErrorsFrame"] = {
},
["GossipFrame"] = {
},
["HelpFrame"] = {
},
["FriendsFrame"] = {
},
["TaxiFrame"] = {
},
["DressUpFrame"] = {
},
["TimeManagerFrame"] = {
},
["WorldMapFrame"] = {
},
["PlayerTalentFrame"] = {
},
["CharacterFrame"] = {
},
["VideoOptionsFrame"] = {
},
["AddonList"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 376,
["RE"] = "BOTTOMLEFT",
["PX"] = 1150,
},
["PVEFrame"] = {
},
["BankFrame"] = {
},
["QuestFrame"] = {
},
["ChannelFrame"] = {
},
["PetStableFrame"] = {
},
["InterfaceOptionsFrame"] = {
},
},
["SIZES"] = {
["QuestLogFrame"] = {
},
["HelpFrame"] = {
},
["ReadyCheckFrame"] = {
},
["AddonList"] = {
},
["WorldStateScoreFrame"] = {
},
["GameMenuFrame"] = {
},
["SettingsPanel"] = {
},
["ItemTextFrame"] = {
},
["MailFrame"] = {
},
["TaxiFrame"] = {
},
["ScriptErrorsFrame"] = {
},
["OpenMailFrame"] = {
},
["FriendsFrame"] = {
},
["GossipFrame"] = {
},
["CharacterFrame"] = {
},
["ChannelFrame"] = {
},
["MerchantFrame"] = {
},
["TimeManagerFrame"] = {
},
["DressUpFrame"] = {
},
["WorldMapFrame"] = {
},
["VideoOptionsFrame"] = {
},
["PlayerTalentFrame"] = {
},
["BankFrame"] = {
},
["SpellBookFrame"] = {
},
["StaticPopup1"] = {
},
["PVEFrame"] = {
},
["StaticPopup2"] = {
},
["QuestFrame"] = {
},
["TradeFrame"] = {
},
["PetStableFrame"] = {
},
["InterfaceOptionsFrame"] = {
},
},
},
["MMICON"] = {
["minimapPos"] = 245.4834504489723,
},
["ELES"] = {
["SIZES"] = {
["IACoordsFrame"] = {
},
["MAActionBar3"] = {
["SW"] = 36,
["SH"] = 454,
},
["MA_LeftEndCap"] = {
["SW"] = 128,
["SH"] = 128,
},
["IAMoneyBar"] = {
},
["MAPetBar"] = {
["SW"] = 354,
["SH"] = 30,
},
["MABuffBar"] = {
["SH"] = 216,
["SW"] = 360,
},
["BagsBar"] = {
["SW"] = 185,
["SH"] = 37,
},
["MA_BlizzArt"] = {
["SW"] = 512,
["SH"] = 43,
},
["MainMenuBarVehicleLeaveButton"] = {
["SH"] = 32,
["SW"] = 32,
},
["MAActionBar6"] = {
["SW"] = 498,
["SH"] = 36,
},
["MA_RightEndCap"] = {
["SW"] = 128,
["SH"] = 128,
},
["TargetFrame"] = {
["SH"] = 100,
["SW"] = 232,
},
["IAILVLBar"] = {
},
["UIWidgetTopCenterContainerFrame"] = {
["SH"] = 72,
["SW"] = 180,
},
["MainMenuExpBar"] = {
["SH"] = 7,
["SW"] = 458,
},
["UIWidgetBelowMinimapContainerFrame"] = {
["SH"] = 72,
["SW"] = 180,
},
["MinimapCluster"] = {
["SCALE"] = 1.2,
["SW"] = 192,
["SH"] = 192,
},
["IATokenBar"] = {
},
["CastingBarFrame"] = {
["SH"] = 13,
["SW"] = 195,
},
["MAMenuBar"] = {
["SW"] = 206,
["SH"] = 32,
},
["MAActionBar5"] = {
["SW"] = 226,
["SH"] = 74,
},
["IASkills"] = {
["SH"] = 108,
["SW"] = 180,
},
["PlayerFrame"] = {
["SH"] = 100,
["SW"] = 232,
},
["MAActionBar1"] = {
["SW"] = 498,
["SH"] = 36,
},
["ReputationWatchBar"] = {
["SH"] = 12,
["SW"] = 512,
},
["StanceBar"] = {
["SW"] = 102,
["SH"] = 30,
},
["MAActionBar4"] = {
["SW"] = 36,
["SH"] = 454,
},
["IAPingFrame"] = {
["SH"] = 20,
["SW"] = 100,
},
},
["POINTS"] = {
["MA_RightEndCap"] = {
["AN"] = "BOTTOM",
["PY"] = 0,
["PX"] = 290,
["RE"] = "BOTTOM",
},
["MAActionBar3"] = {
["AN"] = "RIGHT",
["PY"] = 0,
["PX"] = 0,
["RE"] = "RIGHT",
},
["MA_LeftEndCap"] = {
["AN"] = "BOTTOM",
["PY"] = 0,
["PX"] = -289,
["RE"] = "BOTTOM",
},
["IAMoneyBar"] = {
["PX"] = 0,
["PY"] = 0,
},
["MAPetBar"] = {
["AN"] = "BOTTOM",
["PY"] = 100,
["PX"] = 0,
["RE"] = "BOTTOM",
},
["MABuffBar"] = {
["AN"] = "TOPRIGHT",
["PY"] = -10,
["PX"] = -240,
["RE"] = "TOPRIGHT",
},
["BagsBar"] = {
["AN"] = "BOTTOMRIGHT",
["PY"] = 32,
["RE"] = "BOTTOMRIGHT",
["PX"] = 0,
},
["MA_BlizzArt"] = {
["AN"] = "BOTTOM",
["PY"] = 0,
["PX"] = 0,
["RE"] = "BOTTOM",
},
["MainMenuBarVehicleLeaveButton"] = {
["AN"] = "BOTTOM",
["PY"] = 102,
["RE"] = "BOTTOM",
["PX"] = -210,
},
["MAActionBar6"] = {
["AN"] = "BOTTOM",
["PY"] = 62,
["PX"] = 0,
["RE"] = "BOTTOM",
},
["TargetFrame"] = {
["AN"] = "TOPLEFT",
["PY"] = -210,
["PX"] = 477,
["RE"] = "TOPLEFT",
},
["CastingBarFrame"] = {
["AN"] = "BOTTOM",
["PY"] = 140,
["PX"] = 0,
["RE"] = "BOTTOM",
},
["MAActionBar1"] = {
["AN"] = "BOTTOM",
["PY"] = 3,
["PX"] = 0,
["RE"] = "BOTTOM",
},
["UIWidgetTopCenterContainerFrame"] = {
["AN"] = "TOP",
["PY"] = -20,
["PX"] = 0,
["RE"] = "TOP",
},
["MainMenuExpBar"] = {
["AN"] = "BOTTOM",
["PY"] = 54,
["PX"] = 0,
["RE"] = "BOTTOM",
},
["UIWidgetBelowMinimapContainerFrame"] = {
["AN"] = "TOPRIGHT",
["PY"] = -240,
["PX"] = -10,
["RE"] = "TOPRIGHT",
},
["MinimapCluster"] = {
["AN"] = "TOPRIGHT",
["PY"] = 0,
["PX"] = 0,
["RE"] = "TOPRIGHT",
},
["IATokenBar"] = {
["PX"] = 0,
["PY"] = 0,
},
["ReputationWatchBar"] = {
["AN"] = "BOTTOM",
["PY"] = 42,
["RE"] = "BOTTOM",
["PX"] = 0,
},
["IASkills"] = {
["AN"] = "BOTTOM",
["PY"] = 0,
["PX"] = -650,
["RE"] = "BOTTOM",
},
["MAActionBar5"] = {
["AN"] = "BOTTOM",
["PY"] = 0,
["PX"] = 480,
["RE"] = "BOTTOM",
},
["MAMenuBar"] = {
["AN"] = "BOTTOMRIGHT",
["PY"] = 0,
["RE"] = "BOTTOMRIGHT",
["PX"] = 0,
},
["PlayerFrame"] = {
["AN"] = "TOPLEFT",
["PY"] = -210,
["PX"] = 250,
["RE"] = "TOPLEFT",
},
["IAILVLBar"] = {
["PX"] = 0,
["PY"] = 0,
},
["MALock"] = {
["AN"] = "RIGHT",
["PY"] = -40,
["RE"] = "RIGHT",
["PX"] = -450,
},
["StanceBar"] = {
["AN"] = "BOTTOM",
["PY"] = 100,
["PX"] = 0,
["RE"] = "BOTTOM",
},
["MAActionBar4"] = {
["AN"] = "RIGHT",
["PY"] = 0,
["PX"] = -40,
["RE"] = "RIGHT",
},
["IAPingFrame"] = {
["AN"] = "TOP",
["PY"] = -220,
["PX"] = 0,
["RE"] = "TOP",
},
},
["OPTIONS"] = {
["SHOWMINIMAPBUTTON"] = {
["ENABLED"] = true,
},
["GAMETOOLTIP"] = {
["ENABLED"] = false,
},
["MINIMAP"] = {
["ENABLED"] = true,
},
["ReputationWatchBar"] = {
["HEIGHT"] = 12,
["WIDTH"] = 512,
},
["MOVEFRAMES"] = {
["ENABLED"] = true,
},
["BONUSROLLFRAME"] = {
["ENABLED"] = false,
},
["RAIDBOSSEMOTEFRAME"] = {
["ENABLED"] = false,
},
["ARCHEOLOGYDIGSITEPROGRESSBAR"] = {
["ENABLED"] = false,
},
["MICROMENU"] = {
["ENABLED"] = true,
["ROWS"] = 1,
},
["BAGS"] = {
["ENABLED"] = true,
},
["TARGETFRAMESPELLBAR"] = {
["ENABLED"] = false,
},
["DURABILITY"] = {
["ENABLED"] = false,
},
["TargetFrame"] = {
},
["VEHICLESEATINDICATOR"] = {
["ENABLED"] = false,
},
["MA_BlizzArt"] = {
},
["FOCUSFRAMEBUFF1"] = {
["ENABLED"] = false,
},
["MAINMENUEXPBAR"] = {
["ENABLED"] = true,
},
["EDITMODE"] = {
["ENABLED"] = true,
},
["TALKINGHEAD"] = {
["ENABLED"] = false,
},
["TARGETFRAMENAMEBACKGROUND"] = {
["ENABLED"] = false,
},
["BOSSTARGETFRAMECONTAINER"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME7"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME2"] = {
["ENABLED"] = false,
},
["TARGETOFTARGETFRAME"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME3"] = {
["ENABLED"] = false,
},
["IAMoneyBar"] = {
},
["MINIMAPZONETEXT"] = {
["ENABLED"] = false,
},
["FRAMESKEYSCALE"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME9"] = {
["ENABLED"] = false,
},
["ACTIONBARS"] = {
["ENABLED"] = true,
},
["UIWidgetTopCenterContainerFrame"] = {
},
["MAPROFILES"] = {
["ENABLED"] = true,
},
["BOSSBANNER"] = {
["ENABLED"] = false,
},
["TARGETFRAMEBUFF1"] = {
["ENABLED"] = false,
},
["LEAVEVEHICLE"] = {
["ENABLED"] = true,
},
["GROUPLOOTCONTAINER"] = {
["ENABLED"] = false,
},
["StanceBar"] = {
["SPACING"] = 6,
["FLIPPED"] = false,
["COUNT"] = 3,
},
["MainMenuBarVehicleLeaveButton"] = {
},
["EventToastManagerFrame"] = {
["ENABLED"] = false,
},
["ACTIONBAR9"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME5"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME6"] = {
["ENABLED"] = false,
},
["TargetFrameNumericalThreat"] = {
["ENABLED"] = false,
},
["MAPETFRAME"] = {
["ENABLED"] = false,
},
["MOVESMALLBAGS"] = {
["ENABLED"] = false,
},
["MainMenuExpBar"] = {
["HEIGHT"] = 7,
["WIDTH"] = 458,
},
["SHOWTIPS"] = {
["ENABLED"] = true,
},
["ZONETEXTFRAME"] = {
["ENABLED"] = false,
},
["COMBOFRAME"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME4"] = {
["ENABLED"] = false,
},
["GAMETOOLTIP_ONCURSOR"] = {
["ENABLED"] = false,
},
["CHAT1"] = {
["ENABLED"] = false,
},
["MAActionBar4"] = {
["FLIPPED"] = false,
["SPACING"] = 2,
["COUNT"] = 12,
["Hide"] = false,
["ROWS"] = 12,
},
["CHAT5"] = {
["ENABLED"] = false,
},
["IAILVLBAR"] = {
["ENABLED"] = true,
},
["QUESTTRACKER"] = {
["ENABLED"] = false,
},
["STANCEBAR"] = {
["ENABLED"] = true,
},
["CHAT8"] = {
["ENABLED"] = false,
},
["CASTINGBAR"] = {
["ENABLED"] = true,
},
["CHAT3"] = {
["ENABLED"] = false,
},
["PETBAR"] = {
["ENABLED"] = true,
},
["GHOSTFRAME"] = {
["ENABLED"] = false,
},
["IATokenBar"] = {
},
["PLAYERLEVELTEXT"] = {
["ENABLED"] = false,
},
["ROLEPOLLPOPUP"] = {
["ENABLED"] = false,
},
["SAVEFRAMEPOSITION"] = {
["ENABLED"] = true,
},
["CHATBUTTONFRAME1"] = {
["ENABLED"] = false,
},
["MAPAGES"] = {
["ENABLED"] = false,
},
["IACoordsFrame"] = {
["ENABLED"] = true,
},
["UIERRORSFRAME"] = {
["ENABLED"] = false,
},
["MA_LeftEndCap"] = {
},
["CastingBarFrame"] = {
},
["ACTIONBAR4"] = {
["ENABLED"] = false,
},
["BagsBar"] = {
["Hide"] = true,
},
["MALOCK"] = {
["ENABLED"] = false,
},
["UIWIDGETBELOWMINIMAP"] = {
["ENABLED"] = true,
},
["MAFPSFrame"] = {
["ENABLED"] = false,
},
["IASkills"] = {
},
["REPUTATIONWATCHBAR"] = {
["ENABLED"] = true,
},
["MIRRORTIMER1"] = {
["ENABLED"] = false,
},
["IAPingFrame"] = {
["ENABLED"] = true,
},
["MA_RightEndCap"] = {
},
["UIWidgetBelowMinimapContainerFrame"] = {
},
["PlayerFrame"] = {
},
["MAMenuBar"] = {
["SPACING"] = 2,
["FLIPPED"] = false,
["COUNT"] = 8,
["Hide"] = true,
},
["LOSSOFCONTROLFRAME"] = {
["ENABLED"] = false,
},
["CHATQUICKJOIN"] = {
["ENABLED"] = false,
},
["MAActionBar5"] = {
["FLIPPED"] = false,
["SPACING"] = 2,
["COUNT"] = 12,
["ROWS"] = 2,
["Hide"] = false,
},
["IASKILLS"] = {
["ENABLED"] = true,
},
["READYCHECKLISTENERFRAME"] = {
["ENABLED"] = false,
},
["MAActionBar6"] = {
["SPACING"] = 6,
["FLIPPED"] = false,
["COUNT"] = 12,
["ROWS"] = 1,
},
["ACTIONBAR7"] = {
["ENABLED"] = false,
},
["DISABLEMOVEMENT"] = {
["ENABLED"] = false,
},
["TARGETFRAME"] = {
["ENABLED"] = true,
},
["FRAMESKEYRESET"] = {
["ENABLED"] = false,
},
["ALERTFRAME"] = {
["ENABLED"] = false,
},
["TARGETOFFOCUSFRAME"] = {
["ENABLED"] = false,
},
["PLAYERFRAMEBACKGROUND"] = {
["ENABLED"] = false,
},
["BLIZZARDACTIONBUTTONSART"] = {
["ENABLED"] = true,
},
["CHATBUTTONFRAME8"] = {
["ENABLED"] = false,
},
["IAILVLBar"] = {
},
["CHAT6"] = {
["ENABLED"] = false,
},
["COMPACTARENAFRAME"] = {
["ENABLED"] = false,
},
["COMPACTRAIDFRAMECONTAINER"] = {
["ENABLED"] = false,
},
["ACTIONBAR3"] = {
["ENABLED"] = false,
},
["TOKENBAR"] = {
["ENABLED"] = true,
},
["CHAT2"] = {
["ENABLED"] = false,
},
["QUEUESTATUSFRAME"] = {
["ENABLED"] = false,
},
["FOCUSFRAME"] = {
["ENABLED"] = false,
},
["CHAT9"] = {
["ENABLED"] = false,
},
["BUFFS"] = {
["ENABLED"] = true,
},
["CHATEDITBOX"] = {
["ENABLED"] = false,
},
["CHAT4"] = {
["ENABLED"] = false,
},
["MABuffBar"] = {
["MABUFFMODE"] = 0,
["MABUFFSPACINGX"] = 6,
},
["BNToastFrame"] = {
["ENABLED"] = false,
},
["ACTIONBAR8"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME10"] = {
["ENABLED"] = false,
},
["COMPACTRAIDFRAMEMANAGER"] = {
["ENABLED"] = false,
},
["PLAYERFRAME"] = {
["ENABLED"] = true,
},
["PARTYFRAME"] = {
["ENABLED"] = false,
},
["FRAMESKEYDRAG"] = {
["ENABLED"] = false,
},
["MAPetBar"] = {
["SPACING"] = 6,
["FLIPPED"] = false,
["COUNT"] = 10,
},
["TICKETSTATUSFRAME"] = {
["ENABLED"] = false,
},
["DEBUFFS"] = {
["ENABLED"] = false,
},
["GROUPLOOTFRAME1"] = {
["ENABLED"] = false,
},
["UIWIDGETPOWERBAR"] = {
["ENABLED"] = false,
},
["QUEUESTATUSBUTTON"] = {
["ENABLED"] = false,
},
["TARGETFRAMETOTDEBUFF1"] = {
["ENABLED"] = false,
},
["OVERRIDEACTIONBAR"] = {
["ENABLED"] = false,
},
["SAVEFRAMESCALE"] = {
["ENABLED"] = true,
},
["MAActionBar1"] = {
["SPACING"] = 6,
["FLIPPED"] = false,
["COUNT"] = 12,
["ROWS"] = 1,
},
["MONEYBAR"] = {
["ENABLED"] = true,
},
["ENDCAPS"] = {
["ENABLED"] = true,
},
["MinimapCluster"] = {
},
["MOVELOOTFRAME"] = {
["ENABLED"] = false,
},
["OBJECTIVETRACKERBONUSBANNERFRAME"] = {
["ENABLED"] = false,
},
["PETFRAMEHAPPINESS"] = {
["ENABLED"] = false,
},
["ACTIONBAR2"] = {
["ENABLED"] = false,
},
["ACTIONBAR10"] = {
["ENABLED"] = false,
},
["MAActionBar3"] = {
["FLIPPED"] = false,
["SPACING"] = 2,
["COUNT"] = 12,
["Hide"] = false,
["ROWS"] = 12,
},
["POSSESSBAR"] = {
["ENABLED"] = false,
},
["CHAT10"] = {
["ENABLED"] = false,
},
["CHAT7"] = {
["ENABLED"] = false,
},
["UIWIDGETTOPCENTER"] = {
["ENABLED"] = true,
},
["POWERBAR"] = {
["ENABLED"] = false,
},
},
},
},
["DEFAULT"] = {
["FRAMES"] = {
["POINTS"] = {
["QuestLogFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 261,
["RE"] = "BOTTOMLEFT",
["PX"] = 39,
},
["TradeSkillFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 312,
["PX"] = 60,
["RE"] = "BOTTOMLEFT",
},
["ClassTrainerFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 292,
["RE"] = "BOTTOMLEFT",
["PX"] = 7,
},
["AddonList"] = {
},
["GameMenuFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 419,
["PX"] = 763,
["RE"] = "BOTTOMLEFT",
},
["ItemRefTooltip"] = {
},
["CharacterFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 296,
["RE"] = "BOTTOMLEFT",
["PX"] = 636,
},
["MailFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 405,
["RE"] = "BOTTOMLEFT",
["PX"] = 29,
},
["LFGParentFrame"] = {
},
["MacroFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 313,
["RE"] = "BOTTOMLEFT",
["PX"] = 683,
},
["ScriptErrorsFrame"] = {
},
["TabardFrame"] = {
},
["StaticPopup1"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 713,
["RE"] = "BOTTOMLEFT",
["PX"] = 694,
},
["PlayerTalentFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 354,
["PX"] = 899,
["RE"] = "BOTTOMLEFT",
},
["BattlefieldMapFrame"] = {
},
["SpellBookFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 300,
["RE"] = "BOTTOMLEFT",
["PX"] = 972,
},
["StaticPopup2"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 602,
["PX"] = 630,
["RE"] = "BOTTOMLEFT",
},
["QuestFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 292,
["RE"] = "BOTTOMLEFT",
["PX"] = 222,
},
["TradeFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 381,
["RE"] = "BOTTOMLEFT",
["PX"] = 17,
},
["PetStableFrame"] = {
},
["InterfaceOptionsFrame"] = {
},
["InspectFrame"] = {
},
["AuctionFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 368,
["PX"] = 210,
["RE"] = "BOTTOMLEFT",
},
["CommunitiesFrame"] = {
},
["BankFrame"] = {
},
["SettingsPanel"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 261,
["PX"] = 988,
["RE"] = "BOTTOMLEFT",
},
["ModelPreviewFrame"] = {
},
["OpenMailFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 295,
["RE"] = "BOTTOMLEFT",
["PX"] = 389,
},
["TaxiFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 343,
["RE"] = "BOTTOMLEFT",
["PX"] = 0,
},
["GossipFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 394,
["RE"] = "BOTTOMLEFT",
["PX"] = 422,
},
["MerchantFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 397,
["PX"] = 189,
["RE"] = "BOTTOMLEFT",
},
["DressUpFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 291,
["PX"] = 1203,
["RE"] = "BOTTOMLEFT",
},
["WorldMapFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 273,
["PX"] = 446,
["RE"] = "BOTTOMLEFT",
},
["HelpFrame"] = {
},
["VideoOptionsFrame"] = {
},
["ReadyCheckFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 422,
["RE"] = "BOTTOMLEFT",
["PX"] = 697,
},
["WorldStateScoreFrame"] = {
},
["CraftFrame"] = {
},
["ItemTextFrame"] = {
},
["PVEFrame"] = {
},
["FriendsFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 455,
["RE"] = "BOTTOMLEFT",
["PX"] = 289,
},
["TimeManagerFrame"] = {
},
["ChannelFrame"] = {
},
},
["SIZES"] = {
["QuestLogFrame"] = {
["SCALE"] = 1.006,
},
["TradeSkillFrame"] = {
["SCALE"] = 1.054,
},
["ReadyCheckFrame"] = {
},
["AddonList"] = {
},
["VideoOptionsFrame"] = {
},
["ItemRefTooltip"] = {
},
["CharacterFrame"] = {
["SCALE"] = 0.988,
},
["MailFrame"] = {
},
["LFGParentFrame"] = {
},
["MacroFrame"] = {
},
["ScriptErrorsFrame"] = {
},
["TabardFrame"] = {
},
["StaticPopup1"] = {
["SCALE"] = 0.958,
},
["PlayerTalentFrame"] = {
["SCALE"] = 0.958,
},
["BattlefieldMapFrame"] = {
},
["SpellBookFrame"] = {
["SCALE"] = 1.03,
},
["StaticPopup2"] = {
},
["QuestFrame"] = {
["SCALE"] = 0.952,
},
["TradeFrame"] = {
},
["PetStableFrame"] = {
},
["InterfaceOptionsFrame"] = {
},
["InspectFrame"] = {
},
["AuctionFrame"] = {
},
["CommunitiesFrame"] = {
},
["BankFrame"] = {
},
["SettingsPanel"] = {
["SCALE"] = 0.88,
},
["ModelPreviewFrame"] = {
},
["RolePollPopup"] = {
},
["OpenMailFrame"] = {
},
["TaxiFrame"] = {
},
["GossipFrame"] = {
["SCALE"] = 0.994,
},
["MerchantFrame"] = {
["SCALE"] = 0.982,
},
["DressUpFrame"] = {
},
["WorldMapFrame"] = {
["SCALE"] = 0.906,
},
["PVPReadyDialog"] = {
},
["HelpFrame"] = {
},
["TimeManagerFrame"] = {
},
["WorldStateScoreFrame"] = {
},
["PVEFrame"] = {
},
["CraftFrame"] = {
},
["GameMenuFrame"] = {
["SCALE"] = 0.976,
},
["ItemTextFrame"] = {
},
["ClassTrainerFrame"] = {
},
["FriendsFrame"] = {
["SCALE"] = 1.042,
},
["ChannelFrame"] = {
},
},
},
["MMICON"] = {
["minimapPos"] = 331.0287551537731,
},
["ELES"] = {
["POINTS"] = {
["PetFrameHappiness"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 850,
["RE"] = "BOTTOMLEFT",
["PX"] = 180,
},
["MALock"] = {
},
},
["SIZES"] = {
["PetFrameHappiness"] = {
["SH"] = 23,
["SW"] = 24,
},
},
["OPTIONS"] = {
["CHAT5"] = {
["ENABLED"] = false,
},
["QUESTTRACKER"] = {
["ENABLED"] = false,
},
["CHAT10"] = {
["ENABLED"] = false,
},
["SCALELOOTFRAME"] = {
["ENABLED"] = false,
},
["GAMETOOLTIP"] = {
["ENABLED"] = false,
},
["MINIMAP"] = {
["ENABLED"] = false,
},
["CHAT8"] = {
["ENABLED"] = false,
},
["CHAT6"] = {
["ENABLED"] = false,
},
["BONUSROLLFRAME"] = {
["ENABLED"] = false,
},
["CHAT3"] = {
["ENABLED"] = false,
},
["PETBAR"] = {
["ENABLED"] = false,
},
["GHOSTFRAME"] = {
["ENABLED"] = false,
},
["MINIMAPFLAG"] = {
["ENABLED"] = false,
},
["ARCHEOLOGYDIGSITEPROGRESSBAR"] = {
["ENABLED"] = false,
},
["PLAYERLEVELTEXT"] = {
["ENABLED"] = false,
},
["ROLEPOLLPOPUP"] = {
["ENABLED"] = false,
},
["TARGETFRAMETOTBUFF1"] = {
["ENABLED"] = false,
},
["BAGS"] = {
["ENABLED"] = false,
},
["TARGETFRAMESPELLBAR"] = {
["ENABLED"] = false,
},
["SAVEFRAMEPOSITION"] = {
["ENABLED"] = true,
},
["CHATBUTTONFRAME1"] = {
["ENABLED"] = false,
},
["MAPAGES"] = {
["ENABLED"] = false,
},
["SHOWMINIMAPBUTTON"] = {
["ENABLED"] = false,
},
["LFGMinimapFrame"] = {
["ENABLED"] = false,
},
["DURABILITY"] = {
["ENABLED"] = false,
},
["MICROMENU"] = {
["ENABLED"] = false,
},
["CHAT2"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME8"] = {
["ENABLED"] = false,
},
["CHAT7"] = {
["ENABLED"] = false,
},
["TARGETFRAMEDEBUFF1"] = {
["ENABLED"] = false,
},
["GAMETOOLTIP_ONCURSOR"] = {
["ENABLED"] = false,
},
["ACTIONBAR4"] = {
["ENABLED"] = false,
},
["MOVEFRAMES"] = {
["ENABLED"] = true,
},
["MALOCK"] = {
["ENABLED"] = false,
},
["PetFrameHappiness"] = {
},
["FOCUSFRAMEBUFF1"] = {
["ENABLED"] = false,
},
["UIWIDGETTOPCENTER"] = {
["ENABLED"] = false,
},
["TALKINGHEAD"] = {
["ENABLED"] = false,
},
["EDITMODE"] = {
["ENABLED"] = true,
},
["PETFRAMEHAPPINESS"] = {
["ENABLED"] = true,
},
["UIWIDGETBELOWMINIMAP"] = {
["ENABLED"] = false,
},
["TARGETFRAMENAMEBACKGROUND"] = {
["ENABLED"] = false,
},
["PARTYFRAME"] = {
["ENABLED"] = false,
},
["MAFPSFrame"] = {
["ENABLED"] = false,
},
["REPUTATIONWATCHBAR"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME7"] = {
["ENABLED"] = false,
},
["BOSSTARGETFRAMECONTAINER"] = {
["ENABLED"] = false,
},
["ENDCAPS"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME10"] = {
["ENABLED"] = false,
},
["MIRRORTIMER1"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME2"] = {
["ENABLED"] = false,
},
["GROUPLOOTFRAME1"] = {
["ENABLED"] = false,
},
["CASTINGBAR"] = {
["ENABLED"] = false,
},
["UIERRORSFRAME"] = {
["ENABLED"] = false,
},
["TARGETOFTARGETFRAME"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME3"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME"] = {
["ENABLED"] = false,
},
["ACTIONBAR8"] = {
["ENABLED"] = false,
},
["STANCEBAR"] = {
["ENABLED"] = false,
},
["ACTIONBAR3"] = {
["ENABLED"] = false,
},
["CHATQUICKJOIN"] = {
["ENABLED"] = false,
},
["TargetFrameNumericalThreat"] = {
["ENABLED"] = false,
},
["READYCHECKLISTENERFRAME"] = {
["ENABLED"] = false,
},
["MINIMAPZONETEXT"] = {
["ENABLED"] = false,
},
["ACTIONBAR10"] = {
["ENABLED"] = false,
},
["ACTIONBAR7"] = {
["ENABLED"] = false,
},
["FRAMESKEYSCALE"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME9"] = {
["ENABLED"] = false,
},
["FRAMESKEYRESET"] = {
["ENABLED"] = false,
},
["ALERTFRAME"] = {
["ENABLED"] = false,
},
["ACTIONBARS"] = {
["ENABLED"] = false,
},
["MAPROFILES"] = {
["ENABLED"] = false,
},
["BLIZZARDACTIONBUTTONSART"] = {
["ENABLED"] = false,
},
["TARGETOFFOCUSFRAME"] = {
["ENABLED"] = false,
},
["TARGETFRAME"] = {
["ENABLED"] = false,
},
["BOSSBANNER"] = {
["ENABLED"] = false,
},
["QUEUESTATUSFRAME"] = {
["ENABLED"] = false,
},
["COMPACTRAIDFRAMECONTAINER"] = {
["ENABLED"] = false,
},
["FOCUSFRAME"] = {
["ENABLED"] = false,
},
["TARGETFRAMEBUFF1"] = {
["ENABLED"] = false,
},
["CHAT9"] = {
["ENABLED"] = false,
},
["LEAVEVEHICLE"] = {
["ENABLED"] = false,
},
["GROUPLOOTCONTAINER"] = {
["ENABLED"] = false,
},
["TARGETFRAMETOTDEBUFF1"] = {
["ENABLED"] = false,
},
["BUFFS"] = {
["ENABLED"] = false,
},
["CHATEDITBOX"] = {
["ENABLED"] = false,
},
["EventToastManagerFrame"] = {
["ENABLED"] = false,
},
["CHAT4"] = {
["ENABLED"] = false,
},
["PLAYERFRAMEBACKGROUND"] = {
["ENABLED"] = false,
},
["ACTIONBAR9"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME5"] = {
["ENABLED"] = false,
},
["COMPACTRAIDFRAMEMANAGER"] = {
["ENABLED"] = false,
},
["PLAYERFRAME"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME6"] = {
["ENABLED"] = false,
},
["FRAMESKEYDRAG"] = {
["ENABLED"] = false,
},
["MAPETFRAME"] = {
["ENABLED"] = false,
},
["TICKETSTATUSFRAME"] = {
["ENABLED"] = false,
},
["DEBUFFS"] = {
["ENABLED"] = false,
},
["DISABLEMOVEMENT"] = {
["ENABLED"] = false,
},
["UIWIDGETPOWERBAR"] = {
["ENABLED"] = false,
},
["QUEUESTATUSBUTTON"] = {
["ENABLED"] = false,
},
["BNToastFrame"] = {
["ENABLED"] = false,
},
["OVERRIDEACTIONBAR"] = {
["ENABLED"] = false,
},
["SAVEFRAMESCALE"] = {
["ENABLED"] = true,
},
["MOVESMALLBAGS"] = {
["ENABLED"] = false,
},
["VEHICLESEATINDICATOR"] = {
["ENABLED"] = false,
},
["SHOWTIPS"] = {
["ENABLED"] = true,
},
["ZONETEXTFRAME"] = {
["ENABLED"] = false,
},
["MOVELOOTFRAME"] = {
["ENABLED"] = false,
},
["OBJECTIVETRACKERBONUSBANNERFRAME"] = {
["ENABLED"] = false,
},
["COMBOFRAME"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME4"] = {
["ENABLED"] = false,
},
["MAINMENUEXPBAR"] = {
["ENABLED"] = false,
},
["RAIDBOSSEMOTEFRAME"] = {
["ENABLED"] = false,
},
["POSSESSBAR"] = {
["ENABLED"] = false,
},
["COMPACTARENAFRAME"] = {
["ENABLED"] = false,
},
["CHAT1"] = {
["ENABLED"] = false,
},
["LOSSOFCONTROLFRAME"] = {
["ENABLED"] = false,
},
["POWERBAR"] = {
["ENABLED"] = false,
},
},
},
},
},
["minimapPos"] = 0,
["MoveAny"] = {
},
["VERSION"] = 2,
}


ClassicFriendlyNameplates = {
["NamePlatesSettings"] = {
true,
},
["NamePlatesFontSettings"] = {
"Fonts\\FRIZQT__.TTF",
12,
"",
"Default",
false,
},
["NamePlatesGeneralSettings"] = {
false,
true,
false,
},
["CNamePlatesSettings"] = {
false,
},
["NamePlatesFriendlySettings"] = {
false,
true,
false,
false,
true,
true,
false,
false,
false,
},
["NamePlatesEnemySettings"] = {
false,
true,
false,
false,
true,
true,
false,
false,
false,
},
}


TipTac_Config = {
["showUnitTip"] = true,
["optionsBottom"] = 413.6669006347656,
["showStatus"] = true,
["tipBackdropEdge"] = "Interface\\Tooltips\\UI-Tooltip-Border",
["reactColoredBackdrop"] = false,
["backdropEdgeSize"] = 14,
["tipBackdropBG"] = "Interface\\Tooltips\\UI-Tooltip-Background",
["version_TipTac_Config"] = "24.11.23",
["tipColor"] = {
0,
0,
0,
1,
},
["enableBackdrop"] = false,
["gradientColor"] = {
0,
0,
0,
1,
},
["minimapConfig"] = {
},
["tipBorderColor"] = {
0.3,
0.3,
0.4,
},
["targetYouText"] = "<YOU>",
["top"] = 304.4446411132813,
["gradientTip"] = false,
["left"] = 1592.666748046875,
["optionsLeft"] = 473.1108093261719,
}

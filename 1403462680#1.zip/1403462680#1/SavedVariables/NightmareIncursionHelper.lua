
NIHdatabase = {
["profileKeys"] = {
["Emz - Shadowstrike (AU)"] = "Default",
["Skeeboo - Shadowstrike (AU)"] = "Default",
["Poisongrace - Maladath (AU)"] = "Default",
},
["global"] = {
["Maladath (AU)"] = {
["myChars"] = {
["Poisongrace"] = {
["quests"] = {
},
["class"] = "ROGUE",
},
},
},
},
}

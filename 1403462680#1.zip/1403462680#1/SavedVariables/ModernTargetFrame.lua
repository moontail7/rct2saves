
ModernTargetFrame_Options = {
["StatusBarText"] = true,
["ClassificationTexture"] = true,
["ThreatIndicatorNumber"] = true,
["ThreatIndicatorGlow"] = true,
["HealthVisibilityPatch"] = true,
}

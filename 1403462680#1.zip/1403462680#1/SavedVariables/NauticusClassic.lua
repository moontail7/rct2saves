
NauticusClassic5DB = {
	["profileKeys"] = {
		["Squishcow - Shadowstrike (AU)"] = "Squishcow - Shadowstrike (AU)",
		["Emz - Shadowstrike (AU)"] = "Emz - Shadowstrike (AU)",
		["Lavy - Shadowstrike (AU)"] = "Lavy - Shadowstrike (AU)",
		["Logoutnow - Shadowstrike (AU)"] = "Logoutnow - Shadowstrike (AU)",
		["Bumboclaat - Shadowstrike (AU)"] = "Bumboclaat - Shadowstrike (AU)",
		["Falseclaimin - Shadowstrike (AU)"] = "Falseclaimin - Shadowstrike (AU)",
		["Creditfraud - Shadowstrike (AU)"] = "Creditfraud - Shadowstrike (AU)",
		["Poisongrace - Shadowstrike (AU)"] = "Poisongrace - Shadowstrike (AU)",
	},
	["global"] = {
		["newerVerAge"] = 1707622340,
		["uptime"] = 61029.145,
		["newerVersion"] = 10304,
		["knownCycles"] = {
			{
				["swaps"] = 1,
				["boots"] = 0,
				["since"] = 731803.5800000001,
			}, -- [1]
			{
				["swaps"] = 1,
				["boots"] = 0,
				["since"] = 713450.64,
			}, -- [2]
			{
				["swaps"] = 1,
				["boots"] = 0,
				["since"] = 586507.932,
			}, -- [3]
			{
				["swaps"] = 1,
				["boots"] = 0,
				["since"] = 697079.7080000001,
			}, -- [4]
			{
				["swaps"] = 3,
				["boots"] = 0,
				["since"] = 16324.64200000011,
			}, -- [5]
			{
				["swaps"] = 2,
				["boots"] = 0,
				["since"] = -463272.967,
			}, -- [6]
			{
				["swaps"] = 4,
				["boots"] = 0,
				["since"] = -1045772.31,
			}, -- [7]
			{
				["swaps"] = 2,
				["boots"] = 0,
				["since"] = 145568.5320000001,
			}, -- [8]
			{
				["swaps"] = 4,
				["boots"] = 0,
				["since"] = 286441.464,
			}, -- [9]
			{
				["swaps"] = 5,
				["boots"] = 0,
				["since"] = 338230.252,
			}, -- [10]
		},
		["timestamp"] = 1709985128,
	},
	["profiles"] = {
		["Squishcow - Shadowstrike (AU)"] = {
		},
		["Emz - Shadowstrike (AU)"] = {
		},
		["Lavy - Shadowstrike (AU)"] = {
		},
		["Logoutnow - Shadowstrike (AU)"] = {
		},
		["Bumboclaat - Shadowstrike (AU)"] = {
		},
		["Falseclaimin - Shadowstrike (AU)"] = {
		},
		["Creditfraud - Shadowstrike (AU)"] = {
		},
		["Poisongrace - Shadowstrike (AU)"] = {
		},
	},
}


CharacterStatsClassicDB = {
["statsPanelHidden"] = false,
["useBlizzardBlockValue"] = false,
["useTransparentStatsBackground"] = true,
}

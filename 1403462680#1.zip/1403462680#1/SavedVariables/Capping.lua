
CappingSettings = {
["profileKeys"] = {
["Emz - Shadowstrike (AU)"] = "Default",
["Poisongrace - Maladath (AU)"] = "Default",
},
["profiles"] = {
["Default"] = {
["position"] = {
"RIGHT",
"RIGHT",
-331.2218017578125,
-172.6664276123047,
},
},
},
}


ECDC_Pos = "Hori"
ECDC_Visi = nil
ECDC_Size = 1
ECDC_Row = 1
ECDC_Border = nil
ECDC_ShowTestIcons = nil
ECDC_Padding = 0
savedVersion = "3.0.0"

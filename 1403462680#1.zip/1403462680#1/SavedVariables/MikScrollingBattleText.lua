
MSBTProfiles_SavedVars = {
["profiles"] = {
["Default"] = {
["critFontSize"] = 18,
["critFontName"] = "2002",
["creationVersion"] = "5.9.1",
["normalFontName"] = "2002",
["normalFontSize"] = 12,
["triggers"] = {
["MSBT_TRIGGER_LOW_MANA"] = {
["disabled"] = true,
},
},
},
},
}
MSBT_SavedMedia = {
["fonts"] = {
},
["sounds"] = {
},
}

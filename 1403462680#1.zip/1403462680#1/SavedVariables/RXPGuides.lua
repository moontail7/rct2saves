
RXPData = {
["gameVersion"] = 11404,
["defaultProfile"] = false,
["cache"] = "Moontail#11187",
["release"] = "v4.6.54",
["cacheVersion"] = 26,
["trainGenericSpells"] = true,
}
RXPDB = {
["profileKeys"] = {
["Skeeboo - Shadowstrike (AU)"] = "global",
["Falseclaimin - Whitemane"] = "global",
["Poisongrace - Shadowstrike (AU)"] = "global",
["Boof - Arugal"] = "global",
["Fuccwit - Whitemane"] = "global",
["Logoutnow - Shadowstrike (AU)"] = "global",
["Bumboclaat - Shadowstrike (AU)"] = "global",
["Gopea - Arugal"] = "global",
["Creditfraud - Shadowstrike (AU)"] = "global",
["Raasclaat - Skull Rock"] = "global",
["Fuccwit - Bigglesworth"] = "global",
["Poisongrace - Maladath (AU)"] = "global",
["Squishcow - Shadowstrike (AU)"] = "global",
["Adadadad - Skull Rock"] = "global",
["Emz - Shadowstrike (AU)"] = "global",
["Falseclaimin - Shadowstrike (AU)"] = "global",
["Rightclicker - Skull Rock"] = "global",
["Lavy - Shadowstrike (AU)"] = "global",
},
["profiles"] = {
["global"] = {
["reports"] = {
["splits"] = {
["Falseclaimin|MAGE|Shadowstrike (AU)"] = {
["current"] = {
["duration"] = 9276,
["text"] = "Level Time: 02:34:36",
},
["title"] = "Falseclaimin (MAGE) - Shadowstrike (AU)",
["history"] = {
["levels"] = {
{
["totalDuration"] = 1379,
["text"] = "Level 2         22:59",
["duration"] = 1379,
},
{
["totalDuration"] = 2038,
["text"] = "Level 3         33:58",
["duration"] = 659,
},
{
["totalDuration"] = 2645,
["text"] = "Level 4         44:05",
["duration"] = 607,
},
{
["totalDuration"] = 3124,
["text"] = "Level 5         52:04",
["duration"] = 479,
},
{
["totalDuration"] = 4622,
["text"] = "Level 6      01:17:02",
["duration"] = 1498,
},
{
["totalDuration"] = 6129,
["text"] = "Level 7      01:42:09",
["duration"] = 1507,
},
{
["totalDuration"] = 7355,
["text"] = "Level 8      02:02:35",
["duration"] = 1226,
},
{
["totalDuration"] = 9563,
["text"] = "Level 9      02:39:23",
["duration"] = 2208,
},
{
["totalDuration"] = 11637,
["text"] = "Level 10    03:13:57",
["duration"] = 2074,
},
{
["totalDuration"] = 14948,
["text"] = "Level 11    04:09:08",
["duration"] = 3311,
},
{
["totalDuration"] = 19864,
["text"] = "Level 12    05:31:04",
["duration"] = 4916,
},
{
["totalDuration"] = 22881,
["text"] = "Level 13    06:21:21",
["duration"] = 3017,
},
{
["totalDuration"] = 26577,
["text"] = "Level 14    07:22:57",
["duration"] = 3696,
},
{
["totalDuration"] = 30297,
["text"] = "Level 15    08:24:57",
["duration"] = 3720,
},
{
["totalDuration"] = 34788,
["text"] = "Level 16    09:39:48",
["duration"] = 4491,
},
{
["totalDuration"] = 40948,
["text"] = "Level 17    11:22:28",
["duration"] = 6160,
},
{
["totalDuration"] = 44977,
["text"] = "Level 18    12:29:37",
["duration"] = 4029,
},
{
["totalDuration"] = 51351,
["text"] = "Level 19    14:15:51",
["duration"] = 6374,
},
{
["totalDuration"] = 63591,
["text"] = "Level 20    17:39:51",
["duration"] = 12240,
},
{
["totalDuration"] = 73537,
["text"] = "Level 21    20:25:37",
["duration"] = 9946,
},
{
["totalDuration"] = 78233,
["text"] = "Level 22    21:43:53",
["duration"] = 4696,
},
{
["totalDuration"] = 85002,
["text"] = "Level 23    23:36:42",
["duration"] = 6769,
},
},
},
["reportKey"] = "Falseclaimin|MAGE|Shadowstrike (AU)",
["total"] = {
["duration"] = 94300,
["text"] = "Total Time: 26:11:40",
},
},
},
},
},
},
}
RXPSettings = {
["profileKeys"] = {
["Skeeboo - Shadowstrike (AU)"] = "Skeeboo - Shadowstrike (AU)",
["Falseclaimin - Whitemane"] = "Falseclaimin - Whitemane",
["Poisongrace - Shadowstrike (AU)"] = "Poisongrace - Shadowstrike (AU)",
["Boof - Arugal"] = "Boof - Arugal",
["Fuccwit - Whitemane"] = "Fuccwit - Whitemane",
["Logoutnow - Shadowstrike (AU)"] = "Logoutnow - Shadowstrike (AU)",
["Bumboclaat - Shadowstrike (AU)"] = "Bumboclaat - Shadowstrike (AU)",
["Gopea - Arugal"] = "Gopea - Arugal",
["Creditfraud - Shadowstrike (AU)"] = "Creditfraud - Shadowstrike (AU)",
["Raasclaat - Skull Rock"] = "Raasclaat - Skull Rock",
["Fuccwit - Bigglesworth"] = "Fuccwit - Bigglesworth",
["Poisongrace - Maladath (AU)"] = "Poisongrace - Maladath (AU)",
["Squishcow - Shadowstrike (AU)"] = "Squishcow - Shadowstrike (AU)",
["Adadadad - Skull Rock"] = "Adadadad - Skull Rock",
["Emz - Shadowstrike (AU)"] = "Emz - Shadowstrike (AU)",
["Falseclaimin - Shadowstrike (AU)"] = "Falseclaimin - Shadowstrike (AU)",
["Rightclicker - Skull Rock"] = "Rightclicker - Skull Rock",
["Lavy - Shadowstrike (AU)"] = "Lavy - Shadowstrike (AU)",
},
["profiles"] = {
["Skeeboo - Shadowstrike (AU)"] = {
["showDangerousMobsMap"] = false,
["macroAnnounced"] = true,
["hardcore"] = true,
["framePositions"] = {
["activeTargetFrame"] = {
{
"CENTER",
nil,
"CENTER",
392.8890380859375,
-206.2218322753906,
},
},
["RXPFrame"] = {
{
"LEFT",
"UIParent",
"LEFT",
0,
35.00000381469727,
},
},
["activeItemFrame"] = {
{
"CENTER",
"UIParent",
"CENTER",
0,
0,
},
},
["arrowFrame"] = {
{
"TOP",
nil,
"TOP",
365.3337097167969,
-91.55554962158203,
},
},
},
["season"] = 2,
["enableGroupQuests"] = false,
["soloSelfFound"] = true,
["showDangerousUnitscan"] = false,
["frameSizes"] = {
["activeTargetFrame"] = {
90.6666488647461,
68.00003051757812,
},
["RXPFrame"] = {
235,
125.0000152587891,
},
["activeItemFrame"] = {
78.66667175292969,
40.00000762939453,
},
["arrowFrame"] = {
32.00000762939453,
32.00000762939453,
},
},
["frameHeight"] = 125.0000152587891,
},
["Falseclaimin - Whitemane"] = {
["SoM"] = false,
["frameHeight"] = 124.9999923706055,
["macroAnnounced"] = true,
},
["Poisongrace - Shadowstrike (AU)"] = {
["frameHeight"] = 125.0000152587891,
["macroAnnounced"] = true,
["frameSizes"] = {
["activeTargetFrame"] = {
90.6666488647461,
68,
},
["RXPFrame"] = {
235.0000305175781,
125.0000152587891,
},
["activeItemFrame"] = {
78.66667175292969,
40.00000762939453,
},
["arrowFrame"] = {
32.00000762939453,
32.00000762939453,
},
},
["season"] = 2,
["framePositions"] = {
["activeTargetFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-343.1110229492188,
-206.2219696044922,
},
},
["RXPFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-88.88898468017578,
-108.1113128662109,
},
},
["activeItemFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-340.2222900390625,
-204.4442749023438,
},
},
["arrowFrame"] = {
{
"CENTER",
nil,
"CENTER",
-224.8887176513672,
-19.55605506896973,
},
},
},
},
["Boof - Arugal"] = {
["SoM"] = false,
["frameHeight"] = 125.0000076293945,
["activeTalentGuide"] = "ROGUE - Softcore Rogue 10-60",
},
["Fuccwit - Whitemane"] = {
["SoM"] = false,
["frameHeight"] = 125.0000076293945,
["macroAnnounced"] = true,
},
["Logoutnow - Shadowstrike (AU)"] = {
["showDangerousMobsMap"] = false,
["macroAnnounced"] = true,
["hardcore"] = true,
["framePositions"] = {
["arrowFrame"] = {
{
"CENTER",
nil,
"CENTER",
276,
62.00001525878906,
},
},
["RXPFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-90.0000228881836,
-133,
},
},
["activeItemFrame"] = {
{
"CENTER",
"UIParent",
"CENTER",
0,
0,
},
},
["activeTargetFrame"] = {
{
"CENTER",
"UIParent",
"CENTER",
0,
0,
},
},
},
["season"] = 2,
["showEnabled"] = false,
["enableGroupQuests"] = false,
["soloSelfFound"] = true,
["enableBetaFeatures"] = true,
["showDangerousUnitscan"] = false,
["frameSizes"] = {
["arrowFrame"] = {
32.00000762939453,
32.00000762939453,
},
["RXPFrame"] = {
235.0000305175781,
125.0000152587891,
},
["activeItemFrame"] = {
78.66667175292969,
39.99998474121094,
},
["activeTargetFrame"] = {
90.66676330566406,
67.99999237060547,
},
},
["frameHeight"] = 125.0000152587891,
["SoM"] = false,
},
["Bumboclaat - Shadowstrike (AU)"] = {
["showDangerousMobsMap"] = false,
["flashOnFind"] = false,
["framePositions"] = {
["arrowFrame"] = {
{
"CENTER",
nil,
"CENTER",
-140.5553894042969,
-99.2225341796875,
},
},
["RXPFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-92,
-124.0000305175781,
},
},
["activeItemFrame"] = {
{
"CENTER",
nil,
"CENTER",
-225,
-223.9999847412109,
},
},
["activeTargetFrame"] = {
{
"CENTER",
nil,
"CENTER",
365.333251953125,
-88.77787780761719,
},
},
},
["season"] = 2,
["minimap"] = {
["minimapPos"] = 132.8933087238127,
},
["macroAnnounced"] = true,
["activeTalentGuide"] = "PRIEST - Softcore Priest 40-60",
["frameSizes"] = {
["arrowFrame"] = {
32.00000762939453,
32.00000762939453,
},
["RXPFrame"] = {
235.0000305175781,
125.0000152587891,
},
["activeItemFrame"] = {
78.66667175292969,
40.00000762939453,
},
["activeTargetFrame"] = {
90.6666488647461,
40.00000762939453,
},
},
["hideInRaid"] = true,
["frameHeight"] = 125.0000152587891,
},
["Gopea - Arugal"] = {
["frameHeight"] = 125.0000076293945,
["SoM"] = false,
},
["Creditfraud - Shadowstrike (AU)"] = {
["showDangerousMobsMap"] = true,
["SoM"] = false,
["season"] = 2,
["minimap"] = {
["minimapPos"] = 62.88801633794476,
},
["enableGroupQuests"] = false,
["activeTalentGuide"] = "ROGUE - Hardcore Rogue 10-60",
["mapCircle"] = false,
["frameHeight"] = 125.0000152587891,
["macroAnnounced"] = true,
["hardcore"] = false,
["framePositions"] = {
["arrowFrame"] = {
{
"CENTER",
nil,
"CENTER",
-147.0000152587891,
-102.0000076293945,
},
},
["RXPFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-89.44419860839844,
-129.6666870117188,
},
},
["activeItemFrame"] = {
{
"CENTER",
nil,
"CENTER",
122.6666030883789,
-100.4445419311523,
},
},
["activeTargetFrame"] = {
{
"CENTER",
nil,
"CENTER",
365.3338012695313,
-39.11134719848633,
},
},
},
["enableLevelUpAnnounceGroup"] = false,
["dungeons"] = {
["ULDA"] = true,
["SFK"] = true,
["BFD"] = true,
["WC"] = true,
["GNOMER"] = true,
["DM"] = true,
["SM"] = true,
["RFK"] = true,
["RFC"] = true,
["MARA"] = true,
["RFD"] = true,
["ST"] = true,
["ZF"] = true,
},
["enableLevelUpAnnounceSolo"] = false,
["numMapPins"] = 20,
["soloSelfFound"] = false,
["alwaysSendBranded"] = false,
["hightlightTalentPlan"] = false,
["frameSizes"] = {
["arrowFrame"] = {
32.00000762939453,
32.00000762939453,
},
["RXPFrame"] = {
235.0000305175781,
125.0000152587891,
},
["activeItemFrame"] = {
78.66667175292969,
40.00000762939453,
},
["activeTargetFrame"] = {
90.6666488647461,
40.00000762939453,
},
},
["showEnabled"] = false,
["showDangerousUnitscan"] = true,
},
["Raasclaat - Skull Rock"] = {
["arrowScale"] = 1.25,
["showDangerousMobsMap"] = true,
["macroAnnounced"] = true,
["hardcore"] = true,
["dungeons"] = {
["RFK"] = true,
["SFK"] = true,
["MARA"] = true,
["RFC"] = true,
["BFD"] = true,
["ST"] = true,
["WC"] = true,
["ZF"] = true,
},
["enableGroupQuests"] = true,
["soloSelfFound"] = false,
["windowScale"] = 1.2,
["frameHeight"] = 125.0000228881836,
["SoM"] = false,
["arrowText"] = 13,
["showDangerousUnitscan"] = true,
},
["Fuccwit - Bigglesworth"] = {
["frameHeight"] = 124.9999771118164,
["SoM"] = false,
},
["Poisongrace - Maladath (AU)"] = {
["hardcore"] = false,
["framePositions"] = {
["activeTargetFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-381.8887634277344,
-136.3333740234375,
},
},
["RXPFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
0,
-111.5186767578125,
},
},
["activeItemFrame"] = {
{
"CENTER",
nil,
"CENTER",
326,
-162.0000152587891,
},
},
["arrowFrame"] = {
{
"CENTER",
nil,
"CENTER",
396.4445190429688,
-39.11120223999023,
},
},
},
["season"] = 0,
["frameSizes"] = {
["activeTargetFrame"] = {
90.6666488647461,
40.00000762939453,
},
["RXPFrame"] = {
235,
125.0000534057617,
},
["activeItemFrame"] = {
78.66656494140625,
40.00000762939453,
},
["arrowFrame"] = {
32.00000762939453,
32.00000762939453,
},
},
["itemUpgradeSpec"] = "Rogue",
["dungeons"] = {
["ULDA"] = true,
["STOCKS"] = true,
["RFD"] = true,
["GNOMER"] = true,
["DM"] = true,
["MARA"] = true,
["SM"] = true,
["RFK"] = true,
["BFD"] = true,
["ST"] = true,
["ZF"] = true,
},
["soloSelfFound"] = false,
["showDangerousMobsMap"] = true,
["enableGroupQuests"] = true,
["frameHeight"] = 125.0000534057617,
["macroAnnounced"] = true,
["windowScale"] = 1.2,
["showDangerousUnitscan"] = true,
},
["Squishcow - Shadowstrike (AU)"] = {
["showDangerousMobsMap"] = true,
["macroAnnounced"] = true,
["framePositions"] = {
["arrowFrame"] = {
{
"CENTER",
nil,
"CENTER",
-249.7778015136719,
-144.8889617919922,
},
},
["RXPFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-20.11056137084961,
-69.88906860351562,
},
},
["activeItemFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-373.9996948242188,
-151.1109619140625,
},
},
["activeTargetFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-365.3328247070313,
-202.6667785644531,
},
},
},
["season"] = 2,
["dungeons"] = {
["ULDA"] = true,
["SFK"] = true,
["BFD"] = true,
["WC"] = true,
["GNOMER"] = true,
["MARA"] = true,
["RFK"] = true,
["RFC"] = true,
["RFD"] = true,
["SM"] = true,
["ST"] = true,
["ZF"] = true,
},
["enableGroupQuests"] = true,
["soloSelfFound"] = false,
["showDangerousUnitscan"] = true,
["frameSizes"] = {
["arrowFrame"] = {
32.00000762939453,
32.00000762939453,
},
["RXPFrame"] = {
235.0000305175781,
125.0000762939453,
},
["activeItemFrame"] = {
78.66667175292969,
40.00000762939453,
},
["activeTargetFrame"] = {
90.6666488647461,
68.00003051757812,
},
},
["frameHeight"] = 125.0000152587891,
},
["Adadadad - Skull Rock"] = {
["showDangerousMobsMap"] = true,
["macroAnnounced"] = true,
["hardcore"] = true,
["dungeons"] = {
["RFK"] = true,
["SFK"] = true,
["MARA"] = true,
["RFC"] = true,
["BFD"] = true,
["ST"] = true,
["WC"] = true,
["ZF"] = true,
},
["enableGroupQuests"] = true,
["soloSelfFound"] = false,
["showDangerousUnitscan"] = true,
["SoM"] = false,
["frameHeight"] = 124.9999923706055,
},
["Emz - Shadowstrike (AU)"] = {
["frameHeight"] = 125.0000152587891,
["macroAnnounced"] = true,
["frameSizes"] = {
["activeTargetFrame"] = {
90.6666488647461,
67.99999237060547,
},
["RXPFrame"] = {
235.0000305175781,
125.0000152587891,
},
["activeItemFrame"] = {
78.66667175292969,
40.00000762939453,
},
["arrowFrame"] = {
32.00000762939453,
32.00000762939453,
},
},
["season"] = 2,
["framePositions"] = {
["activeTargetFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-368.5553283691406,
-198.6669464111328,
},
},
["RXPFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-19.0000057220459,
-113,
},
},
["activeItemFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-404.2220153808594,
-199.9997863769531,
},
},
["arrowFrame"] = {
{
"CENTER",
nil,
"CENTER",
297.2222290039063,
-94.00004577636719,
},
},
},
},
["Falseclaimin - Shadowstrike (AU)"] = {
["showDangerousMobsMap"] = true,
["SoM"] = false,
["season"] = 2,
["minimap"] = {
["minimapPos"] = 50.47581520411597,
},
["enableQuestAutomation"] = false,
["activeTheme"] = "DarkMode",
["enableBetaFeatures"] = true,
["debug"] = false,
["hardcore"] = false,
["enablelevelSplits"] = false,
["showDangerousUnitscan"] = true,
["frameHeight"] = 125.000129699707,
["macroAnnounced"] = true,
["upcomingTalentCount"] = 1,
["framePositions"] = {
["activeItemFrame"] = {
{
"CENTER",
nil,
"CENTER",
351.0000915527344,
-24,
},
},
["levelSplits"] = {
{
"CENTER",
"UIParent",
"CENTER",
0,
0,
},
},
["RXPFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-80.66658020019531,
-123.4445419311523,
},
},
["arrowFrame"] = {
{
"CENTER",
nil,
"CENTER",
-151,
-85,
},
},
["activeTargetFrame"] = {
{
"CENTER",
nil,
"CENTER",
376,
-86,
},
},
},
["enableLevelUpAnnounceGroup"] = false,
["dungeons"] = {
["ULDA"] = true,
["SFK"] = true,
["BFD"] = true,
["WC"] = true,
["GNOMER"] = true,
["SM"] = true,
["RFK"] = true,
["RFC"] = true,
["MARA"] = true,
["RFD"] = true,
["ST"] = true,
["ZF"] = true,
},
["enableLevelUpAnnounceSolo"] = false,
["shareQuests"] = true,
["soloSelfFound"] = false,
["alwaysSendBranded"] = false,
["hightlightTalentPlan"] = false,
["frameSizes"] = {
["activeItemFrame"] = {
78.66656494140625,
40.00007247924805,
},
["levelSplits"] = {
107.5555572509766,
154,
},
["RXPFrame"] = {
247,
125.000129699707,
},
["arrowFrame"] = {
32.00000762939453,
32.00000762939453,
},
["activeTargetFrame"] = {
90.6666488647461,
67.99999237060547,
},
},
["hideInRaid"] = true,
["enableGroupQuests"] = true,
},
["Rightclicker - Skull Rock"] = {
["showDangerousMobsMap"] = true,
["SoM"] = false,
["minimap"] = {
["minimapPos"] = 358.5664961919176,
},
["checkVersions"] = false,
["windowScale"] = 1.15,
["activeTalentGuide"] = "DRUID - Hardcore Druid 10-60",
["arrowScale"] = 1.2,
["frameHeight"] = 125.0000152587891,
["macroAnnounced"] = true,
["hardcore"] = true,
["enableLevelUpAnnounceGroup"] = false,
["ignoreQuestieConflicts"] = false,
["enableLevelUpAnnounceSolo"] = false,
["alwaysSendBranded"] = false,
["enableFlyStepAnnouncements"] = false,
["showDangerousUnitscan"] = true,
["arrowText"] = 12,
["activeItemsScale"] = 1.15,
},
["Lavy - Shadowstrike (AU)"] = {
["showDangerousMobsMap"] = true,
["macroAnnounced"] = true,
["framePositions"] = {
["activeTargetFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-273.7772827148438,
-122.6669540405273,
},
},
["RXPFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-10.66651439666748,
-119.9571990966797,
},
},
["activeItemFrame"] = {
{
"RIGHT",
nil,
"RIGHT",
-356.2218322753906,
-204.4440612792969,
},
},
["arrowFrame"] = {
{
"CENTER",
nil,
"CENTER",
-292.4446716308594,
-198.2227020263672,
},
},
},
["season"] = 2,
["dungeons"] = {
["ULDA"] = true,
["SFK"] = true,
["BFD"] = true,
["WC"] = true,
["GNOMER"] = true,
["SM"] = true,
["RFK"] = true,
["RFC"] = true,
["MARA"] = true,
["RFD"] = true,
["ST"] = true,
["ZF"] = true,
},
["enableGroupQuests"] = true,
["soloSelfFound"] = false,
["showDangerousUnitscan"] = true,
["frameSizes"] = {
["activeTargetFrame"] = {
90.6666488647461,
67.99999237060547,
},
["RXPFrame"] = {
254.1880798339844,
126.9829330444336,
},
["activeItemFrame"] = {
78.66667175292969,
40.00000762939453,
},
["arrowFrame"] = {
32.00000762939453,
32.00000762939453,
},
},
["frameHeight"] = 126.9829330444336,
},
},
}

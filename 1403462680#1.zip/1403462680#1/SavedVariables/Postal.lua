
Postal3DB = {
["global"] = {
["BlackBook"] = {
["alts"] = {
"Emz|Shadowstrike (AU)|Horde|48|MAGE",
"Poisongrace|Maladath (AU)|Alliance|11|ROGUE",
"Skeeboo|Shadowstrike (AU)|Horde|1|WARRIOR",
},
},
},
["profileKeys"] = {
["Emz - Shadowstrike (AU)"] = "Emz - Shadowstrike (AU)",
["Skeeboo - Shadowstrike (AU)"] = "Skeeboo - Shadowstrike (AU)",
["Poisongrace - Maladath (AU)"] = "Poisongrace - Maladath (AU)",
},
["profiles"] = {
["Emz - Shadowstrike (AU)"] = {
},
["Skeeboo - Shadowstrike (AU)"] = {
},
["Poisongrace - Maladath (AU)"] = {
},
},
}

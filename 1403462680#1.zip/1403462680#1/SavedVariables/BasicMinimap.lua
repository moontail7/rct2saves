
BasicMinimapSV = {
["profileKeys"] = {
["Skeeboo - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Whitemane"] = "Default",
["Poisongrace - Shadowstrike (AU)"] = "Default",
["Boof - Arugal"] = "Default",
["Fuccwit - Whitemane"] = "Default",
["Logoutnow - Shadowstrike (AU)"] = "Default",
["Squishcow - Shadowstrike (AU)"] = "Default",
["Gopea - Arugal"] = "Default",
["Creditfraud - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Skull Rock"] = "Default",
["Raasclaat - Skull Rock"] = "Default",
["Fuccwit - Bigglesworth"] = "Default",
["Lavy - Shadowstrike (AU)"] = "Default",
["Adadadad - Skull Rock"] = "Default",
["Rightclicker - Skull Rock"] = "Default",
["Emz - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Shadowstrike (AU)"] = "Default",
["Bumboclaat - Shadowstrike (AU)"] = "Default",
["Poisongrace - Maladath (AU)"] = "Default",
},
["profiles"] = {
["Default"] = {
["size"] = 170,
["position"] = {
"BOTTOMRIGHT",
"BOTTOMRIGHT",
-344.2676696777344,
57.73882293701172,
},
},
},
}

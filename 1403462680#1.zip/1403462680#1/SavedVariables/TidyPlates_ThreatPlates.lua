
ThreatPlatesDB = {
["char"] = {
["Skeeboo - Shadowstrike (AU)"] = {
["welcome"] = true,
},
["Falseclaimin - Whitemane"] = {
["welcome"] = true,
},
["Poisongrace - Shadowstrike (AU)"] = {
["welcome"] = true,
},
["Boof - Arugal"] = {
["welcome"] = true,
},
["Fuccwit - Whitemane"] = {
["welcome"] = true,
},
["Logoutnow - Shadowstrike (AU)"] = {
["welcome"] = true,
},
["Squishcow - Shadowstrike (AU)"] = {
["welcome"] = true,
},
["Gopea - Arugal"] = {
["welcome"] = true,
},
["Creditfraud - Shadowstrike (AU)"] = {
["welcome"] = true,
},
["Falseclaimin - Skull Rock"] = {
["welcome"] = true,
},
["Raasclaat - Skull Rock"] = {
["welcome"] = true,
},
["Fuccwit - Bigglesworth"] = {
["welcome"] = true,
},
["Poisongrace - Maladath (AU)"] = {
["welcome"] = true,
},
["Rightclicker - Skull Rock"] = {
["welcome"] = true,
},
["Adadadad - Skull Rock"] = {
["welcome"] = true,
},
["Emz - Shadowstrike (AU)"] = {
["welcome"] = true,
},
["Falseclaimin - Shadowstrike (AU)"] = {
["welcome"] = true,
},
["Bumboclaat - Shadowstrike (AU)"] = {
["welcome"] = true,
},
["Lavy - Shadowstrike (AU)"] = {
["welcome"] = true,
},
},
["global"] = {
["version"] = "12.0.12",
},
["profileKeys"] = {
["Skeeboo - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Whitemane"] = "Default",
["Poisongrace - Shadowstrike (AU)"] = "Default",
["Boof - Arugal"] = "Default",
["Fuccwit - Whitemane"] = "Default",
["Logoutnow - Shadowstrike (AU)"] = "Default",
["Squishcow - Shadowstrike (AU)"] = "Default",
["Gopea - Arugal"] = "Default",
["Creditfraud - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Skull Rock"] = "Default",
["Raasclaat - Skull Rock"] = "Default",
["Fuccwit - Bigglesworth"] = "Default",
["Poisongrace - Maladath (AU)"] = "Default",
["Rightclicker - Skull Rock"] = "Default",
["Adadadad - Skull Rock"] = "Default",
["Emz - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Shadowstrike (AU)"] = "Default",
["Bumboclaat - Shadowstrike (AU)"] = "Default",
["Lavy - Shadowstrike (AU)"] = "Default",
},
["profiles"] = {
["Default"] = {
["AuraWidget"] = {
["ShowCooldownSpiral"] = true,
["ShowOmniCC"] = true,
["ShowTooltips"] = true,
["Debuffs"] = {
["ModeIcon"] = {
["IconWidth"] = 20,
["Style"] = "custom",
["IconHeight"] = 20,
},
},
},
["settings"] = {
["castbar"] = {
["show"] = false,
},
["frame"] = {
["height"] = 32,
["width"] = 126,
},
},
},
},
}

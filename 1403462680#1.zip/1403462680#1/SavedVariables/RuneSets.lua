
RuneSetsDB = {
["_auto"] = true,
["Creditfraud-Shadowstrike(AU)"] = {
["sets"] = {
{
["runes"] = {
[6] = {
48162,
132303,
"Shadowstep",
},
[7] = {
48142,
135610,
"Between the Eyes",
},
[8] = {
49174,
132299,
"Master of Subtlety",
},
[10] = {
48160,
132304,
"Mutilate",
},
[5] = {
48148,
134536,
"Quick Draw",
},
},
["includeInMenus"] = true,
["name"] = "Pvp",
},
{
["runes"] = {
[6] = {
48162,
132303,
"Shadowstep",
},
[7] = {
48163,
132287,
"Envenom",
},
[8] = {
49174,
132299,
"Master of Subtlety",
},
[10] = {
48160,
132304,
"Mutilate",
},
[5] = {
48141,
134877,
"Deadly Brew",
},
},
["includeInMenus"] = true,
["name"] = "pve",
},
},
["equipstates"] = {
},
["states"] = {
["dungeon"] = 2,
["world-raid"] = -1,
["world-solo"] = 1,
["raid"] = 2,
["world-party"] = -1,
["pvp"] = 1,
},
},
["_minimap"] = {
["minimapPos"] = 45.63112133557173,
["hide"] = false,
},
["Logoutnow-Shadowstrike(AU)"] = {
["sets"] = {
{
["name"] = "<empty RuneSet>",
["runes"] = {
},
},
},
["equipstates"] = {
},
["states"] = {
["dungeon"] = -1,
["pvp"] = -1,
["world-solo"] = -1,
["raid"] = -1,
["world-party"] = -1,
["world-raid"] = -1,
},
},
["Poisongrace-Maladath(AU)"] = {
["sets"] = {
{
["name"] = "<empty RuneSet>",
["runes"] = {
},
},
},
["equipstates"] = {
},
["states"] = {
["dungeon"] = -1,
["raid"] = -1,
["world-solo"] = -1,
["world-party"] = -1,
["world-raid"] = -1,
["pvp"] = -1,
},
},
["Bumboclaat-Shadowstrike(AU)"] = {
["sets"] = {
{
["name"] = "<empty RuneSet>",
["runes"] = {
},
},
},
["equipstates"] = {
},
["states"] = {
["dungeon"] = -1,
["pvp"] = -1,
["world-solo"] = -1,
["raid"] = -1,
["world-party"] = -1,
["world-raid"] = -1,
},
},
["Skeeboo-Shadowstrike(AU)"] = {
["sets"] = {
{
["name"] = "<empty RuneSet>",
["runes"] = {
},
},
},
["states"] = {
["dungeon"] = -1,
["pvp"] = -1,
["world-solo"] = -1,
["raid"] = -1,
["world-party"] = -1,
["world-raid"] = -1,
},
["equipstates"] = {
},
},
["_edit"] = true,
["Squishcow-Shadowstrike(AU)"] = {
["sets"] = {
{
["name"] = "<empty RuneSet>",
["runes"] = {
},
},
},
["equipstates"] = {
},
["states"] = {
["dungeon"] = -1,
["world-raid"] = -1,
["world-solo"] = -1,
["raid"] = -1,
["world-party"] = -1,
["pvp"] = -1,
},
},
["Lavy-Shadowstrike(AU)"] = {
["sets"] = {
{
["name"] = "<empty RuneSet>",
["runes"] = {
},
},
},
["states"] = {
["dungeon"] = -1,
["pvp"] = -1,
["world-solo"] = -1,
["raid"] = -1,
["world-party"] = -1,
["world-raid"] = -1,
},
["equipstates"] = {
},
},
["Poisongrace-Shadowstrike(AU)"] = {
["sets"] = {
{
["name"] = "<empty RuneSet>",
["runes"] = {
},
},
},
["states"] = {
["dungeon"] = -1,
["pvp"] = -1,
["world-solo"] = -1,
["raid"] = -1,
["world-party"] = -1,
["world-raid"] = -1,
},
["equipstates"] = {
},
},
["Falseclaimin-Shadowstrike(AU)"] = {
["sets"] = {
{
["name"] = "<empty RuneSet>",
["runes"] = {
},
},
},
["equipstates"] = {
},
["states"] = {
["dungeon"] = -1,
["pvp"] = -1,
["world-solo"] = -1,
["raid"] = -1,
["world-party"] = -1,
["world-raid"] = -1,
},
},
["Emz-Shadowstrike(AU)"] = {
["sets"] = {
{
["name"] = "<empty RuneSet>",
["runes"] = {
},
},
},
["states"] = {
["dungeon"] = -1,
["pvp"] = -1,
["world-solo"] = -1,
["raid"] = -1,
["world-party"] = -1,
["world-raid"] = -1,
},
["equipstates"] = {
},
},
}

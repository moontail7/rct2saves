
BattleGroundEnemiesDB = {
["profileKeys"] = {
["Emz - Shadowstrike (AU)"] = "Default",
["Skeeboo - Shadowstrike (AU)"] = "Default",
["Poisongrace - Maladath (AU)"] = "Default",
},
["profiles"] = {
["Default"] = {
["dbVersion"] = 2,
["lastReadVersion"] = "11.0.5.9",
},
},
}

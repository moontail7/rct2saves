
DMTAB = {
["PROFILES"] = {
["DEFAULT"] = {
["FRAMES"] = {
["POINTS"] = {
},
["SIZES"] = {
},
},
["MMICON"] = {
["minimapPos"] = 19.28766032914018,
},
["ELES"] = {
["SIZES"] = {
},
["POINTS"] = {
["DMSettings"] = {
},
},
["OPTIONS"] = {
["SHOWMINIMAPBUTTON"] = {
["ENABLED"] = false,
},
["SETTINGS"] = {
["ENABLED"] = false,
},
["MMBTN"] = {
["ENABLED"] = true,
},
["MASKBUFFSANDDEBUFFS"] = {
["ENABLED"] = true,
},
["MASKMINIMAPBUTTONS"] = {
["ENABLED"] = true,
},
["THINBORDERS"] = {
["ENABLED"] = false,
},
["GRYPHONS"] = {
["ENABLED"] = true,
},
["MASKBUFFSANDEBUFFS"] = {
["ENABLED"] = true,
},
["ACTIONBARS"] = {
},
["MASKACTIONBUTTONS"] = {
["ENABLED"] = true,
},
},
},
},
},
["CURRENTPROFILE"] = "DEFAULT",
["DarkMode"] = {
},
["VALUES"] = {
["COLORMODE"] = 1,
["COLORMODEF"] = 1,
["COLORMODEBAD"] = 1,
["COLORMODEUF"] = 7,
["COLORMODENP"] = 1,
["COLORMODETT"] = 1,
["COLORMODEAB"] = 1,
},
["minimapPos"] = 0,
}

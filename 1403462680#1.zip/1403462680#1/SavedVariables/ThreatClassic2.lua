
ThreatClassic2DB = {
["profileKeys"] = {
["Poisongrace - Maladath (AU)"] = "Default",
["Skeeboo - Shadowstrike (AU)"] = "Default",
["Poisongrace - Shadowstrike (AU)"] = "Default",
["Bumboclaat - Shadowstrike (AU)"] = "Default",
["Lavy - Shadowstrike (AU)"] = "Default",
["Logoutnow - Shadowstrike (AU)"] = "Default",
["Squishcow - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Shadowstrike (AU)"] = "Default",
["Creditfraud - Shadowstrike (AU)"] = "Default",
["Emz - Shadowstrike (AU)"] = "Default",
},
["profiles"] = {
["Default"] = {
["general"] = {
["hideAlways"] = true,
},
["frame"] = {
["width"] = 176.9602661132813,
["height"] = 60.82381820678711,
["position"] = {
nil,
nil,
nil,
1172.941772460938,
-611.931640625,
},
},
["bar"] = {
["count"] = 3,
},
},
},
}

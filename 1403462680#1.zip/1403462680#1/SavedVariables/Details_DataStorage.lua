
DetailsDataStorage = {
	["Data"] = {
	},
	[15] = {
	},
	["VERSION"] = 5,
	["saved_encounters"] = {
	},
	[14] = {
	},
	[16] = {
	},
	["mythic_plus"] = {
	},
}

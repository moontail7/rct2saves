
DBMPvP_AllSavedVars = {
	["Emz-Shadowstrike (AU)"] = {
		["z529"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["m1434"] = {
			[0] = {
				["Enabled"] = true,
				["ResTimerPartyClassColors"] = true,
				["ResTimerParty"] = false,
				["Timer436097active"] = true,
				["ResTimerSelf"] = true,
				["ResTimerSelfCVoice"] = 0,
				["Timer436097nextTColor"] = 0,
				["ResTimerPartyTColor"] = 0,
				["Timer436097nextCVoice"] = 0,
				["ResTimerPartyCVoice"] = 0,
				["Timer436097activeTColor"] = 0,
				["ResTimerSelfTColor"] = 0,
				["Timer436097next"] = true,
				["Timer436097activeCVoice"] = 0,
			},
		},
		["PvPGeneral"] = {
			[0] = {
				["TimerFlagCVoice"] = 0,
				["TimerStartTColor"] = 0,
				["ShowBasesToWin"] = true,
				["TimerFlagTColor"] = 0,
				["HideBossEmoteFrame"] = false,
				["TimerWinCVoice"] = 0,
				["TimerWinTColor"] = 0,
				["TimerCapCVoice"] = 0,
				["TimerFlag"] = true,
				["TimerStartCVoice"] = 0,
				["Enabled"] = true,
				["TimerCap"] = true,
				["TimerWin"] = true,
				["TimerCapTColor"] = 0,
				["ShowRelativeGameTime"] = true,
				["AutoSpirit"] = false,
				["TimerStart"] = true,
			},
		},
		["z489"] = {
			[0] = {
				["Enabled"] = true,
			},
		},
		["m1440"] = {
			[0] = {
				["Enabled"] = true,
				["EstimatedStartTimerTColor"] = 6,
				["HealthFrame"] = true,
				["EstimatedStartTimer"] = true,
				["EstimatedStartTimerCVoice"] = 0,
			},
		},
		["z30"] = {
			[0] = {
				["Enabled"] = true,
				["TimerBossTColor"] = 0,
				["TimerBoss"] = true,
				["AutoTurnIn"] = true,
				["TimerBossCVoice"] = 0,
			},
		},
	},
}


NRunDB_Global = {
["charspec"] = {
},
}
NugRunningConfigCustom = {
["MAGE"] = {
},
["ROGUE"] = {
},
}

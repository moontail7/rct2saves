
NugEnergyDB = {
["DB_VERSION"] = 1,
["profileKeys"] = {
["Emz - Shadowstrike (AU)"] = "Default",
["Poisongrace - Maladath (AU)"] = "Default",
},
["profiles"] = {
["Default"] = {
},
},
}

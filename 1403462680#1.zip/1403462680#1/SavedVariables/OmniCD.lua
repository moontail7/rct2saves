
OmniCDDB = {
	["profileKeys"] = {
		["Skeeboo - Shadowstrike (AU)"] = "Default",
		["Falseclaimin - Whitemane"] = "Default",
		["Poisongrace - Shadowstrike (AU)"] = "Default",
		["Boof - Arugal"] = "Default",
		["Fuccwit - Whitemane"] = "Default",
		["Logoutnow - Shadowstrike (AU)"] = "Default",
		["Bumboclaat - Shadowstrike (AU)"] = "Default",
		["Gopea - Arugal"] = "Default",
		["Creditfraud - Shadowstrike (AU)"] = "Default",
		["Raasclaat - Skull Rock"] = "Default",
		["Fuccwit - Bigglesworth"] = "Default",
		["Lavy - Shadowstrike (AU)"] = "Default",
		["Rightclicker - Skull Rock"] = "Default",
		["Emz - Shadowstrike (AU)"] = "Default",
		["Falseclaimin - Shadowstrike (AU)"] = "Default",
		["Adadadad - Skull Rock"] = "Default",
		["Squishcow - Shadowstrike (AU)"] = "Default",
	},
	["cooldowns"] = {
	},
	["version"] = 3,
	["profiles"] = {
		["Default"] = {
			["modules"] = {
				["Party"] = false,
			},
			["Party"] = {
				["party"] = {
					["extraBars"] = {
						["raidBar0"] = {
							["manualPos"] = {
								["raidBar0"] = {
									["y"] = 392.576319374064,
									["x"] = 939.2994557321363,
								},
							},
						},
					},
				},
			},
		},
	},
}


EasyFramesDB = {
	["profileKeys"] = {
		["Falseclaimin - Skull Rock"] = "Default",
		["Rightclicker - Skull Rock"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["general"] = {
				["frameToSetPoints"] = "target",
			},
		},
	},
}

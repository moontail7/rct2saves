
HealBarSettings = {
	["profileKeys"] = {
		["Rightclicker - Skull Rock"] = "Rightclicker - Skull Rock",
	},
}

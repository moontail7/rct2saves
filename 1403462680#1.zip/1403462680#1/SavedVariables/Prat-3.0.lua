
Prat3DB = {
["namespaces"] = {
["Prat_ChannelColorMemory"] = {
["profiles"] = {
["Default"] = {
["colors"] = {
["looking"] = {
["b"] = 0.7529412508010864,
["g"] = 0.7529412508010864,
["r"] = 1,
},
["hcdeathalertschannel"] = {
["b"] = 0.7529412508010864,
["g"] = 0.7529412508010864,
["r"] = 1,
},
["hcdeathalertschannelb"] = {
["b"] = 0.7490196228027344,
["g"] = 0.7490196228027344,
["r"] = 1,
},
["lookingforgroup"] = {
["r"] = 1,
["g"] = 0.3764706254005432,
["b"] = 0.3529411852359772,
},
["world"] = {
["r"] = 0.917647123336792,
["g"] = 1,
["b"] = 0.8980392813682556,
},
},
},
},
},
["Prat_Fading"] = {
},
["Prat_Scroll"] = {
},
["Prat_Mentions"] = {
},
["Prat_CopyChat"] = {
},
["Prat_PopupMessage"] = {
},
["Prat_ServerNames"] = {
},
["Prat_UrlCopy"] = {
},
["Prat_AltNames"] = {
},
["Prat_PlayerNames"] = {
},
["Prat_Memory"] = {
},
["Prat_Frames"] = {
["profiles"] = {
["Default"] = {
["minchatwidthdefault"] = 296,
["maxchatheightdefault"] = 400,
["initialized"] = true,
["maxchatwidthdefault"] = 608.0000610351562,
},
},
},
["Prat_Editbox"] = {
},
["Prat_History"] = {
},
["Prat_Font"] = {
["profiles"] = {
["Default"] = {
["size"] = {
["ChatFrame5"] = 14,
["ChatFrame4"] = 14,
["ChatFrame6"] = 16,
["ChatFrame1"] = 14,
},
},
},
},
["Prat_KeyBindings"] = {
},
["Prat_Bubbles"] = {
},
["Prat_TellTarget"] = {
},
["Prat_Achievements"] = {
},
["Prat_Paragraph"] = {
},
["Prat_DebugModules"] = {
},
["Prat_Alias"] = {
},
["Prat_OriginalButtons"] = {
},
["Prat_Highlight"] = {
},
["Prat_Sounds"] = {
},
["Prat_ChannelSticky"] = {
},
["Prat_Invites"] = {
},
["Prat_LinkInfoIcons"] = {
},
["Prat_ChannelNames"] = {
},
["Prat_ChatLog"] = {
},
["Prat_Search"] = {
},
["Prat_Buttons"] = {
},
["Prat_Timestamps"] = {
},
["Prat_HoverTips"] = {
},
},
["profileKeys"] = {
["Skeeboo - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Whitemane"] = "Default",
["Poisongrace - Shadowstrike (AU)"] = "Default",
["Boof - Arugal"] = "Default",
["Fuccwit - Whitemane"] = "Default",
["Logoutnow - Shadowstrike (AU)"] = "Default",
["Squishcow - Shadowstrike (AU)"] = "Default",
["Gopea - Arugal"] = "Default",
["Creditfraud - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Skull Rock"] = "Default",
["Raasclaat - Skull Rock"] = "Default",
["Fuccwit - Bigglesworth"] = "Default",
["Poisongrace - Maladath (AU)"] = "Default",
["Bumboclaat - Shadowstrike (AU)"] = "Default",
["Rightclicker - Skull Rock"] = "Default",
["Emz - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Shadowstrike (AU)"] = "Default",
["Adadadad - Skull Rock"] = "Default",
["Lavy - Shadowstrike (AU)"] = "Default",
},
["profiles"] = {
["Default"] = {
["modules"] = {
["Alias"] = 2,
["Mentions"] = 2,
["PopupMessage"] = 2,
["AltNames"] = 2,
["Sounds"] = 2,
["Paragraph"] = 2,
["KeyBindings"] = 2,
["LinkInfoIcons"] = 2,
["DebugModules"] = 2,
["OriginalButtons"] = 2,
["ChatLog"] = 2,
},
},
},
}

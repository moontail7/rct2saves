
FTSavedVars = {
}
FojjiSkipWTF = {
["skip"] = true,
}


Bagnon_Sets = {
["tackleColor"] = {
},
["leatherColor"] = {
},
["engineerColor"] = {
},
["herbColor"] = {
},
["inscribeColor"] = {
},
["soulColor"] = {
},
["quiverColor"] = {
},
["reagentColor"] = {
},
["gemColor"] = {
},
["global"] = {
["inventory"] = {
["rules"] = {
"all",
"all/normal",
"all/trade",
"all/reagent",
"all/keys",
"all/quiver",
"equip",
"equip/armor",
"equip/weapon",
"equip/trinket",
"use",
"use/consume",
"use/enhance",
"trade",
"trade/goods",
"trade/gem",
"trade/glyph",
"trade/recipe",
"quest",
"misc",
"all/souls",
"equip/ammo",
"contain",
},
["point"] = "TOPRIGHT",
["hiddenBags"] = {
false,
false,
false,
false,
[-2] = true,
[0] = false,
},
["color"] = {
},
["hiddenRules"] = {
},
["lockedSlots"] = {
},
["y"] = -230.2223510742188,
["x"] = -293.3306884765625,
["reverseBags"] = true,
["skin"] = "Barber",
["reverseSlots"] = true,
["borderColor"] = {
},
["columns"] = 7,
["brokerObject"] = "TradeSkillMaster",
},
["vault"] = {
["rules"] = {
"all",
"all/normal",
"all/trade",
"all/reagent",
"all/keys",
"all/quiver",
"equip",
"equip/armor",
"equip/weapon",
"equip/trinket",
"use",
"use/consume",
"use/enhance",
"trade",
"trade/goods",
"trade/gem",
"trade/glyph",
"trade/recipe",
"quest",
"misc",
},
["hiddenBags"] = {
},
["color"] = {
},
["lockedSlots"] = {
},
["hiddenRules"] = {
},
["borderColor"] = {
},
},
["guild"] = {
["rules"] = {
"all",
"all/normal",
"all/trade",
"all/reagent",
"all/keys",
"all/quiver",
"equip",
"equip/armor",
"equip/weapon",
"equip/trinket",
"use",
"use/consume",
"use/enhance",
"trade",
"trade/goods",
"trade/gem",
"trade/glyph",
"trade/recipe",
"quest",
"misc",
},
["borderColor"] = {
},
["color"] = {
},
["lockedSlots"] = {
},
["hiddenRules"] = {
},
["hiddenBags"] = {
},
},
["bank"] = {
["rules"] = {
"all",
"all/normal",
"all/trade",
"all/reagent",
"all/keys",
"all/quiver",
"equip",
"equip/armor",
"equip/weapon",
"equip/trinket",
"use",
"use/consume",
"use/enhance",
"trade",
"trade/goods",
"trade/gem",
"trade/glyph",
"trade/recipe",
"quest",
"misc",
"all/souls",
"equip/ammo",
"contain",
},
["point"] = "TOPLEFT",
["hiddenBags"] = {
[5] = false,
[6] = false,
},
["color"] = {
},
["hiddenRules"] = {
},
["y"] = -89.98638916015625,
["x"] = 343.5760192871094,
["borderColor"] = {
},
["lockedSlots"] = {
},
["showBags"] = true,
},
},
["keyColor"] = {
},
["normalColor"] = {
},
["profiles"] = {
},
["mineColor"] = {
},
["version"] = "10.2.4",
["fridgeColor"] = {
},
["display"] = {
},
["enchantColor"] = {
},
["latest"] = {
["cooldown"] = 1711713900,
},
["color"] = {
["quiver"] = {
},
["herb"] = {
},
["normal"] = {
},
["soul"] = {
},
["leather"] = {
},
["mine"] = {
},
["gem"] = {
},
["inscribe"] = {
},
["reagent"] = {
},
["engineer"] = {
},
["key"] = {
},
["tackle"] = {
},
["fridge"] = {
},
["enchant"] = {
},
["account"] = {
},
},
}

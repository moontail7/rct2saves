
BigDebuffsDB = {
["profileKeys"] = {
["Skeeboo - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Whitemane"] = "Default",
["Poisongrace - Shadowstrike (AU)"] = "Default",
["Boof - Arugal"] = "Default",
["Fuccwit - Whitemane"] = "Default",
["Logoutnow - Shadowstrike (AU)"] = "Default",
["Squishcow - Shadowstrike (AU)"] = "Default",
["Gopea - Arugal"] = "Default",
["Creditfraud - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Skull Rock"] = "Default",
["Raasclaat - Skull Rock"] = "Default",
["Fuccwit - Bigglesworth"] = "Default",
["Lavy - Shadowstrike (AU)"] = "Default",
["Adadadad - Skull Rock"] = "Default",
["Rightclicker - Skull Rock"] = "Default",
["Emz - Shadowstrike (AU)"] = "Default",
["Falseclaimin - Shadowstrike (AU)"] = "Default",
["Bumboclaat - Shadowstrike (AU)"] = "Default",
["Poisongrace - Maladath (AU)"] = "Default",
},
["profiles"] = {
["Default"] = {
["nameplates"] = {
["enemyAnchor"] = {
["y"] = -15,
["x"] = 73,
["size"] = 20,
},
},
},
},
}


TotemTimers_GlobalSettings = nil
TotemTimers_Profiles = nil


WT_ShowIgnoreNotice = true
WT_ShowLearnedNotice = true
